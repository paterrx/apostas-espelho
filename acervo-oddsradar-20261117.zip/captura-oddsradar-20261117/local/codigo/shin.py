"""Devig Shin (1993) para mercados de duas vias.

Shin corrige o viés de favorito-azarão do devig proporcional. Sem ele o
favorito sai caro e o azarão sai barato — exatamente o viés que apareceu
na base antiga.
"""
import math


def shin(odds):
    """odds: [over, under] decimais. Devolve (p_over, p_under, z)."""
    pi = [1.0 / o for o in odds]
    S = sum(pi)
    if S <= 1.0:
        return pi[0] / S, pi[1] / S, 0.0

    def f(z):
        acc = 0.0
        for p in pi:
            acc += (math.sqrt(z * z + 4 * (1 - z) * p * p / S) - z) / (2 * (1 - z))
        return acc - 1.0

    lo, hi = 0.0, 0.3
    if f(lo) * f(hi) > 0:
        # shin nao converge: cai para proporcional
        return pi[0] / S, pi[1] / S, 0.0
    for _ in range(80):
        mid = (lo + hi) / 2
        if f(lo) * f(mid) <= 0:
            hi = mid
        else:
            lo = mid
    z = (lo + hi) / 2
    p = [(math.sqrt(z * z + 4 * (1 - z) * x * x / S) - z) / (2 * (1 - z)) for x in pi]
    t = sum(p)
    return p[0] / t, p[1] / t, z


def margem(odds):
    return sum(1.0 / o for o in odds) - 1.0


if __name__ == "__main__":
    for par in ([1.91, 1.91], [1.77, 2.10], [1.20, 5.00], [3.00, 1.372]):
        po, pu, z = shin(par)
        print(par, "margem %.2f%%" % (margem(par) * 100), "p_over %.4f" % po, "justa %.3f" % (1 / po), "z %.4f" % z)
