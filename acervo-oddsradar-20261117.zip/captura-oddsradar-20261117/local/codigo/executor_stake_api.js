// Executor STAKE por GraphQL — roda na aba de stake.com e NÃO clica em nada.
//
// Por que assim: a API de conta da Stake existe (POST /_api/v1/graphql,
// header x-access-token) e é o mesmo caminho que o site usa. A aba serve só de
// transporte: ela carrega o cookie de Cloudflare e a origem, que a casa exige.
// O que a API resolve sozinha: resolver a partida, achar o mercado/resultado,
// cravar e conferir no extrato — sem depender de layout.
//
// A escrita é barrada por IP (`locationBanned`, "We do not operate in this
// country"). Leitura passa do IP da VPS; aposta precisa da saída do PC do dono
// (relé 127.0.0.1:1081 → túnel). Quando a saída não está viva o item volta como
// `sem_saida`, que é gate reavaliado, nunca recusa.
//
// O token NÃO mora aqui: o injetor troca __STAKE_TOKEN__ pelo valor do cofre.
(function () {
  if (window.__execStakeApi) clearInterval(window.__execStakeApi.t);
  var PONTE = "__PONTE__";
  var TOKEN = "__PAINEL_TOKEN__";
  var STAKE_TOKEN = "__STAKE_TOKEN__";
  var GQL = "/_api/v1/graphql";
  var MEU = crypto.randomUUID();
  var VER = "stake-api-v1";
  var CAP = 6;
  var SALDO_MIN = 20;
  var TOL_CAIU = 0.94;     // abaixo disto o preço andou: devolve preco_caiu
  var TOL_ESCOLHE = 0.97;  // margem mínima para aceitar o resultado achado
  var MOEDA = "usdc";
  var ocupado = false, ocupadoDesde = 0, feitas = 0, rodada = Date.now();

  function espera(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function fch(u, o, ms) {
    var c = new AbortController(), t = setTimeout(function () { c.abort(); }, ms || 12000);
    return fetch(u, Object.assign({}, o || {}, { signal: c.signal })).then(function (r) {
      clearTimeout(t); return r;
    }, function (e) { clearTimeout(t); throw e; });
  }

  function ponte(caminho, corpo, ms) {
    return fch(PONTE + caminho, {
      method: corpo ? "POST" : "GET",
      headers: { "X-Painel-Token": TOKEN, "Content-Type": "application/json" },
      body: corpo ? JSON.stringify(corpo) : undefined
    }, ms || 8000);
  }

  async function responde(chave, estado, detalhe, betId) {
    var corpo = { chave: chave, estado: estado, detalhe: detalhe, quando: new Date().toISOString() };
    if (betId) corpo.bet_id = betId;
    try { await ponte("/resultado", corpo, 6000); } catch (e) {}
    return { chave: chave, estado: estado, detalhe: detalhe };
  }

  async function gql(query, variables) {
    var res = await fch(GQL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-access-token": STAKE_TOKEN },
      body: JSON.stringify({ query: query, variables: variables || {} })
    }, 15000);
    var txt = await res.text();
    var j = null;
    try { j = JSON.parse(txt); } catch (e) {}
    return { status: res.status, json: j, texto: txt };
  }

  function erroDe(j) {
    if (!j || !j.errors || !j.errors.length) return null;
    var e = j.errors[0];
    return (e.errorType || "") + "|" + (e.message || "");
  }

  function norm(s) {
    return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
  }

  function numero(s) {
    var m = String(s === undefined || s === null ? "" : s).replace(",", ".").match(/-?\d+(?:\.\d+)?/);
    return m ? parseFloat(m[0]) : null;
  }

  function saldo() {
    return gql("query B { user { balances { available { amount currency } } } }").then(function (r) {
      if (!r.json || !r.json.data || !r.json.data.user) return null;
      var b = (r.json.data.user.balances || []).filter(function (x) {
        return x.available && x.available.currency === MOEDA;
      })[0];
      return b ? Number(b.available.amount) : null;
    }, function () { return null; });
  }

  // ---------- resolução do item -> outcomeId ----------

  function candidatos(grupos, item) {
    var alvoMercado = norm(item.mercado);
    var jogador = norm(item.jogador);
    var lado = norm(item.lado);
    var linha = numero(item.linha !== "" ? item.linha : item.aposta);
    var achados = [];
    (grupos || []).forEach(function (g) {
      (g.templates || []).forEach(function (t) {
        (t.markets || []).forEach(function (m) {
          var textoMercado = norm((m.name || "") + " " + (t.name || "") + " " + (g.name || ""));
          if (alvoMercado && textoMercado.indexOf(alvoMercado) < 0) return;
          // o jogador pode estar no nome do mercado (basquete) ou só no resultado
          // ("Luan Peres 1+" no futebol): checa o mercado e, se não estiver lá,
          // exige no resultado.
          var jogadorNoMercado = !jogador || textoMercado.indexOf(jogador) >= 0;
          if (jogador && !jogadorNoMercado) {
            var temJogador = (m.outcomes || []).some(function (o) {
              return o.active && norm(o.name).indexOf(jogador) >= 0;
            });
            if (!temJogador) return;
          }
          (m.outcomes || []).forEach(function (o) {
            if (!o.active) return;
            var nome = norm(o.name);
            if (jogador && !jogadorNoMercado && nome.indexOf(jogador) < 0) return;
            // lado só filtra quando o resultado realmente traz over/under; prop de
            // futebol ("1+", "2+") não traz, e exigir o lado mataria a linha.
            var nomeTemLado = /^(over|under|mais|menos)/.test(nome);
            if (nomeTemLado && (lado === "over" || lado === "mais")) {
              if (nome.indexOf("over") !== 0) return;
            } else if (lado === "under" || lado === "menos") {
              if (nomeTemLado && nome.indexOf("under") !== 0) return;
              if (!nomeTemLado && jogadorNoMercado) return;
            } else if (!nomeTemLado) {
              // vencedor/handicap: o lado traz a seleção ("Coritiba -0.5").
              // Fica só o nome do time; a linha já é comparada abaixo.
              var mando = norm(item.lado_nome || item.aposta || item.selecao || item.time || "");
              mando = mando.replace(/\s*\(?-?\d+(?:\.\d+)?\)?$/, "").trim();
              if (mando && nome.indexOf(mando) < 0) return;
            }
            if (linha !== null) {
              var nLinha = numero(nome);
              if (nLinha === null || Math.abs(Math.abs(nLinha) - Math.abs(linha)) > 0.26) return;
            }
            var odd = Number(o.odds || 0);
            if (!odd) return;
            achados.push({ id: o.id, odd: odd, nome: o.name, mercado: m.name || t.name, grupo: g.name });
          });
        });
      });
    });
    achados.sort(function (a, b) {
      return Math.abs(a.odd - Number(item.odd || 0)) - Math.abs(b.odd - Number(item.odd || 0));
    });
    return achados;
  }

  async function achaResultado(item) {
    var f = await gql("query F($f: String!) { slugFixture(fixture: $f) { id name } }", { f: item.slug });
    var erro = erroDe(f.json);
    if (erro) return { erro: erro };
    var fx = f.json && f.json.data && f.json.data.slugFixture;
    if (!fx) return { erro: "partida nao achada" };
    // grupos sem filtro não trazem prop: o grupo de jogador tem de ser pedido
    // pelo nome, e é o único caminho para mercado de prop. O nome do grupo muda
    // com o esporte ("players" no futebol e no basquete perto do jogo,
    // "playerProps" no basquete pré-jogo medido antes): pede os dois e junta.
    var g = await gql(
      "query G($id: String!, $f: String!) { sportFixture(fixtureId: $id) { groups { name templates { name markets { name specifiers outcomes { id name odds active } } } } } p1: slugFixture(fixture: $f) { group: groups(groups: [\"players\"]) { name templates { name markets { name specifiers outcomes { id name odds active } } } } } p2: slugFixture(fixture: $f) { group: groups(groups: [\"playerProps\"]) { name templates { name markets { name specifiers outcomes { id name odds active } } } } } }",
      { id: fx.id, f: item.slug }
    );
    erro = erroDe(g.json);
    if (erro) return { erro: erro };
    var base = (g.json.data.sportFixture && g.json.data.sportFixture.groups) || [];
    var props = (g.json.data.p1 && g.json.data.p1.group) || [];
    props = props.concat((g.json.data.p2 && g.json.data.p2.group) || []);
    var lista = candidatos(base.concat(props), item);
    if (!lista.length) return { erro: "linha nao encontrada", fixture: fx.name };
    return { escolha: lista[0], fixture: fx.name };
  }

  // ---------- crava ----------

  var MUT = "mutation SportBetMutation($amount: Float!, $currency: CurrencyEnum!, $outcomeIds: [String!]!, $oddsChange: SportOddsChangeEnum!, $identifier: String, $betType: SportBetTypeEnum!) { sportBet(amount: $amount, currency: $currency, outcomeIds: $outcomeIds, oddsChange: $oddsChange, identifier: $identifier, betType: $betType) { id amount currency payoutMultiplier outcomes { odds outcome { name } } } }";

  async function confirma(id) {
    for (var i = 0; i < 6; i++) {
      await espera(1200);
      var r = await gql("query A($l: Int!) { user { activeSportBets(limit: $l, offset: 0) { id active amount currency bet { iid } outcomes { odds } } } }", { l: 10 });
      var bets = (r.json && r.json.data && r.json.data.user && r.json.data.user.activeSportBets) || [];
      var achada = bets.filter(function (b) { return b.id === id; })[0];
      if (achada) return achada;
      if (bets.length) {
        // sem o id, casa pela última aposta ativa do mesmo preço
        var casada = bets.filter(function (b) {
          return b.active && (b.outcomes || []).some(function (o) { return Number(o.odds) > 0; });
        })[0];
        if (casada) return casada;
      }
    }
    return null;
  }

  async function crava(item) {
    var chave = item.chave;
    if (!item.slug || !item.mercado) return responde(chave, "sem_mapa", item.aposta || "sem slug/mercado");
    var s = await saldo();
    if (s === null) return responde(chave, "sem_saldo", "saldo ilegivel");
    if (s < SALDO_MIN) return responde(chave, "saldo_baixo", String(s));
    var stake = Math.floor(Math.min(Number(item.stake_final || item.stake || 0), s - 1));
    if (stake < 1) return responde(chave, "sem_saldo", String(s));

    var achado = await achaResultado(item);
    if (achado.erro === "linha nao encontrada") {
      // a primeira consulta depois de injetar pode voltar vazia: repete uma vez
      await espera(800);
      achado = await achaResultado(item);
    }
    if (achado.erro) return responde(chave, achado.erro === "partida nao achada" ? "sem_mapa" : "suspenso", achado.erro);
    var alvo = achado.escolha;
    if (alvo.odd < Number(item.odd || 0) * TOL_CAIU) {
      return responde(chave, "preco_caiu", alvo.odd + " < " + item.odd);
    }
    if (alvo.odd < Number(item.odd || 0) * TOL_ESCOLHE) {
      return responde(chave, "suspenso", "odd " + alvo.odd + " fora da margem");
    }

    var ident = "hermes-" + chave.replace(/[^a-z0-9]+/gi, "-").slice(0, 40) + "-" + Date.now();
    var r = await gql(MUT, {
      amount: stake, currency: MOEDA, outcomeIds: [alvo.id],
      oddsChange: "any", identifier: ident, betType: "sports"
    });
    var erro = erroDe(r.json);
    if (erro) {
      // barreira de IP: leitura passa, escrita não. Gate, não recusa.
      if (erro.indexOf("locationBanned") >= 0) return responde(chave, "sem_saida", "IP sem cobertura");
      if (/DUPLICATE|already/i.test(erro)) return responde(chave, "repetida", erro.slice(0, 80));
      if (/odds|price|suspended|not active|unavailable/i.test(erro)) {
        return responde(chave, "preco_caiu", erro.slice(0, 90));
      }
      return responde(chave, "recusada", erro.slice(0, 120));
    }
    var bet = r.json && r.json.data && r.json.data.sportBet;
    if (!bet || !bet.id) return responde(chave, "suspenso", "resposta sem id");
    var conf = await confirma(bet.id);
    feitas++;
    return responde(chave, "feita", stake + " @ " + (bet.payoutMultiplier ? bet.payoutMultiplier : alvo.odd) +
      " (" + alvo.mercado + ")", (conf && conf.bet && conf.bet.iid) || bet.id);
  }

  async function ciclo() {
    if (ocupado && Date.now() - ocupadoDesde > 120000) ocupado = false;
    if (Date.now() - rodada > 600000) { feitas = 0; rodada = Date.now(); }
    if (ocupado || feitas >= CAP) return;
    ocupado = true; ocupadoDesde = Date.now();
    try {
      var fila = await (await ponte("/fila?casa=stake", null, 8000)).json();
      fila = (fila || []).filter(function (i) { return (i.casa || "").toLowerCase() === "stake"; });
      fila.sort(function (a, b) { return Number(b.ev || 0) - Number(a.ev || 0); });
      for (var i = 0; i < fila.length && feitas < CAP; i++) {
        if (fila[i].casa) fila[i].casa = "Stake";
        try { await crava(fila[i]); } catch (e) { await responde(fila[i].chave, "erro", String(e).slice(0, 120)); }
        await espera(300);
      }
    } catch (e) {}
    finally { ocupado = false; }
    var p = document.getElementById("exec-stake-api-pill");
    if (p) p.textContent = "executor stake API: " + feitas + " · " + new Date().toLocaleTimeString("pt-BR");
  }

  window.__execStakeApi = { t: setInterval(ciclo, 9000), ciclo: ciclo, crava: crava,
    achaResultado: achaResultado, saldo: saldo, candidatos: candidatos };
  var d = document.getElementById("exec-stake-api-pill") || document.createElement("div");
  d.id = "exec-stake-api-pill";
  d.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:99999;background:#111;color:#0f0;font:12px monospace;padding:6px 10px;border-radius:6px;border:1px solid #0f0";
  d.textContent = "executor stake API " + VER;
  if (!d.parentNode) document.body.appendChild(d);
  "ok";
})()
