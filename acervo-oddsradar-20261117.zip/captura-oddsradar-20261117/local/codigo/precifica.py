"""Justa de uma linha de prop, reaproveitável pelos produtores de fila.

Mesma matemática do `preco.py` (devig Shin na própria linha, interpolação só
linha com linha, ajuste de nível quando o sharp cota uma linha só, e a maior
justa entre fontes), mas em função: o produtor precisa precificar dezenas de
linhas do mesmo jogo sem chamar o feed uma vez por linha.

Cache por (fixture, prop, jogador): o `mercados` do fontes já traz a escada
inteira, então a primeira linha paga a requisição e as vizinhas saem do cache.
"""
import json, os, time

import estatistica
import fontes
import shin

_CACHE = {}
VALIDADE = 300  # 5 min


def _chave_cache(fx, prop, jog):
    return (fx, prop, fontes.norm(jog))


def _escadas(fx, torneio, prop, jog, media_alvo):
    k = _chave_cache(fx, prop, jog)
    v = _CACHE.get(k)
    if v and time.time() - v[0] < VALIDADE:
        return v[1]
    dados = fontes.mercados([fx], torneio, prop=prop, media_alvo=media_alvo,
                            sobrenome_alvo=fontes.sobrenome(jog))
    sob = fontes.sobrenome(jog)
    out = []
    for b, jogadores in dados.items():
        for nome, linhas in jogadores.items():
            if sob not in fontes.norm(nome):
                continue
            pts = []
            for linha, par in sorted(linhas.items()):
                if not par.get("over") or not par.get("under"):
                    continue
                po, _pu, _ = shin.shin([par["over"], par["under"]])
                pts.append((linha, po))
            if pts:
                out.append({"book": b, "pts": pts})
    _CACHE[k] = (time.time(), out)
    return out


def justa_prop(prop, jogador, linha, lado, fx, torneio):
    """Devolve (justa, n_fontes, ajustada) ou None.

    justa é a MAIOR odd justa entre as fontes (o preço mais conservador).
    """
    media_alvo = None
    try:
        est = estatistica.prob(prop, linha, lado, jogador, None)
        media_alvo = est.get("media")
    except Exception:
        est = {}
    cand, ajustada, fontes_ok = [], False, 0
    for item in _escadas(fx, torneio, prop, jogador, media_alvo):
        pts = item["pts"]
        p = fontes.p_em(pts, linha)
        if p is None and len(pts) == 1:
            l_sharp, p_sharp = pts[0]
            try:
                p_alvo = estatistica.p_over(prop, linha, jogador, None)
                p_s = estatistica.p_over(prop, l_sharp, jogador, None)
            except Exception:
                p_alvo = p_s = None
            if p_alvo is not None and p_s is not None:
                p = min(max(p_sharp + (p_alvo - p_s), 0.02), 0.98)
                ajustada = True
        if p is None:
            continue
        if lado == "under":
            p = 1 - p
        if p <= 0.001:
            continue
        fontes_ok += 1
        cand.append(1 / p)
    if est.get("odd"):
        cand.append(est["odd"])
    if not cand:
        return None
    if not fontes_ok:
        ajustada = True
    return max(cand), fontes_ok, ajustada


def varrer_props(fx, torneio, props):
    """props: [{"jogador","prop","linha","lado","odd"}] -> acrescenta justa/ev.

    Devolve só as que passam o piso da escada de confiança, com o fator de
    stake calculado. O corte de preço é do chamador (o painel manda no piso de
    odd); aqui não se julga stake em reais.
    """
    saida = []
    for p in props:
        r = justa_prop(p["prop"], p["jogador"], p["linha"], p["lado"], fx, torneio)
        if not r:
            continue
        justa, n, ajustada = r
        odd = float(p["odd"] or 0)
        if odd <= 1:
            continue
        ev = (odd / justa - 1) * 100
        if n >= 2:
            minimo, fator = 3.0, 1.0
        elif n == 1:
            minimo, fator = 5.0, 0.5
        else:
            minimo, fator = 8.0, 0.5
        if ajustada:
            fator = min(fator, 0.5)
        if ev < minimo:
            continue
        q = dict(p)
        q.update({"justa": round(justa, 3), "ev": round(ev, 2), "fontes_justa": n,
                  "stake": round(2.0 if n < 2 else 8.0, 2)})
        if ajustada:
            q["ajustada"] = True
        saida.append(q)
    return saida
