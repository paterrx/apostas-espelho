// Executor HERITAGE — um item por vez. Quem abre a página e injeta é o
// `roda_heritage.py` (a navegação recarrega o documento e mataria um laço aqui).
//
// A tela é Angular e roda no frame do provedor (ppm.heritage.linepros.com), onde
// o preço sai em odd AMERICANA (+404 / -242): converte para decimal antes de
// comparar. Item em `window.__itemHeritage`:
//   mercado      = título do bloco no site ("Match Result (3-way)", "Total"...)
//   tipo_escolha = 3way | lado | linha | total
//   escolha      = casa | fora | empate | mais | menos
//   linha        = valor da linha (o sinal é do lado `casa`)
// Preço em `.odd [class*=value]`; bilhete em `.bet-input-selected input` (RISK).
(function () {
  var PONTE = "http://127.0.0.1:8788";
  var MIN_STAKE = 2;      // mínimo de operação; recusa abaixo disso volta como abaixo_min
  var item = window.__itemHeritage || {};
  window.__fimHeritage = null;

  function espera(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function norm(s) {
    return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
  }
  function num(s) {
    var v = parseFloat(String(s).replace(/[^\d.,+-]/g, "").replace(/,(?=\d{3}\b)/g, ""));
    return isNaN(v) ? null : v;
  }
  // a casa fala odd americana; o item é decimal. +116 -> 2,16 | -144 -> 1,694
  function dec(a) {
    if (a === null) return null;
    return a > 0 ? 1 + a / 100 : 1 + 100 / Math.abs(a);
  }
  // Folga de preco: o painel cota ~2% acima da tela (medido: 1,847 x 1,806;
  // 2,89 x 2,83 em 17/11). Sem folga, todo item morre como preco_caiu. 2,5% e o
  // limite em que o EV mediano (6,3%) ainda sobrevive.
  function tolerancia() { return Number(item.odd || 0) * 0.025; }

  function fim(estado, detalhe) {
    window.__fimHeritage = { chave: item.chave, estado: estado, detalhe: detalhe,
                             stake_aceito: estado === "feita" ? window.__stakeHeritage : undefined };
    fetch(PONTE + "/resultado", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chave: item.chave, estado: estado, detalhe: detalhe,
                             stake_aceito: estado === "feita" ? window.__stakeHeritage : undefined })
    }).catch(function () {});
    return estado + " " + detalhe;
  }
  // o título do bloco muda com o esporte e o provedor renomeia sem avisar: além
  // do que veio no item, tenta os sinônimos do mesmo tipo (Handicap/Spread/Puck
  // Line são a mesma coisa; só muda o nome na tela).
  // apelidos por TIPO e por esporte: Draw No Bet (empate anula) não é o mesmo
  // contrato de Moneyline/Game Winner (prorrogação entra), então não se misturam.
  function apelidos(tipo) {
    var e = norm(item.esporte || "");
    if (tipo === "linha") return ["Handicap", "Spread", "Puck Line", "Point Spread"];
    if (tipo === "total") return ["Total", "Game Total", "Match Total"];
    if (tipo === "3way") return ["Match Result (3-way)", "Match Result", "1X2"];
    if (tipo === "lado") {
      return e === "football" ? ["Draw No Bet"] : ["Game Winner", "Match Winner", "Moneyline"];
    }
    return [];
  }
  function painel(alvo) {
    var a = norm(alvo);
    return [].slice.call(document.querySelectorAll(".panel")).filter(function (p) {
      var t = (p.innerText || "").split("\n")[0];
      return norm(t) === a;
    })[0] || null;
  }
  function painelDoItem() {
    var nomes = [item.mercado].concat(apelidos(item.tipo_escolha));
    for (var i = 0; i < nomes.length; i++) {
      var p = painel(nomes[i]);
      if (p) return p;
    }
    return null;
  }
  function rotulo(o) {
    // o rótulo nem sempre tem `.odd-label` (total usa texto solto): o primeiro
    // texto do elemento é o rótulo e a última linha é o preço.
    var e = o.querySelector(".odd-label");
    var t = e ? (e.textContent || "") : ((o.innerText || "").split("\n")[0] || "");
    return norm(t);
  }
  function precoDe(o) {
    var e = o.querySelector(".emphasis") || o.querySelector("[class*=value]") ||
      o.querySelector("span:last-child");
    return dec(num(e ? e.textContent : ""));
  }
  function pareceTime(nome, alvo) {
    if (!nome || !alvo) return false;
    var n = 0;
    while (n < nome.length && n < alvo.length && nome[n] === alvo[n]) n++;
    return n >= 4;
  }
  function temLinha(txt, linha) {
    var alvo = Math.abs(parseFloat(String(linha).replace(",", ".")));
    if (isNaN(alvo)) return false;
    // token exato: "2.5 / 3" é outro contrato e não pode casar com 2.5 por pedaço
    var nums = (txt || "").match(/\d+(?:\.\d+)?/g) || [];
    return nums.length === 1 && Math.abs(parseFloat(nums[0]) - alvo) < 0.001;
  }
  // acha o preço certo dentro do bloco. Casa antes de fora e "Over" antes de
  // "Under"; na linha o rótulo traz só o número assinado.
  function achaOdd(p) {
    var tipo = item.tipo_escolha, esc = item.escolha;
    var ods = [].slice.call(p.querySelectorAll(".odd"));
    if (!ods.length) return null;
    if (tipo === "3way") {
      if (esc === "empate") {
        return ods.filter(function (o) { return /^(draw|empate)/.test(rotulo(o)); })[0] || null;
      }
      var t = norm(item.time);
      return ods.filter(function (o) { return t && pareceTime(rotulo(o), t); })[0] || null;
    }
    if (tipo === "lado") {
      var t2 = norm(item.time);
      var porNome = ods.filter(function (o) { return t2 && pareceTime(rotulo(o), t2); })[0];
      if (porNome) return porNome;
      return ods[{ casa: 0, fora: 1 }[esc]] || null;
    }
    if (tipo === "total") {
      var quer = esc === "mais" ? "over" : "under";
      return ods.filter(function (o) {
        var r = rotulo(o);
        return r.indexOf(quer) === 0 && temLinha(r, item.linha);
      })[0] || null;
    }
    if (tipo === "linha") {
      // o sinal é da PRÓPRIA seleção (nos dois lados: painel e tela). Não inverter:
      // o painel chega a trocar quem é casa ("Tsuen Wan x Seven Up" no painel,
      // "Seven Up vs Tsuen Wan" no site), e inverter pegava o time errado.
      var quer2 = String(item.linha || "").charAt(0);
      return ods.filter(function (o) {
        var r = rotulo(o);
        return r.charAt(0) === quer2 && temLinha(r, item.linha);
      })[0] || null;
    }
    return null;
  }
  // teto da linha vem escrito no bilhete ("Max amount: $25.00"): liga pequena
  // corta bem abaixo da unidade e a casa recusa acima dele
  function maximo() {
    var m = (document.body.innerText || "").match(/Max amount:?\s*\$?\s*([\d.,]+)/i);
    if (!m) return null;
    var t = m[1].replace(/(?<=\d),(?=\d{3})/g, "");
    var v = num(t);
    return v && v > 0 ? v : null;
  }
  // o outro lado da MESMA linha: quando o painel inverte casa/fora, o sinal do
  // item aponta para a linha certa e o time errado. O bilhete decide.
  function irmao(o) {
    var r = rotulo(o);
    var m = r.match(/-?\d+(?:\.\d+)?/);
    if (!m) return null;
    var pai = o.parentElement;
    var ods = [].slice.call(pai.querySelectorAll(".odd"));
    if (ods.length < 2 && pai.parentElement) ods = [].slice.call(pai.parentElement.querySelectorAll(".odd"));
    return ods.filter(function (x) {
      return x !== o && rotulo(x).charAt(0) !== r.charAt(0) && temLinha(rotulo(x), m[0]);
    })[0] || null;
  }
  function boleto() { return document.querySelector(".bet-slip"); }
  // seleção de verdade é `.bet-list .bet` (o `span.bet-slip-item` é só o rótulo
  // "Bet slip" do cabeçalho e contava 1 sempre)
  function itens() { return document.querySelectorAll(".bet-list .bet").length; }
  function campoStake() { return document.querySelector(".bet-input-selected input"); }
  function precoSlip() {
    var it = document.querySelector(".bet-list .bet");
    if (!it) return null;
    var e = it.querySelector(".bet-odd-value__odds") || it.querySelector(".emphasis");
    var m = (e ? (e.textContent || "") : (it.innerText || "")).match(/([+-]\d{3,4})/);
    return m ? dec(num(m[1])) : null;
  }
  // números com sinal colado ("+2.5", "-2.5"); compara valor, não pedaço de texto
  function tokenAssinado(txt, num, querSinal) {
    var toks = (txt || "").match(/[+-]\d+(?:\.\d+)?/g) || [];
    var alvo = parseFloat(num);
    return toks.some(function (x) {
      if (parseFloat(x.slice(1)) !== alvo) return false;
      return querSinal ? x.charAt(0) === querSinal : true;
    });
  }
  function tokenDepoisDe(txt, palavra, num) {
    var pos = (txt || "").indexOf(palavra);
    if (pos < 0) return false;
    var depois = (txt || "").slice(pos + palavra.length, pos + palavra.length + 14);
    var m = depois.match(/\d+(?:\.\d+)?/);
    return !!m && parseFloat(m[0]) === parseFloat(num);
  }
  function selecaoConfere(exigeTime) {
    var it = document.querySelector(".bet-list .bet");
    if (!it) return false;
    var s = norm(it.innerText || "");
    var ln = String(item.linha || "").replace(",", ".");
    var num = ln.replace(/^[+-]/, "");
    if (num && item.tipo_escolha === "linha") {
      // o número tem de vir com o MESMO sinal do item (não 12.5 por 2.5, nem lado trocado)
      if (!tokenAssinado(s, num, ln.charAt(0))) return false;
    }
    if (num && item.tipo_escolha === "total") {
      var quer = item.escolha === "mais" ? "over" : "under";
      if (!tokenDepoisDe(s, quer, num)) return false;
    }
    // o texto do bilhete começa pela liga ("israel national league|..."), então o
    // time tem de ser procurado em QUALQUER posição, por um pedaço dele — não
    // comparado como prefixo do texto inteiro.
    // fora do total o time é obrigatório, mas o nome difere entre painel e site
    // ("Gargzdai SC" x "Gargždu"): 4 letras bastam, e quando nem isso casa a
    // seleção é aceita pelo número e o item é marcado (o número é que decide a linha)
    if (item.tipo_escolha !== "total") {
      var t = norm(item.time);
      if (!t) return false;
      var pedaco = t.slice(0, Math.min(4, t.length));
      var torto = s.indexOf(pedaco) < 0;
      window.__timeTorto = torto;
      if (torto) return false;                 // sem identidade não envia
    }
    return true;
  }
  function toggleFreePlay() {
    // "Use Free Play balance": o free play não devolve a stake, então é ele que
    // queima primeiro; sem marcar, o dinheiro do depósito é que sai.
    var alvo = [].slice.call(document.querySelectorAll("label,button,span,div")).filter(function (e) {
      return e.children.length <= 1 && /use free play/i.test((e.textContent || "").trim());
    })[0];
    if (!alvo) return false;
    var pai = alvo.closest("label,button,.checkbox,[class*=free]") || alvo;
    var marcado = /active|checked|selected/i.test((pai.className || "") + " " + (alvo.className || ""));
    if (marcado) return true;
    (pai.click ? pai : alvo).click();
    return true;
  }
  function preenche(v) {
    var i = campoStake() || [].slice.call(document.querySelectorAll("input[type=number]")).filter(function (x) {
      return x.offsetParent;
    })[0];
    if (!i) return false;
    var set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    i.focus(); set.call(i, String(v));
    i.dispatchEvent(new Event("input", { bubbles: true }));
    i.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  function contaApostas() {                        // "My Bets (N)": recibo da casa
    var m = ((document.querySelector(".bet-slip") || {}).innerText || "").match(/My Bets \((\d+)\)/);
    return m ? parseInt(m[1], 10) : null;
  }
  function botao() {
    // só botão VISÍVEL dentro do boleto: um <a> "Place bet" do cabeçalho casava
    // primeiro e mandava o clique para o lugar errado
    var re = /submit all bets|place bet|accept (new|changed) odds/i;
    var dentro = document.querySelector(".bet-slip--body") || document.querySelector(".bet-slip");
    var lista = dentro ? [].slice.call(dentro.querySelectorAll("button")) : [];
    for (var i = 0; i < lista.length; i++) {
      if (re.test(lista[i].textContent || "") && lista[i].getBoundingClientRect().width > 0) return lista[i];
    }
    var todos = [].slice.call(document.querySelectorAll("button"));
    for (var j = 0; j < todos.length; j++) {
      var q = todos[j].getBoundingClientRect();
      if (re.test(todos[j].textContent || "") && q.width > 0 && todos[j].offsetParent) return todos[j];
    }
    return null;
  }
  async function limpa() {
    var montou = false;
    for (var w = 0; w < 10; w++) {              // bilhete pode ainda não ter montado
      // `.bet-slip` some quando o boleto está aberto (vira `--body`): qualquer um
      // dos dois (ou a própria lista) serve para dizer que o componente montou
      if (document.querySelector(".bet-slip, .bet-slip--body, .bet-list")) { montou = true; break; }
      await espera(300);
    }
    if (!montou) return false;                  // DOM vazio não é "bilhete limpo"
    // o bilhete persiste entre cargas (é serviço + storage): item antigo sobrevive
    // à navegação e, se ficar, a seleção deste item vira 2 no boleto.
    for (var volta = 0; volta < 2; volta++) {
      var alvo = [].slice.call(document.querySelectorAll(".bet-list button.bet__remove, button.bet__remove"));
      alvo.forEach(function (b) { try { b.click(); } catch (e) {} });
      for (var i = 0; i < 4; i++) {
        await espera(250);
        if (itens() === 0) return true;
      }
    }
    return itens() === 0;
  }
  function saldo() {
    var m = (document.body.innerText || "").match(/AVAILABLE\s*\n?\s*\$?\s*([\d.,]+)/i);
    var v = m ? num(m[1]) : null;
    if (v !== null && v >= 0 && v < 1000000) {
      fetch(PONTE + "/saldo", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ casa: "heritage", saldo: v }) }).catch(function () {});
    }
    return v;
  }

  (async function () {
    if (!item.mercado) return fim("sem_mapa", "sem mercado");
    if (!(await limpa())) return fim("boleto_sujo", "boleto nao limpou");
    var s = saldo();
    var pedido = Number(item.stake_final || item.stake || 0);
    if (!isFinite(pedido) || pedido <= 0) return fim("abaixo_min", "stake invalida: " + item.stake_final + "/" + item.stake);
    var stake = Math.floor(pedido);
    if (stake < MIN_STAKE) stake = MIN_STAKE;          // piso da casa, não do pedido
    if (s !== null && s > 0 && stake > s) stake = Math.floor(s);
    var teto = maximo();
    if (teto !== null && teto < stake) stake = Math.floor(teto);
    if (stake < MIN_STAKE) return fim("abaixo_min", "nao cabe o minimo (teto " + teto + " saldo " + s + ")");
    var p = null;
    for (var w = 0; w < 20; w++) {          // o bloco monta depois do cabeçalho
      p = painelDoItem();
      if (p) break;
      await espera(300);
    }
    if (!p) return fim("sem_mapa", "mercado fora da tela: " + item.mercado);
    var o = achaOdd(p);
    if (!o) return fim("suspenso", "linha nao achada: " + item.mercado + " " + item.linha + " " + item.escolha);
    var preco = precoDe(o);
    if (preco === null) return fim("suspenso", "sem preco no mercado");
    if (preco < Number(item.odd) - tolerancia()) return fim("preco_caiu", preco.toFixed(3) + " < " + item.odd);
    if (item.sonda) return fim("sonda", "preco " + preco.toFixed(3) + " " + item.mercado + " " + (item.linha || ""));
    // clica o candidato, confere o TIME no bilhete e, se o painel inverteu o
    // mando, troca pelo outro lado da mesma linha antes de seguir
    var cands = [o], ir = irmao(o);
    if (ir) cands.push(ir);
    var escolhido = null, reserva = null;
    for (var ci = 0; ci < cands.length; ci++) {
      var pc = precoDe(cands[ci]);
      if (pc === null || pc < Number(item.odd) - tolerancia()) continue;
      cands[ci].click();
      await espera(2200);
      if (itens() === 1 && selecaoConfere(true)) { escolhido = cands[ci]; preco = pc; window.__timeTorto = false; break; }
      if (itens() === 1 && !reserva) reserva = { o: cands[ci], preco: pc };   // só a linha casou
      if (itens() > 0) await limpa();
      await espera(400);
    }
    if (!escolhido && reserva) {
      // nenhum lado trouxe o nome do painel: fica o que casa a linha, marcado
      reserva.o.click();
      await espera(2200);
      if (itens() === 1 && selecaoConfere(true)) { escolhido = reserva.o; preco = reserva.preco; }
      else if (itens() > 0) await limpa();
    }
    if (!escolhido) {
      await limpa();
      return fim("suspenso", "selecao nao fixou: " + item.mercado + " " + (item.linha || "") + " " + (item.time || ""));
    }
    // o teto só existe DEPOIS da seleção no bilhete: reler aqui e cortar
    var teto2 = maximo();
    if (teto2 !== null && teto2 < stake) stake = Math.floor(teto2);
    if (stake < MIN_STAKE) { await limpa(); return fim("abaixo_min", "teto da linha " + teto2); }
    var comFp = toggleFreePlay();
    window.__stakeHeritage = stake;                    // só aqui, já cortado
    window.__fpHeritage = comFp;
    if (!preenche(stake)) { await limpa(); return fim("suspenso", "campo de stake nao montou"); }
    await espera(900);
    // daqui pra frente a aposta pode estar em voo: desconhecido nao pode virar
    // estado retentavel, senao a fila crava a mesma linha duas vezes.
    for (var t = 0; t < 3; t++) {
      // render pode ter somado seleção ou trocado o boleto depois da montagem:
      // reconta e reconfere imediatamente antes de enviar
      if (itens() !== 1) { var qtd = itens(); await limpa(); return fim("aceite_pendente", qtd + " selecoes antes do envio"); }
      if (!selecaoConfere(true)) { await limpa(); return fim("aceite_pendente", "selecao trocou"); }
      var sf = campoStake();
      if (!sf || num(sf.value) !== stake) {
        preenche(stake); await espera(600);
        sf = campoStake();
        if (!sf || num(sf.value) !== stake) { await limpa(); return fim("aceite_pendente", "stake nao fixou"); }
      }
      var ps = precoSlip();
      if (ps === null) { await limpa(); return fim("aceite_pendente", "boleto sem preco"); }
      if (ps < Number(item.odd) - tolerancia()) {
        var voltou = ps;
        await limpa();
        return fim("aceite_pendente", "preco do boleto em " + voltou.toFixed(3));
      }
      if (/LOG IN/.test(document.body.innerText || "") &&
          !document.querySelector("[data-testid=account-button]")) {
        await limpa(); return fim("sem_login", "sessao caiu antes do envio");
      }
      var bt = botao();
      if (!bt) { await limpa(); return fim("aceite_pendente", "sem botao de confirmar"); }
      // a referência pode ficar órfã num re-render do Angular: medir só depois de
      // reconsultar o DOM, senão o rect vem zerado e o clique cai em 0,0
      await espera(200);
      if (/log ?in/i.test(bt.textContent || "")) { await limpa(); return fim("sem_login", "boleto pede login"); }
      window.__enviadoHeritage = true;
      var apostasAntes = contaApostas();
      if (window.__traco) window.__traco.push({f:"antes", bt:(bt.textContent||"").trim().slice(0,30), stake:stake, itens:itens(), ps:preco});
      // "Place bet" ignora element.click(): o laço dá um clique real por CDP usando
      // estas coordenadas. Se ele não vier em 3 s, cai no sintético (pode não cravar).
      // o botão pode estar fora da dobra ou o boleto recolhido: abrir e centralizar
      // antes de medir (rect zerado manda o clique para 0,0)
      try {
        var corpoSlip = document.querySelector(".bet-slip--body");
        if (!corpoSlip || !corpoSlip.offsetParent) {
          var tg = document.querySelector(".bet-slip-top__toggler-button");
          if (tg) { tg.click(); await espera(500); }
        }
        bt.scrollIntoView({ block: "center" });
        await espera(300);
      } catch (e) {}
      bt = botao() || bt;
      var qb = bt.getBoundingClientRect();
      if (qb.width === 0) { await espera(300); bt = botao() || bt; qb = bt.getBoundingClientRect(); }
      window.__cliqueFeito = false;
      window.__cliqueHeritage = { x: Math.round(qb.x + qb.width / 2), y: Math.round(qb.y + qb.height / 2) };
      for (var wc = 0; wc < 15 && !window.__cliqueFeito; wc++) await espera(200);
      window.__cliqueHeritage = null;
      // o app aceita o click sintético (foi assim que as apostas saíram); o clique
      // real do laço fica como reforço, não como substituto
      bt.click();
      var decidido = false;
      for (var k = 0; k < 12 && !decidido; k++) {
        await espera(700);
        var corpo = document.body.innerText || "";
        if (window.__traco) window.__traco.push({f:"depois", itens:itens(), clique:!!window.__cliqueFeito, fim:corpo.slice(-160).split(String.fromCharCode(10)).join(" | ")});
        if (/bet (has been|has) (placed|accepted)|bets (have been|have) placed|bet placed|bet accepted|aposta (efetuada|realizada)/i.test(corpo)) {
          // recibo sem a aposta consumida ainda é incerto: aguarda o bilhete esvaziar
          for (var z = 0; z < 6 && itens() > 0; z++) await espera(400);
          if (itens() > 0) { return fim("aceite_pendente", "recibo sem aposta consumida"); }
          await espera(300);
          // publica o aceite antes de mexer na tela: limpeza que falhe não pode
          // rebaixar resultado já decidido
          var detalheFeita = "stake " + stake + " @ " + preco.toFixed(3) + (window.__fpHeritage ? " fp?" : " caixa") +
            (window.__timeTorto ? " time?" : "") +
            " (" + item.mercado + " " + (item.time || "") + " " + (item.linha || "") + ")";
          var r = fim("feita", detalheFeita);
          try { await limpa(); } catch (e) {}
          return r;
          // (código abaixo mantido para leitura antiga)
          return fim("feita", "stake " + stake + " @ " + preco.toFixed(3) + (window.__fpHeritage ? " fp?" : " caixa") +
                     (window.__timeTorto ? " time?" : "") +
                     " (" + item.mercado + " " + (item.time || "") + " " + (item.linha || "") + ")");
        }
        // recibo objetivo: o contador "My Bets (N)" subiu = a casa aceitou esta
        var agoraConta = contaApostas();
        if (apostasAntes !== null && agoraConta !== null && agoraConta > apostasAntes) {
          var detC = "stake " + stake + " @ " + preco.toFixed(3) + (window.__fpHeritage ? " fp?" : " caixa") +
                     " (" + item.mercado + " " + (item.time || "") + " " + (item.linha || "") + ") recibo " +
                     apostasAntes + ">" + agoraConta;
          var rC = fim("feita", detC);
          try { await limpa(); } catch (e) {}
          return rC;
        }
        var noBoleto = ((document.querySelector(".bet-list") || {}).innerText || "") + " " +
                       ((document.querySelector(".bet-slip--body") || {}).innerText || "");
        // texto de minimo no corpo pode ser sobra da tentativa anterior: so vale
        // como recusa se o bilhete ficou vazio NESTA tentativa
        if (itens() === 0 && /minimum (bet|stake)|minimum of/i.test(noBoleto)) {
          var av = noBoleto.match(/[^.\n]*(minimum|minimum of)[^.\n]*/i);
          await limpa();
          return fim("aceite_pendente", "aviso de minimo no boleto: " + (av ? av[0] : "").slice(0, 80));
        }
        if (/suspended|suspens|line has changed|odds have changed/i.test(corpo)) {
          await limpa(); return fim("aceite_pendente", "mercado suspenso/linha mudou");
        }
        if (itens() === 0 && /placed|accepted/i.test(corpo)) decidido = true;
      }
      if (!decidido) break;
    }
    // aposta consumida sem texto de recibo na tela: o bilhete só esvazia quando a
    // casa aceita (ou quando limpamos, o que não é o caso aqui)
    // seleção desaparecida sem recibo não prova aceite (o componente também
    // desmonta em redirect e em rejeição): fica incerto
    await limpa();
    return fim("aceite_pendente", "bilhete vazio sem recibo");
  })().catch(function (e) {
    // sucesso já decidido não pode virar pendente por causa da limpeza
    if (window.__fimHeritage && window.__fimHeritage.estado === "feita") return;
    // depois do envio, exceção é aposta possivelmente em voo: incerta, não terminal;
    // antes do envio nada foi apostado: volta pela fila
    var est = window.__enviadoHeritage ? "aceite_pendente" : "suspenso";
    fim(est, (window.__enviadoHeritage ? "excecao apos envio: " : "excecao antes do envio: ") + String(e).slice(0, 120));
  });
  "ok";
})()
