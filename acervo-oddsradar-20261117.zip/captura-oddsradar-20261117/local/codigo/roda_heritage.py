"""Executor da HERITAGE por CDP: abre o evento, injeta o `executor_heritage.js`
com o item e recolhe o resultado.

Casa de tela: a aposta acontece na DOM do site, então cada item é uma página
diferente e a injeção morre na navegação — o JS executa UM item por carga e quem
manda é este processo. A tela de preço é um frame próprio do provedor
(ppm.heritage.linepros.com); navegar direto nele funciona e evita lidar com
frame cross-origin.

Pré-requisitos: Edge já subido pelo `abre_stake_api.py --com-tunel` (perfil
`edge-saida`, atrás do relé residencial) e sessão logada na Heritage.

Uso:
  python roda_heritage.py                 # laço, 1 item por vez
  python roda_heritage.py --sonda CHAVE   # localiza a linha e diz o preço, sem clique
  python roda_heritage.py --uma           # processa no máximo um item e sai
"""
import json
import os
import re
import sys
import time
import urllib.request

import websockets.sync.client as wsc

PONTE = "http://127.0.0.1:8788"
CDP = "http://127.0.0.1:9223"
AQUI = os.path.dirname(os.path.abspath(__file__))
JS = os.path.join(AQUI, "executor_heritage.js")
CAP_CICLO = 6
ESPERA_CARGA = 25      # s até o evento ter mercado
TELA = "https://ppm.heritage.linepros.com/live/?skin=dark#!/event/%s"


def _get(caminho, metodo="GET"):
    r = urllib.request.Request(CDP + caminho, method=metodo)
    with urllib.request.urlopen(r, timeout=15) as resp:
        return json.loads(resp.read() or b"{}")


_TAB = {}


def _aba():
    """Reusa sempre a MESMA aba: com duas abertas, escolher a primeira da lista
    pode cair na aba que a pessoa está usando e ser navegada por baixo."""
    if _TAB.get("id"):
        for t in _get("/json"):
            if t.get("id") == _TAB["id"]:
                return t
    for t in _get("/json"):
        if "heritage.linepros.com" in (t.get("url") or "") or "heritagesports.eu" in (t.get("url") or ""):
            _TAB["id"] = t.get("id")
            return t
    t = _get("/json/new", "PUT")
    _TAB["id"] = t.get("id")
    with wsc.connect(t["webSocketDebuggerUrl"], max_size=2 ** 25) as ws:
        ws.send(json.dumps({"id": 1, "method": "Page.navigate", "params": {"url": TELA % ""}}))
        ws.recv()
    time.sleep(6)
    for t in _get("/json"):
        if "heritage.linepros.com" in (t.get("url") or ""):
            _TAB["id"] = t.get("id")
            return t
    raise SystemExit("aba da Heritage nao abriu")


def _ev(ws_id, expr):
    ws, ident = ws_id
    ws.send(json.dumps({"id": ident, "method": "Runtime.evaluate",
                        "params": {"expression": expr, "awaitPromise": True, "returnByValue": True}}))
    while True:
        m = json.loads(ws.recv())
        if m.get("id") == ident:
            r = m.get("result", {})
            if r.get("exceptionDetails"):
                return "EXC " + str(r["exceptionDetails"].get("text"))[:120]
            return r.get("result", {}).get("value")


def _abre(aba, item):
    evento = str(item.get("evento") or "")
    if not evento.isdigit():
        return "sem_mapa", "evento invalido: " + evento[:20], None
    url = TELA % evento
    with wsc.connect(aba["webSocketDebuggerUrl"], max_size=2 ** 25) as ws:
        ident = [10]

        def ev(expr):
            ident[0] += 1
            return _ev((ws, ident[0]), expr)

        ws.send(json.dumps({"id": 1, "method": "Page.navigate", "params": {"url": url}}))
        while True:
            nav = json.loads(ws.recv())
            if nav.get("id") == 1:
                break
        if nav.get("error") or (nav.get("result") or {}).get("errorText"):
            return "sem_mapa", "navegacao falhou: " + str(nav.get("error") or nav["result"]["errorText"])[:60], None
        # a rota é hash: navegar de dentro do mesmo documento troca o endereço e
        # deixa a tela antiga montada (e `reload` sozinho volta na home). Passar por
        # about:blank garante documento novo, que é o que a SPA precisa para montar
        # o evento; medido: sem isso 0 painel, com isso 11.
        time.sleep(0.4)
        ws.send(json.dumps({"id": 2, "method": "Page.navigate", "params": {"url": "about:blank"}}))
        while True:
            rl = json.loads(ws.recv())
            if rl.get("id") == 2:
                break
        time.sleep(0.4)
        ws.send(json.dumps({"id": 3, "method": "Page.navigate", "params": {"url": url}}))
        while True:
            rl = json.loads(ws.recv())
            if rl.get("id") == 3:
                break
        t0 = time.time()
        pronto = False
        while time.time() - t0 < ESPERA_CARGA:
            time.sleep(1.5)
            n = ev("document.querySelectorAll('.panel').length")
            if isinstance(n, int) and n >= 8:
                pronto = True
                break
        if not pronto:
            return "sem_mapa", "pagina sem mercado em %ds" % ESPERA_CARGA, None
        onde = str(ev("location.href") or "")
        # compara o ID exato: "/event/12" não pode passar por "/event/123"
        if not re.search(r"#!/event/%s(?:$|[/?&#])" % evento, onde):
            return "sem_mapa", "aba em outro evento: " + onde[-40:], None
        # sem sessão a tela abre, mas o bilhete pede login na hora de cravar
        if ev("var b=document.querySelector('.bet-slip'); !!b && /log ?in/i.test(b.innerText)") is True:
            return "sem_login", "aba da Heritage deslogada", None
        # daqui pra frente o JS pode já ter clicado: queda de CDP é aposta
        # possivelmente em voo, não falha de mapa
        try:
            ev("window.__itemHeritage = %s; window.__fimHeritage = null; 'ok'" % json.dumps(item))
            with open(JS, encoding="utf-8") as f:
                src = f.read()
            ev("(0, eval)(%s)" % json.dumps(src))
            t0 = time.time()
            clicado = False
            while time.time() - t0 < 80:   # sempre maior que o laço do JS
                time.sleep(0.6)
                # o botão de cravar só aceita evento confiável: quem clica é o laço
                if not clicado:
                    c = ev("window.__cliqueHeritage && JSON.stringify(window.__cliqueHeritage)")
                    if isinstance(c, str) and c.startswith("{"):
                        ck = json.loads(c)
                        # aba de fundo pode ter o renderizador ocioso e engolir o
                        # evento: trazer para a frente antes de clicar
                        ident[0] += 1
                        ws.send(json.dumps({"id": ident[0], "method": "Page.bringToFront"}))
                        while True:
                            if json.loads(ws.recv()).get("id") == ident[0]:
                                break
                        time.sleep(0.4)
                        for tp in ("mousePressed", "mouseReleased"):
                            ident[0] += 1
                            ws.send(json.dumps({"id": ident[0], "method": "Input.dispatchMouseEvent",
                                                "params": {"type": tp, "x": ck["x"], "y": ck["y"],
                                                           "button": "left", "clickCount": 1}}))
                            while True:
                                rr = json.loads(ws.recv())
                                if rr.get("id") == ident[0]:
                                    break
                        print("CLIQUE em", ck, "| resp:", rr.get("error") or (rr.get("result") or {}).get("errorText") or "ok")
                        time.sleep(1.5)
                        print("BOLETO:", str(ev("(document.querySelector('.bet-slip--body')||{}).innerText||'-'"))[:160].replace(chr(10)," | "))
                        print("TOPO:", str(ev("document.body.innerText.slice(0,240)"))[:200].replace(chr(10)," | "))
                        print("feito:", ev("window.__cliqueFeito = true; 'ok'"))
                        clicado = True
                r = ev("window.__fimHeritage && JSON.stringify(window.__fimHeritage)")
                if isinstance(r, str) and r.startswith("{"):
                    d = json.loads(r)
                    return d.get("estado"), d.get("detalhe"), d.get("stake_aceito")
        except Exception as e:
            return "aceite_pendente", "cdp caiu com item em voo: " + str(e)[:70], None
        return "aceite_pendente", "script sem resposta em 80 s", None


def _saida_viva():
    try:
        with open(os.path.join(AQUI, "saida-pc-estado.json"), encoding="utf-8") as f:
            est = json.load(f) or {}
        with open(os.path.join(AQUI, "regras.json"), encoding="utf-8") as f:
            limite_s = float((json.load(f) or {}).get("saida_pc_min") or 180)
        return float(est.get("ok_em") or 0) >= time.time() - limite_s
    except Exception:
        return False


def _fila():
    try:
        with urllib.request.urlopen(PONTE + "/fila?casa=heritage", timeout=10) as r:
            return [i for i in json.loads(r.read() or b"[]")
                    if "heritage" in str(i.get("casa") or "").lower()]
    except Exception as e:
        print("fila fora:", e)
        return []


def _papel():
    """True = papel, False = real, None = não sei. Devolver False quando a ponte
    não responde dava autorização com o modo desconhecido."""
    try:
        with urllib.request.urlopen(PONTE + "/modo", timeout=6) as r:
            v = json.loads(r.read() or b"{}").get("papel")
        return True if v is True else (False if v is False else None)
    except Exception:
        return None


def _resultado(chave, estado, detalhe, stake=None):
    """Grava o desfecho. Devolve True só com a ponte confirmando: sem isso o item
    fica pendente e seria apostado de novo — é o caminho de dupla cravação."""
    dados = {"chave": chave, "estado": estado, "detalhe": str(detalhe)[:180]}
    if stake:
        dados["stake_aceito"] = stake
    corpo = json.dumps(dados).encode()
    for tentativa in range(3):
        try:
            req = urllib.request.Request(PONTE + "/resultado", data=corpo,
                                         headers={"Content-Type": "application/json"})
            r = json.loads(urllib.request.urlopen(req, timeout=8).read() or b"{}")
            if r.get("ok"):
                return True
        except Exception:
            pass
        time.sleep(1 + tentativa)
    return False


TRAVA = os.path.join(AQUI, "roda-heritage.lock")


def _vivo(pid):
    try:
        import subprocess
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            "(Get-Process -Id %d -ErrorAction SilentlyContinue).Id" % pid],
                           capture_output=True, text=True, timeout=20)
        return str(pid) in (r.stdout or "")
    except Exception:
        return True


_LOCK = None


def _trava():
    """Uma instância só, com exclusão do SO: ler o pid e escrever depois não é
    atômico — duas partidas simultâneas leem vazio e as duas seguem. O lock fica
    aberto (e travado) até o processo morrer."""
    global _LOCK
    import msvcrt
    _LOCK = open(TRAVA, "a+")
    _LOCK.seek(0)
    try:
        msvcrt.locking(_LOCK.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        print("ja existe um roda_heritage rodando (lock preso)")
        raise SystemExit(0)
    _LOCK.seek(0)
    _LOCK.truncate()
    _LOCK.write(str(os.getpid()))
    _LOCK.flush()


def main():
    _trava()
    if "--sonda" in sys.argv:
        alvo = sys.argv[sys.argv.index("--sonda") + 1]
        fila = [i for i in _fila() if alvo in i.get("chave", "")] or _fila()
        if not fila:
            raise SystemExit("fila vazia de heritage")
        item = dict(fila[0], stake_final=1, sonda=True)
        print("item:", json.dumps(item, ensure_ascii=False)[:300])
        print("resultado:", _abre(_aba(), item)[:2])
        return
    uma = "--uma" in sys.argv
    while True:
        if _papel() is False and _saida_viva():
            fila = sorted(_fila(), key=lambda i: -float(i.get("ev") or 0))[:CAP_CICLO]
            if not fila and "--verboso" in sys.argv:
                print("sem item de heritage na fila")
            if fila:
                aba = _aba()
                for item in fila:
                    if os.path.exists(os.path.join(os.path.dirname(os.path.dirname(AQUI)),
                                                   "PARAR-APOSTAS.txt")) or _papel() is not False:
                        print("freio ou modo papel: parando o lote")
                        break
                    estado, detalhe, stake = _abre(aba, item)
                    print(time.strftime("%H:%M:%S"), estado, item.get("aposta", "")[:60], "|", detalhe)
                    # sem gravação o item continua pendente e seria apostado de novo:
                    # insiste só na gravação (a aposta pode já estar feita) e, se não
                    # houver ponte, segura a fila em vez de puxar item novo
                    gravou = _resultado(item.get("chave"), estado, detalhe, stake)
                    for _t in range(17):
                        if gravou:
                            break
                        time.sleep(10)
                        gravou = _resultado(item.get("chave"), estado, detalhe, stake)
                    # sem gravação a chave segue pendente: ficar SÓ na gravação até
                    # confirmar, sem voltar a adquirir fila (senão o mesmo item é
                    # servido e apostado de novo dentro da mesma execução)
                    while not gravou:
                        time.sleep(15)
                        gravou = _resultado(item.get("chave"), estado, detalhe, stake)
                    if uma and estado in ("feita", "sem_login"):
                        return
                    if estado in ("aceite_pendente", "sem_login"):
                        break
        if uma:
            return
        time.sleep(20)


if __name__ == "__main__":
    main()
