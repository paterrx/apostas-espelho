"""Fonte sharp via OddsPapi, com casamento de jogador e cruzamento de linha.

Regra de ouro: só se compara linha com linha. A justa de um lado na linha L
sai da curva do sharp avaliada em L, interpolada entre as linhas vizinhas
que ele realmente cotou — nunca misturando 12.5 de um lado com 13.5 do outro.
Entre sharps que cotam a mesma linha, vence a MAIOR odd justa (probabilidade
menor): o preço mais conservador.
"""
import itertools, json, math, os, re, time, unicodedata, urllib.request, urllib.parse

K = None


def _chave():
    """Le a chave na hora do uso: o cofre pode estar vazio (é reescrito quando o
    OpenBot reinicia) e o daemon nao pode morrer por isso no import."""
    import chaves
    k = chaves.do_ambiente("ODDSPAPI_API_KEY") or chaves.ler("ODDSPAPI_API_KEY")
    if not k:
        raise RuntimeError("ODDSPAPI_API_KEY ausente no cofre e no ambiente")
    return k
BASE = "https://api.oddspapi.io/v4"

SHARPS = ["pinnacle", "fanduel", "draftkings", "fanatics", "betmgm", "bet365"]
PROPS = {
    "points": "Over Under Player Points (incl. overtime)",
    "rebounds": "Over Under Player Rebounds (incl. overtime)",
    "assists": "Over Under Player Assists (incl. overtime)",
    "pra": "Over Under Player Points + Assists + Rebounds (incl. overtime)",
    "threes": "Over Under Player 3 Point FG (incl. overtime)",
    "steals": "Over Under Player Steals (incl. overtime)",
    "blocks": "Over Under Player Blocks (incl. overtime)",
    "stocks": "Over Under Player Steals + Blocks (incl. overtime)",
    "pts_ast": "Over Under Player Points + Assists (incl. overtime)",
    "pts_reb": "Over Under Player Points + Rebounds (incl. overtime)",
}
_PROP_POR_BOOK = {
    "pinnacle": {"points", "rebounds", "assists", "pra", "threes"},
    "fanduel": {"points", "rebounds", "assists", "pra", "threes", "steals", "blocks", "stocks", "pts_ast", "pts_reb"},
    "fanatics": {"points", "rebounds", "assists", "pra", "threes", "steals", "blocks", "stocks", "pts_ast", "pts_reb"},
    "draftkings": {"points", "rebounds", "assists", "pra", "threes", "steals", "blocks", "stocks", "pts_ast", "pts_reb"},
    "betmgm": {"points", "rebounds", "assists", "pra", "threes"},
    "bet365": set(PROPS),
}
# props de contagem: a escada de linhas comeca em 0,5
CONTAGEM = {"steals", "blocks", "stocks", "threes"}
_cache_mk = None


def _get(caminho):
    url = BASE + caminho + ("&" if "?" in caminho else "?") + "apiKey=" + urllib.parse.quote(_chave())
    for _ in range(4):
        try:
            r = urllib.request.urlopen(urllib.request.Request(url, headers={"Accept": "application/json"}), timeout=40)
            return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(json.loads(e.read()).get("error", {}).get("retryMs", 1000) / 1000 + 0.3)
                continue
            raise RuntimeError("HTTP %s em %s" % (e.code, caminho))
        except Exception:
            time.sleep(1.0)
    raise RuntimeError("falhou: " + caminho)


def _nome_market():
    global _cache_mk
    if _cache_mk is None:
        caminho = os.path.join(os.path.dirname(__file__), "markets_cache.json")
        if os.path.exists(caminho) and time.time() - os.path.getmtime(caminho) < 7 * 86400:
            _cache_mk = {str(k): v for k, v in json.load(open(caminho)).items()}
        else:
            mk = _get("/markets?sportId=11")
            _cache_mk = {str(m["marketId"]): m["marketName"] for m in mk}
            json.dump(_cache_mk, open(caminho, "w"))
    return _cache_mk


def norm(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    return " ".join(re.sub(r"[^a-z ]", " ", s).split())


def sobrenome(nome):
    return norm(nome).split()[-1] if norm(nome) else ""


def _pares_da_linha(por_slot, base=0.5):
    """por_slot: {slot: {jogador: preco}}. Devolve {slot: (indice, lado)} ou None.

    O indice e o posto na escada (0 = linha mais baixa); a linha final sai de
    `_linhas`, que ancora o indice na media do jogador quando ela existe —
    preco sozinho nao diz a linha.
    """
    slots = list(por_slot)
    n = len(slots)
    if n < 2 or n % 2 or n // 2 > 5:
        return None
    metade = n // 2
    jogadores = set().union(*[set(p) for p in por_slot.values()])
    melhor, score = None, 1e9
    for overs in itertools.combinations(slots, metade):
        unders = [s for s in slots if s not in overs]
        o = sorted(overs, key=lambda s: sum(por_slot[s].values()) / len(por_slot[s]))
        u = sorted(unders, key=lambda s: -sum(por_slot[s].values()) / len(por_slot[s]))
        sc = 0.0
        for so, su in zip(o, u):
            for j in jogadores:
                if j in por_slot[so] and j in por_slot[su]:
                    sc += abs(1 / por_slot[so][j] + 1 / por_slot[su][j] - 1.055)
        if sc < score:
            score, melhor = sc, (o, u)
    if melhor is None:
        return None
    o, u = melhor
    ms = [1 / por_slot[so][j] + 1 / por_slot[su][j] - 1
          for so, su in zip(o, u) for j in jogadores if j in por_slot[so] and j in por_slot[su]]
    if not ms or not all(0 < m < 0.20 for m in ms):
        return None
    out = {}
    for k, (so, su) in enumerate(zip(o, u)):
        out[so] = (k, "over")
        out[su] = (k, "under")
    return out


def _linha(indice, indice_ancora, media):
    """Converte o posto na escada em linha: ancora na media do jogador."""
    ancora = math.floor(media) + 0.5
    return ancora + (indice - indice_ancora)


def fixture_ids(tournament_id, casa, fora):
    """Todos os fixtures futuros do par (as vezes o mesmo jogo aparece duplicado)."""
    import datetime
    fx = _get(f"/fixtures?tournamentId={tournament_id}")
    agora = datetime.datetime.now(datetime.timezone.utc).isoformat()
    nc, nf = norm(casa), norm(fora)
    out = []
    for f in fx:
        p1 = norm(f.get("participant1Name") or "")
        p2 = norm(f.get("participant2Name") or "")
        if not p1 or not p2:
            continue
        par = ((nc in p1 or p1 in nc) and (nf in p2 or p2 in nf)) or \
              ((nc in p2 or p2 in nc) and (nf in p1 or p1 in nf))
        if par and f.get("statusId") == 0 and (f.get("startTime") or "") >= agora[:19]:
            out.append(f["fixtureId"])
    return out


def fixture_id(tournament_id, casa, fora):
    """Acha o fixture pelo par de participantes, preferindo jogo futuro nao iniciado."""
    import datetime
    fx = _get(f"/fixtures?tournamentId={tournament_id}")
    agora = datetime.datetime.now(datetime.timezone.utc).isoformat()
    nc, nf = norm(casa), norm(fora)

    def casa_ok(f):
        p1 = norm(f.get("participant1Name") or "")
        p2 = norm(f.get("participant2Name") or "")
        if not p1 or not p2:
            return False
        return ((nc in p1 or p1 in nc) and (nf in p2 or p2 in nf)) or \
               ((nc in p2 or p2 in nc) and (nf in p1 or p1 in nf))

    cand = [f for f in fx if casa_ok(f)]
    futuros = [f for f in cand if f.get("statusId") == 0 and (f.get("startTime") or "") >= agora[:19]]
    if futuros:
        return min(futuros, key=lambda f: f["startTime"])["fixtureId"]
    if cand:
        return max(cand, key=lambda f: f.get("startTime") or "")["fixtureId"]
    return None


def mercados(fixtures, tournament_id, books=SHARPS, prop=None, media_alvo=None, sobrenome_alvo=None):
    """{book: {jogador: {linha: {over, under}}}} para a prop pedida.

    media_alvo: media de 10 jogos do jogador alvo, usada para ancorar a linha
    dos mercados sem passo explicito. Sem ela a linha sai do chute a partir
    de 0,5 (e o CLI avisa).
    """
    alvo_ids = {fixtures} if isinstance(fixtures, str) else set(fixtures)
    mks = _nome_market()
    out = {b: {} for b in books}
    for b in books:
        if prop and prop not in _PROP_POR_BOOK.get(b, set()):
            continue
        try:
            dados = _get(f"/odds-by-tournaments?bookmaker={b}&tournamentIds={tournament_id}")
        except RuntimeError:
            continue
        if not isinstance(dados, list) or not dados:
            continue
        f = [x for x in dados if x.get("fixtureId") in alvo_ids]
        if not f:
            continue
        f = f[0]
        escada = {}   # jogador -> [(preco_medio, slot_a, slot_b)]

        for mid, m in (f.get("bookmakerOdds", {}).get(b, {}) or {}).get("markets", {}).items():
            nome = mks.get(str(mid), "")
            if prop and nome != PROPS.get(prop):
                continue
            if not prop and not nome.startswith("Over Under Player"):
                continue
            por_slot, explicito = {}, True
            for oid, o in m["outcomes"].items():
                for pl in o["players"].values():
                    if pl.get("active") is False or not pl.get("playerName"):
                        continue
                    bok = pl.get("bookmakerOutcomeId") or ""
                    if re.match(r"^-?[\d.]+/(over|under)$", bok):
                        chave = bok
                    else:
                        chave = oid
                        explicito = False
                    por_slot.setdefault(chave, {})[pl["playerName"]] = pl["price"]
            if explicito:
                for chave, jogadores in por_slot.items():
                    linha, lado = chave.split("/")
                    for jog, preco in jogadores.items():
                        out[b].setdefault(jog, {}).setdefault(float(linha), {})[lado] = preco
                continue
            # sem passo explicito: cada mercado e UMA linha; guarda os pares e
            # resolve linha e lado depois, com a media do jogador como ancora
            pares = _pares_da_linha(por_slot)
            if not pares:
                continue
            por_jog = por_jogador(por_slot, pares)
            for jog, precos in por_jog.items():
                if len(precos) != 2:
                    continue
                s1, s2 = [s for s, _ in sorted(precos.items(), key=lambda x: por_slot[x[0]].get(jog, 99))]
                if jog not in por_slot[s1] or jog not in por_slot[s2]:
                    continue
                medio = (por_slot[s1][jog] + por_slot[s2][jog]) / 2
                p_cheap = (1 / por_slot[s1][jog]) / ((1 / por_slot[s1][jog]) + (1 / por_slot[s2][jog]))
                escada.setdefault(jog, []).append((p_cheap, por_slot[s1][jog], por_slot[s2][jog]))
        if escada:
            resolvido = resolver_escada(escada, media_alvo, sobrenome_alvo)
            for jog, linhas in resolvido.items():
                for linha, reg in linhas.items():
                    # não sobrescreve linha explícita do mesmo book (era `out[b] =`)
                    out[b].setdefault(jog, {}).setdefault(linha, {}).update(reg)
    return out


def resolver_escada(escada, media_alvo=None, sobrenome_alvo=None):
    """Converte escadas de preco em {jogador: {linha: {over, under}}}.

    A ordem das linhas vem da probabilidade do lado barato: no degrau mais
    baixo o over e o mais provavel (p_cheap alto) e ela cai conforme a linha
    sobe. O degrau mais perto de 50/50 e a linha principal, ancorada na media
    do jogador; as linhas andam de 1 em 1 a partir dela.
    """
    out = {}
    for jog, pares in escada.items():
        pares.sort(key=lambda p: -p[0])
        m = media_alvo if (media_alvo and sobrenome_alvo and sobrenome_alvo in norm(jog)) else None
        if m:
            ancora = min(range(len(pares)), key=lambda i: abs(pares[i][0] - 0.5))
            base = math.floor(m) + 0.5 - ancora
        else:
            base = 0.5
        for i, (_, barato, caro) in enumerate(pares):
            linha = base + i
            if m is not None and linha < m:
                reg = {"over": barato, "under": caro}
            else:
                reg = {"over": caro, "under": barato}
            out.setdefault(jog, {})[linha] = reg
    return out


def _preco(par):
    return par[0]


def por_jogador(por_slot, cls):
    """{jogador: {slot: (indice, lado)}} a partir da classificacao do mercado."""
    out = {}
    for chave, (idx, lado) in cls.items():
        for jog in por_slot[chave]:
            out.setdefault(jog, {})[chave] = (idx, lado)
    return out


def precos_over(por_slot, cls, jog, indice):
    for chave, (idx, lado) in cls.items():
        if idx == indice and lado == "over" and jog in por_slot[chave]:
            return por_slot[chave][jog]
    return 2.0


def curva(pares):
    """[(linha, p_over)] ordenada por linha — só linhas com os dois lados."""
    return sorted((l, p) for l, p in pares)


def p_em(curva_pts, linha):
    """Interpola a probabilidade de over na linha pedida; None fora da faixa."""
    if not curva_pts:
        return None
    exato = [p for l, p in curva_pts if abs(l - linha) < 1e-9]
    if exato:
        return exato[0]
    abaixo = [(l, p) for l, p in curva_pts if l < linha]
    acima = [(l, p) for l, p in curva_pts if l > linha]
    if not abaixo or not acima:
        return None
    l0, p0 = abaixo[-1]
    l1, p1 = acima[0]
    return p0 + (p1 - p0) * (linha - l0) / (l1 - l0)