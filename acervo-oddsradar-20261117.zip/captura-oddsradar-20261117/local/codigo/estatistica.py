"""Odd estatistica a partir dos ultimos 10 jogos.

Camada de baixo: so entra quando o mercado nao tem duas sharps. Usa ESPN
(gamelog publico). A conta e binomial negativa (variancia livre), nunca
Poisson puro, porque roubo, block e rebote sao superdispersos: Poisson
subestima o miolo e superestima as caudas.

Regra de honestidade: a media dos 10 jogos e encolhida em direcao a media
de liga da prop (2 jogos ficticios) para nao cravar 3,4 roubos parceiros
de uma sequencia quente.

A saida e uma ODD, e ela sempre entra como a mais conservadora: quando ha
justa sharp, a justa final e a MAIOR das duas (a menor probabilidade).
"""
import json, math, re, time, unicodedata, urllib.parse, urllib.request

H = {"User-Agent": "Mozilla/5.0"}
ESPN = "https://site.api.espn.com/apis/site/v2/sports/basketball/nba"
ESPN_LOG = "https://site.web.api.espn.com/apis/common/v3/sports/basketball/nba/athletes/{}/gamelog"

# media de liga por jogo, usada como priors
PRIOR = {"points": 9.0, "rebounds": 4.3, "assists": 2.6, "threes": 1.2,
         "steals": 0.9, "blocks": 0.5, "stocks": 1.4, "pra": 16.0,
         "pts_ast": 11.6, "pts_reb": 13.3}
PESO_PRIOR = 2.0


def _g(url):
    return json.loads(urllib.request.urlopen(urllib.request.Request(url, headers=H), timeout=30).read())


def _norm(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    return " ".join(re.sub(r"[^a-z ]", " ", s).split())


def atleta(nome, time_abbr=None):
    """Acha o atleta no roster do time ou, sem time, pela busca da ESPN."""
    if not time_abbr:
        u = ("https://site.web.api.espn.com/apis/search/v2?type=player&limit=3&query="
             + urllib.parse.quote(nome))
        try:
            for bloco in _g(u).get("results", []):
                for c in bloco.get("contents", []):
                    if "nba" in (c.get("description") or "").lower():
                        return {"id": (c.get("uid") or "").split(":")[-1], "fullName": c.get("displayName")}
        except Exception:
            return None
        return None
    roster = _g(f"{ESPN}/teams/{time_abbr.lower()}/roster").get("athletes", [])
    alvo = _norm(nome)
    sob = alvo.split()[-1]
    cand = [a for a in roster if sob in _norm(a["fullName"])]
    if not cand:
        return None
    for a in cand:
        if _norm(a["fullName"]) == alvo or alvo.replace(",", "") .split()[0] in _norm(a["fullName"]):
            return a
    return cand[0]


def jogos(ath_id, n=10):
    d = _g(ESPN_LOG.format(ath_id))
    labels = [x.lower() for x in (d.get("names") or d.get("labels") or [])]
    ix = {l: i for i, l in enumerate(labels)}
    alias = {"minutes": "min", "points": "pts", "totalrebounds": "reb", "assists": "ast",
             "steals": "stl", "blocks": "blk", "threepointfieldgoalsmade-threepointfieldgoalsattempted": "3pt"}
    def idx(nome):
        for k in (nome, alias[nome]):
            if k in ix:
                return ix[k]
        return None
    c = [idx(n) for n in ("minutes", "points", "totalrebounds", "assists", "steals", "blocks",
                          "threepointfieldgoalsmade-threepointfieldgoalsattempted")]
    if any(x is None for x in c):
        return []
    out = []
    for st in d.get("seasonTypes", []):
        for cat in st.get("categories", []):
            for ev in cat.get("events", []):
                s = ev.get("stats") or []
                if len(s) <= max(c):
                    continue
                try:
                    tres = float(str(s[c[6]]).split("-")[0])
                except ValueError:
                    tres = 0.0
                try:
                    out.append({"min": float(s[c[0]]), "pts": float(s[c[1]]), "reb": float(s[c[2]]),
                                "ast": float(s[c[3]]), "stl": float(s[c[4]]), "blk": float(s[c[5]]), "t3": tres})
                except ValueError:
                    continue
    return out[:n]


def valores(jogos_, prop):
    mapa = {"points": ["pts"], "rebounds": ["reb"], "assists": ["ast"], "threes": ["t3"],
            "steals": ["stl"], "blocks": ["blk"], "stocks": ["stl", "blk"],
            "pra": ["pts", "reb", "ast"], "pts_ast": ["pts", "ast"], "pts_reb": ["pts", "reb"]}
    chaves = mapa[prop]
    return [sum(j[k] for k in chaves) for j in jogos_]


def nb_pmf(k, mu, var):
    if var <= mu * 1.000001:
        # Poisson pela via log: `mu ** k` e `factorial(k)` estouram acima de k~170
        return math.exp(-mu + k * math.log(mu) - math.lgamma(k + 1)) if mu > 0 else (
            1.0 if k == 0 else 0.0)
    p = mu / var
    r = mu * p / (1 - p)
    return math.exp(math.lgamma(k + r) - math.lgamma(r) - math.lgamma(k + 1) + r * math.log(p) + k * math.log(1 - p))


def media(nome, prop):
    """Media dos ultimos 10 jogos, sem precisar de time."""
    a = atleta(nome)
    if not a:
        return None
    js = jogos(a["id"], 10)
    v = valores(js, prop) if js else []
    return (sum(v) / len(v)) if v else None


def p_over(prop, linha, nome, time_abbr=None):
    """So a probabilidade de over na linha, para usar como inclinacao."""
    r = prob(prop, linha, "over", nome, time_abbr)
    return r.get("p")


def prob(prop, linha, lado, nome, time_abbr):
    """Devolve dict com p_over, odd justa, amostra e avisos."""
    a = atleta(nome, time_abbr)
    if not a:
        return {"erro": "atleta nao encontrado no roster"}
    todos = jogos(a["id"], 80)
    js = todos[:10]
    if len(js) < 5:
        return {"erro": "menos de 5 jogos na temporada", "jogos": len(js)}
    v = valores(js, prop)
    minutos = sum(j["min"] for j in js) / len(js)
    n = len(v)
    media = sum(v) / n
    # prior = media da propria temporada quando ha jogos suficientes; senao a de liga
    if len(todos) >= 15:
        centro = sum(valores(todos, prop)) / len(todos)
    else:
        centro = PRIOR[prop]
    mu = (media * n + centro * PESO_PRIOR) / (n + PESO_PRIOR)
    var = sum((x - media) ** 2 for x in v) / max(n - 1, 1)
    var = max(var, mu)
    inteira = abs(linha - round(linha)) < 1e-9
    k = int(round(linha))
    # o teto era fixo em 40 e em linha >= 39 o range saía vazio: p_over virava 0
    # e o under ia a 1,0 com justa 1,000. Topo acompanha mu e var.
    topo = max(k + 40, int(mu + 8 * math.sqrt(var) + 8))
    if inteira:  # linha inteira: igual a linha empurra
        p_over = sum(nb_pmf(i, mu, var) for i in range(k + 1, topo))
        p_under = sum(nb_pmf(i, mu, var) for i in range(0, k))
        empate = nb_pmf(k, mu, var)
        # aposta com push paga 1 em empate: a justa é condicional a não-empate
        if empate < 0.999:
            p_over, p_under = p_over / (1 - empate), p_under / (1 - empate)
    else:
        p_over = sum(nb_pmf(i, mu, var) for i in range(int(math.floor(linha)) + 1, topo))
        p_under = max(0.0, 1 - p_over)
        empate = 0.0
    p = p_over if lado == "over" else p_under
    avisos = []
    if minutos < 18:
        avisos.append("minutos baixos (%.0f)" % minutos)
    if n < 8:
        avisos.append("amostra curta")
    if media == 0:
        avisos.append("zerado nos 10 jogos")
    return {"p": p, "odd": (1 / p) if p > 0 else None, "media": media, "mu": mu, "var": var,
            "minutos": minutos, "n": n, "empate": empate, "avisos": avisos,
            "ultimos": v, "jogador": a["fullName"]}
