"""Executor Magic Markets — exchange de USDT, ordem por API.

Diferença para as casas: aqui é exchange. A ordem é um limite (só executa no
preço pedido ou melhor), a stake vai como par ["USDT", valor] e o `bet_type`
("ml,h", "ah,a,14") vem pronto do produtor — nunca se monta o texto.

Dois passos: POST /v2/betslips/ registra o interesse e devolve o id; POST
/v2/orders/ compromete dinheiro com preço-limite. Sem WebSocket aqui: a cotação
ao vivo chega pelo livro que o produtor já leu, e o limite é a odd do item.

Uso:
  python executor_magic.py            # uma rodada
  python executor_magic.py --loop 20
"""
import argparse, json, os, re, sys, time, uuid
import urllib.error
import urllib.request

import chaves
import magia
import saidas
import regras as regras_mod

AQUI = os.path.dirname(os.path.abspath(__file__))
PONTE = "http://127.0.0.1:8788"
BASE = "https://magicmarkets.com/v2"
def _chave():
    k = chaves.do_ambiente("MAGICMARKETS_API_KEY") or chaves.ler("MAGICMARKETS_API_KEY")
    if not k:
        raise RuntimeError("MAGICMARKETS_API_KEY ausente no cofre e no ambiente")
    return k
CASA = "Magic"
SALDO_MIN = 20
LIQ_VEZES = 1.3
CAP = 6
LOTE = 20
POSTAS = os.path.join(AQUI, "posts_magic.json")
DRY = "--dry" in sys.argv


def _cab():
    return {"X-Api-Key": _chave(), "Content-Type": "application/json",
            "accept": "application/json", "User-Agent": "Mozilla/5.0"}


def _req(metodo, caminho, corpo=None, ms=20000):
    dados = json.dumps(corpo).encode() if corpo is not None else None
    r = urllib.request.Request(BASE + caminho, data=dados, headers=_cab(), method=metodo)
    try:
        with saidas.abre(r, ms / 1000) as resp:
            return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        texto = e.read().decode("utf-8", "replace")
        try:
            return e.code, json.loads(texto)
        except Exception:
            return e.code, {"bruto": texto[:300]}


def _posta(modo):
    try:
        d = json.load(open(POSTAS, encoding="utf-8"))
    except Exception:
        d = {}
    corte = time.time() - 6 * 3600
    d = {k: v for k, v in d.items() if v > corte}
    if modo == "grava":
        json.dump(d, open(POSTAS, "w", encoding="utf-8"))
    return d


def responde(chave, estado, detalhe="", bet_id=""):
    corpo = {"chave": chave, "estado": estado, "detalhe": detalhe,
             "quando": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    if bet_id:
        corpo["bet_id"] = bet_id
    try:
        r = urllib.request.Request(PONTE + "/resultado", method="POST",
                                   data=json.dumps(corpo).encode(),
                                   headers={"Content-Type": "application/json"})
        urllib.request.urlopen(r, timeout=8).read()
    except Exception:
        pass


def saldo():
    try:
        return magia.saldo()
    except Exception:
        return None


def abertas():
    """Chaves (evento|bet_type) com ordem aberta: nao reordenar o mesmo livro."""
    try:
        st, d = _req("GET", "/orders/")
        saida = set()
        for o in (d.get("data") or []):
            if o.get("closed"):
                continue
            ev = (o.get("event_info") or {}).get("event_id") or ""
            saida.add("%s|%s" % (ev, o.get("bet_type") or ""))
        return saida
    except Exception:
        return set()


def _cotacao(bid):
    """Cotação do betslip. O preco de verdade vem daqui, nao do livro lido antes.

    A casa manda a cotacao no stream `pmm`; o proprio guia aceita ler em
    GET /betslips/{id}/. Sem cotacao, nao se inventa preco.
    """
    for _ in range(10):
        st, d = _req("GET", "/betslips/%s/" % bid)
        if st != 200:
            return None, st
        dados = d.get("data") or {}
        pl = dados.get("price_list") or []
        if pl:
            ef = (pl[0] or {}).get("effective") or {}
            if ef.get("price"):
                return ef, 200
        if dados.get("closed"):
            return None, 410
        time.sleep(0.7)
    return None, 0


def _abre_betslip(item, base_bt):
    st, d = _req("POST", "/betslips/", {"sport": "basket", "event_id": item["event_id"],
                                       "bet_type": "for," + base_bt, "betslip_type": "normal"})
    if st not in (200, 201):
        return None
    return ((d.get("data") or {}).get("betslip_id"))


LADO_ML = {"casa": "ml,h", "home": "ml,h", "fora": "ml,a", "away": "ml,a"}


def _prepara(item):
    """Completa `event_id`/`bet_type` dos itens que o painel manda.

    O produtor antigo ja mandava os dois; o stream do painel manda `href` e
    `chave_mercado`, entao o miolo e montado aqui. Mercado que nao sabemos
    escrever fica sem bet_type e cai em `sem_mapa` (sai da fila, nao trava).
    """
    if not item.get("event_id"):
        m = re.search(r"/(\d{4}-\d{2}-\d{2}),([^/?]+)", str(item.get("href") or ""))
        if m:
            # "data,slug,id1,id2" -> "data,id1,id2" (o slug nao entra na consulta)
            partes = m.group(2).split(",")
            if len(partes) >= 3 and partes[-1].isdigit() and partes[-2].isdigit():
                item["event_id"] = "%s,%s,%s" % (m.group(1), partes[-2], partes[-1])
    if item.get("bet_type") or not item.get("chave_mercado"):
        return
    if str(item.get("chave_mercado")).lower() == "jogo_1x2" and "·" not in str(item.get("mercado") or ""):
        item["bet_type"] = LADO_ML.get(str(item.get("lado") or "").lower())


FAMILIA_BT = {
    "jogo_gols_handicap": {"casa": "ah,h,", "home": "ah,h,", "fora": "ah,a,", "away": "ah,a,"},
    "jogo_pontos_handicap": {"casa": "ah,h,", "home": "ah,h,", "fora": "ah,a,", "away": "ah,a,"},
    "jogo_gols_total": {"mais": "ahover,", "over": "ahover,", "menos": "ahunder,", "under": "ahunder,"},
    "jogo_pontos_total": {"mais": "ahover,", "over": "ahover,", "menos": "ahunder,", "under": "ahunder,"},
}


def _bet_type_do_livro(item, livro):
    """Escolhe a linha no livro da exchange pela chave, nao pelo texto do painel."""
    pref = (FAMILIA_BT.get(str(item.get("chave_mercado") or "").lower()) or {}).get(
        str(item.get("lado") or "").lower())
    if not pref or not livro:
        return None
    m = re.search(r"([+-]?\d+(?:[.,]\d+)?)", str(item.get("linha") or item.get("aposta") or ""))
    alvo = float(m.group(1).replace(",", ".")) if m else None
    if alvo is None:
        # sem linha explícita: casa pelo preço do livro, não pela primeira chave
        # (a ordem do livro é arbitrária e a primeira linha podia ser outra)
        odd = float(item.get("odd") or 0)
        melhor, dist = None, 9e9
        for k in livro:
            if not k.startswith(pref):
                continue
            v = livro.get(k)
            b = (v.get("back") or [None])[0] if isinstance(v, dict) else None
            if not b:
                continue
            d = abs(float(b) - odd)
            if d < dist:
                melhor, dist = k, d
        return melhor
    melhor, dist = None, 99.0
    for k in livro:
        if not k.startswith(pref):
            continue
        if alvo is None:
            return k
        try:
            v = float(k.rsplit(",", 1)[1]) / 10.0
        except Exception:
            continue
        d = abs(v - alvo)
        if d < dist:
            melhor, dist = k, d
    return melhor if dist <= 0.55 else None


def crava(item, saldo_livre, em_aberto=None):
    """Devolve o estado final do item, pela ordem oficial: betslip, cotacao, ordem."""
    chave = item["chave"]
    _prepara(item)
    bet_type = item.get("bet_type")
    if not bet_type and item.get("event_id"):
        try:
            item["bet_type"] = _bet_type_do_livro(item, magia.livro("basket", item["event_id"]))
        except Exception:
            pass
        bet_type = item.get("bet_type")
    if not bet_type or not item.get("event_id"):
        return responde(chave, "sem_mapa", "sem bet_type/event_id")
    if chave in _posta("le"):
        return responde(chave, "repetida", "")
    bt = str(bet_type)
    base = bt.split(",", 1)[1] if bt.split(",", 1)[0] in ("for", "against") else bt
    if em_aberto and ("%s|for,%s" % (item.get("event_id"), base)) in em_aberto:
        return responde(chave, "adiada", "ja tem ordem aberta nesse livro")

    # linha exata e, se ela morreu, a vizinha mais proxima do mesmo lado (ate 3 pontos)
    tentativas = [base]
    vizinha = None
    try:
        livro = magia.livro("basket", item["event_id"])
        if base not in livro and "," in base:
            cabeca, cauda = base.rsplit(",", 1)
            alvo, dist = None, 99
            for k in livro:
                if not k.startswith(cabeca + ","):
                    continue
                try:
                    d = abs(float(k.rsplit(",", 1)[1]) - float(cauda))
                except Exception:
                    continue
                if d < dist:
                    vizinha, dist = k, d
            if vizinha and dist <= 30:
                tentativas.append(vizinha)
    except Exception:
        pass

    erro = "sem betslip"
    for base_t in tentativas:
        bid = _abre_betslip(item, base_t)
        if not bid:
            continue
        ef, st_cot = _cotacao(bid)
        if not ef:
            erro = "sem cotacao (%s)" % st_cot
            continue
        preco = float(ef.get("price") or 0)
        if not preco:
            erro = "cotacao sem preco"
            continue
        if preco < float(item["odd"]) * 0.94:
            return responde(chave, "preco_caiu", "%s < %s" % (preco, item["odd"]))
        stake = float(item.get("stake_final") or item.get("stake") or 0)
        if saldo_livre is not None:
            stake = min(stake, saldo_livre - 1)
        teto = ef.get("max")            # vem como ["USDT", valor] na maioria das vezes
        teto_linha = float(teto[1] if isinstance(teto, list) and len(teto) > 1 else (teto or 0))
        if teto_linha:
            stake = min(stake, teto_linha)
        stake = round(stake, 2)
        if stake < 1:
            return responde(chave, "sem_saldo", str(saldo_livre))
        if DRY:
            return responde(chave, "adiada", "dry %s @ %s (linha %s)" % (stake, preco, base_t))

        try:
            st, od = _req("POST", "/orders/", {
                "betslip_id": bid, "price": preco, "stake": ["USDT", stake], "duration": 10,
                "exchange_mode": "take_only", "accept_partial_fill": True,
                "accept_better_price": True, "request_uuid": str(uuid.uuid4()),
            })
        except Exception as e:
            # timeout/URLError depois do POST: antes subia e a rodada engolia sem
            # responde(). Confere se a ordem abriu antes de soltar a chave.
            try:
                aberta = "%s|for,%s" % (item.get("event_id"), base_t) in (abertas() or set())
            except Exception:
                aberta = False
            if aberta:
                return responde(chave, "adiada", "POST sem veredito; ordem aberta no livro")
            return responde(chave, "adiada", "POST sem veredito (%s)" % str(e)[:60])
        if st not in (200, 201):
            codigo = (od.get("error") or {}).get("code") or st
            return responde(chave, "erro_linha", str(codigo)[:80])
        oid = (od.get("data") or {}).get("order_id")
        for _ in range(12):
            time.sleep(1)
            _s, d = _req("GET", "/orders/%s/" % oid)
            o = d.get("data") or {}
            estado = str(o.get("status") or "").lower()
            casado = 0.0
            if isinstance(o.get("stake"), list):
                casado = float(o.get("stake")[1] or 0)
            if estado in ("done", "filled") or casado > 0 or (o.get("bets") or []):
                feito = _posta("le")
                feito[chave] = time.time()
                json.dump(feito, open(POSTAS, "w", encoding="utf-8"))
                return responde(chave, "feita", "%s @ %s (pedido %s, linha %s)" % (
                    casado or stake, o.get("price") or preco, preco, base_t), str(oid))
            if o.get("closed"):
                return responde(chave, "recusada", "ordem %s: %s" % (estado, o.get("close_reason") or "?"))
        return responde(chave, "adiada", "ordem aberta %s" % oid, str(oid))
    return responde(chave, "suspenso", erro)


def rodada():
    if regras_mod.regras().get("papel"):
        print("modo papel: nada a cravar")
        return
    fila = json.loads(urllib.request.urlopen(PONTE + "/fila?casa=magic", timeout=10).read())
    fila = [i for i in fila if str(i.get("casa")).lower() in (CASA.lower(), "magic markets")]
    fila.sort(key=lambda x: float(x.get("ev") or 0), reverse=True)
    s = (saldo() or {}).get("saldo")
    if s is not None:
        # a régua precisa do caixa da casa: sem isso o teto por casa usa 0
        try:
            urllib.request.urlopen(urllib.request.Request(
                PONTE + "/saldo", data=json.dumps({"casa": CASA, "saldo": round(s, 2)}).encode(),
                headers={"Content-Type": "application/json"}), timeout=8).read()
        except Exception:
            pass
    if s is None:
        print("saldo ilegivel, parando a rodada")
        return
    if s < SALDO_MIN:
        print("saldo baixo:", s)
        return
    feitas = 0
    em_aberto = abertas()
    for item in fila[:LOTE]:
        if feitas >= CAP or s < 1:
            break
        try:
            print(" ", item.get("chave"), "->", crava(item, s, em_aberto))
        except Exception as e:
            print("  erro:", e)
        feitas += 1
        time.sleep(0.05)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--loop", type=int, default=0)
    p.add_argument("--dry", action="store_true")
    a = p.parse_args()
    while True:
        print("rodada", time.strftime("%H:%M:%S"))
        try:
            rodada()
        except Exception as e:
            print("rodada falhou:", e)
        if not a.loop:
            break
        time.sleep(a.loop)


if __name__ == "__main__":
    main()
