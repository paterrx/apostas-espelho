// Executor STAKE — roda na aba da stake.com já logada.
// Diferente do executor da Cloudbet: a Stake não tem API de aposta com preço por
// mercado, então aqui se crava pela tela — abre a partida, expande o jogador,
// clica o lado certo, digita a stake e confirma. A ordem vem da ponte.
//
// Item da fila precisa de: chave, slug (último trecho da URL da partida),
// jogador, mercado (texto do mercado na tela, ex. "Points"), linha, lado
// (over/under), odd, stake e comeca. Sem slug ou sem mercado, devolve sem_mapa.
(function () {
  if (window.__execStake) clearInterval(window.__execStake.t);
  var PONTE = "http://127.0.0.1:8788";
  var MEU = crypto.randomUUID();
  var VER = "stake-v1";
  var CAP = 4;               // cap da rodada: lotes menores, rajada menos de robo
  var SALDO_MIN = 20;
  var LIMITE_TELA = 12;      // minutos para achar a linha antes de desistir
  var ocupado = false, ocupadoDesde = 0, feitas = 0, rodada = Date.now();

  function espera(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function fch(u, o, ms) {
    var c = new AbortController(), t = setTimeout(function () { c.abort(); }, ms || 12000);
    return fetch(u, Object.assign({}, o || {}, { signal: c.signal })).then(function (r) {
      clearTimeout(t); return r;
    }, function (e) { clearTimeout(t); throw e; });
  }
  async function responde(chave, estado, detalhe) {
    try {
      await fch(PONTE + "/resultado", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chave: chave, estado: estado, detalhe: detalhe, quando: new Date().toISOString() })
      }, 6000);
    } catch (e) {}
  }
  function saldo() {
    var m = document.body.innerText.match(/^([\d.,]+)\s*\nWallet/m);
    if (!m) return null;
    // o site mostra "498.00000000": ponto é decimal, vírgula é milhar
    var v = parseFloat(m[1].replace(/,/g, ""));
    return isNaN(v) ? null : v;
  }
  function minutosAte(item) {
    var c = item.comeca || "";
    var m = c.match(/(\d+)\s*h\s*(\d+)?/);
    if (m) return parseInt(m[1], 10) * 60 + (m[2] ? parseInt(m[2], 10) : 0);
    m = c.match(/(\d+)\s*(?:min|m)(?![a-z])/);
    if (m) return parseInt(m[1], 10);
    return null;
  }
  function norm(s) {
    return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
  }
  async function irPara(slug) {
    if (location.pathname.indexOf(slug) >= 0) return true;
    history.pushState({}, "", "/sports/basketball/" + slug);
    window.dispatchEvent(new PopStateEvent("popstate"));
    await espera(2500);
    return location.pathname.indexOf(slug) >= 0;
  }
  function normTxt(el) {
    return norm((el && el.textContent) || "").replace(/\s+/g, " ").trim();
  }
  function achaBotao(mercado, linha, lado, odd) {
    var linhaTxt = String(linha).replace(",", ".");
    var oddTxt = String(odd).replace(",", ".");
    var ladoTxt = lado === "under" ? "under" : "over";
    var alvoMercado = norm(mercado);
    var todos = [].slice.call(document.querySelectorAll("button"));
    // linha de jogo: o próprio botão carrega "Over 223.5"
    for (var i = 0; i < todos.length; i++) {
      if (normTxt(todos[i]) === ladoTxt + " " + linhaTxt) return todos[i];
    }
    // prop: o botão carrega lado + ODD ("Over 1.83"); linha e mercado estão no bloco
    for (var j = 0; j < todos.length; j++) {
      var b = todos[j];
      var tb = normTxt(b);
      if (tb !== ladoTxt && (!oddTxt || tb !== ladoTxt + " " + oddTxt)) continue;
      var pai = b.closest("[class*=svelte]");
      for (var n = 0; n < 8 && pai; n++) {
        var t = normTxt(pai);
        // bloco pequeno = a linha do mercado, não o contêiner da aba inteira
        if (t.length < 180 && t.indexOf(alvoMercado) >= 0 &&
            (t.indexOf(" " + linhaTxt + " ") >= 0 || t.indexOf(linhaTxt + " ") >= 0)) return b;
        pai = pai.parentElement;
      }
    }
    // sem linha explicitada: primeiro botão do mercado
    for (var k = 0; k < todos.length; k++) {
      var tb2 = normTxt(todos[k]);
      if (tb2 !== ladoTxt && (!oddTxt || tb2 !== ladoTxt + " " + oddTxt)) continue;
      var p2 = todos[k].parentElement;
      for (var m = 0; m < 6 && p2; m++) {
        if (normTxt(p2).indexOf(alvoMercado) >= 0 && normTxt(p2).length < 180) return todos[k];
        p2 = p2.parentElement;
      }
    }
    return null;
  }
  async function expandir(jogador) {
    var spans = document.querySelectorAll("span");
    for (var i = 0; i < spans.length; i++) {
      if (norm(spans[i].textContent) === norm(jogador) ||
          norm(spans[i].textContent).indexOf(norm(jogador)) === 0) {
        var h = spans[i];
        while (h && String(h.className).indexOf("header") < 0) h = h.parentElement;
        (h || spans[i]).dispatchEvent(new MouseEvent("click", { bubbles: true }));
        await espera(900);
        return true;
      }
    }
    return false;
  }
  function preenche(stake) {
    var i = document.querySelector("input[role=spinbutton], input[type=number]");
    if (!i) return false;
    var set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    i.focus(); set.call(i, String(stake));
    i.dispatchEvent(new Event("input", { bubbles: true }));
    i.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  async function crava(item) {
    var min = minutosAte(item);
    if (min !== null && (min < 5 || min > 360)) return responde(item.chave, "fora_janela", "comeca em " + min + " min");
    if (!item.slug || !item.mercado) return responde(item.chave, "sem_mapa", item.aposta || "");
    var s = saldo();
    if (s === null) return responde(item.chave, "sem_saldo", "saldo ilegivel");
    if (s < SALDO_MIN) return responde(item.chave, "saldo_baixo", String(s));
    var stake = Math.floor(Math.min(Number(item.stake_final || item.stake || 0), s - 1));
    if (stake < 1) return responde(item.chave, "sem_saldo", String(s));
    if (!(await irPara(item.slug))) return responde(item.chave, "sem_mapa", "nao abriu " + item.slug);
    // mercado pode estar em aba: prop mora em "Player Props", linha principal em "Popular"
    var radios = item.jogador ? ["Player Props"] : ["Popular", "All"];
    for (var r = 0; r < radios.length; r++) {
      var rb = [].slice.call(document.querySelectorAll("button[role=radio]"))
        .filter(function (x) { return x.textContent.trim() === radios[r]; })[0];
      if (rb) { rb.click(); await espera(1800); }
      if (item.jogador) { await expandir(item.jogador); await espera(1200); }
      var alvo = achaBotao(item.mercado, item.linha, item.lado, item.odd);
      if (alvo) {
        alvo.click();
        await espera(1200);
        if (!preenche(stake)) return responde(item.chave, "erro", "sem campo de stake");
        await espera(700);
        var pb = [].slice.call(document.querySelectorAll("button"))
          .filter(function (x) { return x.textContent.trim() === "Place Bet"; })[0];
        if (!pb || pb.disabled) return responde(item.chave, "erro", "Place Bet travado");
        pb.click();
        for (var t = 0; t < 10; t++) {
          await espera(800);
          var txt = document.body.innerText;
          if (/placed successfully|foi colocada com sucesso/i.test(txt)) {
            feitas++;
            return responde(item.chave, "feita", "stake " + stake + " @ " + item.odd);
          }
          if (/odds (have )?changed|odds mudaram|suspended|suspenso/i.test(txt)) {
            return responde(item.chave, "preco_caiu", "odd mudou na confirmacao");
          }
        }
        return responde(item.chave, "recusada", "sem confirmacao em 8 s");
      }
    }
    return responde(item.chave, "suspenso", "linha nao achada na tela");
  }
  async function modoPapel() {
    try { return (await (await fch(PONTE + "/modo", {}, 4000)).json()).papel === true; }
    catch (e) { return false; }
  }
  async function ciclo() {
    var dono = null;
    try { dono = JSON.parse(localStorage.getItem("execStake:dono") || "null"); } catch (e) {}
    if (dono && dono.id !== MEU && dono.t > rodada) { clearInterval(window.__execStake.t); return; }
    try { localStorage.setItem("execStake:dono", JSON.stringify({ id: MEU, t: Date.now() })); } catch (e) {}
    if (Date.now() - rodada > 600000) { feitas = 0; rodada = Date.now(); }
    if (ocupado && Date.now() - ocupadoDesde > 90000) ocupado = false;
    if (ocupado || feitas >= CAP) return;
    if (await modoPapel()) return;
    // ritmo humano: pula ~1 em 5 batidas, em vez de metronomo exato
    if (Math.random() < 0.2) return;
    ocupado = true; ocupadoDesde = Date.now();
    try {
      var fila = await (await fch(PONTE + "/fila", {}, 8000)).json();
      fila.sort(function (a, b) { return Number(b.ev || 0) - Number(a.ev || 0); });
      for (var i = 0; i < fila.length; i++) {
        if (feitas >= CAP) break;
        if (fila[i].casa && fila[i].casa.toLowerCase() !== "stake") continue;
        try { await crava(fila[i]); } catch (e) { await responde(fila[i].chave, "erro", String(e).slice(0, 120)); }
        await espera(400);
      }
    } catch (e) {} finally { ocupado = false; }
    var p = document.getElementById("exec-pill");
    if (p) p.textContent = "executor stake: " + feitas + " feitas · saldo " + saldo() + " · " + new Date().toLocaleTimeString("pt-BR");
  }
  window.__execStake = { t: setInterval(ciclo, 9000), ciclo: ciclo, crava: crava,
    achaBotao: achaBotao, expandir: expandir, saldo: saldo, minutosAte: minutosAte };
  var d = document.getElementById("exec-pill") || document.createElement("div");
  d.id = "exec-pill";
  d.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:99999;background:#111;color:#0f0;font:12px monospace;padding:6px 10px;border-radius:6px;border:1px solid #0f0";
  d.textContent = "executor stake ligado " + VER;
  if (!d.parentNode) document.body.appendChild(d);
  ciclo();
  "ok";
})()
