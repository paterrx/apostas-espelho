#!/usr/bin/env python3
"""Coleta o painel sem navegador e alimenta a ponte.

O navegador descarrega a aba do painel por inatividade e o vigia injetado morre
junto. Aqui a sessão é um cookie em disco e não existe aba: nada para cair.

Login: POST /api/auth/login e /api/auth/login-2fa com `confiarNavegador`. O
código de 6 dígitos entra por painel_codigo.txt (o código muda a cada 30 s, por
isso a espera é por arquivo novo, não por valor). Quando o cookie morre, o
processo para a coleta, pede código e volta sozinho.

Dois laços, os mesmos filtros dos vigias antigos:
  1. SSE do painel -> linhas com EV e justa -> POST /fila
  2. vencedor de jogo: justa das outras casas -> preço da Cloudbet -> POST /fila

Uso: python3 coleta_painel.py            (roda os dois laços)
     python3 coleta_painel.py --entrar   (só faz login e sai)
"""
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar

AQUI = os.path.dirname(os.path.abspath(__file__))
PAINEL = "https://crawler-odd-dashboard.hamjcl.easypanel.host"
PONTE = "http://127.0.0.1:8788"
CRED = os.path.join(AQUI, "painel_credenciais.json")
VAULT = os.path.join(os.environ.get("APPDATA", ""), "OpenBot", "agent-api-keys", ".vault",
                     "agent-9b86ddbd-18a4-46a9-8737-dcaff1941539")
CODIGO = os.path.join(AQUI, "painel_codigo.txt")
PEDIDO = os.path.join(AQUI, "coleta-pedido-2fa.txt")
COOKIES = os.path.join(AQUI, "painel-cookies.json")
VISTOS = os.path.join(AQUI, "coleta-vistos.json")
LOG = os.path.join(AQUI, "coleta-painel.log")

def _faixa_json(chave="faixa_odd", padrao=(1.5, 4.6)):
    """Banda de odd vem do regras.json: hardcoded aqui e no executor, mexer num
    lado só faz a linha entrar na fila e morrer como fora_faixa."""
    try:
        with open(os.path.join(AQUI, "regras.json"), encoding="utf-8") as f:
            v = (json.load(f) or {}).get(chave) or padrao
        return (float(v[0]), float(v[1]))
    except Exception:
        return padrao


NOSSAS = re.compile(r"cloudbet|magic markets|stake\.com|3et|heritage", re.I)
# o painel manda o nome da casa como texto livre; o executor e as regras usam o
# nome canônico. Sem este mapa, item de Stake chega como "Stake.com" e nenhum
# executor pega.
CANON = {"cloudbet": "Cloudbet", "magic markets": "Magic", "stake.com": "Stake", "3et": "3et",
         "heritage": "Heritage"}
# mercado do painel (crítico, em inglês) -> texto do botão na tela da Stake:
# o executor procura o texto do mercado na página, não a chave.
STAKE_MERCADO = {
    # prop: primeiro mercado que a casa limita. Entra, mas com peso menor.
    "points": "Points", "rebounds": "Rebounds", "assists": "Assists",
    "threes": "Three Made", "steals": "Steals", "blocks": "Blocks",
    "stocks": "Steals + Blocks", "pts_reb": "Points + Rebounds",
    "pts_ast": "Points + Assists", "pra": "Points + Assists + Rebounds",
    "reb_ast": "Rebounds + Assists",
    # jogo: mercado principal, último a ser limitado. Texto do site.
    "jogo_1x2": "1x2", "jogo_vencedor": "Winner",
    "jogo_gols_handicap": "Asian Handicap", "jogo_pontos_handicap": "Asian Handicap",
    "jogo_gols_total": "Asian Total", "jogo_pontos_total": "Asian Total",
}

# 3et: a tela é outra casa, com nomes de mercado próprios em inglês e o preço num
# span por linha (`.binary-market__runner`). O valor aqui é o TÍTULO do mercado na
# página; o executor abre esse bloco e escolhe o preço pelo lado e pela linha.
# `{time}` é trocado pelo time do lado do item. Mercado que não está na tela fica
# fora do mapa e o item não entra (senão morre como sem_mapa na aba).
# Tipo de escolha: "3way" (casa/empate/fora por posição), "linha" (casa antes,
# fora depois, linha no nome), "total" (mais antes, menos depois), "time" (nome do
# time no runner), "combinado" (time + mais/menos no mesmo nome).
TRESET_MERCADO = {
    "jogo_1x2": ("1x2", "3way"),          # futebol: 3 lados
    "jogo_vencedor": ("Moneyline", "lado"),   # sem empate: 2 lados (Draw No Bet no futebol)
    "jogo_gols_handicap": ("Handicap", "linha"),
    "jogo_pontos_handicap": ("Handicap", "linha"),   # basquete: mesmo handicap da tela
    "jogo_gols_total": ("Total", "total"),
    "jogo_pontos_total": ("Total", "total"),
    "time_gols_total": ("Team Goals - {time} - Over/Under", "total"),
    "time_pontos_total": ("Team Goals - {time} - Over/Under", "total"),
    "time_sem_sofrer_gol": ("Clean Sheet", "time"),
    "jogo_resultado_total": ("1X2 & Goals O/U", "combinado"),
}
# Heritage: a tela é o frame do provedor com título de mercado em inglês por
# esporte. O valor aqui é o TÍTULO exato do bloco; `{time}` é trocado pelo time
# do lado do item. Só jogo inteiro (periodId vazio/m/g), senão crava no período
# errado com a mesma chave de mercado.
HERITAGE_MERCADO = {
    # (esporte, mercado) -> (título do bloco, tipo de escolha). O título muda por
    # esporte: hockey tem "Puck Line/Match Winner", basquete e futebol americano
    # usam "Spread/Game Winner". Esporte fora da tabela não entra (sem mapa).
    ("football", "jogo_1x2"): ("Match Result (3-way)", "3way"),
    ("football", "jogo_vencedor"): ("Draw No Bet", "lado"),
    ("football", "jogo_gols_handicap"): ("Handicap", "linha"),
    ("football", "jogo_gols_total"): ("Total", "total"),
    ("basketball", "jogo_vencedor"): ("Game Winner", "lado"),
    ("basketball", "jogo_pontos_handicap"): ("Spread", "linha"),
    ("basketball", "jogo_pontos_total"): ("Total", "total"),
    ("hockey", "jogo_vencedor"): ("Match Winner", "lado"),
    ("hockey", "jogo_gols_handicap"): ("Puck Line", "linha"),
    ("hockey", "jogo_gols_total"): ("Total", "total"),
    ("american-football", "jogo_vencedor"): ("Game Winner", "lado"),
    ("american-football", "jogo_pontos_handicap"): ("Spread", "linha"),
    ("american-football", "jogo_pontos_total"): ("Total", "total"),
}
CASAS_LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "casas-vistas.log")
CONTAGEM = os.path.join(os.path.dirname(os.path.abspath(__file__)), "casas-contagem.json")
_anotado = {}
_conta = {}
_conta_desde = [0.0]


def _anota_casa(casa, url, mercado, ev=None, odd=None):
    """Conta toda linha de casa que ainda não operamos e grava uma amostra a cada
    10 min por casa+mercado. É o levantamento de volume/EV e do que vale mapear."""
    chave = (casa or "").strip().lower()[:30]
    if not chave:
        return
    agora = time.time()
    c = _conta.setdefault(chave, {})
    c["n"] = c.get("n", 0) + 1
    c["casa"] = (casa or "").strip()[:40]
    if ev is not None:
        evs = c.setdefault("evs", [])
        evs.append(float(ev))
        if len(evs) > 500:
            del evs[:-500]
    if agora - _conta_desde[0] > 60:
        _conta_desde[0] = agora
        try:
            with open(CONTAGEM, "w", encoding="utf-8") as f:
                json.dump({k: {"casa": v.get("casa"), "n": v.get("n", 0),
                               "ev_max": round(max(v.get("evs") or [0]), 2),
                               "ev_med": round(sum(v.get("evs") or [0]) / max(1, len(v.get("evs") or [1])), 2)}
                           for k, v in _conta.items()}, f, ensure_ascii=False)
        except Exception:
            pass
    k2 = chave + "|" + (mercado or "").lower()[:20]
    if agora - _anotado.get(k2, 0) < 600:
        return
    _anotado[k2] = agora
    try:
        with open(CASAS_LOG, "a", encoding="utf-8") as f:
            f.write("%s\t%s\t%s\tev=%s\todd=%s\t%s\n" % (
                time.strftime("%Y-%m-%dT%H:%M:%S"), (casa or "").strip()[:40], (mercado or "")[:30],
                ev if ev is not None else "", odd if odd is not None else "", (url or "")[:120]))
    except Exception:
        pass


def _cfg(chave, padrao):
    try:
        with open(os.path.join(AQUI, "regras.json"), encoding="utf-8") as f:
            return (json.load(f) or {}).get(chave, padrao)
    except Exception:
        return padrao


def saida_pc_viva():
    """Casa que só pode sair pelo IP do PC: sem o batimento do relé, não enfileira.

    Evita a fila de casa de tela encher com o PC desligado e vencer na janela.
    """
    try:
        with open(os.path.join(AQUI, "saida-pc-estado.json"), encoding="utf-8") as f:
            est = json.load(f) or {}
        limite = time.time() - float(_cfg("saida_pc_min", 180))
        return float(est.get("ok_em") or 0) >= limite
    except Exception:
        return False


EV_MIN, FAIXA, JANELA = 5.0, _faixa_json(), (-60, 1440)   # prop 22 h à frente morria na janela de 12 h
ML_EV_MIN, ML_EV_FRACO, ML_FAIXA, ML_JANELA = 5.0, 8.0, _faixa_json("ml_faixa_odd", (1.15, 9.0)), (25, 1440)
EXIGE = re.compile(r"^(pinnacle|comparativa|legado|semi-sharp)", re.I)
ESPORTE_CB = {"football": "soccer", "basketball": "basketball", "tennis": "tennis",
              "nfl": "american-football", "hockey": "ice-hockey", "mma": "mma",
              "boxing": "boxing", "cricket": "cricket"}

_trava_login = threading.Lock()
_jar = http.cookiejar.CookieJar()


def log(txt):
    linha = "%s %s" % (time.strftime("%Y-%m-%dT%H:%M:%S"), txt)
    print(linha, flush=True)
    try:
        if os.path.getsize(LOG) > 2 * 1024 * 1024:
            os.replace(LOG, LOG + ".1")
    except OSError:
        pass
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(linha + "\n")
    except Exception:
        pass


# ---------------------------------------------------------------- cookies
def carrega_cookies():
    try:
        d = json.load(open(COOKIES, encoding="utf-8"))
    except Exception:
        return
    host = urllib.parse.urlsplit(PAINEL).hostname
    for c in d:
        try:
            _jar.set_cookie(http.cookiejar.Cookie(
                version=0, name=c["n"], value=c["v"], port=None, port_specified=False,
                domain=host, domain_specified=True, domain_initial_dot=False,
                path="/", path_specified=True, secure=True, expires=None,
                discard=False, comment=None, comment_url=None, rest={}))
        except Exception:
            continue


def salva_cookies():
    d = [{"n": c.name, "v": c.value} for c in _jar]
    tmp = COOKIES + ".novo"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, COOKIES)
    except Exception:
        pass


def abre(metodo="GET", url="", dados=None, ms=20000, streams=False):
    r = urllib.request.Request(url, data=dados, method=metodo,
                               headers={"Content-Type": "application/json",
                                        "User-Agent": "Mozilla/5.0 coleta-painel"})
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_jar))
    return op.open(r, timeout=ms / 1000 if not streams else 300)


def _totp(segredo):
    """Código TOTP de 6 dígitos (RFC 6238, passo de 30 s) do segredo base32."""
    import base64
    import hashlib
    import hmac
    import struct
    chave = base64.b32decode(segredo.replace(" ", "").replace("-", "").upper())
    marco = int(time.time()) // 30
    h = hmac.new(chave, struct.pack(">Q", marco), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return "%06d" % ((struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def _espera_codigo(desde):
    """Devolve o código 2FA: TOTP do cofre (PAINEL_TOTP) ou arquivo novo.

    Com o segredo TOTP salvo o login é sozinho; sem ele, espera alguém colar o
    código em `painel_codigo.txt` e deixa o marcador `coleta-pedido-2fa.txt`.
    """
    # dois nomes históricos: o cofre tem PAINEL_CODIGO_2FA (código colado, vence),
    # mas o que serve é o segredo TOTP base32 em PAINEL_TOTP. Aceitar os dois evita
    # restart que fica esperando alguém colar código em 15 min.
    bruto = _segredo("PAINEL_TOTP") or _segredo("PAINEL_CODIGO_2FA")
    segredo = bruto if re.fullmatch(r"[A-Za-z2-7=\s]{16,}", bruto or "") else ""
    if bruto and not segredo:
        log("2FA do cofre não é segredo base32 (%d chars) — gravando PAINEL_TOTP resolve" % len(bruto))
    if segredo:
        try:
            cod = _totp(segredo)
            log("código 2FA gerado pelo segredo do cofre")
            return cod
        except Exception as e:
            log("segredo TOTP inválido: %s" % e)
    log("pedindo código 2FA em painel_codigo.txt")
    try:
        with open(PEDIDO, "w", encoding="utf-8") as f:
            f.write(str(int(time.time())))
    except Exception:
        pass
    fim = time.time() + 900
    try:
        while time.time() < fim:
            try:
                m = os.path.getmtime(CODIGO)
                if m > desde:
                    v = re.sub(r"\D", "", open(CODIGO, encoding="utf-8").read())
                    if 6 <= len(v) <= 10:
                        return v
            except Exception:
                pass
            time.sleep(2)
        return None
    finally:
        try:
            os.remove(PEDIDO)
        except Exception:
            pass


def _segredo(nome):
    """Valor do cofre: primeiro a pasta deste agente, depois o cofre comum."""
    comuns = [VAULT, os.path.join(os.environ.get("APPDATA", ""), "OpenBot", "agent-api-keys", ".vault")]
    for base in comuns:
        try:
            v = open(os.path.join(base, nome), encoding="utf-8").read().strip()
            if v:
                return v
        except Exception:
            continue
    return ""


def _credenciais():
    try:
        d = json.load(open(CRED, encoding="utf-8"))
        if d.get("email") and d.get("senha"):
            return d["email"], d["senha"]
    except Exception:
        pass
    e, s = _segredo("PAINEL_EMAIL"), _segredo("PAINEL_SENHA")
    return (e, s) if e and s else (None, None)


def entrar(force=False):
    """Faz o login. Devolve True se a sessão está de pé."""
    with _trava_login:
        if not force:
            try:
                r = abre(url=PAINEL + "/api/ev/stream", ms=8000)
                if r.status == 200:
                    r.close()
                    return True
            except Exception:
                pass
        email, senha = _credenciais()
        if not email or not senha:
            log("sem e-mail/senha do painel no cofre — não dá para entrar")
            return False
        desde = time.time()
        try:
            r = abre("POST", PAINEL + "/api/auth/login",
                     json.dumps({"email": email, "senha": senha}).encode())
            d = json.loads(r.read())
        except urllib.error.HTTPError as e:
            log("login recusado: HTTP %s %s" % (e.code, e.read()[:120]))
            return False
        except Exception as e:
            log("login falhou: %s" % e)
            return False
        if d.get("etapa") == "config_2fa":
            log("2FA ainda não configurado nesta conta (faça pelo navegador)")
            return False
        if d.get("etapa") == "codigo_2fa":
            cod = _espera_codigo(desde)
            if not cod:
                log("código 2FA não chegou em 15 min")
                return False
            try:
                r = abre("POST", PAINEL + "/api/auth/login-2fa",
                         json.dumps({"loginToken": d.get("loginToken"), "codigo": cod,
                                     "confiarNavegador": True}).encode())
                rd = json.loads(r.read())
            except Exception as e:
                log("2fa falhou: %s" % e)
                return False
            if rd.get("etapa") != "ok":
                log("2fa recusado: %s" % rd.get("error"))
                return False
        elif d.get("etapa") != "ok":
            log("login em etapa inesperada: %s" % d.get("etapa"))
            return False
        salva_cookies()
        log("sessão aberta")
        return True


# ---------------------------------------------------------------- vistos
def vistos_carrega():
    corte = time.time() - 60 * 60     # a ponte deduplica por chave; aqui só evita repetir o retrato
    try:
        d = json.load(open(VISTOS, encoding="utf-8"))
        return {k: v for k, v in d.items() if float(v) > corte}
    except Exception:
        return {}


def vistos_grava(v):
    try:
        tmp = VISTOS + ".novo"
        json.dump(v, open(tmp, "w", encoding="utf-8"))
        os.replace(tmp, VISTOS)
    except Exception:
        pass


# ---------------------------------------------------------------- ponte
def status():
    try:
        return json.loads(abre(url=PONTE + "/status", ms=5000).read())
    except Exception:
        return {}


def manda(item):
    try:
        abre("POST", PONTE + "/fila", json.dumps(item).encode(), ms=6000).read()
        return True
    except Exception:
        return False


def min_ate(kick):
    try:
        n = float(kick or 0)
    except Exception:
        return None
    if not n:
        return None
    return round((n - time.time() * 1000) / 60000)


# ---------------------------------------------------------------- laço 1: SSE
def sse():
    vistos = vistos_carrega()
    while True:
        st = status()
        if st.get("parado") or float(st.get("hoje") or 0) >= float(st.get("limite") or 999):
            time.sleep(20)
            continue
        try:
            r = abre(url=PAINEL + "/api/ev/stream?v=%d" % int(time.time() * 1000), ms=120000)
            if r.status != 200:
                raise RuntimeError("stream %s" % r.status)
            log("SSE aberto")
            t_con = time.time()
            for bruto in r:
                linha = bruto.decode("utf-8", "ignore").strip()
                if not linha.startswith("data:"):
                    continue
                try:
                    linhas = (json.loads(linha[5:].strip()) or {}).get("linhas") or []
                except Exception:
                    continue
                processa(linhas, vistos)
                # O painel manda o retrato inteiro na abertura e depois só difusão fina.
                # Renova a conexão para reaproveitar o retrato; a dedupe por chave segura repetido.
                if time.time() - t_con > 100:
                    break
            r.close()
        except urllib.error.HTTPError as e:
            if e.code in (401, 403, 302):
                log("stream %s — renovando sessão" % e.code)
                entrar(force=True)
            else:
                log("stream erro HTTP %s" % e.code)
                time.sleep(10)
        except Exception as e:
            log("stream caiu: %s" % e)
            time.sleep(5)


def processa(linhas, vistos):
    st = status()
    hoje, limite = float(st.get("hoje") or 0), float(st.get("limite") or 999)
    for l in linhas:
        if hoje >= limite:
            return
        casa = l.get("casa") or ""
        if not NOSSAS.search(casa):
            _anota_casa(casa, l.get("url") or "", l.get("mercado") or "", l.get("ev"), l.get("odd"))
            continue
        casa = CANON.get(casa.strip().lower(), casa.strip())
        if casa in (_cfg("casas_saida_pc", []) or []) and not saida_pc_viva():
            continue   # casa de saída residencial com o PC fora: não entra agora
        if l.get("tipo") not in ("prop", "jogo"):
            continue
        try:
            ev, odd = float(l.get("ev")), float(l.get("odd"))
        except Exception:
            continue
        if ev < EV_MIN or not (FAIXA[0] <= odd <= FAIXA[1]):
            continue
        falta = min_ate(l.get("kickoff"))
        if falta is not None and not (JANELA[0] <= falta <= JANELA[1]):
            continue
        fonte = l.get("justaFonte") or ""
        if not re.search("pinnacle", fonte, re.I) and ev < 8:
            continue
        url = l.get("url") or ""
        # casa de tela: o item precisa do slug da partida no site e do texto do
        # mercado como aparece no botão. Sem os dois o executor responde sem_mapa.
        slug = mercado_tela = ""
        if casa == "Stake":
            slug = url.rstrip("/").split("/")[-1]
            mercado_tela = STAKE_MERCADO.get((l.get("mercado") or "").strip().lower(), "")
            if not slug or not re.match(r"^\d", slug) or not mercado_tela:
                continue   # mercado sem mapa de tela não entra: morreria na aba
            # prop da Stake morre no apito (o grupo playerProps não existe em jogo):
            # sem folga de fila o item nasce morto. 25 min cobre o atraso medido.
            if not (l.get("mercado") or "").strip().lower().startswith("jogo_"):
                if falta is None or falta < 25:
                    continue
        tipo_escolha = escolha = time_sel = total_lado = ""
        if casa not in CANON.values():
            continue          # casa com "3et" no meio do nome entrava sem mapa
        if casa == "3et":
            partes = str(l.get("chave") or "").split("|")
            mercado = (l.get("mercado") or "").strip().lower()
            mt = TRESET_MERCADO.get(mercado)
            if not mt or not re.search(r"/event/\d+", url):
                continue
            # período: só jogo inteiro. "· 1º tempo", quarto e set têm a MESMA chave
            # de mercado e eram cravação no período errado.
            per = (partes[4] if len(partes) > 4 else "jogo").strip().lower()
            txt_per = "%s %s" % (l.get("mercado") or "", l.get("mercadoNome") or "")
            if per not in ("jogo", "jogo_pr") or re.search(
                    r"·|1º tempo|2º tempo|half|quarter|\bq[1-4]\b|set \d", txt_per, re.I):
                continue
            mercado_tela, tipo_escolha = mt
            esporte = (l.get("esporte") or "").strip().lower()
            # o nome do bloco muda com o esporte e com o mercado
            if mercado == "jogo_1x2":
                if esporte != "football":
                    continue
                mercado_tela, tipo_escolha = "1x2", "3way"
            elif mercado == "jogo_vencedor":
                # "vencedor sem empate": no futebol é Draw No Bet, no basquete Moneyline
                mercado_tela = "Draw No Bet" if esporte == "football" else "Moneyline"
                tipo_escolha = "lado"
            elif mercado == "jogo_resultado_total" and esporte != "football":
                mercado_tela = "Moneyline And Total"
            lado = (l.get("lado") or "").strip().lower()
            # combinado carrega DOIS eixos: o lado do time e o total
            escolha = {"sim": "casa", "nao": "fora"}.get(lado, lado)
            total_lado = ""
            for suf, valor in (("_mais", "mais"), ("_menos", "menos")):
                if escolha.endswith(suf):
                    escolha, total_lado = escolha[: -len(suf)], valor
            if lado in ("mais", "menos"):
                total_lado = lado
            # a escolha tem de existir na lista do tipo, senão cairia no índice 1
            permitidas = {"3way": ("casa", "empate", "fora"), "lado": ("casa", "fora"),
                          "linha": ("casa", "fora"), "total": ("mais", "menos"),
                          "combinado": ("casa", "fora", "empate"), "time": ("casa", "fora")}
            if escolha not in permitidas.get(tipo_escolha, ()):
                continue
            # linha: o painel manda `linha` vazia nos mercados de jogo — o valor e o
            # sinal estão no fim da seleção ("AS Cannes -2", "Mais de 232")
            ln = l.get("linha")
            if ln in (None, ""):
                m_ln = re.search(r"([+-]?\d+(?:\.\d+)?)\s*$", str(l.get("selecao") or ""))
                ln = m_ln.group(1) if m_ln else ""
            if tipo_escolha in ("linha", "total", "combinado") and not ln:
                continue
            if tipo_escolha in ("time", "combinado") or "{time}" in mercado_tela:
                # o time vem do prefixo do lado (casa_/fora_) ou da chave, nunca de sim/não
                if tipo_escolha == "time":
                    if lado != "sim":
                        continue          # "não sofre gol: Não" fica fora por ora
                    lado_time = (partes[5] if len(partes) > 5 else "") or escolha
                else:
                    lado_time = (partes[5] if len(partes) > 5 else "") or escolha
                times = re.split(r"\s+x\s+|\s+vs\.?\s+", l.get("jogo") or "")
                if len(times) != 2 or lado_time not in ("casa", "fora"):
                    continue
                time_sel = times[0 if lado_time == "casa" else 1].strip()
                mercado_tela = mercado_tela.replace("{time}", time_sel)
                escolha = lado_time
                ln = ln or ""
            l = dict(l, linha=ln)
            if tipo_escolha == "combinado" and not total_lado:
                continue
        elif casa == "Heritage":
            mercado = (l.get("mercado") or "").strip().lower()
            esporte = (l.get("esporte") or "").strip().lower()
            hm = HERITAGE_MERCADO.get((esporte, mercado))
            mev = re.search(r"eventId=(\d+)", url)
            if not hm or not mev:
                continue
            # período: só jogo inteiro. Meio, quarto e set têm a MESMA chave de
            # mercado e eram cravação no período errado.
            mper = re.search(r"periodId=([a-z0-9]+)", url)
            if (mper.group(1) if mper else "").lower() not in ("", "m", "g"):
                continue
            mercado_tela, tipo_escolha = hm
            lado = (l.get("lado") or "").strip().lower()
            total_lado = ""
            for suf, valor in (("_mais", "mais"), ("_menos", "menos")):
                if lado.endswith(suf):
                    lado, total_lado = lado[: -len(suf)], valor
            ln = l.get("linha")
            if ln in (None, ""):
                m_ln = re.search(r"([+-]?\d+(?:\.\d+)?)\s*$", str(l.get("selecao") or ""))
                ln = m_ln.group(1) if m_ln else ""
            times = re.split(r"\s+x\s+|\s+vs\.?\s+", l.get("jogo") or "")
            if tipo_escolha == "total":
                if total_lado not in ("mais", "menos") or not ln:
                    continue
                escolha = total_lado
            elif tipo_escolha == "linha":
                if lado not in ("casa", "fora") or not ln or len(times) != 2:
                    continue
                escolha = lado
                time_sel = times[0 if lado == "casa" else 1].strip()
            else:                                  # 3way / lado
                if lado == "empate":
                    if tipo_escolha != "3way":
                        continue
                    escolha = "empate"
                elif lado in ("casa", "fora") and len(times) == 2:
                    escolha = lado
                    time_sel = times[0 if lado == "casa" else 1].strip()
                else:
                    continue
            l = dict(l, linha=ln, evento=mev.group(1))
        # o id do evento está no caminho ("/event/2699328-slug"), não no fim
        m = re.search(r"/event/(\d+)", url) or re.search(r"(\d+)/?(?:$|\?)", url)
        evento = (m.group(1) if m else "") or str(l.get("evento") or "")
        if not evento:
            continue
        chave = ("%s|%s" % (casa, l.get("selId") or l.get("chave") or "")).lower()
        if chave in vistos:
            continue
        agora = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        item = {
            "quando": agora, "chave": chave, "casa": casa, "origem": "coleta-sse",
            "jogo": l.get("jogo"), "liga": l.get("liga"), "esporte": l.get("esporte") or "",
            "comeca": "" if falta is None else "%dmin" % falta,
            "aposta": l.get("selecao") or l.get("texto") or "",
            "mercado": mercado_tela or l.get("mercadoNome") or l.get("mercado"),
            "slug": slug,
            "lado": l.get("lado") or "", "escolha": escolha,
            "tipo_escolha": tipo_escolha, "time": time_sel, "total": total_lado,
            "prop": l.get("tipo") == "prop", "jogador": l.get("jogador") or "",
            # linha: a que o branch acima resolveu (sinal incluído). O fallback antigo
            # pescava qualquer número entre barras e pegava o id do evento.
            "linha": l.get("linha") or "",
            "chave_mercado": l.get("mercado") or "", "odd": odd,
            "justa": float(l.get("justa") or 0), "ev": ev,
            "liq": l.get("liq") or l.get("liquidez") or None,
            "href": url, "evento": str(evento), "kickoff": l.get("kickoff"),
            "link_aposta": url,
            "fontes_justa": (int(re.search(r"(\d) casas", fonte).group(1))
                             if re.search(r"(\d) casas", fonte)
                             else (1 if re.search("pinnacle", fonte, re.I) else None)),
            "outra_casa": bool(re.search(r"\d casas", fonte)),
            "justa_fonte": fonte, "tipo": l.get("tipo"),
            "confianca": l.get("confianca") or l.get("conf"),
        }
        # marca visto só DEPOIS de a ponte aceitar: ponte fora não pode custar a linha
        if manda(item):
            hoje += 1
            vistos[chave] = time.time()
            vistos_grava(vistos)


# ---------------------------------------------------------------- laço 2: vencedor
def sem_acento(s):
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", str(s or "").lower())
                   if unicodedata.category(c) != "Mn")


def tokens(s):
    return [t for t in re.sub(r"[^a-z0-9 ]", " ", sem_acento(s)).split()
            if len(t) >= 4 and t not in ("club", "team") and not re.fullmatch(r"u\d+", t)]


def casa_bate(alvo, nome):
    a, b = tokens(alvo), tokens(nome)
    return bool(a and b and set(a) & set(b))


def leitura(url, ms=15000):
    return json.loads(abre(url=url, ms=ms).read())


def rodada_ml(vistos):
    st = status()
    if st.get("parado") or float(st.get("hoje") or 0) >= float(st.get("limite") or 999):
        return
    # 1. justa do vencedor das outras casas
    justas = {}
    try:
        r = abre(url=PAINEL + "/api/ev/stream", ms=20000)
        t0 = time.time()
        for bruto in r:
            linha = bruto.decode("utf-8", "ignore").strip()
            if linha.startswith("data:"):
                linhas = (json.loads(linha[5:].strip()) or {}).get("linhas") or []
                break
            if time.time() - t0 > 15:
                break
        r.close()
    except Exception as e:
        log("ml: sem snapshot (%s)" % e)
        return
    for l in linhas:
        if l.get("mercado") != "jogo_vencedor":
            continue
        if re.search("cloudbet", l.get("casa") or "", re.I):
            continue
        if l.get("lado") not in ("casa", "fora"):
            continue
        j = float(l.get("justa") or 0)
        if j <= 1.01:
            continue
        falta = min_ate(l.get("kickoff"))
        if falta is not None and not (ML_JANELA[0] <= falta <= ML_JANELA[1]):
            continue
        fonte = l.get("justaFonte") or ""
        if not EXIGE.search(fonte):
            continue
        forte = bool(re.search("pinnacle", fonte, re.I))
        ch = "%s|%s" % (l.get("match_id") or l.get("grupo") or l.get("jogo"), l.get("lado"))
        atual = justas.get(ch)
        if not atual or (forte and not atual["forte"]):
            justas[ch] = {"j": j, "fonte": fonte, "jogo": l.get("jogo"),
                          "esporte": l.get("esporte"), "kickoff": l.get("kickoff"), "forte": forte}
    if not justas:
        return
    # 2. eventos da Cloudbet por esporte
    agora = int(time.time())
    indice = {}
    for info in justas.values():
        esp = ESPORTE_CB.get(info.get("esporte"))
        if not esp or esp in indice:
            continue
        try:
            d = leitura(PONTE + "/cloudbet/v2/odds/events?sport=%s&from=%d&to=%d"
                        % (esp, agora, agora + 43200))
        except Exception:
            indice[esp] = []
            continue
        indice[esp] = [ev for c in (d.get("competitions") or []) for ev in (c.get("events") or [])]
    # 3. preço da Cloudbet e envio
    for ch, info in justas.items():
        partes = re.split(r"\s+x\s+", str(info.get("jogo") or ""))
        if len(partes) != 2:
            continue
        ev = next((e for e in indice.get(ESPORTE_CB.get(info.get("esporte")), [])
                   if casa_bate(partes[0], (e.get("home") or {}).get("name"))
                   and casa_bate(partes[1], (e.get("away") or {}).get("name"))), None)
        if not ev:
            continue
        try:
            det = leitura(PONTE + "/cloudbet/v2/odds/events/%s" % ev["id"])
        except Exception:
            continue
        mk = det.get("markets") or {}
        chave_mk = next((m for m in mk if re.search(r"\.(moneyline|match_odds)$", m)), None)
        if not chave_mk:
            continue
        lado = ch.split("|")[-1]
        alvo = "home" if lado == "casa" else "away"
        sel = None
        for sub, corpo in (mk[chave_mk].get("submarkets") or {}).items():
            for s in corpo.get("selections") or []:
                if s.get("outcome") == alvo:
                    sel = s
                    break
            if sel:
                break
        if not sel:
            continue
        odd, maximo = float(sel.get("price") or 0), float(sel.get("maxStake") or 0)
        if not (ML_FAIXA[0] <= odd <= ML_FAIXA[1]):
            continue
        if maximo and maximo < 5:
            continue
        lev = (odd / info["j"] - 1) * 100
        if lev < (ML_EV_MIN if info["forte"] else ML_EV_FRACO):
            continue
        chave = "cloudbet-ml|%s|%s" % (ev["id"], lado)
        if vistos.get(chave):
            continue
        nome = (ev.get("home") if lado == "casa" else ev.get("away"))["name"]
        item = {
            "quando": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "chave": chave, "casa": "Cloudbet", "origem": "coleta-ml",
            "jogo": info["jogo"], "liga": (det.get("competition") or {}).get("name") or "",
            "comeca": "%dmin" % (min_ate(time.mktime(time.strptime(det["cutoffTime"][:19], "%Y-%m-%dT%H:%M:%S")) * 1000) or 0)
            if det.get("cutoffTime") else "",
            "aposta": "%s x %s · Vencedor: %s" % (ev["home"]["name"], ev["away"]["name"], nome),
            "mercado": "Vencedor", "prop": False, "lado": lado, "linha": "",
            "odd": odd, "justa": info["j"], "ev": lev, "liq": maximo or None,
            "href": "https://www.cloudbet.com/pt-br/sports/%s/%s" % (info.get("esporte"), ev["id"]),
            "url": sel.get("marketUrl"), "evento": str(ev["id"]), "tipo": "jogo",
            "justa_fonte": info["fonte"],
            "fontes_justa": 1 if re.search("pinnacle", info["fonte"], re.I) else None,
            "confianca": sel.get("confianca") or sel.get("conf"),
        }
        vistos[chave] = time.time()
        vistos_grava(vistos)
        if manda(item):
            log("ml: enviado %s" % chave)


def laco_ml(vistos):
    while True:
        try:
            rodada_ml(vistos)
        except Exception as e:
            log("ml erro: %s" % e)
        time.sleep(120)


def main():
    carrega_cookies()
    if "--entrar" in sys.argv:
        for i in range(3):
            if entrar(force=True):
                sys.exit(0)
            log("tentativa %d falhou, esperando código novo" % (i + 1))
            time.sleep(3)
        sys.exit(1)
    while not entrar():
        time.sleep(30)
    vistos = vistos_carrega()
    threading.Thread(target=laco_ml, args=(vistos,), daemon=True).start()
    while True:
        try:
            sse()
        except Exception as e:
            log("sse reiniciando: %s" % e)
            time.sleep(5)


if __name__ == "__main__":
    main()
