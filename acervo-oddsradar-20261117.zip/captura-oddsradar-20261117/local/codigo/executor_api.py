"""Executor API — crava na Cloudbet pela API oficial, sem aba da Cloudbet.

Contrato: GET /fila na ponte (o vigia publica), cota em /pub/v2/odds/lines e crava
em /pub/v4/bets/place/straight. A cotacao traz maxStake/minStake, entao o limite
de liquidez passa a ser real em vez de estimado.

Trava de seguranca: so roda se existir o arquivo MODO_API.txt. Com o executor5.js
ativo na aba, os dois cravarian a mesma linha; a chave local evita o par.

Uso:
  python executor_api.py            # uma rodada
  python executor_api.py --loop 20  # rodadas a cada 20 s
"""
import csv, gzip, json, os, re, sys, time, unicodedata, uuid
import urllib.error
import urllib.request

AQUI = os.path.dirname(os.path.abspath(__file__))
PONTE = "http://127.0.0.1:8788"
BASE = "https://sports-api.cloudbet.com/pub"
TOLERANCIA = 0.03          # recusa se o preco cair mais de 3% desde o painel
DERIVA_MAX = 0.02          # aceita escorregar ate 2% na hora de cravar
FRIA_S = 180               # prop que a casa nao tem espera isso antes de nova tentativa
_FRIAS = {}
LOTE = 25

_ARQ_REGRAS = os.path.join(AQUI, "regras.json")
_FAIXA = [0.0, None]       # [mtime, (min, max)] — banda de odd vem do json


def _faixa():
    """Banda de odd do regras.json, relida quando o arquivo muda. Hardcoded nos
    dois lados (aqui e na coleta), mexer num só faz a linha morrer em fora_faixa."""
    try:
        m = os.path.getmtime(_ARQ_REGRAS)
        if _FAIXA[1] is not None and _FAIXA[0] == m:
            return _FAIXA[1]
        with open(_ARQ_REGRAS, encoding="utf-8") as f:
            v = (json.load(f) or {}).get("faixa_odd") or (1.5, 4.6)
        _FAIXA[0], _FAIXA[1] = m, (float(v[0]), float(v[1]))
        return _FAIXA[1]
    except Exception:
        return _FAIXA[1] or (1.5, 4.6)
CSV = os.path.join(AQUI, "apostas_api.csv")
POSTAS = os.path.join(AQUI, "postas_api.json")
MOEDAS = ["USDC", "USDT"]
ALIAS = {"assists": "player_assists", "points": "player_points", "rebounds": "player_rebounds",
         "blocks": "player_blocks", "steals": "player_steals", "turnovers": "player_turnovers",
         "three_pointers": "player_three_point_field_goals", "steals_and_blocks": "player_steals_blocks",
         "points_and_rebounds": "player_points_rebounds", "points_and_assists": "player_points_assists",
         "assists_and_rebounds": "player_rebounds_assists",
         "points_and_assists_and_rebounds": "player_points_rebounds_assists"}
PROPS = {
    "assistencias": "player_assists", "pontos": "player_points", "rebotes": "player_rebounds",
    "cestas de 3": "player_three_point_field_goals", "roubos de bola": "player_steals",
    "tocos": "player_blocks", "bloqueios": "player_blocks", "turnovers": "player_turnovers",
    "roubos + tocos": "player_steals_blocks",
    "pontos + rebotes": "player_points_rebounds",
    "pontos + assistencias": "player_points_assists",
    "pontos + rebotes + assistencias": "player_points_rebounds_assists",
    "pontos + assistencias + rebotes": "player_points_rebounds_assists",
    "rebotes + assistencias": "player_rebounds_assists",
    "assistencias + rebotes": "player_rebounds_assists",
}

# O feed parou de devolver mercado de prop de jogador: so a pagina do evento os traz.
# La o mercado e `<esporte>.player_props_<stat>_player_ou_<sufixo>` e o jogador vai como
# `player_key=s-<nome-sem-acento>`. A chave abaixo e (esporte, rotulo do painel).
# Sufixo: futebol americano/basquete usam `incl_ot` (prorrogacao), futebol usa `in_ft`.
PROPS_PAGINA = {
    ("basketball", "pontos"): ("points", "incl_ot"),
    ("basketball", "rebotes"): ("rebounds", "incl_ot"),
    ("basketball", "assistencias"): ("assists", "incl_ot"),
    ("basketball", "cestas de 3"): ("three_pointers", "incl_ot"),
    ("basketball", "roubos de bola"): ("steals", "incl_ot"),
    ("basketball", "tocos"): ("blocks", "incl_ot"),
    ("basketball", "bloqueios"): ("blocks", "incl_ot"),
    ("basketball", "turnovers"): ("turnovers", "incl_ot"),
    ("basketball", "roubos + tocos"): ("steals_and_blocks", "incl_ot"),
    ("basketball", "pontos + rebotes"): ("points_and_rebounds", "incl_ot"),
    ("basketball", "pontos + assistencias"): ("points_and_assists", "incl_ot"),
    ("basketball", "rebotes + assistencias"): ("assists_and_rebounds", "incl_ot"),
    ("basketball", "pontos + rebotes + assistencias"): ("points_and_assists_and_rebounds", "incl_ot"),
    ("basketball", "pontos + assistencias + rebotes"): ("points_and_assists_and_rebounds", "incl_ot"),
    ("american-football", "jardas recebidas"): ("receiving_yards", "incl_ot"),
    ("american-football", "jardas corridas"): ("rushing_yards", "incl_ot"),
    ("american-football", "jardas passadas"): ("passing_yards", "incl_ot"),
    ("american-football", "recepcoes"): ("receptions", "incl_ot"),
    ("american-football", "passes completos"): ("passing_completions", "incl_ot"),
    ("american-football", "tentativas de passe"): ("passing_attempts", "incl_ot"),
    ("american-football", "tentativas de corrida"): ("rushing_attempts", "incl_ot"),
    ("american-football", "interceptacoes lancadas"): ("interceptions", "incl_ot"),
    ("american-football", "field goals convertidos"): ("field_goals", "incl_ot"),
    ("soccer", "chutes a gol"): ("shots_on_target", "in_ft"),
    ("soccer", "faltas cometidas"): ("fouls", "in_ft"),
    ("soccer", "defesas"): ("saves", "in_ft"),
    ("soccer", "impedimentos"): ("offsides", "in_ft"),
}


def sem_acento(t):
    return "".join(c for c in unicodedata.normalize("NFD", t) if unicodedata.category(c) != "Mn")


_JOGADORES = {}


def _jogadores(evento):
    """Chaves de jogador do evento (a casa usa c<hex>-nome-completo, nao s-nome)."""
    ev = str(evento or "")
    if not ev:
        return []
    guardado = _JOGADORES.get(ev)
    if guardado and time.time() - guardado[0] < 900:
        return guardado[1]
    st, d = api("/v2/odds/events/%s" % ev)
    lista = list(((d or {}).get("players") or {})) if st == 200 else []
    _JOGADORES[ev] = (time.time(), lista)
    return lista


def chave_player(nome, evento=None):
    alvo = re.sub(r"\s+", "-", sem_acento(nome).lower().replace("'", "").replace(".", "").strip())
    for k in _jogadores(evento):
        if k == alvo or k.endswith("-" + alvo):
            return k
    return "s-" + alvo  # reserva: o formato antigo, quando o evento ainda nao traz a lista


_META = {}
_PAGINAS = {}


def _meta(evento):
    """(esporte, competicao) do evento, para montar o endereco da pagina dele."""
    ev = str(evento or "")
    if not ev:
        return None
    guardado = _META.get(ev)
    if guardado and time.time() - guardado[0] < 900:
        return guardado[1]
    st, d = api("/v2/odds/events/%s" % ev)
    if st != 200:
        return None
    esporte = str((d.get("sport") or {}).get("key") or "")
    comp = str((d.get("competition") or {}).get("key") or "")
    if esporte and comp.startswith(esporte + "-"):
        comp = comp[len(esporte) + 1:]
    if not esporte or not comp:
        return None
    par = (esporte, comp)
    _META[ev] = (time.time(), par)
    return par


def _html(url):
    """Corpo da pagina do evento (o JSON de mercados vem embutido nela)."""
    req = urllib.request.Request(url, headers={
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/126.0 Safari/537.36"),
        "Accept-Encoding": "gzip", "Accept-Language": "pt-BR"})
    try:
        with _urlopen(req, 25) as r:
            bruto = r.read()
            if (r.headers.get("Content-Encoding") or "").lower() == "gzip":
                bruto = gzip.decompress(bruto)
            texto = bruto.decode("utf-8", "replace")
    except Exception:
        return ""
    return texto.replace("\\\\u0026", "&").replace("\\u0026", "&")


def _pagina(evento, fresco=False):
    """HTML do evento em cache curto; prop nao existe mais no REST do feed."""
    ev = str(evento or "")
    if not ev:
        return ""
    guardado = _PAGINAS.get(ev)
    if guardado and not fresco and time.time() - guardado[0] < 120:
        return guardado[1]
    meta = _meta(ev)
    if not meta:
        return ""
    html = _html("https://www.cloudbet.com/pt-br/sports/%s/%s/%s" % (meta[0], meta[1], ev))
    _PAGINAS[ev] = (time.time(), html)
    return html


def _texto_prop(aposta, mercado=""):
    """(jogador, lado, total, unidade) do texto do prop; None se nao for prop.

    A unidade vem no proprio texto ("Mais de 9.5 Pontos"); quando nao vem — o futebol
    americano manda em campo separado — cai no rotulo do mercado.
    """
    limpo = re.sub(r"aguardando confirma[^\"]*?da casa\s*", "", str(aposta or ""), flags=re.I)
    limpo = re.sub(r"\s*(Prop|Super Odds?)\s*$", "", limpo.strip(), flags=re.I)
    m = re.match(r"^(.+?)\s*·\s*(Mais|Menos)\s*de\s*([\d.,]+)\s*(.*)$", limpo)
    if not m:
        return None
    unidade = sem_acento(m.group(4) or "").lower().strip()
    if not unidade:
        unidade = sem_acento(str(mercado or "").split("·")[0]).lower().strip()
    if not unidade:
        return None
    return m.group(1), ("over" if m.group(2) == "Mais" else "under"), m.group(3).replace(",", "."), unidade


def _preco_pagina(item, fresco=False):
    """(marketUrl, preco, maxStake, minStake) do prop lido na pagina; None se nao achar.

    O `marketUrl` sai igual ao que o site usa no bilhete, entao serve para cravar.
    `fresco` relê a pagina ignorando o cache: o preco do prop muda em segundos e
    preco velho faz a casa segurar o lance em PENDING_ACCEPTANCE.
    """
    partes = _texto_prop(item.get("aposta"), item.get("mercado"))
    if not partes:
        return None
    jogador, lado, total, unidade = partes
    meta = _meta(item.get("evento"))
    if not meta:
        return None
    esporte = meta[0]
    par = PROPS_PAGINA.get((esporte, unidade))
    if not par:
        return None
    stat, sufixo = par
    slug = re.sub(r"\s+", "-", sem_acento(jogador).lower().replace("'", "").replace(".", "").strip())
    html = _pagina(item.get("evento"), fresco)
    if not html:
        return None
    # a ordem dos parametros muda por esporte (futebol poe period=ft antes do jogador),
    # entao casa o mercado, o lado, o jogador e o total sem exigir ordem fixa
    padrao = re.compile(r'"([a-z_]+\.[a-z_]*player_props_%s_player_ou_[a-z0-9_]*/%s\?[^"]{0,90}?'
                        r'player_key=s-%s[^"]{0,40}?[&?]?total=%s)"'
                        % (re.escape(stat), lado, re.escape(slug), re.escape(total)))
    achado = padrao.search(html)
    if not achado:
        return None
    alvo = achado.group(1)
    trecho = html[achado.end():achado.end() + 400]
    preco = re.search(r'"price":([\d.]+)', trecho)
    if not preco:
        return None
    maximo = re.search(r'"maxStake":([\d.]+)', trecho)
    minimo = re.search(r'"minStake":([\d.]+)', trecho)
    return (alvo, float(preco.group(1)),
            float(maximo.group(1)) if maximo else 0.0,
            float(minimo.group(1)) if minimo else 0.0)


def da_chave():
    env = (os.environ.get("CLOUDBET_API_KEY") or "").strip()
    if env:
        return env
    try:
        import chaves
        do_cofre = chaves.ler("CLOUDBET_API_KEY")
        if do_cofre:
            return do_cofre
    except Exception:
        pass
    # ultimo recurso: arquivo de texto (menos seguro). Avisa uma vez por processo.
    try:
        with open(os.path.join(AQUI, "chave-api.txt"), encoding="utf-8") as f:
            val = f.read().strip()
        if val:
            if not AVISOS:
                print("AVISO: chave lida de chave-api.txt (ambiente/cofre indisponiveis)")
                AVISOS.append(1)
            return val
    except Exception:
        pass
    if not AVISOS:
        print("AVISO: nenhuma chave de API disponivel")
        AVISOS.append(1)
    return ""


AVISOS = []


PROXIES = {"i": 0}


def _lista_proxies():
    """Saídas brasileiras: env CLOUDBET_PROXIES ou `proxies.txt` (uma por linha).

    A Cloudbet trata IP dos EUA como fora de jurisdição; por IP do Brasil o WAF
    libera. A lista existe para trocar sozinho quando um proxy cai ou é barrado.
    """
    bruto = os.environ.get("CLOUDBET_PROXIES") or ""
    if not bruto:
        try:
            with open(os.path.join(AQUI, "proxies.txt"), encoding="utf-8") as f:
                bruto = f.read()
        except Exception:
            return []
    return [p.strip() for p in bruto.replace("\n", ",").split(",") if p.strip()]


def _urlopen(req, tempo):
    """Abre por proxy; em 403 (WAF) ou falha de rede, troca de saída e tenta a próxima."""
    ps = _lista_proxies()
    if not ps:
        return urllib.request.urlopen(req, timeout=tempo)
    erros = []
    for k in range(len(ps)):
        i = (PROXIES["i"] + k) % len(ps)
        op = urllib.request.build_opener(
            urllib.request.ProxyHandler({"http": ps[i], "https": ps[i]}))
        try:
            return op.open(req, timeout=tempo)
        except urllib.error.HTTPError as e:
            if e.code == 403:
                erros.append("%d:403" % i)
                continue
            raise
        except Exception as e:
            erros.append("%d:%s" % (i, type(e).__name__))
            continue
    PROXIES["i"] = (PROXIES["i"] + 1) % len(ps)
    raise urllib.error.URLError("saidas falharam: " + ",".join(erros))


def api(caminho, corpo=None, metodo="GET", tempo=25):
    req = urllib.request.Request(BASE + caminho, method=metodo,
                                 headers={"X-API-Key": da_chave(), "accept": "application/json",
                                          "Content-Type": "application/json"})
    if corpo is not None:
        req.data = json.dumps(corpo).encode()
    try:
        with _urlopen(req, tempo) as r:
            return r.status, json.loads(r.read().decode("utf-8", "replace") or "{}")
    except urllib.error.HTTPError as e:
        texto = e.read().decode("utf-8", "replace")
        try:
            return e.code, json.loads(texto or "{}")
        except Exception:
            return e.code, {"texto": texto}
    except Exception as e:
        return 0, {"texto": str(e)}


LADO_CASA = {"casa": "home", "home": "home", "fora": "away", "away": "away",
             "empate": "draw", "draw": "draw", "mais": "over", "over": "over",
             "menos": "under", "under": "under", "sim": "yes", "nao": "no", "no": "no"}

# familia do mercado -> bases possiveis na casa
FAMILIA = (
    (("1x2", "vencedor", "resultado", "moneyline"), ("match_odds", "moneyline", "1x2")),
    (("total", "gols", "pontos_total"), ("total_goals", "totals", "total")),
    (("handicap", "spread"), ("asian_handicap", "handicap", "spread")),
)
PERIODOS = (("1o tempo", "period_first_half"), ("1º tempo", "period_first_half"),
            ("1st half", "period_first_half"), ("2o tempo", "period_second_half"),
            ("2º tempo", "period_second_half"), ("2nd half", "period_second_half"))

# chave curta do painel -> chaves da casa; a primeira que responder 200 vence
PROP_CHAVES = {
    "fouls": ("player_fouls", "player_fouls_committed", "player_total_fouls"),
    "cards": ("player_cards", "player_to_be_booked", "player_cards_received"),
    "sot": ("player_shots_on_target", "player_shot_on_target"),
    "shots": ("player_shots", "player_total_shots"),
    "reb_ast": ("player_rebounds_assists", "player_points_rebounds_assists"),
    "pra": ("player_points_rebounds_assists",),
    "pr": ("player_points_rebounds",),
    "pa": ("player_points_assists",),
    "receptions": ("player_receptions",),
}
ESPORTES_PROP = ("basketball", "soccer", "american_football", "ice_hockey")

_EVENTOS = {}


def numero(texto):
    m = re.search(r"([+-]?\d+(?:[.,]\d+)?)", str(texto or ""))
    return float(m.group(1).replace(",", ".")) if m else None


def _mercados(evento):
    """Selecoes do evento na casa (marketUrl pronta), cache de 4 min.

    A casa devolve a marketUrl de cada selecao no proprio evento; ler dali evita
    adivinhar prefixo de esporte e nome de mercado, que mudam de tempos em tempos.
    """
    guardado = _EVENTOS.get(evento)
    if guardado and time.time() - guardado[0] < 240:
        return guardado[1]
    st, d = api("/v2/odds/events/%s" % evento)
    lista = []
    if st == 200:
        for chave, m in (d.get("markets") or {}).items():
            base = chave.split(".", 1)[1] if "." in chave else chave
            for subm in (m.get("submarkets") or {}).values():
                for sel in (subm.get("selections") or []):
                    if sel.get("marketUrl"):
                        lista.append({"base": base, "outcome": sel.get("outcome"),
                                      "params": sel.get("params") or "", "url": sel.get("marketUrl")})
    _EVENTOS[evento] = (time.time(), lista)
    return lista


def _url_do_evento(item):
    """marketUrl de mercado de jogo (vencedor, total, handicap), lida do evento."""
    ev = str(item.get("evento") or "")
    alvo = LADO_CASA.get(str(item.get("lado") or "").lower().strip())
    if not ev or not alvo:
        return None
    texto = sem_acento((item.get("mercado") or "") + " " + (item.get("chave_mercado") or "")).lower()
    bases = []
    for marcas, opcoes in FAMILIA:
        if any(m in texto for m in marcas):
            bases.extend(opcoes)
    if not bases:
        return None
    periodo = next((s for marca, s in PERIODOS if marca in texto), None)
    valor = numero(item.get("linha")) if str(item.get("linha") or "").strip() else numero(item.get("aposta"))
    melhor, marca = None, None
    for sel in _mercados(ev):
        if sel["outcome"] != alvo:
            continue
        base = sel["base"]
        if not any(base == b or base.startswith(b + "_") for b in bases):
            continue
        if periodo and periodo not in base:
            continue
        if not periodo and ("_period" in base or "_half" in base or "_quarter" in base):
            continue
        dist = 0.0
        if valor is not None:
            v = numero(sel["params"])
            if v is None:
                continue
            # o sinal do parametro muda de mercado para mercado; casa pelo modulo e
            # prefere o mesmo sinal que o painel mandou
            dist = abs(abs(v) - abs(valor))
            if dist > 0.51:          # so a linha exata ou a vizinha de meio ponto
                continue
            nota = (dist, 0 if (v < 0) == (valor < 0) else 1, len(base))
        else:
            nota = (0.0, 0, len(base))
        if marca is None or nota < marca:
            melhor, marca = sel["url"], nota
    return melhor


def _esporte_do_item(item):
    """Prefixo de esporte da casa, tirado do link do evento."""
    texto = str(item.get("href") or item.get("link_aposta") or item.get("url") or "")
    m = re.search(r"/sports/([a-z0-9-]+)/", texto)
    if not m:
        return None
    return m.group(1).replace("-", "_")


def _urls_prop(item):
    """Candidatos de marketUrl para prop de jogador; o primeiro que responder 200 vale."""
    chave_m = str(item.get("chave_mercado") or "").lower().strip()
    jogador = item.get("jogador") or ""
    lado = str(item.get("lado") or "").lower()
    linha = item.get("linha")
    if not jogador or not chave_m:
        return []
    if lado in ("mais", "over"):
        lado = "over"
    elif lado in ("menos", "under"):
        lado = "under"
    elif lado in ("sim", "yes"):
        lado = "yes"
    elif lado in ("nao", "no"):
        lado = "no"
    else:
        return []
    if lado in ("over", "under") and linha in (None, ""):
        return []
    # o painel manda nome curto em ingles ("reb_ast") ou a chave da casa pronta
    if chave_m.startswith("player_"):
        chaves = (chave_m,)
    else:
        chaves = PROP_CHAVES.get(chave_m) or (
            ALIAS.get(chave_m) or PROPS.get(sem_acento(chave_m)) or "",)
    total = "" if lado in ("yes", "no") else "&total=" + str(linha).replace(",", ".")
    jog = chave_player(jogador, item.get("evento"))
    esporte = _esporte_do_item(item)
    esportes = (esporte,) if esporte else ESPORTES_PROP
    urls = []
    for ch in chaves:
        if not ch:
            continue
        for esporte in esportes:
            for param in ("player_key", "player"):
                urls.append(f"{esporte}.{ch}/{lado}?{param}={jog}{total}")
    return urls


def monta_url(aposta, mercado=""):
    """'Dejounte Murray · Menos de 4.5 AssistênciasProp' -> marketUrl (texto puro)."""
    partes = _texto_prop(aposta, mercado)
    if not partes:
        return None
    jogador, lado, total, unidade = partes
    prop = PROPS.get(unidade)
    if not prop:
        return None
    return (f"basketball.{prop}/{lado}?player={chave_player(jogador)}&total={total}")


def monta_urls(item):
    """Lista de marketUrl candidatas para o item; vazia = sem mapa.

    Ordem: marketUrl pronta da fonte, texto livre, leitura do evento (jogo) e,
    por fim, as chaves de prop. Quem consome para no primeiro 200.
    """
    pronta = str(item.get("url") or "")
    if re.match(r"^[a-z_]+\.[a-z0-9_]+/(home|away|draw|over|under|yes|no)(\?|$)", pronta):
        return [pronta]
    urls = []
    por_texto = monta_url(item.get("aposta", ""), item.get("mercado", ""))
    if por_texto:
        urls.append(por_texto)
    do_evento = _url_do_evento(item)
    if do_evento:
        urls.append(do_evento)
    urls.extend(_urls_prop(item))
    vistos, saida = set(), []
    for u in urls:
        if u not in vistos:
            vistos.add(u)
            saida.append(u)
    return saida



def httponte(caminho, corpo=None):
    dados = None if corpo is None else json.dumps(corpo).encode()
    req = urllib.request.Request(PONTE + caminho, data=dados,
                                 headers={"Content-Type": "application/json"},
                                 method="GET" if corpo is None else "POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode() or "{}")
    except Exception:
        return {}


def saldo(moeda):
    st, d = api(f"/v1/account/currencies/{moeda}/balance")
    if st == 200:
        try:
            return float(d.get("amount") or 0)
        except Exception:
            return 0.0
    return 0.0


def avisa_saldo():
    """Manda o caixa real para a ponte: sem isso a banca do teto fica velha."""
    total = round(sum(saldo(m) for m in MOEDAS), 2)
    if total > 0:
        httponte("/saldo", {"casa": "Cloudbet", "saldo": total})
    return total


def postas():
    """Chaves cravadas nas últimas 6 h. Sem isso, um aviso perdido à ponte fazia
    o ciclo seguinte cravar a mesma linha de novo (o referenceId é novo a cada vez)."""
    try:
        with open(POSTAS, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return {}
    corte = time.time() - 6 * 3600
    return {k: v for k, v in d.items() if v > corte}


def marca_posta(chave):
    d = postas()
    d[chave] = time.time()
    try:
        json.dump(d, open(POSTAS, "w", encoding="utf-8"))
    except Exception:
        pass


def desmarca_posta(chave):
    """Volta a chave para a fila: lance segurado pela casa que nao chegou a debitar
    some do extrato, entao travar por 6 h perderia a aposta."""
    d = postas()
    if chave in d:
        d.pop(chave)
        try:
            json.dump(d, open(POSTAS, "w", encoding="utf-8"))
        except Exception:
            pass


def _iso_margem(segundos):
    """Instante de referencia (UTC, com folga) para casar aposta nova na casa."""
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - segundos)) + ".000000Z"


def _perdida(st):
    """Resposta sem veredito: a casa pode ter aceitado e a resposta se perdeu."""
    return st == 0 or st >= 500 or st in (408, 429)


def _confere_casa(evento, url, stake, desde, tentativas=3):
    """Procura na casa a aposta que esta tentativa pode ter cravado.

    Devolve o betId, "ausente" (a casa respondeu e nao ha) ou "indefinido" (nem a
    lista foi lida). Casa por evento + mercado + stake com criacao dentro da
    janela; aceite parcial vem com stake menor, entao o piso e metade."""
    for n in range(tentativas):
        st, r = api("/v4/bets?limit=25")
        if st == 200:
            for it in (r.get("items") or []):
                sel = it.get("selection") or {}
                if str(sel.get("eventId") or "") != str(evento):
                    continue
                if str(sel.get("marketUrl") or "") != str(url):
                    continue
                if str(it.get("createTime") or "") < desde:
                    continue
                try:
                    s = float(it.get("stake") or 0)
                except Exception:
                    s = 0.0
                if s + 0.02 >= stake * 0.5:
                    return str(it.get("betId") or "")
            if n == tentativas - 1:
                return "ausente"
        if n < tentativas - 1:
            time.sleep(4)
    return "indefinido"


def _resposta_perdida(item, corpo, evento, url, preco, stake, desde, moeda):
    """Resposta perdida da casa: confere o que ja existe antes de cravar de novo.

    Era por aqui que vinha o par dobrado: a aposta entrava, a resposta morria e a
    linha voltava na rodada seguinte com stake cheia."""
    achado = _confere_casa(evento, url, stake, desde)
    if achado and achado not in ("ausente", "indefinido"):
        item["_bet"] = achado
        marca_posta(item.get("chave") or "")
        return "feita", f"confirmada na casa apos resposta perdida: {moeda} {stake:.2f} @ {preco}"
    # ausente, ou casa ilegivel: repete com o MESMO referenceId, que a casa trata
    # como idempotencia. Se a primeira entrou, vem DUPLICATE_REQUEST e nao dobra.
    st, resp = api("/v4/bets/place/straight", corpo, "POST")
    estado = str(resp.get("state") or "")
    if st in (200, 201) and estado in ("ACCEPTED", "PENDING_ACCEPTANCE"):
        item["_bet"] = str(resp.get("betId") or "")
        marca_posta(item.get("chave") or "")
        if estado == "ACCEPTED":
            return "feita", f"ACCEPTED na repetida: {moeda} {stake:.2f} @ {preco}"
        return "aceite_pendente", f"PENDING na repetida: {moeda} {stake:.2f} @ {preco}"
    sel = resp.get("selection") or {}
    codigo = sel.get("rejectionCode") or resp.get("status") or f"HTTP {st}"
    if codigo == "DUPLICATE_REQUEST":
        bet = _confere_casa(evento, url, stake, desde, tentativas=2)
        item["_bet"] = bet if bet not in ("ausente", "indefinido", None) else ""
        marca_posta(item.get("chave") or "")
        return "feita", f"ja estava na casa (referenceId repetido): {moeda} {stake:.2f} @ {preco}"
    if _perdida(st):
        # duas respostas perdidas: trava a chave para nao dobrar e deixa para conferir
        marca_posta(item.get("chave") or "")
        return "aceite_duvidoso", "resposta perdida duas vezes: chave travada, conferir"
    return "recusado", str(codigo)


def marca_fria(chave):
    """Marca a linha como fria e poda a memoria: sem teto ela cresce o dia inteiro."""
    if len(_FRIAS) > 5000:
        corte = time.time() - 3600      # maior espera possivel + folga
        for k in [k for k, v in list(_FRIAS.items()) if v < corte]:
            _FRIAS.pop(k, None)
    if chave:
        _FRIAS[chave] = time.time()


def registra(item, estado, detalhe, ref, moeda=""):
    novo = not os.path.exists(CSV)
    with open(CSV, "a", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter=";")
        if novo:
            w.writerow(["quando", "jogo", "aposta", "odd_painel", "preco", "stake",
                        "moeda", "ref", "estado", "detalhe", "bet_id"])
        w.writerow([time.strftime("%Y-%m-%dT%H:%M:%S"), item.get("jogo", ""), item.get("aposta", ""),
                    item.get("odd", ""), item.get("_preco", ""), item.get("stake_final") or item.get("stake", ""),
                    moeda, ref, estado, detalhe, item.get("_bet", "")])


def _paga(preco, item):
    """O preço novo ainda vale a pena?

    Tolerância de 3% é o corte normal, mas ela é cega: linha com EV 10% caindo
    3,6% ainda paga 6% e morria. Aceita também quando o EV restante é >= 5%.
    """
    try:
        odd = float(item.get("odd") or 0)
        justa = float(item.get("justa") or 0)
    except Exception:
        return False
    if preco >= odd * (1 - TOLERANCIA):
        return True
    if os.environ.get("TOL_CEGA"):      # desliga o critério de EV (para o portão medir)
        return False
    return bool(justa > 1 and (preco / justa - 1) >= 0.05)


def _espera_fria(item):
    """Espera proporcional a distancia do jogo.

    Prop de 22 h a frente nao merece nova tentativa a cada 3 min: eram 60
    avaliacoes por hora por linha e 89 linhas frias no dia.
    """
    try:
        m = int(str(item.get("comeca") or "").split("min")[0])
    except Exception:
        return FRIA_S
    if m >= 720:
        return 1800
    if m >= 360:
        return 900
    return FRIA_S


def _fria(item, detalhe):
    """Marca fria e devolve adiada com prazo: a fila só a devolve quando vencer."""
    marca_fria(item.get("chave"))
    resta = _espera_fria(item)
    item["_adiada_ate"] = int(time.time()) + resta
    return "adiada", "%s (nova tentativa em %ds)" % (detalhe, resta)


def processa(item):
    if item.get("chave") in postas():
        return "repetida", "ja cravada nas ultimas 6 h"
    item["_ref"] = str(uuid.uuid4())
    urls = monta_urls(item)
    evento = str(item.get("evento") or "")
    if not evento:
        return "sem_mapa", "sem evento"
    # a espera vale para QUALQUER linha que a casa nao tem, nao so prop: 89 linhas mortas
    # geraram 7 mil avaliacoes num dia porque a fila devolve o item a cada ciclo
    frio = _FRIAS.get(item.get("chave") or "")
    if frio:
        resta = int(float(item.get("_adiada_ate") or (frio + _espera_fria(item))) - time.time())
        if resta > 0:
            # estado próprio: a fila não devolve antes da hora e o cooldown não
            # gasta tentativa. Antes virava sem_mapa, saía da fila viva e morria
            # em segundos — 21 linhas boas perdidas só hoje.
            item["_adiada_ate"] = int(time.time()) + resta
            return "adiada", "linha fria: sem preco na casa, nova tentativa em %ds" % resta
    da_pagina = _preco_pagina(item)      # prop: preco sai da pagina, o feed nao tem mais
    if not urls and not da_pagina:
        return _fria(item, f"sem url ({bool(urls)}) e sem preco na pagina")
    faixa = _faixa()
    if not (faixa[0] <= float(item.get("odd") or 0) <= faixa[1]):
        return "fora_faixa", "odd fora de %.2f-%.2f" % faixa

    # prop nao existe mais no feed: o preco do prop sai da pagina do evento; o resto
    # continua no /lines. Candidatas em ordem, 404 so passa adiante.
    url, linha, st = "", {}, 0
    if da_pagina:
        url, preco, maximo, minimo = da_pagina
    else:
        for cand in urls:
            st, linha = api("/v2/odds/lines", {"eventId": evento, "marketUrl": cand}, "POST")
            if st == 200:
                url = cand
                break
            if st == 403:
                return "erro_linha", "HTTP 403 no /v2/odds/lines (WAF)"
        if st != 200:
            return _fria(item, f"HTTP {st} {str(linha)[:110]}")
        preco = float(linha.get("price") or 0)
        maximo = float(linha.get("maxStake") or 0)
        minimo = float(linha.get("minStake") or 0)
    item["_preco"] = preco
    if preco <= 0:
        return "sem_preco", str(linha.get("status") or "preco 0 na pagina (selecao desligada)")[:100]
    if not _paga(preco, item):
        return "preco_caiu", f"painel {item['odd']} agora {preco}"

    stake = float(item.get("stake_final") or item.get("stake") or 8)
    item["_liquidez"] = maximo        # liquidez da linha medida na casa, vai no resultado
    if maximo and stake > maximo:
        stake = round(maximo, 2)

    saldos = {m: saldo(m) for m in MOEDAS}
    caixa = round(sum(saldos.values()), 2)
    if stake < 0.5:
        return "sem_saldo", "caixa insuficiente (%.2f)" % caixa
    if minimo and stake < minimo:
        return "abaixo_minimo", f"min {minimo}"

    if da_pagina:
        # preco de prop muda em segundos: relê a pagina agora, senao a casa segura o lance
        novo = _preco_pagina(item, fresco=True)
        if not novo:
            return _fria(item, "prop saiu da pagina antes de cravar")
        url, preco, maximo, minimo = novo
        item["_preco"] = preco
        item["_liquidez"] = maximo
        if not _paga(preco, item):
            return "preco_caiu", f"painel {item['odd']} agora {preco} (relido)"
        if maximo and stake > maximo:
            stake = round(maximo, 2)
        if stake < 0.5:
            return "sem_saldo", "caixa insuficiente (%.2f)" % caixa
        if minimo and stake < minimo:
            return "abaixo_minimo", f"min {minimo}"

    moeda = next((m for m in MOEDAS if saldos[m] >= stake), None)
    if not moeda:
        return "sem_saldo", "USDC e USDT abaixo do stake"

    corpo = {"referenceId": item["_ref"], "currency": moeda, "stake": f"{stake:.2f}",
             "acceptPartialStake": True,
             "priceChange": {"value": "BETTER", "slippageToleranceRatio": str(DERIVA_MAX)},
             "selection": {"eventId": evento, "marketUrl": url, "price": str(preco)}}
    desde = _iso_margem(30)   # janela para reconhecer esta tentativa na casa
    # segunda cinta de idempotência, no lugar do chute: a trava por chave
    # (postas_api.json) cai quando o mesmo lance volta com outra chave ou depois de
    # um "ausente" cedo demais — em 16/11 foram 233,34 cravados duas vezes com 61 s.
    # O certo é perguntar à casa se a seleção já está lá antes de cravar.
    ja = _confere_casa(evento, url, stake, desde, tentativas=1)
    if ja and ja not in ("ausente", "indefinido"):
        item["_bet"] = ja
        marca_posta(item.get("chave") or "")
        return "repetida", f"ja existe na casa ({ja})"
    st, resp = api("/v4/bets/place/straight", corpo, "POST")
    estado = str(resp.get("state") or "")
    if st == 403:
        return "erro_linha", "HTTP 403 no /v4/bets (WAF): nada cravado"
    if _perdida(st):
        # resposta sem veredito: nunca recrava as cegas — a aposta pode ter entrado
        return _resposta_perdida(item, corpo, evento, url, preco, stake, desde, moeda)
    if st in (200, 201) and estado in ("ACCEPTED", "PENDING_ACCEPTANCE"):
        item["_bet"] = str(resp.get("betId") or "")
        marca_posta(item.get("chave") or "")
        if estado == "ACCEPTED":
            return "feita", f"ACCEPTED {moeda} {stake:.2f} @ {preco}"
        # PENDING sem debito no saldo e aceite nao confirmado: medido aqui, a casa
        # segura o lance e o extrato so lista liquidada, entao o saldo e a prova
        antes = caixa
        for _ in range(8):
            time.sleep(5)
            if antes - round(sum(saldo(m) for m in MOEDAS), 2) >= stake * 0.9:
                return "feita", f"confirmada pelo saldo {moeda} {stake:.2f} @ {preco}"
        # soltar a chave sem conferir era outro caminho do par: confere na casa
        achado = _confere_casa(evento, url, stake, desde)
        if achado and achado not in ("ausente", "indefinido"):
            item["_bet"] = achado
            return "feita", f"aceite pendente confirmado na casa {moeda} {stake:.2f} @ {preco}"
        if achado == "ausente":
            desmarca_posta(item.get("chave") or "")
            return "aceite_pendente", f"PENDING sem debito e sem aposta na casa: solta {moeda} {stake:.2f}"
        return "aceite_pendente", f"PENDING sem debito e casa ilegivel: chave travada {moeda} {stake:.2f}"
    sel = resp.get("selection") or {}
    codigo = sel.get("rejectionCode") or resp.get("status") or resp.get("texto") or f"HTTP {st}"
    if codigo == "STAKE_ABOVE_MAX" and sel.get("stake"):
        corpo["stake"] = str(sel["stake"])
        corpo["referenceId"] = str(uuid.uuid4())
        st, resp = api("/v4/bets/place/straight", corpo, "POST")
        if _perdida(st):
            # reoferta também pode perder a resposta; antes caía em "recusado" e
            # a aposta podia ter entrado (chave solta, linha volta e dobra)
            return _resposta_perdida(item, corpo, evento, url, preco,
                                     float(corpo["stake"]), desde, moeda)
        if st in (200, 201) and resp.get("state") in ("ACCEPTED", "PENDING_ACCEPTANCE"):
            item["_bet"] = str(resp.get("betId") or "")
            marca_posta(item.get("chave") or "")   # sem isto a linha volta e crava de novo
            return "feita", f"reoferta {corpo['stake']} @ {preco}"
        codigo = (resp.get("selection") or {}).get("rejectionCode") or codigo
        return "recusado", str(codigo)
    if codigo == "PRICE_ABOVE_MARKET" and sel.get("price"):
        # pedimos melhor que a casa no instante anterior: se o preco novo ainda paga
        # a tolerancia, reoferta pelo preco dela em vez de perder a linha
        novo = float(sel["price"])
        if _paga(novo, item):
            corpo["selection"]["price"] = str(novo)
            corpo["referenceId"] = str(uuid.uuid4())
            st, resp = api("/v4/bets/place/straight", corpo, "POST")
            if _perdida(st):
                return _resposta_perdida(item, corpo, evento, url, novo,
                                         float(corpo["stake"]), desde, moeda)
            if st in (200, 201) and resp.get("state") in ("ACCEPTED", "PENDING_ACCEPTANCE"):
                item["_bet"] = str(resp.get("betId") or "")
                marca_posta(item.get("chave") or "")   # idem: reoferta tambem tem de travar
                return "feita", f"reoferta pelo preco da casa {corpo['stake']} @ {novo}"
            codigo = (resp.get("selection") or {}).get("rejectionCode") or codigo
        return "recusado", "PRICE_ABOVE_MARKET (%s)" % sel.get("price")
    return "recusado", str(codigo)


def rodada():
    if not os.path.exists(os.path.join(AQUI, "MODO_API.txt")):
        print("MODO_API.txt ausente — executor da API fica fora")
        return 0
    st, info = api("/v1/account/info", tempo=15)
    if st != 200:
        print(f"API recusou (HTTP {st}) — fila intocada")
        try:
            with open(os.path.join(AQUI, "api_estado.json"), "w", encoding="utf-8") as f:
                json.dump({"veredito": f"recusada:{st}", "quando": time.strftime("%Y-%m-%dT%H:%M:%S")}, f)
        except Exception:
            pass
        return 0
    caixa = avisa_saldo()
    print(f"caixa lido: {caixa:.2f}")
    fila = httponte("/fila?casa=cloudbet") or []
    if isinstance(fila, dict):
        fila = fila.get("fila") or []
    feitas = 0
    for item in fila[:LOTE]:
        if "cloudbet" not in str(item.get("casa") or "").lower():
            continue  # item de outra casa fica pendente para o executor dela
        estado, detalhe = processa(item)
        chave = item.get("chave", "")
        corpo_res = {"chave": chave, "estado": estado, "detalhe": detalhe,
                     "quando": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        if item.get("_bet"):
            corpo_res["bet_id"] = item["_bet"]
        if item.get("href"):
            corpo_res["link_aposta"] = item["href"]
        if item.get("_liquidez"):
            corpo_res["liquidez"] = item["_liquidez"]
        if item.get("_adiada_ate"):
            corpo_res["adiada_ate"] = item["_adiada_ate"]
        httponte("/resultado", corpo_res)
        registra(item, estado, detalhe, item.get("_ref", ""))
        print(f"{estado:12} {item.get('aposta','')[:60]:60} {detalhe}")
        if estado == "feita":
            feitas += 1
            # registro próprio do aceite: a fila é limpa e a planilha não pode depender dela
            try:
                with open(os.path.join(AQUI, "apostas_feitas.jsonl"), "a", encoding="utf-8") as f:
                    f.write(json.dumps({
                        "chave": chave, "bet_id": item.get("_bet") or "",
                        "jogo": item.get("jogo") or "", "liga": item.get("liga") or "",
                        "aposta": item.get("aposta") or "", "odd": item.get("odd"),
                        "preco": item.get("_preco"), "stake": item.get("stake_final") or item.get("stake"),
                        "justa": item.get("justa"), "ev": item.get("ev"),
                        "href": item.get("href") or "", "liquidez": item.get("_liquidez"),
                        "casa": item.get("casa") or "Cloudbet",
                        "quando": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, ensure_ascii=False) + "\n")
            except Exception:
                pass
        if estado == "sem_saldo":
            break
    print(f"rodada: {feitas} cravadas de {len(fila)} na fila")
    if feitas:
        # a planilha pessoal tem de refletir o aceite sem depender de aba: o
        # espelho roda aqui, com trava e no máximo a cada 20 s
        try:
            import espelha
            espelha.atualiza(20)
        except Exception as e:
            print("espelho nao atualizado: %s" % e)
    return feitas


if __name__ == "__main__":
    if "--loop" in sys.argv:
        while True:
            rodada()
            time.sleep(int(sys.argv[sys.argv.index("--loop") + 1]))
    else:
        rodada()
