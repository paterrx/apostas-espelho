"""Precificador de prop. Uso:

  python preco.py --jogo "Boston Celtics" --fora "New York Knicks" --jogador "Anunoby" \
                  --prop steals --linha 1.5 --lado under --odd 1.53 [--torneio 132] [--time away]

Saida: justa por sharp (devig Shin na propria linha, interpolando entre linhas
vizinhas), justa estatistica dos ultimos 10 jogos, justa final conservadora,
edge e veredito com stake.

Regras travadas:
 - minimo 2 sharps na mesma linha -> edge >= 3 pontos, stake cheia
 - 1 sharp + estatistica          -> edge >= 5, stake pela metade
 - so estatistica                 -> edge >= 8, stake pela metade
 - odd fora de 1,50-4,60 nao entra (teto de mercado e devig inflado)
 - stake cai com a odd: 20 ate 3,0 | 15 ate 4,5 | 10 acima
"""
import argparse, sys, time
import fontes, estatistica, shin

STAKE = 20.0


def stake_por_odd(odd):
    if odd <= 3.0:
        return STAKE
    if odd <= 4.5:
        return STAKE * 0.75
    return STAKE * 0.5


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--torneio", default="132")
    p.add_argument("--jogo", required=True)
    p.add_argument("--fora", required=True)
    p.add_argument("--jogador", required=True)
    p.add_argument("--prop", required=True, choices=list(fontes.PROPS))
    p.add_argument("--linha", type=float, required=True)
    p.add_argument("--lado", choices=["over", "under"], required=True)
    p.add_argument("--odd", type=float, required=True, help="odd da soft")
    p.add_argument("--time", default="home", choices=["home", "away"])
    p.add_argument("--abbr", required=True, help="abreviacao ESPN do time do jogador (ex.: ny)")
    a = p.parse_args()

    casa, fora = (a.jogo, a.fora) if a.time == "home" else (a.fora, a.jogo)
    fxs = fontes.fixture_ids(a.torneio, casa, fora)
    if not fxs:
        fx = fontes.fixture_id(a.torneio, casa, fora)
        if not fx:
            sys.exit("jogo nao encontrado no torneio %s" % a.torneio)
        fxs = [fx]
    print("fixtures", ",".join(fxs))

    est = estatistica.prob(a.prop, a.linha, a.lado, a.jogador, a.abbr)
    media_alvo = est.get("media")
    dados = fontes.mercados(fxs, a.torneio, prop=a.prop, media_alvo=media_alvo,
                            sobrenome_alvo=fontes.sobrenome(a.jogador))
    alvo = fontes.norm(a.jogador)
    sob = fontes.sobrenome(a.jogador)

    justas = []
    print("\nsharp              linha  margem    justa   p_%s" % a.lado)
    for b, jogadores in dados.items():
        for jog, linhas in jogadores.items():
            if sob not in fontes.norm(jog):
                continue
            pts = []
            for linha, par in sorted(linhas.items()):
                if not par.get("over") or not par.get("under"):
                    continue
                po, pu, _ = shin.shin([par["over"], par["under"]])
                pts.append((linha, po, shin.margem([par["over"], par["under"]])))
            if not pts:
                continue
            p = fontes.p_em([(l, po) for l, po, _ in pts], a.linha)
            ajustada = False
            if p is None and len(pts) == 1 and est.get("mu"):
                # sharp com uma linha so: mantem o nivel dele e ajusta pela
                # inclinacao do modelo ate a linha da soft
                l_sharp, p_sharp = pts[0][0], pts[0][1]
                p_mod_alvo = estatistica.p_over(a.prop, a.linha, a.jogador, a.abbr)
                p_mod_sharp = estatistica.p_over(a.prop, l_sharp, a.jogador, a.abbr)
                if p_mod_alvo is not None and p_mod_sharp is not None:
                    p = min(max(p_sharp + (p_mod_alvo - p_mod_sharp), 0.02), 0.98)
                    ajustada = True
            if p is None:
                continue
            if a.lado == "under":
                p = 1 - p
            if p <= 0.001:
                continue
            mesmo = [m for l, _, m in pts if abs(l - a.linha) < 1e-9]
            marg = min(mesmo) if mesmo else None
            justas.append({"book": b, "jog": jog, "p": p, "odd": 1 / p, "margem": marg,
                            "exato": marg is not None, "ajustada": ajustada})
            print("  %-16s %5.1f  %s  %8.3f  %.4f%s" % (b, a.linha, ("%5.2f%%" % (marg * 100)) if marg is not None else "  int. ", 1 / p, p,
                                                        "" if marg is not None else ("  (curva)" if ajustada else "  (interpolada)")))

    odd_est = est.get("odd")
    if odd_est:
        print("  %-16s %5.1f  %5s  %8.3f  %.4f   %s" % ("ESTATISTICA(10j)", a.linha, "-", odd_est, est["p"],
                                                      ",".join(est["avisos"]) or "ok"))

    n_sharp = len(justas)
    cand = [j["odd"] for j in justas] + ([odd_est] if odd_est else [])
    if not cand:
        sys.exit("sem referencia de preco")
    justa = max(cand)                      # mais conservador
    edge = (a.odd / justa - 1) * 100
    fonte = [j["book"] for j in justas if abs(j["odd"] - justa) < 1e-9]

    if n_sharp >= 2:
        minimo, fator = 3.0, 1.0
    elif n_sharp == 1:
        minimo, fator = 5.0, 0.5
    else:
        minimo, fator = 8.0, 0.5
    if all(j["ajustada"] for j in justas) and justas:
        fator = min(fator, 0.5)

    print("\njusta final %.3f  (%s)   odd soft %.3f   EDGE %+.2f%%" % (justa, ",".join(fonte) or "estatistica", a.odd, edge))
    motivos = []
    if n_sharp < 2:
        motivos.append("so %d sharp" % n_sharp)
    if a.odd < 1.50:
        motivos.append("odd < 1,50")
    if a.odd > 4.60:
        motivos.append("odd > 4,60")
    if edge < minimo:
        motivos.append("edge < %.0f%%" % minimo)
    if motivos:
        print("VEREDITO: PASSA (%s)" % "; ".join(motivos))
        return
    print("VEREDITO: APOSTA  stake R$ %.0f  (limite do mercado confere antes de cravar)" % (stake_por_odd(a.odd) * fator))


if __name__ == "__main__":
    main()
