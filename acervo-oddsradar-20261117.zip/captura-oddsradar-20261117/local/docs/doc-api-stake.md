# API da Stake: o que existe, como foi provado e o que falta

Levantado em 16/11/2026 na aba da stake.com (região US, página anônima) e
confirmado com curl/página. Nada aqui é suposição sobre o schema: cada campo
listado foi executado e devolveu 200.

## Endpoint e autenticação

- `POST https://stake.com/_api/v1/graphql` (é o endpoint do próprio site; o
  antigo `/_api/graphql` também responde).
- Header `x-access-token: <token>` — token de conta, criado em
  Settings → Security → API Tokens. O cofre guarda o bom em
  `STAKE_SPORTS_API_KEY`; o `STAKE_API_KEY` está vencido e devolve "sua sessão
  expirou".
- Prova de identidade: `query { user { id name } }` devolve
  `{"id":"cd0ad98e-…","name":"paterra"}` com o token bom.
- Introspecção está desligada (Cosmo Router). Campo inexistente devolve
  `Cannot query field …`; argumento faltando devolve `argument: X is required`.
  Foi assim que o schema foi mapeado.

## Leitura (passa do IP da VPS)

- Saldo: `query B { user { balances { available { amount currency } } } }` —
  a conta tem só `usdc`, 498,83.
- Limite por aposta: `info { currencies { name sportBetMin { value } betMax { value } } }`
  — usdc mínimo 0,009, máximo 250.000.000.
- Partida por slug: `slugFixture(fixture: "<slug>") { id name }`.
- Mercados: `sportFixture(fixtureId: <uuid>) { groups { name templates { name markets { name specifiers outcomes { id name odds active } } } } }`
  — **`SportFixture.markets` está bloqueado por região** (`permissionFlag`); o
  caminho é `groups → templates → markets → outcomes`.
- Prop de jogador: o grupo não vem em `groups` sem filtro. Tem de ser pedido pelo
  nome: `groups(groups: ["playerProps"])`. O app pede exatamente esse valor.
- Apostas ativas: `user { activeSportBets(limit, offset) { id active amount currency bet { iid } outcomes { odds } } }`
  — `bet.iid` é o identificador de conferência (`sport:<n>`).
- Resultado de um mercado: `sportMarketOutcome(outcomeId, provider: betradar)`.

## Escrita (barrada pelo IP da VPS)

```
mutation SportBetMutation($amount: Float!, $currency: CurrencyEnum!,
  $outcomeIds: [String!]!, $oddsChange: SportOddsChangeEnum!,
  $identifier: String, $betType: SportBetTypeEnum!) {
  sportBet(amount: $amount, currency: $currency, outcomeIds: $outcomeIds,
           oddsChange: $oddsChange, identifier: $identifier, betType: $betType) {
    id amount currency payoutMultiplier outcomes { odds outcome { name } }
  }
}
```

- `outerIds` é lista; uma seleção simples é `[id]` e `betType: "sports"`
  (`esports` para esporte eletrônico).
- `identifier` é livre e serve de idempotência (a casa devolve
  `DUPLICATE_REQUEST` na repetição).
- Chamada real com `0.05 usdc` em Coritiba 1x2 (odd 3.25) devolveu:
  `errors: [{ message: "We do not operate in this country.",
  errorType: "locationBanned" }]` e `data: null`.
- Ou seja: a mutação é **validada** (schema, moeda, stake, mercado) e só cai na
  checagem de geolocalização do backend. Não é Cloudflare, não é chave, não é
  mercado fechado.

## Consequência de desenho

1. Leitura funciona da VPS; **aposta precisa do IP residencial**. O relé
   (`saida_relay.py`, 127.0.0.1:1081) é o caminho, e o navegador precisa sair por
   ele (`--proxy-server=http://127.0.0.1:1081`), senão o cookie de Cloudflare não
   casa com o IP.

### Transporte que funciona (testado em 16/11/2026)

- Túnel **HTTP** do cloudflared **não serve**: o Cloudflare responde
  `400 Bad Request` ao `CONNECT` de um proxy. Túnel `tcp://` também não se
  alcança direto com TLS.
- O caminho que funciona: no PC `cloudflared --url tcp://127.0.0.1:1081`; aqui
  `cloudflared access tcp --hostname <url do túnel> --url 127.0.0.1:1083`; o relé
  aponta para `127.0.0.1:1083` e é ele quem leva o token.
- Sem cookie de Cloudflare a API responde a página `stake-errors.pages.dev/
  ip-blocked`, mesmo de IP residencial. O navegador de saída (Edge com
  `--proxy-server`) resolve isso porque pega o cookie válido para o IP.
- Quem injeta é `abre_stake_api.py` (CDP): abre o Edge no relé, navega e aplica
  `stake_api_pronto.js`. A porta 1083 é fixa, então troca de URL do túnel exige
  só reiniciar o `cloudflared access`, nunca a aba.
- Prova: aposta real de 0,05 USDC aceita (id `aa9fc333-…`, `iid sport:693591058`,
  `status confirmed`, saldo caiu exatamente 0,05).
2. A página pode ficar **anônima**: o token no header basta. Sem login, sem 2FA,
   sem CAPTCHA — some o que antes prendia o executor à máquina do dono.
3. O executor vive na aba e usa GraphQL, sem clique: `executor_stake_api.js`,
   montado por `injeta_stake_api.py` (token vem do cofre na hora) e servido pela
   ponte em `/js/stake_api_pronto.js`.
4. Queda de IP não é recusa: o executor devolve `sem_saida`, que `regras.retentar`
   reavalia como gate (sem gastar tentativa) e o coletor já nem enfileira Stake
   com a saída fria (`casas_saida_pc`/`saida_pc_min`).
5. Não ligar dois donos: com o executor de API ativo, o `executor_stake_casa.js`
   (clique) deve ficar fora da injeção.

## Provado e não provado

- Provado: schema, saldo, mercados (inclusive resolve do outcome por slug +
  mercado + lado + linha + odd para um jogo real — Coritiba), autenticação,
  recusa de escrita por IP e o estado `sem_saida` chegando à ponte.
- Não provado: **aceite de verdade** (depende do IP do PC), liquidez por linha do
  prop da Stake, `maxStake` por resultado e o comportamento do prop em jogo ao
  vivo. Prop de NBA só abriu perto do horário — o jogo testado (Boston × Orlando,
  17/11 00:00 GMT) ainda não tinha preço no momento deste levantamento.

## Pendências para ligar

1. PC rodando `saida_pc.py` + `cloudflared --url http://127.0.0.1:1081` e o
   endereço do túnel em `saida-pc-url.txt` (hoje o arquivo aponta para
   `127.0.0.1:1082`, teste local, por isso a saída ainda é o IP da VPS).
2. Navegador da VPS lançado com `--proxy-server=http://127.0.0.1:1081` e perfil
   próprio; aí o batimento de saída fica fresco e o coletor volta a enfileirar
   Stake.
3. Primeira aposta real pequena, conferida em `activeSportBets` e no saldo.

## Limitar menos: o que a praça diz e o que fazemos

Relato consistente em fóruns (r/Stake, vários tópicos de "maximum limit"): a
casa corta por **comportamento de ganhador**, começa pelos mercados de **prop** e
por liga menor, o limite **varia por esporte e por odd** (odd baixa aceita mais) e
o corte costuma ser **reversível** com o tempo ou com perda — não é ban. Um
relato cita teto de US$ 10 mil em prop no nível platina e US$ 1.000 em esporte
depois de limitado.

Prática adotada:

- **Mercado de jogo primeiro** (1x2, Asian Handicap, Asian Total, Winner); prop
  entra, mas é o último a valer a pena e o primeiro a morrer.
- Nada de exótico (placar exato, escanteios) enquanto houver jogo disponível.
- Espalhar em vez de empilhar: poucas linhas por evento, vários eventos.
- Pedir bem abaixo do máximo da linha (a casa negocia pelo tamanho).
- Manter cadência humana: cap por rodada e pular parte das batidas.

O mapa do coletor passou a incluir os mercados de jogo para a Stake
(`STAKE_MERCADO`, 17 chaves). O executor resolve o time pela `aposta` da seleção,
porque o lado `casa/fora` não traz nome.

Medir o limite por mercado na conta exige escrita, e escrita exige o túnel do PC
ligado — a leitura de odds não devolve limite (`SportMarketOutcome` não expõe
máximo) e a página anônima não mostra o "Max" do betslip.

## Correção de 17/11/2026: o grupo de prop e a hora

- `groups(groups: ["playerProps"])` volta **vazio**; o grupo certo é **`players`** (e o
  prop de futebol vem em `goalscorers`, que já aparece sem filtro). Medido no
  Coritiba × Santos: `players` devolveu 7 templates com "Luan Peres 1+ @ 13".
- **Prop morre no apito inicial**: 45 min depois do início o grupo volta vazio, e no
  basquete ele nem existe 13 h antes. Só há prop na janela perto do jogo.
- Por isso: `regras.aplicar` recusa prop com `prop_fechado` (epoch vem do slug), a
  fila não reentrega prop depois do início e o coletor exige 25 min de folga para
  prop da Stake.
- O casador procura o jogador no mercado **ou no resultado** e não exige
  over/under quando o resultado não traz ("1+", "2+").
