# API oficial da Cloudbet — contrato pronto (chave era a velha, não a casa)

**RESOLVIDO EM 16/11/2026: o 401 nunca foi defeito da casa.** Havia duas chaves diferentes:
a do cofre (`CLOUDBET_API_KEY`, 737 bytes) responde **200** em `/v1/account/info`; a cópia em
texto puro em `chave-api.txt`, de mesmo tamanho e hash diferente, é que estava revogada. O
`chaves.ler` estourava `FileNotFoundError` quando faltava um nome e o `except` do executor
caía no `chave-api.txt` — por isso todo 401 parecia credencial recusada pela casa. Correções
de 16/11: `chaves.ler` filtra os caminhos existentes antes de ordenar; o txt velho virou
`chave-api.txt.velho-20261116`; o executor da API autentica e lê saldo (nada cravado, fila
bloqueada por teto). O histórico abaixo fica como estava, para não reescrever o que se pensou.

Estado em 11/11/2026, 05:35 UTC (02:35 BRT). Escrito porque o achado é caro de redescobrir.

## O que existe

A Cloudbet tem API oficial de negociação (trading), distinta do caminho que o
`executor5.js` usa hoje (token do Firebase da sessão da página). A chave fica em
Conta > Preferências > "Chave da API" e é um JWT de longa duração
(`access_tier: trading`, validade até 2036).

- Chave guardada em `chave-api.txt` (segredo; não colar em chat nem em tabela).
- Header: `X-API-Key`. Base: `https://sports-api.cloudbet.com/pub`.
- Conta: `GET /v1/account/info`, `GET /v1/account/currencies`,
  `GET /v1/account/currencies/{moeda}/balance`.
- Linha: `POST /v2/odds/lines` com `{eventId, marketUrl}` — devolve `price`,
  `maxStake`, `minStake` e `status`. Aqui está o ganho real: liquidez medida.
- Cravar: `POST /v4/bets/place/straight` com
  `{referenceId, currency, stake, acceptPartialStake, priceChange{value,slippageToleranceRatio}, selection{eventId,marketUrl,price}}`.
  `referenceId` é idempotência: repetir a mesma aposta exige UUID novo.
- Recusas vêm em `selection.rejectionCode`: `PRICE_ABOVE_MARKET`,
  `STAKE_ABOVE_MAX` (com `reofferStake`), `STAKE_BELOW_MIN`,
  `INSUFFICIENT_FUNDS`, `LIABILITY_LIMIT_EXCEEDED`, `DUPLICATE_REQUEST`.
- `GET /v4/bets` lista apostas: serve para conferir o que foi aceito.

## O defeito

A chave é recusada com **HTTP 401 "invalid api key"** em todo endpoint — feed,
conta e apostas —, inclusive por `curl` e pelo próprio navegador com o contrato
exato do swagger da casa. O token está íntegro: três segmentos, assinatura de 342
caracteres (256 bytes, RS256), payload legível, `sub` igual ao uuid da conta.

Testado e descartado: anular e gerar de novo (a casa devolve o mesmo `jti`, então
a chave emitida em 29/09 é a vigente), variantes de header (`Authorization:
Bearer`, `x-api-key`), `Content-Type`, `User-Agent`, `Origin`, e o host
alternativo `api.cloudbet.com` (301). Sem chave alguma a resposta é a mesma, ou
seja, o erro é de credencial, não de rota.

Suspeita principal: a chave de assinatura (kid `HKp92…`) saiu do conjunto que o
IAM da casa aceita, e o botão "Gerar chave" devolve o token guardado em vez de
emitir um novo. É problema do lado deles.

## Ferramentas prontas

- `sonda_api.py` — bate nos quatro endpoints e grava `api_estado.json` com o
  veredito. Rodar de novo é o teste de "já consertaram": `VEREDITO=ok` libera.
- `executor_api.py` — executa o ciclo pela API (cota, compara preço, respeita
  `maxStake`, crava com `BETTER` + 2% de escória, trata reoferta). Enquanto a
  chave estiver morta ele **não toca na fila**: sai antes de consumir, para não
  roubar item do executor da página. `--loop 20` roda em série.

## Protocolo aberto (11/11/2026, 05:45 UTC)

Ticket enviado no chat de suporte da casa com o uuid da conta, o horário de
emissão da chave e a lista de endpoints e variantes já testadas. A resposta
automática do suporte empurrou para o fórum de discussões da API no GitHub
(`github.com/Cloudbet/docs/discussions`), que é onde a engenharia deles responde.

Falta: publicar o caso no fórum. `gh` está logado como `paterrx`, mas o token é
de GitHub App e não tem permissão de escrita em discussions (`FORBIDDEN`), e o
navegador não está logado no GitHub. Texto pronto do post em `ticket-cloudbet.md`.

## Regra de convivência

Um dono por vez. Enquanto `executor5.js` estiver ativo na aba, o
`executor_api.py` só entra depois de parar o da aba (e vice-versa), senão os dois
cravarão a mesma linha — a dedupe do vigia não cobre dois executores.
