# Precificador de prop — regras travadas

Motor de preço para prop de jogador. Cada número sai de fonte medida, não de opinião.

## Como roda

```
python preco.py --jogo "New York Knicks" --fora "Milwaukee Bucks" \
  --jogador "Anunoby" --prop steals --linha 1.5 --lado under --odd 1.80 \
  --abbr ny --time home
```

Saída: justa por sharp (devig Shin na própria linha), justa estatística dos últimos
10 jogos, justa final e veredito com stake. `--odd` é a odd da soft, lida na tela.

## De onde vem cada número

| Prop | Pinnacle | FanDuel | Fanatics | DraftKings | Camada estatística |
|---|---|---|---|---|---|
| pontos, rebotes, assistências, PRA, 3 pontos | sim | sim | sim | sim | apoio |
| roubo, block, roubo+block, ponto+assist, ponto+reb | **não** | sim | sim | sim | obrigatória |

Medido em 10/11: a Pinnacle lista 5 tipos de prop; roubo, block e as combinações
não existem nela. Nessas, o preço vem de duas casas de margem e o modelo
estatístico entra como terceira opinião, com stake pela metade.

A Cloudbet **não entrega prop pela API** (24 mercados por jogo, nenhum de jogador).
Prop no lado da soft é sempre leitura de tela.

## Cruzamento de linha

Só se compara linha com linha. A justa de um lado em L sai da curva do sharp
avaliada em L, interpolada entre as linhas vizinhas cotadas — nunca misturando
12,5 de um lado com 13,5 do outro. Entre sharps na mesma linha vale a **maior**
odd justa (probabilidade menor): o preço mais conservador.

Limite honesto do feed: cada casa manda **uma** linha por prop no NBA, então
quase sempre não há linha vizinha. Nesse caso a justa é deslocada do nível do
sharp para a linha da soft pela inclinação do modelo, o CLI marca `(curva)` e a
stake cai para metade. A etiqueta de linha carrega ±1 ponto de incerteza.

## Camada estatística

- Últimos 10 jogos, da ESPN; média encolhida em direção à média da temporada do
  próprio jogador (ou à de liga, quando há menos de 15 jogos).
- Binomial negativa, nunca Poisson puro: roubo, block e rebote são
  superdispersos e Poisson erra as caudas.
- A odd estatística **nunca** substitui a sharp por ser melhor; entra como a
  mais conservadora das duas (a maior odd).
- Avisos automáticos: menos de 18 minutos por jogo, menos de 8 jogos, zerado na
  amostra.

## Regras de entrada

| Situação | Edge mínimo | Stake |
|---|---|---|
| 2 ou mais sharps na mesma linha | 3% | cheia |
| 1 sharp + estatística | 5% | metade |
| só estatística | 8% | metade |
| justa por curva (sem linha vizinha) | 3% | metade |

Fora de 1,50–4,60 de odd não entra: abaixo é devig inflado, acima o teto de
responsabilidade da casa estoura. Stake cheia é 20; de 3,0 a 4,5 cai para 15;
acima disso, 10.

## Frescor do dado

O feed da Pinnacle via OddsPapi observa a mudança em 0,46 s (p50), mas **a
página só devolve preço vivo**: 88% dos preços com menos de 10 minutos de idade
batem com a Pinnacle ao vivo; acima de 60 minutos, só 10%. Portanto:

- `changedAt` com mais de 10 minutos = preço velho, reconferir antes de cravar.
- Nas 5 props que a Pinnacle cota, a API pública dela responde de graça e manda
  `changedAt` próprio — usar ela como conferência.

## Limite de mercado e repetição

Limite baixo não impede a aposta, mas preço repetido piora. Em aposta a favor o
que está em risco é a **stake**; stake × (odd − 1) é o lucro. Em lay, na
exchange, aí sim vira responsabilidade. O teto do mercado é sempre medido em
responsabilidade.

- Repetir na mesma seleção: até **3 cravações**, a 2ª com metade da 1ª e a 3ª com
  metade da 2ª. Total nunca acima de 1,1× a stake base (base 20 → teto 22; a
  primeira já sai menor se a soma estourar).
- Só repete se o **edge ainda for ≥ 3 pontos contra a justa naquele momento**.
  Odd piorou 3 pontos desde a entrada = edge perto de zero, para.
- As 3 cravações contam como **uma** aposta na amostra das 270 do CLV; senão o
  intervalo fica estreito demais.
- Depois de cravar, reconferir o limite restante na tela.

## Fontes pagas: o que vale

- **Pinnacle direta (API pública, sem chave):** primária nas 5 props dela. Grátis.
- **OddsPapi:** necessária só para FanDuel, Fanatics e DraftKings. O plano free dá 250 requisições/mês — 8 por dia, não sustenta 10 apostas. O mínimo útil é US$ 27 (esportes) + FanDuel US$ 30 + Fanatics US$ 20 = US$ 77/mês, o que cobre 5 mil requisições. A Pinnacle aparece travada nos planos pagos: mais um motivo para não depender dela pelo agregador.
- **Pinnapi:** só se quiser empurrão de queda de preço (drops). A API pública da Pinnacle já entrega o mesmo dado sem chave.

## Concentração e stake no pipeline ao vivo

Estas valem no ciclo automático e são aplicadas **no servidor** (`regras.py`, chamado
pela ponte), não na página: script reinjetado zera estado e regra frouxa volta.
Configuração em `regras.json`.

| Regra | Padrão | Por quê |
|---|---|---|
| Teto de exposição do dia | 250% da banca | acima disso a casa dita o preço, não a régua |
| Teto por evento | 25% da banca e 6 apostas | 84 apostas em 6 jogos é uma aposta só, repetida; 4% travava o jogo inteiro em 3 props |
| Linha correlata (mesma pessoa, mesmo mercado, mesmo lado, total diferente) | 2ª a 50%, 3ª a 25%, 4ª recusa | 5,5 e 6,5 rebotes não são duas teses, são uma |
| Kelly | 1/4 sobre a justa do painel, preso entre 0,15% e 6% da banca | Kelly só **corta** stake; nunca infla acima da faixa |
| Base | 0,4% da banca | piso de sobrevivência a 68% de acerto |
| Stop do dia | perda **líquida** acima de 30% da banca (30u = 600) | dia ruim de 15u é normal; só trava com o dobro, e item travado volta quando o gate abre |
| Idade da linha | 10 minutos no painel | acima disso a justa é de outro preço |
| Degrau fraco (sem 3 fontes e sem outra casa) | só com EV ≥ 10% e stake 2 | é o degrau que pagou a conta até aqui |

Recusa sai com estado próprio (`cap_total`, `cap_evento`, `cap_linha`) e motivo
gravado no item — nenhuma linha é descartada em silêncio e todas voltam quando a
condição muda, exceto a quarta correlata, que é recusa definitiva.

### Critério de decisão (pré-registrado)

Com amostra pequena, decidir por impressão vira justificativa. Vale o combinado:
com 30 liquidadas por degrau, o degrau sem confirmação abaixo de −10% de ROI sai
de vez; o degrau com 3 fontes acima de zero sobe para stake cheia e o piso de EV
cai para 4%. Enquanto não houver 30 por faixa, nada muda.

A banca de `regras.json` é o **equity** (saldo livre + exposição aberta), não a
banca declarada: só o dinheiro que existe pode limitar.

## Limites conhecidos

- Prop na Cloudbet só pela tela; sem app lendo a tela, a odd entra à mão.
- A linha de uma prop não vem no feed das casas americanas: é reconstruída pelo preço e pela média. Erro de ±1 linha é possível e por isso existe o `(curva)` com metade da stake.
- Não há settlement nem CLV automáticos por prop ainda: fechamento de cada aposta é manual.


## Modo papel (12/11/2026)

Ligado por `"papel": true` em `regras.json`, com o pipeline rodando normal e
**nenhuma aposta cravada**. Motivo: ROI de −25,9% em 131 liquidadas com EV
invertido (faixa 10-15% pior que 5-7%), assinatura de régua errada, não de azar.

Como funciona:
- `GET /modo` devolve `papel`; os quatro executores param nele (JS e o da Magic).
- `papel.py` move o item pendente para `papel.json` com a stake que as regras
  já aplicaram e marca a fila como `papel` — nada é enviado à casa.
- `papel` conta em ABERTAS: o freio de exposição e o teto por casa valem igual,
  senão a simulação não vale.
- `liquida_papel.py` apura pelo placar e pela súmula da ESPN, 2h30 depois do
  início; grava `papel.csv` e tira o item das abertas (`papel_ganha` etc.).
- Item que não casar time/jogador em 48 h vira `papel_indefinido`, contado à
  parte e nunca escondido do ROI.
- `modo_papel.py` é o único processo do modo: produtores a cada 4 min, registro
  a cada 20 s, apuração a cada 5 min. A guarda de 5 min reinjeta os executores
  e reergue o daemon.

Medição: `PAPEL=1 python estudo.py` (lê `papel.json`). Voltar ao real é apagar
`papel` do `regras.json` — o resto do caminho já existe.

Valores definidos pelo Gabriel; confirmados em 16/11/2026.
