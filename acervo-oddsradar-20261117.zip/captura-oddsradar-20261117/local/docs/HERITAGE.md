# Heritage — casa de tela (construída 17/11/2026)

Conta 145993 (Gabriel). Domínio que funciona do Brasil: heritagesports.eu.
A bet105 (site novo da mesma gente) **bloqueia o Brasil**; o cadastro e a aposta
acontecem no domínio antigo.

## Como o executor funciona

- `roda_heritage.py` abre `https://ppm.heritage.linepros.com/live/?skin=dark#!/event/<evento>`
  no Edge de saída (CDP 9223) e injeta `executor_heritage.js` (servido em
  `/js/executor_heritage.js`, na lista `JS_PERMITIDOS` da ponte).
- O preço na tela é **odd americana** (`+116` / `-144`); o executor converte para
  decimal antes de comparar. Nunca comparar direto com `item.odd`.
- Espelho de mercado (`HERITAGE_MERCADO`, em `coleta_painel.py`) é por esporte:
  futebol `Match Result (3-way)` / `Handicap` / `Total` / `Draw No Bet`; hockey
  `Puck Line` / `Match Winner`; basquete e futebol americano `Spread` /
  `Game Winner`. Só **jogo inteiro** (`periodId` vazio, `m` ou `g`).
- O sinal da linha no painel é do lado `casa`; em `escolha=fora` o rótulo do site
  é o inverso — o executor inverte de propósito.
- Bilhete: seleção em `.bet-list .bet`, remoção em `button.bet__remove`, preço em
  `.bet-odd-value__odds`, stake em `.bet-input-selected input`. O bilhete
  **persiste entre cargas**: sempre limpar antes do item.
- `Use Free Play balance` (quando existe) é marcado antes de digitar a stake.

Sondas provadas em 17/11 04:5x: `Spread` fora `+14` → 1.806; `Total` menos 122,5
→ 1.820; `Game Winner` casa → 1.104.

## Bônus: o que os termos fazem com a conta

Depósito de US$ 400 virou 400 de saldo + **400 de free play** (100% de match).

- `Rollover $8.000` (10x de depósito + bônus), conforme o painel da conta.
- **Volume de free play NÃO conta** para o rollover (regra 11). O rollover tem de
  ser feito com dinheiro.
- Free play **não devolve a stake** (regra 13): o que entra é só o ganho, então o
  valor extraído é `face × p × (odd − 1)` — **não** `face × p × odd`. Números reais:
  a 1,5 dá US$ 133,33 (33,3% do face); a 2,0 dá US$ 200,00 (50%). A 1,5 rende 3×
  mais cash por unidade de variância, mas a 2,0 entrega US$ 66,67 a mais; fatiada em
  7 apostas de 60 o desvio cai de 200 para 75,59 (1,4% do equity), então **queime o
  free play a ~2,0 fatiado**, não a 1,4–1,7.
- O depósito fica **30 dias** (regra 2); o que dá para sacar antes disso são os
  ganhos, e só com rollover cumprido.
- Apostar os **dois lados do mesmo jogo** exclui as duas do rollover (regra 11).
- Quebrar o depósito em pelo menos 3 apostas relativamente iguais (regra 16).
- Acima de US$ 3.000 de ganho agregado a conta vira "house money" e não paga
  bônus/rebate (regra 15).
- Cláusula de jogador profissional/syndicate pode revogar bônus e ganhos
  (regras 6, 7 e 10, inclusive taxa de fechamento). É o risco de verdade.

## Risco do desenho (medido pelo Revisor 1)

- Rollover de 8.000 é **20× o depósito**: 134 apostas de 60 ou 320 de 25. Chance de
  zerar a carteira de 400 antes de fechar: 19% a 54% (stake 60) e 3% a 35% (stake 25)
  — estimativa browniana. Stake de 60 é 15% de uma carteira de 400.
- Se a tela pagar 2,5% menos que o painel (é o medido), o EV de tela é
  `(1 + EV) × 0,975 − 1`: 5% vira **2,375%** e fica negativo abaixo de 2,564%.
- Teto prático: **~1.000 na casa** (equivale a `dom_teto_casa` 0,067) e saque do
  ganho assim que o rollover fechar — a cláusula de jogador profissional alcança
  bônus e ganhos, não o dinheiro que já saiu.

## Sequência operacional

1. Queimar os 400 de free play (odd 1,4–1,7, stake alta) até virar cash.
2. Rodar o rollover de 8.000 com as apostas normais do pipeline.
3. Só então sacar; o depósito de 400 fica até 30 dias.

## Pendências

- Sessão logada **no Edge de saída** — feita em 17/11 05:0x; é dela que o executor depende.
- **Free play não é aplicado**: o aceite sai do caixa (AVAILABLE 400 → 379 → 356 nas
  duas apostas da auditoria) e o FP fica ocioso; o executor marca o toggle quando acha
  o controle e o detalhe sai como "fp?", mas a casa não trocou a modalidade. Próximo
  conserto antes de volume.
- **Saldo não é lido**: a superfície do executor é o frame do provedor, que não tem
  "AVAILABLE" (é do cabeçalho da página-mãe). `casas.Heritage` fica fixo até resolver.
- `MODO_HERITAGE.txt` criado; laço sob o guarda.
- Mínimo por aposta da casa ainda não medido (executor assume US$ 2 e corta no teto da
  linha).
- Mercados sem mapa que a casa tem em toda partida: totais de time, cantos, games de
  tênis, `jogo_empate_anula` e props. Ver `auditoria-heritage-2026-11-17.md`.

