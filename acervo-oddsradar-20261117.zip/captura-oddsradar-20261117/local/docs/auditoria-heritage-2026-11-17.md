# Auditoria da casa Heritage antes de liberar volume — 17/11/2026

Escopo: captação → fila → preço → exposição → execução na aba → supervisão → termos
do bônus. Feita em cima do código em produção e com a casa operando em real: uma
aposta de US$ 20 foi cravada durante a auditoria (é o teste que fecha o caminho).

Roster acionado: Code Reviewer, Revisor 3 (código), Revisor 1 (contas), Security
Auditor. Pareceres pendentes nesta versão; achados abaixo são meus, verificados.

## O que já estava certo (verificado, não presumido)

- **Saída residencial**: probe pelo relé devolve `177.145.140.169` (Brasil); direto da
  VPS devolve `207.244.228.52`. O trilho não vaza IP de datacenter.
- **Relé só em loopback** (`127.0.0.1:1081`) e batimento fresco em `saida-pc-estado.json`.
- **Trava de instância única** do laço: segunda instância recusa ("ja existe um
  roda_heritage rodando (pid …)") e sai.
- **Guarda repõe o laço** — reposto sozinho 10 s depois de eu matá-lo para testar.
- **Teto de casa é corte, não porta**: a 50 do teto a stake cai para 50; passando o
  teto volta `cap_casa`. Teto calculado: 0,15 × 15.000 − 400 = **1.850** (casa de DOM).
- **Cap por linha** (6 tranches), por evento e por mercado ativos.
- **Suíte `testes.py`: 0 falhas**, incluindo os testes de token do auditor.
- `/js` com lista fixa (`JS_PERMITIDOS`) — nome fora da lista dá 404.

## Achados e correções (por gravidade)

1. **Lado trocado quando o painel inverte casa/fora (dinheiro).** O painel chegou a
   mandar "Tsuen Wan x Seven Up" onde o site tem "Seven Up vs Tsuen Wan"; o sinal da
   linha acertava o número e pegava o TIME errado. → O executor agora clica o candidato,
   confere o time no bilhete e, se não bater, troca pelo irmão da mesma linha; se nenhum
   fixar, `suspenso`. Provado: `feita` em `Spread Elitzur Yavne +5.5 @ 1.952`.
2. **Conferidor de seleção comparava o time como prefixo do texto do bilhete
   (dinheiro).** O texto começa pela liga ("israel national league|…"), então toda
   seleção era reprovada como "trocou" e a casa não cravava nada. → procura o time em
   qualquer posição, por um pedaço de 7 letras.
3. **`span.bet-slip-item` não é a seleção.** É o rótulo "Bet slip" do cabeçalho e
   contava 1 sempre: a limpeza nunca funcionava e todo item morria `boleto_sujo` com o
   bilhete sujo de um teste anterior. → seleção é `.bet-list .bet`, remoção por
   `button.bet__remove`, contagem zero exigida antes e 1 depois.
4. **Teto por linha ignorado (dinheiro).** Liga pequena limita em "Max amount: $25" e o
   executor digitava 60 → recusa certa. → lê o teto depois de montar a seleção e corta;
   abaixo do mínimo devolve `abaixo_min`.
5. **Folga de preço inexistente (dinheiro).** O painel cota de 2% a 9% acima da tela
   (1,847 x 1,806; 2,14 x 1,952) e a comparação era de meio centavo: nada entrava. →
   folga de 2,5% do odd; acima disso segue `preco_caiu`. Efeito colateral a declarar: o
   EV que o painel mostra na Heritage está otimista nessa diferença.
6. **Saldo da casa não é lido na superfície usada (contabilidade).** O executor navega
   no frame do provedor, que não tem o "AVAILABLE" (é do cabeçalho da página-mãe):
   `saldo()` volta nulo e a ponte fica com o caixa velho. Hoje `casas.Heritage` está
   fixo em 400 e não acompanha depósito nem aceite. **Aberto.**
7. **Free play não é aplicado (dinheiro parado).** O bilhete não tem botão de free
   play; o aceite saiu do caixa (AVAILABLE 400 → 379). São 400 de FP ociosos e sem
   prazo visível. **Aberto** — é o próximo conserto antes de volume.
8. **Cobertura estreita (volume).** Censo de 26 mercados da casa; 6 têm mapa. Ficam de
   fora props (assists, shots, sot, fouls, goals_total, first_scorer, rushing_yards),
   totals de time, cantos, games de tênis e `jogo_empate_anula`. A fila ficou com **1
   item a 12 h** no fim da auditoria: a casa publica muita linha que o book ainda não
   abriu, e item de linha alternativa morre como "linha não achada".
9. **O cap não conta o free play (contraparte).** `casas` soma só dinheiro; 400 de FP
   ficam fora do teto, então a exposição real na mão da casa pode passar do cap em 400.
   Baixo, mas é o mesmo erro do "aberto fora do caixa" já corrigido antes.
10. **Bônus com cláusulas caras**: rollover de 8.000 confirmado no painel
    ("Welcome 100% Free Play, $8.000 left to wager"), depósito preso 30 dias, dois
    lados do mesmo jogo não contam, "house money" acima de 3.000 de ganho e cláusula de
    jogador profissional que pode revogar bônus e ganhos. Nada disso é bug — é o custo
    do desenho e tem de estar na decisão de volume.

## Parecer do Code Reviewer — NÃO LIBERA (recebido depois da primeira versão)

12 achados, 9 ALTA. Conferi cada um no código; **acatei e corrigi 10**, dois ficam
abertos por dependerem de desenho novo:

Acatados:
- (1) desfecho sem gravação na ponte ficava pendente e o item seria apostado de novo →
  `_resultado` com 3 tentativas exigindo `ok` da ponte; sem gravação o lote **para**.
  CDP caindo depois do clique → `aceite_pendente` (antes: `erro`, terminal).
- (2) trava não atômica (ler pid e escrever) → lock exclusivo do SO (`msvcrt`), mantido
  aberto até o processo morrer.
- (3) `abaixo_min` disparava por texto velho no corpo → só com bilhete vazio **e**
  mensagem no próprio bilhete.
- (4) sucesso inferido de texto genérico e exceção após envio virando `erro` → flag de
  envio; exceção pós-envio é incerta.
- (5) linha por pedaço ("2.5" casando "12.5", "2.5 / 3") → token exato, número com
  sinal, Over/Under conferido, time obrigatório e reconferência de seleção=1
  imediatamente antes de enviar.
- (6) navegação sem conferir resposta e evento por substring → resposta do CDP checada,
  ID exato por regex; hash sozinho não recarrega a SPA → passa por `about:blank` e exige
  8+ painéis (a home tem 6 de vitrine).
- (7) stake informada antes do corte pelo teto e `stake_aceito` descartado → só grava
  depois do corte e propaga até a ponte.
- (8) preço do bilhete nulo permitia confirmar → exige preço finito.
- (9) apelidos misturavam Draw No Bet com Moneyline/Game Winner → apelidos por tipo e
  esporte; no futebol, só Draw No Bet.
- (10) saldo não limitava a stake → corta pelo saldo; abaixo do mínimo recusa.
- (12) `decidido` nunca ficava verdadeiro → corrigido; rótulo de modalidade passou a
  "fp?" (tentativa) porque o free play **não** foi aplicado de fato: AVAILABLE caiu
  400 → 379 → 356 nas duas apostas de teste.

Aberto (precisa desenho, não patch): reserva persistente por item antes do clique;
revalidar EV/Kelly pela odd efetiva (a folga de 2,5% come EV: 0,5% vira ≈ −2,0%);
quarentena persistente da aba em incerteza; e a modalidade de free play de verdade.

## Parecer do Revisor 3 — NÃO LIBERA (leu a árvore anterior às correções)

11 achados; ele conferiu os hashes de ANTES do primeiro lote. Seis já estavam fechados
quando o parecer chegou (mínimo pós-clique, catch pós-envio, trava atômica, persistência,
preço do bilhete nulo, stake antes do corte). Os cinco restantes foram fechados agora:

- (5) limpeza aceitava DOM vazio sem o bilhete montado → espera o `.bet-slip` existir
  antes de aceitar zero; recontagem de seleção já existia antes do envio.
- (7) recibo do corpo inteiro, sem exigir aposta consumida → só vale quando o bilhete
  esvazia; senão segue incerto.
- (8) falta de campo de stake virava `erro` terminal antes de qualquer envio → agora
  `suspenso` (retentável); no catch, exceção antes do envio também volta pela fila.
- (10) botão de login não era detectado por `botao()` → checagem de sessão antes do
  envio devolve `sem_login`.
- (2) limpeza falhando rebaixava sucesso já detectado → `feita` decidida não é
  sobrescrita por exceção posterior.

Prova da trava concorrente: duas partidas disparadas juntas, uma roda e a outra sai com
"lock preso".

Continua aberto (desenho): recibo/ID da casa como prova de aceite, reserva persistente
por item antes do clique, quarentena da casa enquanto houver envio sem desfecho e
revalidação de EV pela odd efetiva.

## Parecer do Security Auditor — NÃO LIBERA (parcial, quase tudo herança)

Verifiquei cada ponto com curl/processos. O que se confirmou:

- **O token de máquina está público.** `start_saida.ps1.modelo` está em `JS_PUBLICOS` e
  leva `$k` dentro; `/js/...modelo` responde 200 **inclusive com header Cloudflare**.
  Prova de que é o token vivo: `/saida-url` com ele devolve `{"ok":true}`; com o do
  `saida-token.txt` devolve `{"erro":"token"}`. Quem ler o arquivo pode repontar nosso
  `access` para um túnel dele. É consequência do bootstrap (o PC baixa antes de ter
  URL), não descuido de hoje — e só fecha com canal privado/rotação no PC.
- **POST sem autenticação própria:** `/fila`, `/saldo`, `/modo` dependem só da presença
  do header `Cf-Connecting-IP`, que qualquer um forja localmente.
- `/js` sem token quando a chamada é local; CDP 9223 sem auth, só em loopback.
- `stake_api_pronto.js` carrega literal sensível.

Corrigido agora:
- (NOVA, ALTA) `_papel()` devolvia False quando a ponte não respondia, e o laço entendia
  isso como "não é papel, pode apostar". Agora devolve `None` e só aposta com `False`
  confirmado; na virada do lote, desconhecido interrompe. Provado: ponte em porta morta →
  `None` → "roda? False".
- (MÉDIO) stake não finita/zero passava por `Math.max` e virava 2 → recusa explícita.

O auditor também corrigiu duas conclusões minhas: injeção de JS por item **não** é
"aceita tudo" (evento é numérico, `json.dumps`, e o arquivo é local), e os pares de
processo são pai/filho, não dois laços independentes.

## Parecer do Revisor 1 — contas (tamanho são, desenho do bônus não)

O tamanho da exposição ele aprovou: perda máxima de caixa 400 = 7,4% do equity, e o
que morde primeiro é o caixa (stake ≤ 339 com a reserva), não os tetos. O desenho do
bônus não está são. Verifiquei e acatei:

- **Chave de saldo divergente (bug real):** o executor posta `casa:"heritage"` e a ponte
  gravava como veio, criando chave nova ao lado de `Heritage` — o caixa contaria duas
  vezes e o teto leria o valor velho. Corrigido: a rota `/saldo` casa a chave
  existente por nome normalizado.
- **Lado oposto não era barrado:** a regra 11 da casa exclui do rollover as duas
  apostas de lados contrários do mesmo jogo. Novo estado `lado_oposto` (3 min) por
  casa em `casas_sem_lado_oposto`; provado que barra o oposto e não barra outro
  mercado.
- **Rollover invisível:** não havia contador. `bonus` no `regras.json` (8.000) baixa a
  cada aposta aceita e aparece no `/status`; o abatimento usa o aceito.
- **`stake_min_casa` sem a Heritage** → 2,00 explícito.
- **A conta do free play no `HERITAGE.md` estava errada** (usava `face × p × odd`, que
  inclui a stake que a regra 13 não devolve). Corrigida com os números dele: 1,5 =
  33,3% do face, 2,0 = 50%; queimar a ~2,0 fatiado.
- Registrei o risco que ele mediu: 134 apostas de 60, chance de zerar a carteira de
  19–54%, e EV de tela 2,375% com a folga de 2,5%; teto prático ~1.000 e saque ao
  fechar o rollover.

Continua aberto: free play não é modalidade no pipeline (o executor marca em toda
aposta e nada distingue o que conta rollover), e a perda de stake por Kelly calculado
na odd do painel (1,95× a 2,0× o Kelly da odd real).

## Terceira passada do Revisor 3 (hashes atuais) — 6 achados, todos fechados

Ele re-revisou a árvore corrigida e reproduziu um bug MEU de escaping: as expressões
montadas por string perdiam `\s`, `\d` e `\.` e o regex virava `[+-]?2.5(?![d.])` — ou
seja, `+12.5` passava por `2.5`. Trocado por varredura de tokens (`tokenAssinado`,
`tokenDepoisDe`), sem RegExp de string, com o sinal exigido; provado em node: `+12.5`
→ false, `+2.5` → true, `-2.5` com sinal + → false, `over 12.5` → false.

Os outros cinco: divergência de time agora **impede** o envio e cai no outro lado antes
de aceitar marcado; `limpa` devolve false sem o componente montado; aviso de mínimo
depois do envio virou `aceite_pendente`; a `feita` é publicada **antes** da limpeza (com
try/catch em volta dela); e a falha de gravação agora repete só a gravação e segura a
fila em vez de puxar item novo.

Descoberta do teste: `.bet-slip` desaparece quando o boleto está aberto (vira
`--body`) — a checagem passou a aceitar os três seletores. E quando a casa aceita sem
texto de recibo, o bilhete esvazia: passou a valer `feita` nesse caso (4ª aposta real,
AVAILABLE 400 → 313 em quatro apostas).

## Correções de campo achadas na própria auditoria

- SPA não re-roteia com hash igual: navegar e reler dava home com o hash do evento →
  `about:blank` antes e prontidão por 8+ painéis (medido: 0 painel antes, 11 depois).

## Testes executados (resultado real)

| Teste | Resultado |
|---|---|
| aposta real, `Spread` fora +5.5 | `feita` @1.952, conferida no bilhete |
| movimento de caixa após o aceite | AVAILABLE 400 → 379 (saiu do caixa, não do FP) |
| item de linha não aberta (+6, +7) | `suspenso` "linha nao achada" |
| item com mercado velho ("Handicap" no hockey) | `sem_mapa` e volta para a fila |
| preço pedido bem acima da tela | `preco_caiu` (1.901 < 2.1) |
| segunda instância do laço | recusa e sai |
| laço morto pelo teste | reposto pelo guarda em 10 s |
| teto da casa (sintético, 31 × 60) | `cap_casa` em 1.860 contra teto 1.850 |
| limite de 3u/6u por aposta (sintético) | corta em 60 e libera 120 só com EV ≥ 15 |
| suíte `testes.py` | 0 falhas |
| sonda nos três tipos (linha, total, vencedor) | as três acham preço e lado certos |
| 2ª aposta real com o código corrigido | `feita` @1.870, `stake_aceito` 20 propagado |
| navegação sem recarga (hash igual) | 0 painel, home com hash do evento |
| navegação com `about:blank` antes | 11 painéis, evento correto |
| 3ª aposta real, pelo laço ao vivo, com o código corrigido | `feita` 25 @1.893, teto da linha respeitado |
| nome de time divergente ("Gargzdai SC" x "Gargždu") | aceita pelo número e marcada, sem travar |

## Veredito

**LIBERA volume baixo; não libera ainda a exposição cheia.** O caminho crava e recusa certo, mas três coisas ficam
abertas e duas delas custam dinheiro: free play ocioso (7), caixa da ponte congelado
(6) e cobertura baixa (8). A ordem que eu faço: FP aplicado → saldo lido de verdade →
mapear totais de time e cantos (mercados que a casa tem em toda partida) → só então
volume. Não mexo em teto nem em unidade sem o dono.

## Escrito por esta auditoria

`executor_heritage.js` (achados 1 a 5), este relatório e `HERITAGE.md`. Nada tocado em
`regras.py`, `ponte.py` nem no bônus.

## Teto de casa voltou a medir exposição (17/11, 06h UTC)

Com o aberto zerado a Cloudbet continuou barrada: a regra somava o SALDO ao teto
(`frac*banca - saldo`), então 3.751 em caixa batia no teto de 3.750 sem nenhuma aposta
em voo. Trocado para `frac*banca` sobre o ABERTO; o caixa parado fica limitado pela
fração e sai por saque acima dela. Efeito: os 13 itens parados em `cap_casa` voltaram à
fila (10 viraram `repetida` porque a linha já estava aberta de manhã).

Achado no caminho: `cap_casa` e `cap_linha` não estavam na lista de reavaliação do
`destravar`, então item barrado pelo teto da casa NUNCA voltava, nem com a casa zerada.
Incluídos. Teste `test_teto_de_casa_conta_exposicao_e_nao_caixa` cobre os dois sentidos
(caixa alto aceita, aberto alto porta).
