"""Retoma a captura onde parou: pula evento já baixado e faz jogadores e stream."""
import json, os, time, urllib.parse

import coleta_acervo as c

AQUI = c.AQUI

eventos = set()
try:
    for p in json.load(open(os.path.join(AQUI, "partidas.json"), encoding="utf8")):
        eventos.add(p.get("id"))
except Exception:
    pass
for arq in os.listdir(AQUI):
    if arq.startswith("grade_") and arq.endswith(".json"):
        try:
            d = json.load(open(os.path.join(AQUI, arq), encoding="utf8"))
        except Exception:
            continue
        for g in d.get("jogos") or []:
            eventos.add(g.get("evento"))

feitos = set()
for arq in os.listdir(os.path.join(AQUI, "cru")):
    if arq.startswith("api_odds-screen_jogo_"):
        feitos.add(arq.rsplit("_", 1)[-1].split(".")[0])

faltam = sorted(str(x) for x in eventos if x and str(x) not in feitos)
print("eventos:", len(eventos), "faltam:", len(faltam), flush=True)
for ev in faltam:
    c.j("/api/odds-screen/jogo/%s" % ev)

nomes = set()
for arq in os.listdir(os.path.join(AQUI, "cru")):
    if arq.startswith("grade_props_"):
        try:
            d = json.load(open(os.path.join(AQUI, "cru", arq), encoding="utf8"))
        except Exception:
            continue
        for g in d.get("jogos") or []:
            if g.get("jogador"):
                nomes.add(g["jogador"].split()[-1])
for nome in sorted(nomes):
    if not os.path.exists(os.path.join(AQUI, "cru", "api_props_buscar_q_" + urllib.parse.quote(nome) + ".bin")):
        c.j("/api/props/buscar?q=" + urllib.parse.quote(nome))

c.grava("manifesto_continua.json", c.MANIF)
print("TOTAL", c.N, flush=True)
