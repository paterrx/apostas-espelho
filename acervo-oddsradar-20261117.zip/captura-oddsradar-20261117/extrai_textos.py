import glob, re

palavras = re.compile("liquidez|justa|taxa|cobertura|regra|bolsa|clone|minima|fusao|apelido|reserva|vincul|sharp|copiar|steam|mexer|confian|arredond", re.I)
literal = re.compile(r'"([^"\\]{45,400})"|\'([^\'\\]{45,400})\'')
vistos, saida = set(), []
for a in glob.glob("cru/*.js"):
    s = open(a, encoding="utf8", errors="ignore").read()
    for m in literal.finditer(s):
        t = m.group(1) or m.group(2)
        if not palavras.search(t):
            continue
        if re.search(r"[{}<>]|function|className|var\(--", t):
            continue
        t = t.replace("\\n", " ").strip()
        if t in vistos:
            continue
        vistos.add(t)
        saida.append(t)
with open("textos-do-metodo.md", "w", encoding="utf8") as f:
    f.write("# Textos de regra e metodo no front do Odds Radar (17/11/2026)\n\n")
    for t in saida:
        f.write("- " + t + "\n")
print(len(saida))
