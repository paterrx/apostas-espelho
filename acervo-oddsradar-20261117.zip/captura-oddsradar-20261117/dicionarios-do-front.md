# Dicionários embutidos no front do Odds Radar (17/11/2026)

Extraídos do bundle. É o vocabulário do método deles.

## fonte oficial da taxa

```
fonteOficial:''
```
