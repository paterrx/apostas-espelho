"""Captura de tudo que o papel tipster enxerga no Odds Radar.

Salva cru, com manifesto (url, hora, bytes, sha256) e pausa entre chamadas.
Feito para rodar uma vez e virar acervo de estudo (catálogo de casamento).
"""
import hashlib, json, os, sys, time, urllib.error, urllib.parse, urllib.request

BASE = "https://crawler-odd-dashboard.hamjcl.easypanel.host"
SESSAO = os.environ["SESS"]
AQUI = os.path.dirname(os.path.abspath(__file__))
CRU = os.path.join(AQUI, "cru")
os.makedirs(CRU, exist_ok=True)

MANIF = []
N = 0


def pega(caminho, pasta="cru", nome=None, ms=45000, tent=4):
    global N
    url = BASE + caminho
    for t in range(tent):
        try:
            req = urllib.request.Request(url, headers={
                "Cookie": "dash_sessao=" + SESSAO,
                "Accept": "application/json",
                "User-Agent": "Mozilla/5.0",
            })
            with urllib.request.urlopen(req, timeout=ms / 1000) as r:
                corpo = r.read()
                code = r.status
            break
        except urllib.error.HTTPError as e:
            corpo = e.read()
            code = e.code
            if code in (429, 502, 503) and t < tent - 1:
                time.sleep(2 + 2 * t)
                continue
            if code >= 500 and t < tent - 1:
                time.sleep(1 + t)
                continue
            break
        except Exception:
            if t == tent - 1:
                raise
            time.sleep(1 + t)
    N += 1
    limpo = nome or (caminho.strip("/").replace("/", "_").replace("?", "_").replace("&", "_").replace("=", "-")[:120] or "raiz")
    caminho_disco = os.path.join(CRU, limpo if limpo.endswith((".json", ".html", ".js")) else limpo + ".bin")
    with open(caminho_disco, "wb") as f:
        f.write(corpo)
    MANIF.append({"url": caminho, "arquivo": os.path.relpath(caminho_disco, AQUI), "code": code,
                  "bytes": len(corpo), "sha256": hashlib.sha256(corpo).hexdigest(),
                  "em": time.strftime("%Y-%m-%dT%H:%M:%S")})
    print("%3d %s %7d %s" % (code, "OK " if code == 200 else "ERRO", len(corpo), caminho[:90]), flush=True)
    time.sleep(0.35)
    return code, corpo


def j(caminho, **kw):
    code, corpo = pega(caminho, **kw)
    if code != 200:
        return None
    try:
        return json.loads(corpo)
    except Exception:
        return None


def grava(nome, obj):
    p = os.path.join(AQUI, nome)
    with open(p, "w", encoding="utf8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    # 1) configuração e saúde — desenho do sistema
    for rota in ["/api/casas", "/api/labels", "/api/fontes/atraso", "/api/pinnacle/saude",
                 "/api/props/status?magro=1", "/api/stats", "/api/props/params",
                 "/api/ev/alertas", "/api/sistema/saude", "/api/props/ligas"]:
        j(rota)

    # 2) partidas — catálogo de evento/liga (all=1 traz tudo que o coletor viu)
    partidas = j("/api/props/partidas?all=1") or []
    grava("partidas.json", partidas)

    # 3) página e bundles (dicionários embutidos: classe de casa, mercado canônico, taxas)
    for rota, nome in [("/", "index.html"), ("/carimboSaude.js", "carimboSaude.js"),
                       ("/aparelho.js", "aparelho.js")]:
        pega(rota, nome=nome)
    html = open(os.path.join(CRU, "index.html"), encoding="utf8", errors="ignore").read()
    import re
    for m in re.findall(r'src="(/[^"]+\.js)"', html):
        pega(m, nome=m.strip("/").replace("/", "_"))

    # 4) grade por esporte e tipo, janelas curta e longa — odds, justa, liquidez, url de aposta
    esportes = ["tennis", "football", "basketball", "hockey", "esports", "volleyball",
                "handball", "cricket", "nfl", "mma", "boxing"]
    eventos = set()
    for tipo in ("jogo", "props"):
        for esporte in esportes:
            for horas in (24, 168):
                d = j("/api/odds-screen/grade?horas=%d&tipo=%s&esporte=%s" % (horas, tipo, esporte))
                if isinstance(d, dict):
                    for g in d.get("jogos") or []:
                        eventos.add(g.get("evento"))
                    grava("grade_%s_%s_%dh.json" % (tipo, esporte, horas), d)
    # grade sem filtro de esporte (visão agregada do que o painel conta)
    j("/api/odds-screen/grade?horas=24&tipo=jogo")
    j("/api/odds-screen/grade?horas=168&tipo=props")

    # 5) cada jogo, um a um — mercados canônicos, colunas, props e mapa casa->url
    for ev in sorted(x for x in eventos if x):
        j("/api/odds-screen/jogo/%s" % ev)

    # 6) jogadores vistos nos props: busca por sobrenome, para o catálogo de apelidos
    nomes = set()
    for arq in os.listdir(AQUI):
        if arq.startswith("grade_props_") and arq.endswith(".json"):
            try:
                d = json.load(open(os.path.join(AQUI, arq), encoding="utf8"))
            except Exception:
                continue
            for g in d.get("jogos") or []:
                if g.get("jogador"):
                    nomes.add(g["jogador"].split()[-1])
    for nome in sorted(nomes)[:120]:
        j("/api/props/buscar?q=" + urllib.parse.quote(nome))

    # 7) stream ao vivo por 45 s (fotografia do que chega)
    try:
        req = urllib.request.Request(BASE + "/api/ev/stream", headers={
            "Cookie": "dash_sessao=" + SESSAO, "Accept": "text/event-stream", "User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=60) as r:
            fim = time.time() + 45
            buf = []
            while time.time() < fim:
                linha = r.readline()
                if not linha:
                    break
                buf.append(linha.decode("utf8", "ignore"))
        with open(os.path.join(CRU, "stream_45s.txt"), "w", encoding="utf8") as f:
            f.writelines(buf)
        print("stream linhas:", len(buf), flush=True)
    except Exception as e:
        print("stream falhou:", e, flush=True)

    grava("manifesto.json", MANIF)
    print("TOTAL", N, "chamadas", flush=True)
