// =====================================================================
// EFEITO DAS OBSERVAÇÕES DE LIQUIDAÇÃO NO EV — uma regra só, usada pelo motor de EV (ev.js) e por todas as telas. [01/10]
//
// Pedido do Matheus: observação de liquidação não é só texto. Cada uma diz, POR LADO da aposta, o que a regra da casa
// faz contra a referência (Pinnacle). Quatro classes, nenhuma conta (decisão de 01/10: "não tente calcular"):
//   · sem_efeito — gatilho raro ou diferença sem peso (abandono aos 80 × 65 min): não vira alerta.
//   · a_favor    — a regra só pode melhorar o pagamento desse lado: selo verde; o EV mostrado é o MÍNIMO. EV e Kelly
//                  não mudam (é margem extra, não ação).
//   · contra     — a regra pode piorar esse lado: alerta laranja, EV e Kelly não mudam, o admin analisa. O robô não
//                  aposta.
//   · bloqueia   — a comparação não faz sentido (unidade diferente): o lado sai do EV (a EV+ esconde por padrão).
// Observação sem efeito cadastrado para a linha = "pendente": alerta como antes, e o robô não aposta.
//
// O efeito mira um mercado: '*' (todos os da observação), '@jogo' / '@jogador' (observação de casa inteira que só vale
// para mercados de jogo ou de jogador) ou o código do mercado. E um lado: '*', casa, fora, empate, mais, menos, sim, nao,
// nenhum. Procura do mais específico para o mais largo.
// =====================================================================
(function (raiz, fabrica) {
  const m = fabrica();
  if (typeof module === "object" && module.exports) module.exports = m;
  else raiz.LiqEfeito = m;
})(typeof self !== "undefined" ? self : this, function () {
  const CLASSES = ["sem_efeito", "a_favor", "contra", "bloqueia"];
  // [07/10] "favorito" (odd abaixo de 2,00 — preço acima de 0,50) e "azarao" (2,00 ou mais): efeito que depende do PREÇO, não do
  // lado. Polymarket em e-sports: W.O. antes do início liquida em 50/50 — quem comprou acima de 0,50 perde contra a anulação da
  // Pinnacle (contra); quem comprou abaixo ganha (a favor). Vale só na linha com odd conhecida; sem odd, cai no '*'.
  const LADOS = ["*", "casa", "fora", "empate", "mais", "menos", "sim", "nao", "nenhum", "favorito", "azarao"];
  const ladoDoPreco = odd => { const o = Number(odd); return Number.isFinite(o) && o > 1 ? (o < 2 ? "favorito" : "azarao") : null; };
  const ROTULO = { sem_efeito: "Sem efeito", a_favor: "A favor", bloqueia: "Bloqueia", contra: "Contra (alerta)", pendente: "Sem classificação" };
  // gravidade do resultado de uma linha (o pior decide o selo)
  const PESO = { sem_efeito: 0, a_favor: 1, contra: 2, pendente: 3, bloqueia: 4 };

  const norm = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const normCasa = s => norm(s).replace(/[^a-z0-9]+/g, "");
  // código do esporte da observação a partir do que a tela tem (código do registro ou o texto da casa)
  function esporteDe(s) {
    const t = norm(s);
    if (!t) return null;
    if (/futebol americano|american|nfl|ncaaf/.test(t)) return "nfl";
    if (/futebol|soccer|^football$/.test(t)) return "football";
    if (/basquete|basket/.test(t)) return "basketball";
    if (/tenis|tennis/.test(t) && !/mesa|table/.test(t)) return "tennis";
    if (/hoquei|hockey/.test(t)) return "hockey";
    if (/beisebol|baseball/.test(t)) return "baseball";
    if (/volei|volley/.test(t)) return "volleyball";
    if (/e-?sports?|cs2|dota|valorant|league of legends/.test(t)) return "esports";
    if (/mma|ufc|artes marciais/.test(t)) return "mma";
    if (/boxe|boxing/.test(t)) return "boxing";
    if (/handebol|andebol|handball/.test(t)) return "handball";
    if (/dardos|darts/.test(t)) return "darts";
    if (/criquete|cricket/.test(t)) return "cricket";
    if (/sinuca|snooker/.test(t)) return "snooker";
    return "outro";
  }
  // mercado de jogo/time ou de jogador (pelo código do cadastro)
  // [02/10] sem mercado (Super Odd que o catálogo não traduziu) o escopo é desconhecido: só vale o efeito de '*'. Antes
  // virava "@jogador" e a Super Odd de resultado recebia as regras de props (reserva que entra…)
  const escopoDe = mercado => (!mercado ? null : /^(jogo|time)_/.test(String(mercado)) ? "@jogo" : "@jogador");
  // lado da tela de props (over/under/yes/no) no código do catálogo
  const ladoDeProp = s => ({ over: "mais", under: "menos", yes: "sim", no: "nao" }[s] || s || "*");
  // classe gravada → classe válida (efeito antigo "calculo", de antes de 01/10, conta como contra)
  const classeDe = c => (c === "calculo" ? "contra" : CLASSES.includes(c) ? c : "pendente");

  // efeito da observação para (mercado, lado): do mais específico ao mais largo
  function efeitoPara(obs, mercado, lado, odd) {
    const ef = obs.efeitos || [];
    if (!ef.length) return null;
    const esc = escopoDe(mercado), l = lado || "*", p = ladoDoPreco(odd);
    const acha = (a, ld) => (a && ld ? ef.find(x => x.alvo === a && x.lado === ld) : null);
    return acha(mercado, l) || acha(mercado, p) || acha(mercado, "*") || acha(esc, l) || acha(esc, p) || acha(esc, "*")
      || acha("*", l) || acha("*", p) || acha("*", "*") || null;
  }

  // [06/10] PARTE DO JOGO NÃO HERDA A REGRA DO MERCADO INTEIRO. A observação de um mercado (código) fala do jogo inteiro
  // ("se o tenista desistir, o vencedor da PARTIDA é anulado"); o vencedor do 1º set, o total do 1º tempo ou o handicap
  // do 1º quarto são outra aposta. Na parte, o mercado vira "<código>@<período>": não casa observação nem efeito do código;
  // valem só as de casa inteira ('*') e as de escopo ('@jogo' / '@jogador'). Print do Matheus em 06/10 (Jogo de Ouro).
  const PERIODOS_INTEIRO = ["", "jogo", "jogo_pr"];
  const naParte = (mercado, periodo) => (mercado && periodo != null && !PERIODOS_INTEIRO.includes(String(periodo)) ? `${mercado}@${periodo}` : mercado);

  // [06/10] OBSERVAÇÃO SÓ ONDE ELA SE APLICA (pedido do Matheus: "por que uma obs de props aparece numa aposta que não é de
  // props?"). A Kalshi tinha "props de jogador: quem não entra liquida pelo preço justo" com efeito só para '@jogador'; no
  // vencedor do basquete nenhum efeito a cobria e a tela mostrava "Sem classificação". Regra única, para todas as telas:
  //   - observação COM efeitos vale só no mercado que algum efeito cobre ('*', o escopo do mercado ou o código dele);
  //   - observação SEM efeito (ainda não classificada) vale pelo texto: texto só de props (toda frase fala de jogador)
  //     vale só em mercado de jogador; texto misto ou de jogo vale em todos, como antes (na dúvida, aparece).
  const SO_JOGADOR = /\bprops?\b|de jogador|jogador(a|es)? (que|nao)|player|marcador|goleador|artilheiro|reserva que entra|titular|play or pay/;
  function escopoDoTexto(o) {
    const frases = String(o.texto || "").split(/ · |\. (?=[A-ZÁÉÍÓÚ(])/).map(norm).filter(Boolean);
    return frases.length && frases.every(f => SO_JOGADOR.test(f)) ? "@jogador" : null;
  }
  function cobre(o, mercado) {
    const esc = escopoDe(mercado);
    const ef = o.efeitos || [];
    if (ef.length) return ef.some(x => x.alvo === "*" || (esc && x.alvo === esc) || (mercado && x.alvo === mercado));
    const et = escopoDoTexto(o);
    return !et || et === esc;
  }

  // [29/10] REGRA PELO MERCADO DA CASA (decisão do Matheus, issue #117): a casa pode ter dois mercados dela que caem no MESMO
  // mercado nosso e liquidam diferente (Stake: "Anytime Goalscorer" [40], 90 min e reserva que entra vale; "Player goals (incl.
  // overtime)" [775], só titular e conta a prorrogação — os dois viram Gols 1+). O coletor mantém uma seleção só, a de maior odd,
  // e grava a grafia do mercado de onde ela veio (bruto.molde). A observação com molde_casa vale só quando a linha veio desse
  // mercado da casa; sem molde conhecido na linha (tela que não sabe de onde veio), vale toda observação — o pior caso.
  const normMolde = s => norm(s).replace(/\s+/g, " ").trim();
  const moldeBate = (o, molde) => !o.molde_casa || molde == null || normMolde(o.molde_casa) === normMolde(molde);

  // observações que valem para a linha: casa (qualquer nome que a tela tenha), mercado, esporte e mercado da casa
  function obsDaLinha(lista, casas, mercado, esporte, molde) {
    const ns = (casas || []).map(normCasa).filter(Boolean);
    if (!ns.length) return [];
    const e = esporteDe(esporte);
    return (lista || []).filter(o => ns.includes(o.casa_norm) && (o.mercado === "*" || (mercado && o.mercado === mercado)) && (!o.esporte || !e || o.esporte === e)
      && moldeBate(o, molde) && cobre(o, mercado));
  }

  /** Resultado para UMA linha (EV+, robô): classe final, o que cada observação fez e se o robô pode apostar. */
  function avaliaLinha(lista, { casas, mercado: m0, esporte, lado, periodo, odd, molde }) {
    const mercado = naParte(m0, periodo);
    const obs = obsDaLinha(lista, casas, mercado, esporte, molde);
    if (!obs.length) return null;
    const itens = [];
    let pior = "sem_efeito", aprovado = true;
    for (const o of obs) {
      const ef = efeitoPara(o, mercado, lado, odd);
      const classe = ef ? classeDe(ef.classe) : "pendente";
      if (!ef || !ef.aprovado) aprovado = false;
      if (PESO[classe] > PESO[pior]) pior = classe;
      itens.push({ id: o.id, casa: o.casa, mercado: o.mercado, texto: o.texto, fonte: o.fonte || null, classe, aprovado: !!(ef && ef.aprovado) });
    }
    // o robô só aposta com tudo classificado e aprovado, e nada contra ou bloqueando
    return { classe: pior, itens, apostavelAuto: aprovado && (pior === "sem_efeito" || pior === "a_favor") };
  }

  /**
   * Resumo sem a linha exata (cabeçalho de coluna, card de Super Odd): o pior efeito possível nas observações da casa
   * naquele mercado (e lado, quando a tela sabe). Só sem_efeito = nada a mostrar.
   */
  function resumo(lista, { casas, mercado: m0, esporte, lado, periodo, molde }) {
    const mercado = naParte(m0, periodo);
    const obs = obsDaLinha(lista, casas, mercado, esporte, molde);
    if (!obs.length) return null;
    let pior = "sem_efeito";
    const itens = [];
    // [02/10] sem lado (cabeçalho de coluna, card de Super Odd): o efeito de CADA lado, não só o pior — "a favor" no Mais e
    // "bloqueia" no Menos aparecia como "Bloqueia: este lado sai do EV" no cabeçalho da bet365 na tela de props
    const porLado = {};
    for (const o of obs) {
      let cls;
      if (lado) { const ef = efeitoPara(o, mercado, lado); cls = ef ? classeDe(ef.classe) : "pendente"; }
      else {
        const esc = escopoDe(mercado);
        const efs = (o.efeitos || []).filter(x => x.alvo === "*" || (esc && x.alvo === esc) || (mercado && x.alvo === mercado));
        cls = !efs.length ? "pendente" : efs.map(x => classeDe(x.classe)).reduce((a, c) => (PESO[c] > PESO[a] ? c : a), "sem_efeito");
        const ladosVistos = [...new Set(efs.map(x => x.lado).filter(x => x !== "*"))];
        const porLadoObs = {};
        for (const l of ladosVistos.length ? ladosVistos : ["*"]) {
          const ef = efeitoPara(o, mercado, l);
          const c = ef ? classeDe(ef.classe) : "pendente";
          porLadoObs[l] = c;
          if (!porLado[l] || PESO[c] > PESO[porLado[l]]) porLado[l] = c;
        }
        itens.push({ o, classe: cls, efeitos: o.efeitos || [], porLado: porLadoObs });
        if (PESO[cls] > PESO[pior]) pior = cls;
        continue;
      }
      if (PESO[cls] > PESO[pior]) pior = cls;
      itens.push({ o, classe: cls, efeitos: o.efeitos || [] });
    }
    // lado sem efeito próprio herda o '*' (o que vale para todos)
    if (porLado["*"]) for (const l of Object.keys(porLado)) if (l !== "*" && PESO[porLado["*"]] > PESO[porLado[l]]) porLado[l] = porLado["*"];
    const classesLados = [...new Set(Object.entries(porLado).filter(([l]) => l !== "*" || Object.keys(porLado).length === 1).map(([, c]) => c))];
    return { classe: pior, itens, porLado: lado ? null : porLado, varia: !lado && classesLados.length > 1 };
  }

  // texto curto de um efeito (tooltip e tela de cadastro)
  function descreveEfeito(ef) {
    const alvo = ef.alvo === "*" ? "" : ef.alvo === "@jogo" ? "mercados de jogo · " : ef.alvo === "@jogador" ? "mercados de jogador · " : ef.alvo + " · ";
    const lado = ef.lado === "*" ? "todos os lados" : ef.lado;
    return `${alvo}${lado}: ${ROTULO[classeDe(ef.classe)] || ef.classe}`;
  }

  return { ladoDoPreco, CLASSES, LADOS, ROTULO, normCasa, normMolde, esporteDe, escopoDe, ladoDeProp, classeDe, efeitoPara, obsDaLinha, avaliaLinha, resumo, descreveEfeito, naParte, cobre, escopoDoTexto };
});
