// =====================================================================
// [18/10] issue #127: PERGUNTA E CONFIRMAÇÃO DENTRO DA PÁGINA, NUNCA confirm()/prompt() DO NAVEGADOR.
//
// O navegador automatizado do auditor cancela sozinho todo diálogo nativo: no #119 (mescla de jogadores), no #125 ("Hora…")
// e no #127 ("É a mesma pessoa/clube que…" → clicar no que FICA não juntava Galli #4649884 em #2471073: o confirm() voltava
// false e a função saía calada). Eram 52 diálogos nativos no front (index.html 36 confirm + 11 prompt; props.jsx 4 + 1).
// Aqui fica a troca única: `await confirma(texto)` → true/false e `await pergunta(texto, padrao)` → texto ou null (como o
// prompt), num quadro desenhado na própria página. SEMPRE com await: a promessa sem await é "verdadeira" e gravaria sem
// perguntar (o test/dialogoNativo.test.js recusa as duas coisas).
// Carregado no index.html e por require nos testes.
// =====================================================================
(function (raiz) {
  /** Rótulos dos botões; `opcoes.sim`/`opcoes.nao` trocam o "Confirmar"/"Voltar". */
  const rotulos = (opcoes, comCampo) => ({
    sim: (opcoes && opcoes.sim) || (comCampo ? "OK" : "Confirmar"),
    nao: (opcoes && opcoes.nao) || (comCampo ? "Cancelar" : "Voltar"),
  });

  let fila = Promise.resolve();

  // um quadro por vez: o segundo pedido espera o primeiro ser respondido
  const abre = (texto, comCampo, padrao, opcoes) => {
    const vez = fila.then(() => new Promise((resolve) => {
      const doc = raiz.document;
      const r = rotulos(opcoes, comCampo);
      const fundo = doc.createElement("div");
      fundo.setAttribute("role", "dialog");
      fundo.setAttribute("aria-modal", "true");
      fundo.className = "dialogo-pagina";
      fundo.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;z-index:10000;padding:16px";
      const caixa = doc.createElement("div");
      caixa.style.cssText = "background:#fff;color:#1b1b1b;border-radius:12px;padding:18px 20px;max-width:560px;width:100%;box-shadow:0 10px 40px rgba(0,0,0,.25);font-size:14px;max-height:85vh;overflow:auto";
      const p = doc.createElement("div");
      p.style.cssText = "white-space:pre-wrap;line-height:1.45;margin-bottom:14px";
      p.textContent = String(texto == null ? "" : texto);
      caixa.appendChild(p);
      let campo = null;
      if (comCampo) {
        campo = doc.createElement("input");
        campo.className = "inp";
        campo.value = padrao == null ? "" : String(padrao);
        campo.style.cssText = "width:100%;box-sizing:border-box;margin-bottom:14px";
        caixa.appendChild(campo);
      }
      const linha = doc.createElement("div");
      linha.style.cssText = "display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap";
      const bNao = doc.createElement("button");
      bNao.className = "btn-sm";
      bNao.textContent = r.nao;
      const bSim = doc.createElement("button");
      bSim.className = "btn-sm b-green";
      bSim.textContent = r.sim;
      linha.appendChild(bNao);
      linha.appendChild(bSim);
      caixa.appendChild(linha);
      fundo.appendChild(caixa);
      const fecha = (valor) => { doc.removeEventListener("keydown", tecla, true); fundo.remove(); resolve(valor); };
      const sim = () => fecha(comCampo ? campo.value : true);
      const nao = () => fecha(comCampo ? null : false);
      const tecla = (e) => {
        if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); nao(); }
        else if (e.key === "Enter" && (comCampo || e.target === bSim || e.target === fundo || e.target === doc.body)) { e.preventDefault(); e.stopPropagation(); sim(); }
      };
      bSim.onclick = sim;
      bNao.onclick = nao;
      doc.addEventListener("keydown", tecla, true);
      doc.body.appendChild(fundo);
      (campo || bSim).focus();
      if (campo) campo.select();
    }));
    fila = vez.catch(() => {});
    return vez;
  };

  /** Pergunta sim/não. Devolve uma promessa de true (Confirmar) ou false (Voltar/Esc). */
  const confirma = (texto, opcoes) => abre(texto, false, null, opcoes);
  /** Pede um texto. Devolve uma promessa do texto digitado (OK/Enter) ou null (Cancelar/Esc), como o prompt(). */
  const pergunta = (texto, padrao, opcoes) => abre(texto, true, padrao, opcoes);

  const api = { confirma, pergunta, rotulos };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else { raiz.confirma = confirma; raiz.pergunta = pergunta; raiz.dialogo = api; }
})(typeof window !== "undefined" ? window : globalThis);
