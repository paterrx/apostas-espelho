(function (global) {
  "use strict";
  function daLinha(s, lado, linha) {
    const limiar = lado === "over" && linha != null && Number.isFinite(Number(linha)) ? Math.floor(Number(linha)) + 1
      : lado === "yes" && linha == null ? 1 : null;
    if (limiar === null || !Array.isArray(s?.rows)) return null;
    const amostras = [];
    for (const n of [10, 20]) {
      if (s.rows.length < n) continue;
      const jogos = s.rows.slice(0, n);
      if (jogos.some(j => j?.value == null || !Number.isFinite(Number(j.value)))) continue;
      const k = jogos.filter(j => Number(j.value) >= limiar).length;
      amostras.push({ n, k, p: k / n, odd: k ? Math.round(n / k * 1000) / 1000 : null });
    }
    const melhor = amostras.reduce((a, x) => x.odd !== null && (a === null || x.odd > a.odd) ? x : a, null);
    return { limiar, amostras, melhor };
  }
  const api = { daLinha };
  if (typeof module === "object" && module.exports) module.exports = api;
  else global.EstatisticaAmostra = api;
})(typeof window === "object" ? window : globalThis);
