















(function () {
  const { useState, useEffect, useMemo, useRef, useCallback } = React;

  const CSS = `
    .pp-wrap{display:flex;flex-direction:column;gap:14px}
    .pp-top{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
    .pp-src{display:flex;gap:6px;flex-wrap:wrap;align-items:center;font-size:12px;color:var(--ink-2)}
    .pp-src .pill{display:inline-flex;align-items:center;gap:5px;padding:4px 9px;border-radius:999px;background:var(--paper-2);border:1px solid var(--line)}
    .pp-src .pill.ok b{color:var(--up)} .pp-src .pill.warn b{color:var(--amber-deep)} .pp-src .pill.bad b{color:var(--down)}
    .pp-mkts{display:flex;gap:6px;flex-wrap:wrap}
    .pp-mkts button{border:1px solid var(--line-2);background:var(--card);color:var(--ink-2);padding:6px 11px;border-radius:999px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:var(--f-body)}
    .pp-mkts button.on{background:var(--navy-700);border-color:var(--navy-700);color:#fff}
    .pp-mkts button .n{opacity:.65;font-weight:500;margin-left:4px}
    .pp-filters{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end}
    .pp-filters .fg{display:flex;flex-direction:column;gap:4px}
    .pp-filters label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;color:var(--mut)}
    .pp-books{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
    .pp-books .grp{display:flex;gap:4px;flex-wrap:wrap;align-items:center;padding:4px 6px;border-radius:10px;border:1px dashed var(--line-2)}
    .pp-books .grp .gt{font-size:10.5px;font-weight:700;color:var(--mut);text-transform:uppercase;margin-right:2px}
    .pp-books .bk{border:1px solid var(--line-2);background:var(--card);padding:3px 8px;border-radius:999px;font-size:11.5px;cursor:pointer;font-family:var(--f-body);color:var(--ink-2)}
    .pp-books .bk.on{background:var(--primary-container);border-color:var(--primary);color:var(--primary)}
    .pp-books .bk.lnk{color:var(--primary);text-decoration:underline;border-style:dashed}
    .pp-tblwrap{border:1px solid var(--line);border-radius:14px;overflow:auto;background:var(--card);max-height:calc(100vh - 32px)}
    /* [11/11] a tabela rola por dentro com quase a altura da janela: o cabeçalho (casas) fica sempre à vista e o jogador preso à esquerda */
    .pp-lines{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
    .pp-lines .rot{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;color:var(--mut);margin-right:2px}
    .pp-lines button{border:1px solid var(--line-2);background:var(--card);color:var(--ink-2);padding:4px 10px;border-radius:999px;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--f-body)}
    .pp-lines button.on{background:var(--navy-700);border-color:var(--navy-700);color:#fff}
    .pp-lines button .n{opacity:.65;font-weight:500;margin-left:4px}
    .pp-nav{display:inline-flex;gap:4px;align-items:center}
    .pp-nav select{font-size:12.5px;max-width:340px;border:1px solid var(--line-2);border-radius:8px;padding:4px 6px;background:var(--card);color:var(--ink)}
    .pp-tbl thead th .fav{color:#c98a00;margin-right:2px}
    /* [11/11] a coluna Linha nunca fica estreita a ponto de cortar "Mais de 2,5" (vale também sobre a largura que a pessoa salvou) */
    .pp-tbl th.ln .pp-cw,.pp-tbl td.ln .pp-cw{min-width:112px}
    table.pp-tbl{border-collapse:separate;border-spacing:0;font-size:12.5px;min-width:100%}
    .pp-tbl th,.pp-tbl td{padding:6px 8px;border-bottom:1px solid var(--line);white-space:nowrap}
    .pp-tbl thead th{position:sticky;top:0;background:var(--paper-2);z-index:3;font-size:11px;font-weight:700;color:var(--navy-700);text-transform:uppercase;letter-spacing:.2px;text-align:center;border-bottom:1px solid var(--line-2)}
    .pp-tbl thead tr.grp th{top:0;background:var(--navy-800);color:#fff;font-size:10.5px;letter-spacing:.6px}
    .pp-tbl thead tr.bks th{top:0}
    .pp-tbl td.pl .pp-mg{margin-left:6px;border:1px solid var(--line-2);background:var(--card);color:var(--navy-700);border-radius:6px;font-size:11px;padding:0 5px;cursor:pointer;line-height:16px}
    .pp-lsel{font-family:var(--f-data);font-size:11.5px;border:1px solid var(--line-2);border-radius:6px;background:var(--card);color:var(--ink);padding:1px 2px;max-width:140px}
    .pp-tbl td.ln .fora{color:var(--amber-deep)}
    .pp-modal-bg{position:fixed;inset:0;background:rgba(10,20,30,.42);z-index:80;display:flex;align-items:center;justify-content:center;padding:16px}
    .pp-modal{background:var(--card);color:var(--ink);border-radius:14px;padding:16px 18px;width:min(760px,100%);max-height:88vh;overflow:auto;display:flex;flex-direction:column;gap:12px;box-shadow:0 18px 48px rgba(0,0,0,.28)}
    .pp-modal-h{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
    .pp-modal-h .t{font-weight:700;font-size:15px}
    .pp-modal-h .s{font-size:12px;color:var(--mut);margin-top:2px}
    table.pp-det{border-collapse:collapse;width:100%;font-size:12.5px}
    .pp-det th{text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.3px;color:var(--mut);padding:6px 8px;border-bottom:1px solid var(--line-2)}
    .pp-det td{padding:6px 8px;border-bottom:1px solid var(--line)}
    .pp-det td.casa{font-weight:600;vertical-align:top}
    .pp-det td.od{font-family:var(--f-data);font-variant-numeric:tabular-nums}
    .pp-det tr.usada td{background:rgba(15,157,110,.12)}
    .pp-graf svg{width:100%;height:auto;display:block}
    .pp-leg{display:flex;gap:10px;flex-wrap:wrap;font-size:11.5px;color:var(--ink-2);margin-top:4px}
    .pp-leg i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:4px;vertical-align:-1px}
    .pp-mlist{display:flex;flex-direction:column;gap:4px;max-height:46vh;overflow:auto}
    .pp-tbl thead th.grp-uk{background:#0A4E86}.pp-tbl thead th.grp-br{background:#0B7A88}.pp-tbl thead th.grp-bb{background:#6C3FC5}.pp-tbl thead th.grp-casa{background:#1B7F3B}.pp-tbl thead th.grp-bta{background:#E4572E}.pp-tbl thead th.grp-bm{background:#7A5195}.pp-tbl thead th.grp-rcb{background:#B8860B}.pp-tbl thead th.grp-blz{background:#C42B1C}.pp-tbl thead th.grp-pix{background:#0F7B6C}.pp-tbl thead th.grp-bes{background:#1F5FA8}.pp-tbl thead th.grp-vs{background:#8A6D1F}.pp-tbl thead th.grp-bgo{background:#5B3FA8}.pp-tbl thead th.grp-pa{background:#0F3D5E}
    .pp-tbl thead th.hs{color:var(--teal-deep)}
    .pp-tbl th.pl,.pp-tbl td.pl{position:sticky;left:0;z-index:2;background:var(--card);text-align:left;min-width:170px;font-weight:600;border-right:1px solid var(--line-2)}
    .pp-tbl thead th.pl{z-index:4;background:var(--paper-2)}
    .pp-tbl th.ln,.pp-tbl td.ln{position:sticky;left:170px;z-index:2;background:var(--card);text-align:left;min-width:128px;font-family:var(--f-data);font-size:11.5px;color:var(--ink-2);border-right:1px solid var(--line-2)}
    .pp-tbl thead th.ln{z-index:4;background:var(--paper-2)}
    .pp-tbl td.od{text-align:center;font-family:var(--f-data);font-size:12.5px;color:var(--ink);cursor:pointer}
    .pp-tbl td.od.best{background:rgba(15,157,110,.14);color:#0a6b4c;font-weight:700}
    .pp-tbl td.od.stale{color:var(--mut);opacity:.75}
    .pp-tbl td.od a{text-decoration:none;color:inherit;display:block}
    .pp-tbl td.od.empty{color:var(--line-2);cursor:default}
    .pp-tbl td.od .sx{font-size:8.5px;opacity:.55;margin-left:3px;vertical-align:top;font-family:var(--f-body)}
    .pp-tbl td.od .tam{font-size:9px;opacity:.6;line-height:1.1;font-family:var(--f-body);font-weight:400}
    .pp-tbl tr.sep td{border-top:2px solid var(--line-2)}
    .pp-tbl tr:hover td{background:var(--paper)}
    .pp-tbl tr:hover td.od.best{background:rgba(15,157,110,.22)}
    .pp-tbl td.best-col{text-align:center;font-family:var(--f-data);font-weight:700;color:var(--primary);border-right:1px solid var(--line-2);border-left:1px solid var(--line-2)}
    .pp-tbl th.best-col{border-right:1px solid var(--line-2);border-left:1px solid var(--line-2)}
    /* [19/09] melhor odd acima da maior odd justa: é o que vale apostar */
    .pp-tbl td.best-col.acima{background:#0f9d6e;color:#fff;border-radius:6px}
    .pp-brtag{display:inline-block;font-size:9px;font-weight:700;line-height:1.3;color:#0B7A88;border:1px solid currentColor;border-radius:3px;padding:0 3px;margin-left:4px;vertical-align:1px}
    /* [19/09] alça de redimensionar coluna (largura fica salva por usuário) */
    .pp-tbl thead th{position:sticky}
    .pp-rz{position:absolute;right:-4px;top:0;bottom:0;width:8px;cursor:col-resize;z-index:6;user-select:none}
    .pp-rz:hover,.pp-rz.on{background:rgba(15,157,110,.35)}
    .pp-tbl th.fixw,.pp-tbl td.fixw{overflow:hidden;text-overflow:ellipsis}
    .pp-cw{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0 auto}
    .pp-tbl td.pl .pp-cw,.pp-tbl th.pl .pp-cw,.pp-tbl td.ln .pp-cw,.pp-tbl th.ln .pp-cw{margin:0}
    .pp-tbl th.brcol{box-shadow:inset 0 -3px 0 #0f9d6e}
    .pp-tbl th.fair-col,.pp-tbl td.fair-col{min-width:91px;text-align:center;background:color-mix(in srgb,var(--amber) 10%,var(--card));border-bottom-color:color-mix(in srgb,var(--amber) 25%,var(--line))}
    .pp-tbl th.fair-col{background:color-mix(in srgb,var(--amber) 17%,var(--card));color:var(--ink-2);text-transform:none}
    .pp-tbl .fair-col.fair-first{border-left:3px solid color-mix(in srgb,var(--amber) 45%,var(--line))}
    .pp-tbl .fair-col.fair-last{border-right:3px solid color-mix(in srgb,var(--amber) 45%,var(--line))}
    .pp-tbl .fair-label{display:block;font-size:9px;font-weight:500;text-transform:uppercase;letter-spacing:.5px;color:var(--mut);margin-bottom:2px}
    .pp-tbl td.fair-col{font-family:var(--f-data);font-variant-numeric:tabular-nums;font-weight:600;color:var(--ink)}
    .pp-tbl tr:hover td.fair-col{background:color-mix(in srgb,var(--amber) 18%,var(--card))}
    .pp-tbl td.fair-col.missing{color:var(--mut);font-weight:400}
    /* [21/09] odd estatística (SofaScore): coluna própria, verde, separada das três justas por grupo de clones */
    .pp-tbl th.estat-col,.pp-tbl td.estat-col{min-width:91px;text-align:center;background:color-mix(in srgb,var(--up) 9%,var(--card));border-left:3px solid color-mix(in srgb,var(--up) 40%,var(--line));border-right:3px solid color-mix(in srgb,var(--up) 40%,var(--line))}
    .pp-tbl th.estat-col{background:color-mix(in srgb,var(--up) 16%,var(--card));color:var(--ink-2);text-transform:none}
    .pp-tbl td.estat-col{font-family:var(--f-data);font-variant-numeric:tabular-nums;font-weight:600;color:var(--ink)}
    .pp-tbl td.estat-col.clic{cursor:pointer}
    .pp-tbl tr:hover td.estat-col{background:color-mix(in srgb,var(--up) 18%,var(--card))}
    .pp-tbl td.estat-col.missing{color:var(--mut);font-weight:400}
    .pp-tbl .estat-frac{display:block;font-size:10px;font-weight:500;color:var(--mut);margin-top:1px}
    .pp-estat-form{display:flex;flex-direction:column;gap:10px;font-size:13px;color:var(--ink)}
    .pp-estat-form .campo{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
    .pp-estat-form .pp-inp{width:66px;min-width:0;text-align:center}
    .pp-estat-form .pp-chk{font-size:13px;color:var(--ink);padding:2px 0}
    .pp-estat-form small{display:block;color:var(--mut);font-size:11.5px;margin:-6px 0 0 24px;line-height:1.45}
    .pp-estat-acoes{display:flex;gap:8px;justify-content:flex-end}
    .pp-estat-res{text-align:center;border:1px solid var(--line);border-radius:10px;padding:12px;background:var(--paper-2)}
    .pp-estat-res .cap{font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:var(--mut);font-weight:700}
    .pp-estat-res .odd{font-size:34px;font-weight:800;color:var(--navy-700);font-variant-numeric:tabular-nums;line-height:1.15}
    .pp-estat-res .frac{font-size:13px;color:var(--ink-2)}
    .pp-estat-avisos{display:flex;flex-direction:column;gap:5px}
    .pp-estat-avisos div{border-radius:7px;padding:6px 9px;font-size:12px;border:1px solid var(--line);background:var(--paper-2);color:var(--ink-2)}
    .pp-estat-avisos div.warn{border-color:color-mix(in srgb,var(--amber) 45%,var(--line));background:color-mix(in srgb,var(--amber) 12%,var(--card));color:var(--ink)}
    .pp-det tr.miss td{color:var(--mut)}
    .pp-det td.ok{color:var(--up);font-weight:700;text-align:right} .pp-det td.no{color:var(--mut);font-weight:700;text-align:right}
    .pp-estat-flag{margin-left:3px;font-size:11px;cursor:help}
    .pp-fair-note{font-size:11.5px;color:var(--ink-2);display:flex;gap:10px;align-items:center;flex-wrap:wrap}
    .pp-fair-note button{border:0;background:none;color:var(--primary);text-decoration:underline;cursor:pointer;font:inherit;padding:0}
    .pp-fair-settings{margin:22px 0 14px}
    .pp-fair-settings h3{font-size:17px;color:var(--ink);margin:0 0 8px}
    .pp-fair-settings p{font-size:12px;color:var(--ink-2);line-height:1.6;margin:6px 0 12px}
    .pp-fair-summary{display:flex;gap:12px;flex-wrap:wrap;margin:10px 0 14px;font-size:12px;color:var(--ink-2)}
    .pp-fair-summary span{background:var(--paper-2);border:1px solid var(--line);border-radius:8px;padding:8px 11px}
    .pp-empty{padding:30px;text-align:center;color:var(--mut)}
    .pp-meta{font-size:11.5px;color:var(--mut);display:flex;gap:14px;flex-wrap:wrap;align-items:center}
    .pp-alert{display:flex;align-items:center;gap:8px;padding:10px 14px;border-radius:10px;font-size:12.5px;background:color-mix(in srgb,var(--amber) 12%,transparent);border:1px solid color-mix(in srgb,var(--amber) 40%,transparent)}
    .pp-alert.bad{background:color-mix(in srgb,var(--down) 10%,transparent);border-color:color-mix(in srgb,var(--down) 40%,transparent)}
    .pp-alert.ok{background:color-mix(in srgb,var(--up) 10%,transparent);border-color:color-mix(in srgb,var(--up) 35%,transparent)}
    .pp-inp{border:1px solid var(--line-2);border-radius:9px;padding:7px 10px;font-size:12.5px;font-family:var(--f-body);background:var(--card);color:var(--ink);min-width:150px}
    .pp-chk{display:inline-flex;align-items:center;gap:6px;font-size:12.5px;color:var(--ink-2);cursor:pointer;padding:6px 0;user-select:none}
    .pp-hist{position:fixed;z-index:50;background:var(--navy-900);color:#fff;border-radius:10px;padding:8px 10px;font-size:11.5px;box-shadow:0 8px 24px rgba(0,0,0,.25);max-width:280px}
    .pp-hist .h{font-family:var(--f-data);display:flex;justify-content:space-between;gap:10px}
    /* seletor de partidas */
    .pp-pick{display:flex;flex-direction:column;gap:10px}
    .pp-pick .bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
    .pp-pick .bar .q{flex:1;min-width:240px;position:relative}
    .pp-pick .bar .q .pp-inp{width:100%;padding-left:32px;box-sizing:border-box}
    .pp-pick .bar .q .ms-icon{position:absolute;left:9px;top:8px;font-size:18px;color:var(--mut)}
    .pp-pick .chips{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
    .pp-pick .chip{border:1px solid var(--line-2);background:var(--card);color:var(--ink-2);padding:5px 10px;border-radius:999px;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--f-body);display:inline-flex;align-items:center;gap:5px}
    .pp-pick .chip.on{background:var(--navy-700);border-color:var(--navy-700);color:#fff}
    .pp-pick .chip .n{opacity:.65;font-weight:500}
    .pp-pick .chip.src.on{background:var(--primary);border-color:var(--primary)}
    .pp-pick .sub{font-size:11px;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:.3px;margin-right:2px}
    .pp-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:8px;max-height:52vh;overflow:auto;padding-right:4px}
    .pp-list .it{border:1px solid var(--line);border-radius:12px;padding:10px 12px;background:var(--card);cursor:pointer;display:flex;flex-direction:column;gap:3px}
    .pp-list .it:hover{border-color:var(--primary)}
    .pp-list .it.on{border-color:var(--primary);box-shadow:0 0 0 2px var(--primary-container)}
    .pp-list .it .t{font-weight:600;font-size:13px;display:flex;justify-content:space-between;gap:8px}
    .pp-list .it .t .ko{font-family:var(--f-data);font-weight:600;color:var(--primary);font-size:12px;white-space:nowrap}
    .pp-list .it .s{font-size:11px;color:var(--mut);display:flex;gap:8px;flex-wrap:wrap}
    .pp-list .it .s b{color:var(--ink-2);font-weight:600}
    .pp-list .it .lg{font-size:11px;color:var(--ink-2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .pp-list .it .sx{display:inline-flex;gap:3px}
    .pp-list .it .sx span{font-size:9.5px;font-weight:700;padding:1px 5px;border-radius:5px;color:#fff;opacity:.35}
    .pp-list .it .sx span.on{opacity:1}
    .pp-list .it .sx .uk{background:#0A4E86}.pp-list .it .sx .br{background:#0B7A88}.pp-list .it .sx .bb{background:#6C3FC5}.pp-list .it .sx .cda{background:#1B7F3B}.pp-list .it .sx .rcb{background:#B8860B}.pp-list .it .sx .brs{background:#1F5FA8}
    .pp-day{font-size:11px;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:.4px;margin:6px 0 2px;grid-column:1/-1;position:sticky;top:0;background:var(--card);z-index:1;padding:2px 0}
    .pp-day .n{font-weight:500;opacity:.7;margin-left:6px;text-transform:none}
    .pp-busca{position:relative;z-index:30}
    .pp-busca .campo{display:flex;align-items:center;gap:8px;border:1px solid var(--line);border-radius:12px;padding:8px 12px;background:var(--card)}
    .pp-busca input{flex:1;border:0;outline:0;background:transparent;font-family:var(--f-body);font-size:13.5px;color:var(--ink);min-width:0}
    .pp-busca .lim{border:0;background:transparent;cursor:pointer;color:var(--mut);font-size:16px;line-height:1}
    .pp-busca .res{position:absolute;left:0;right:0;top:calc(100% + 4px);background:var(--card);border:1px solid var(--line);border-radius:12px;box-shadow:0 12px 32px rgba(10,20,30,.16);max-height:62vh;overflow:auto;padding:6px}
    .pp-busca .gr{font-size:10.5px;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:.4px;padding:6px 8px 2px}
    .pp-busca .it{display:block;width:100%;text-align:left;border:0;background:transparent;border-radius:9px;padding:7px 8px;cursor:pointer;font-family:var(--f-body)}
    .pp-busca .it:hover,.pp-busca .it.on{background:var(--bg-2,rgba(10,20,30,.05))}
    .pp-busca .it .n{font-size:13px;font-weight:600;color:var(--ink)}
    .pp-busca .it .s{font-size:11.5px;color:var(--mut);margin-top:1px}
    .pp-busca .it .mk{display:inline-flex;gap:6px;flex-wrap:wrap;margin-top:3px}
    .pp-busca .it .mk span{font-size:11px;border:1px solid var(--line-2);border-radius:999px;padding:1px 7px;color:var(--navy-700)}
    .pp-busca .vazio{padding:10px;font-size:12.5px;color:var(--mut)}
    .pp-busca .justa{font-size:11.5px;color:var(--navy-700);margin-top:3px}
    .pp-busca table.pj{border-collapse:collapse;margin-top:5px;font-size:11.5px;font-variant-numeric:tabular-nums}
    .pp-busca table.pj th{font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;color:var(--mut);text-align:right;padding:1px 10px 2px 0}
    .pp-busca table.pj th:first-child,.pp-busca table.pj td:first-child{text-align:left;min-width:150px;color:var(--ink)}
    .pp-busca table.pj td{text-align:right;padding:2px 10px 2px 0;color:var(--navy-700)}
    .pp-busca table.pj tr.val td b{color:#0b7a4b}
    .pp-busca table.pj td.k{color:#0b7a4b;font-weight:700;white-space:nowrap}
    .pp-busca .justa b{font-weight:700}
    tr.pp-foco td{background:rgba(16,140,90,.12)!important;transition:background .8s}
    .pp-selbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;border:1px solid var(--line);border-radius:12px;padding:8px 12px;background:var(--card)}
    .pp-selbar .t{font-weight:700;font-size:14px;color:var(--ink)}
    .pp-selbar .ln{font-size:12px;color:var(--mut)}
    .pp-selbar .sw{margin-left:auto;display:flex;gap:6px}
    .pp-selbar .sw button,.pp-btn{border:1px solid var(--line-2);background:var(--card);color:var(--navy-700);padding:6px 10px;border-radius:9px;font-size:12px;font-weight:600;cursor:pointer;font-family:var(--f-body);display:inline-flex;align-items:center;gap:4px}
    .pp-btn.pri{background:var(--navy-700);border-color:var(--navy-700);color:#fff}
    .pp-btn:disabled{opacity:.5;cursor:default}
    /* casas */
    .pc-wrap{display:flex;flex-direction:column;gap:14px}
    .pc-tbl{width:100%;border-collapse:collapse;font-size:12.5px}
    .pc-tbl th{background:var(--paper-2);text-align:left;padding:8px 10px;font-size:11px;font-weight:700;color:var(--navy-700);text-transform:uppercase;letter-spacing:.3px;border-bottom:1px solid var(--line-2);position:sticky;top:0;z-index:1}
    .pc-tbl td{padding:6px 10px;border-bottom:1px solid var(--line);vertical-align:middle}
    .pc-tbl tr.lk td{background:color-mix(in srgb,var(--up) 5%,transparent)}
    .pp-colsrc{display:block;font-size:9.5px;font-weight:600;opacity:.6;letter-spacing:.02em;text-transform:none}
    .pc-tbl .src{font-size:10px;font-weight:700;padding:2px 6px;border-radius:5px;color:#fff;display:inline-block}
    .pc-tbl .src.oc_uk{background:#0A4E86}.pc-tbl .src.oc_br{background:#0B7A88}.pc-tbl .src.bb{background:#6C3FC5}.pc-tbl .src.casa{background:#1B7F3B}.pc-tbl .src.betano{background:#E4572E}.pc-tbl .src.betmonitor{background:#7A5195}.pc-tbl .src.receba{background:#B8860B}.pc-tbl .src.blaze{background:#C42B1C}.pc-tbl .src.pixbet{background:#0F7B6C}.pc-tbl .src.betesporte{background:#1F5FA8}.pc-tbl .src.vivasorte{background:#8A6D1F}.pc-tbl .src.betgo{background:#5B3FA8}
    .pc-tbl .sug{font-size:11.5px;color:var(--teal-deep);cursor:pointer;text-decoration:underline dotted}
    .pc-tbl .sug.parcial{color:var(--amber-deep)}
    .pc-tbl select{max-width:260px}
    .pc-stats{display:flex;gap:14px;flex-wrap:wrap;font-size:12.5px;color:var(--ink-2)}
    .pc-stats b{color:var(--ink)}
    .pc-house{display:inline-flex;align-items:center;gap:6px}
    .pc-house img{width:18px;height:18px;border-radius:4px;object-fit:contain;background:#fff}
  `;
  if (!document.getElementById("pp-css")) {const st = document.createElement("style");st.id = "pp-css";st.textContent = CSS;document.head.appendChild(st);}

  const SRC = { oc_uk: { label: "OddsChecker UK", short: "UK", cls: "grp-uk" }, oc_br: { label: "OddsChecker BR", short: "BR", cls: "grp-br" }, bb: { label: "BetBurger", short: "BB", cls: "grp-bb" }, casa: { label: "Casa de Apostas", short: "CdA", cls: "grp-casa" }, betano: { label: "Betano", short: "Bta", cls: "grp-bta" }, betmonitor: { label: "Betmonitor", short: "BM", cls: "grp-bm" }, receba: { label: "Receba", short: "Rcb", cls: "grp-rcb" }, blaze: { label: "Blaze", short: "Blz", cls: "grp-blz" }, pixbet: { label: "Pixbet", short: "Pix", cls: "grp-pix" }, betesporte: { label: "BETesporte", short: "BEs", cls: "grp-bes" }, vivasorte: { label: "Viva Sorte Bet", short: "VS", cls: "grp-vs" }, betgo: { label: "BetGo", short: "BGo", cls: "grp-bgo" } };
  const SRC_IDS = ["oc_uk", "oc_br", "casa", "betano", "betmonitor", "receba", "blaze", "pixbet", "betesporte", "vivasorte", "betgo"];
  const SIDE_LBL = { over: "Mais de", under: "Menos de", yes: "Sim", no: "Não" };

  const linhaTxt = (v) => String(Number(v)).replace(".", ",");

  const nomeCasaFav = (n) => String(n || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s*·\s*via .*$/, "").trim();
  const lerFavs = () => {try {return new Set(JSON.parse(localStorage.getItem("os.favs") || "[]"));} catch (e) {return new Set();}};
  const fmtOdd = (v) => Number(v).toFixed(2);

  const usdP = (v) => {const n = Number(v);if (!isFinite(n)) return "";return "US$ " + (n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1).replace(".", ",") + " mil" : n < 10 ? n.toFixed(2).replace(".", ",") : Math.round(n));};
  const fmtKo = (ts) => {const d = new Date(ts);return d.toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "2-digit" }) + " " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });};
  const fmtHora = (ts) => new Date(ts).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  const dayKey = (ts) => new Date(ts).toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long" });
  const ymd = (ts) => fusoSP.diaSP(ts);
  const ago = (ts) => typeof timeAgo === "function" ? timeAgo(ts) : "";
  const lsGet = (k, d) => {try {const v = localStorage.getItem(k);return v == null ? d : JSON.parse(v);} catch {return d;}};
  const lsSet = (k, v) => {try {localStorage.setItem(k, JSON.stringify(v));} catch {}};
  const norm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  async function getJson(url, onRelogin) {
    const r = await fetch(url, { credentials: "include" });
    if (r.status === 401) {onRelogin && onRelogin("relogin");throw new Error("sessão expirada");}
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "HTTP " + r.status);
    return j;
  }
  async function postJson(url, body, onRelogin) {
    const r = await fetch(url, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
    if (r.status === 401) {onRelogin && onRelogin("relogin");throw new Error("sessão expirada");}
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "HTTP " + r.status);
    return j;
  }


  const DEF_PICK = { q: "", day: "all", hours: "all", srcs: [], sort: "kickoff", onlyOdds: true };
  function MatchPicker({ partidas, sel, onSel, pick, setPick }) {

    const days = useMemo(() => {
      const m = new Map();
      partidas.forEach((p) => {const k = ymd(p.kickoff);if (!m.has(k)) m.set(k, { k, ts: p.kickoff, n: 0 });m.get(k).n++;});
      return [...m.values()].sort((a, b) => a.ts - b.ts);
    }, [partidas]);
    const hoje = ymd(Date.now()),amanha = ymd(Date.now() + 86400e3);
    const dayLabel = (d) => d.k === hoje ? "Hoje" : d.k === amanha ? "Amanhã" : new Date(d.ts).toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "2-digit" });
    const leagues = useMemo(() => {const m = new Map();partidas.forEach((p) => {const l = p.league || "—";m.set(l, (m.get(l) || 0) + 1);});return [...m.entries()].sort((a, b) => b[1] - a[1]);}, [partidas]);

    const list = useMemo(() => {
      const q = norm(pick.q).trim();
      const toks = q.split(/\s+/).filter(Boolean);
      let rs = partidas.filter((p) => {
        if (pick.day !== "all" && ymd(p.kickoff) !== pick.day) return false;
        if (pick.hours !== "all") {
          const h = (fusoSP.partesSP(p.kickoff) || { hora: 0 }).hora;
          if (pick.hours === "manha" && !(h >= 6 && h < 12)) return false;
          if (pick.hours === "tarde" && !(h >= 12 && h < 18)) return false;
          if (pick.hours === "noite" && !(h >= 18 || h < 6)) return false;
          if (pick.hours === "prox3" && !(p.kickoff - Date.now() <= 3 * 3600e3)) return false;
        }
        if (pick.srcs.length && !pick.srcs.every((s) => Number(p["n_" + { oc_uk: "uk", oc_br: "br", casa: "casa", betano: "betano", betmonitor: "betmonitor", receba: "receba", blaze: "casasbr", pixbet: "casasbr", betesporte: "casasbr", vivasorte: "casasbr", betgo: "casasbr" }[s]] || 0) > 0)) return false;
        if (pick.onlyOdds && !(Number(p.n_odds) > 0)) return false;
        if (toks.length) {
          const hay = norm(`${p.home} ${p.away} ${p.league || ""}`);
          if (!toks.every((t) => hay.includes(t))) return false;
        }
        return true;
      });
      if (pick.sort === "odds") rs = rs.slice().sort((a, b) => Number(b.n_odds) - Number(a.n_odds) || a.kickoff - b.kickoff);else
      if (pick.sort === "books") rs = rs.slice().sort((a, b) => Number(b.n_books) - Number(a.n_books) || a.kickoff - b.kickoff);else
      if (pick.sort === "league") rs = rs.slice().sort((a, b) => String(a.league || "").localeCompare(String(b.league || ""), "pt-BR") || a.kickoff - b.kickoff);
      return rs;
    }, [partidas, pick]);

    const groups = useMemo(() => {
      const g = new Map();
      list.forEach((p) => {const k = pick.sort === "league" ? p.league || "—" : dayKey(p.kickoff);if (!g.has(k)) g.set(k, []);g.get(k).push(p);});
      return [...g.entries()];
    }, [list, pick.sort]);

    const P = (patch) => setPick((v) => ({ ...v, ...patch }));
    const toggleSrc = (s) => P({ srcs: pick.srcs.includes(s) ? pick.srcs.filter((x) => x !== s) : [...pick.srcs, s] });
    const limpar = () => P({ ...DEF_PICK });
    const ativo = pick.q || pick.day !== "all" || pick.hours !== "all" || pick.srcs.length || pick.sort !== "kickoff" || !pick.onlyOdds;
    const inputRef = useRef(null);
    useEffect(() => {if (inputRef.current) inputRef.current.focus();}, []);

    return React.createElement("div", { className: "pp-pick" },
    React.createElement("div", { className: "bar" },
    React.createElement("div", { className: "q" }, React.createElement(Ic, { n: "search" }), React.createElement("input", { ref: inputRef, className: "pp-inp", placeholder: "Buscar por time ou competição… (ex.: flamengo, libertadores, premier)", value: pick.q, onChange: (e) => P({ q: e.target.value }),
      onKeyDown: (e) => {if (e.key === "Enter" && list.length) onSel(list[0].id);if (e.key === "Escape") P({ q: "" });}, list: "pp-leagues" })),
    React.createElement("datalist", { id: "pp-leagues" }, leagues.slice(0, 60).map(([l]) => React.createElement("option", { key: l, value: l }))),
    React.createElement("div", { className: "sel-wrap" }, React.createElement("select", { className: "sel", value: pick.sort, onChange: (e) => P({ sort: e.target.value }) },
    React.createElement("option", { value: "kickoff" }, "Por horário"), React.createElement("option", { value: "league" }, "Por competição"), React.createElement("option", { value: "odds" }, "Mais odds"), React.createElement("option", { value: "books" }, "Mais casas")), React.createElement(Ic, { n: "arrow_drop_down" })),
    React.createElement("label", { className: "pp-chk" }, React.createElement("input", { type: "checkbox", checked: !pick.onlyOdds, onChange: (e) => P({ onlyOdds: !e.target.checked }) }), "incluir sem odds"),
    ativo ? React.createElement("button", { className: "pp-btn", onClick: limpar }, React.createElement(Ic, { n: "filter_alt_off" }), "limpar") : null
    ),
    React.createElement("div", { className: "chips" },
    React.createElement("span", { className: "sub" }, "Dia"),
    React.createElement("button", { className: "chip" + (pick.day === "all" ? " on" : ""), onClick: () => P({ day: "all" }) }, "Todos", React.createElement("span", { className: "n" }, partidas.length)),
    days.map((d) => React.createElement("button", { key: d.k, className: "chip" + (pick.day === d.k ? " on" : ""), onClick: () => P({ day: pick.day === d.k ? "all" : d.k }) }, dayLabel(d), React.createElement("span", { className: "n" }, d.n))),
    React.createElement("span", { className: "sub", style: { marginLeft: 8 } }, "Hora"),
    [["all", "Qualquer"], ["prox3", "Próximas 3h"], ["manha", "Manhã"], ["tarde", "Tarde"], ["noite", "Noite"]].map(([k, l]) => React.createElement("button", { key: k, className: "chip" + (pick.hours === k ? " on" : ""), onClick: () => P({ hours: k }) }, l)),
    React.createElement("span", { className: "sub", style: { marginLeft: 8 } }, "Com odds em"),
    SRC_IDS.map((s) => React.createElement("button", { key: s, className: "chip src" + (pick.srcs.includes(s) ? " on" : ""), onClick: () => toggleSrc(s), title: SRC[s].label }, SRC[s].short))
    ),
    !partidas.length ? React.createElement("div", { className: "pp-empty" }, "Nenhuma partida na janela. O coletor descobre as partidas das ligas a cada 2 h.") :
    !list.length ? React.createElement("div", { className: "pp-empty" }, "Nada bate na busca. ", React.createElement("a", { href: "#", onClick: (e) => {e.preventDefault();limpar();} }, "Limpar filtros")) :
    React.createElement("div", { className: "pp-list" },
    groups.map(([day, lst]) => React.createElement(React.Fragment, { key: day },
    React.createElement("div", { className: "pp-day" }, day, React.createElement("span", { className: "n" }, lst.length, " ", lst.length === 1 ? "jogo" : "jogos")),
    lst.map((p) => React.createElement("div", { key: p.id, className: "it" + (sel === p.id ? " on" : ""), onClick: () => onSel(p.id) },
    React.createElement("div", { className: "t" }, React.createElement("span", null, p.home || "?", " × ", p.away || "?"), React.createElement("span", { className: "ko" }, pick.sort === "league" ? fmtKo(p.kickoff) : fmtHora(p.kickoff))),
    React.createElement("div", { className: "lg", title: p.league || "" }, p.league || "—"),
    React.createElement("div", { className: "s" },
    React.createElement("span", { className: "sx" },
    React.createElement("span", { className: "uk" + (p.n_uk > 0 ? " on" : ""), title: `OddsChecker UK: ${p.n_uk} odds` }, "UK ", p.n_uk),
    React.createElement("span", { className: "br" + (p.n_br > 0 ? " on" : ""), title: `OddsChecker BR: ${p.n_br} odds` }, "BR ", p.n_br),
    React.createElement("span", { className: "cda" + (p.n_casa > 0 ? " on" : ""), title: `Casa de Apostas: ${p.n_casa || 0} odds` }, "CdA ", p.n_casa || 0),
    React.createElement("span", { className: "rcb" + (p.n_receba > 0 ? " on" : ""), title: `Receba: ${p.n_receba || 0} odds` }, "Rcb ", p.n_receba || 0),
    React.createElement("span", { className: "brs" + (p.n_casasbr > 0 ? " on" : ""), title: `Blaze + Pixbet + BETesporte + Viva Sorte + BetGo: ${p.n_casasbr || 0} odds` }, "BR ", p.n_casasbr || 0)
    ),
    React.createElement("span", null, React.createElement("b", null, p.n_books), " casas"),
    p.last_scan && React.createElement("span", null, "há ", ago(p.last_scan))
    )
    ))
    ))
    )
    );
  }


  const CORES = ["#0A4E86", "#E4572E", "#1B7F3B", "#7A5195", "#0B7A88", "#C08A00", "#B23A48", "#3F6C51", "#5B6770", "#8C4A2F"];
  function Grafico({ itens }) {
    const series = itens.map((i, n) => {
      const pts = (i.historico || []).map((h) => ({ t: Number(h.ts), v: Number(h.odds) }));
      if (!pts.length) pts.push({ t: i.mudou || i.capturada, v: Number(i.odds) });
      if (i.capturada > pts[pts.length - 1].t) pts.push({ t: i.capturada, v: Number(i.odds) });
      return { nome: `${i.casa} · ${i.fonteCurta}`, cor: CORES[n % CORES.length], pts: pts.sort((a, b) => a.t - b.t) };
    }).filter((sr) => sr.pts.length);
    const todos = series.flatMap((sr) => sr.pts);
    if (!todos.length) return null;
    const W = 680,H = 210,PL = 44,PR = 12,PT = 12,PB = 28;
    const t0 = Math.min(...todos.map((p) => p.t)),t1 = Math.max(...todos.map((p) => p.t));
    let v0 = Math.min(...todos.map((p) => p.v)),v1 = Math.max(...todos.map((p) => p.v));
    if (v1 - v0 < 0.1) {v0 -= 0.1;v1 += 0.1;}
    const x = (t) => PL + (t1 === t0 ? (W - PL - PR) / 2 : (t - t0) / (t1 - t0) * (W - PL - PR));
    const y = (v) => PT + (1 - (v - v0) / (v1 - v0)) * (H - PT - PB);
    const fmtT = (t) => new Date(t).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    const ticksT = t1 === t0 ? [t0] : [t0, t0 + (t1 - t0) / 2, t1];

    const degrau = (pts) => pts.map((p, j) => j === 0 ? `M${x(p.t)},${y(p.v)}` : `H${x(p.t)}V${y(p.v)}`).join("");
    return React.createElement("div", { className: "pp-graf" },
    React.createElement("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Histórico da odd por casa e fonte" },
    [v0, (v0 + v1) / 2, v1].map((v, i) => React.createElement("g", { key: i }, React.createElement("line", { x1: PL, x2: W - PR, y1: y(v), y2: y(v), stroke: "var(--line)" }), React.createElement("text", { x: PL - 6, y: y(v) + 4, textAnchor: "end", fontSize: "10", fill: "var(--mut)" }, v.toFixed(2)))),
    ticksT.map((t, i) => React.createElement("text", { key: i, x: x(t), y: H - 9, textAnchor: ticksT.length === 1 ? "middle" : i === 0 ? "start" : i === ticksT.length - 1 ? "end" : "middle", fontSize: "10", fill: "var(--mut)" }, fmtT(t))),
    series.map((sr, i) => React.createElement("g", { key: i }, React.createElement("path", { d: degrau(sr.pts), fill: "none", stroke: sr.cor, strokeWidth: "2" }), sr.pts.map((p, j) => React.createElement("circle", { key: j, cx: x(p.t), cy: y(p.v), r: "2.6", fill: sr.cor }))))
    ),
    React.createElement("div", { className: "pp-leg" }, series.map((sr, i) => React.createElement("span", { key: i }, React.createElement("i", { style: { background: sr.cor } }), sr.nome)))
    );
  }

  function CellModal({ alvo, onClose }) {
    const { cell, row, mkLabel } = alvo;
    const [det, setDet] = useState(null);
    useEffect(() => {
      let vivo = true;
      getJson("/api/props/detalhe?ids=" + (cell.ids && cell.ids.length ? cell.ids : [cell.id]).join(",")).then((d) => vivo && setDet(d)).catch((e) => vivo && setDet({ erro: e.message }));
      return () => {vivo = false;};
    }, [cell.id]);
    useEffect(() => {const k = (e) => {if (e.key === "Escape") onClose();};document.addEventListener("keydown", k);return () => document.removeEventListener("keydown", k);}, [onClose]);
    const itens = det && det.itens ? det.itens : [];
    const porCasa = new Map();
    itens.forEach((i) => {if (!porCasa.has(i.casa)) porCasa.set(i.casa, []);porCasa.get(i.casa).push(i);});
    const linha = row.line !== null ? `${SIDE_LBL[row.side]} ${row.line}` : SIDE_LBL[row.side];
    return React.createElement("div", { className: "pp-modal-bg", onClick: onClose },
    React.createElement("div", { className: "pp-modal", role: "dialog", "aria-label": "Detalhe da odd", onClick: (e) => e.stopPropagation() },
    React.createElement("div", { className: "pp-modal-h" },
    React.createElement("div", null, React.createElement("div", { className: "t" }, row.player, " · ", mkLabel, " · ", linha),
    React.createElement("div", { className: "s" }, cell.colName, ": ", fmtOdd(cell.odds), " na tabela, que é a captura mais recente entre casas e fontes")),
    React.createElement("button", { className: "pp-btn", onClick: onClose }, "Fechar")
    ),
    det === null ? React.createElement("div", { className: "pp-empty" }, "carregando…") : det.erro ? React.createElement("div", { className: "pp-alert bad" }, det.erro) : React.createElement(React.Fragment, null,
    React.createElement(Grafico, { itens: itens }),
    React.createElement("table", { className: "pp-det" }, React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Casa"), React.createElement("th", null, "Fonte"), React.createElement("th", null, "Odd"), React.createElement("th", null, "Mudou"), React.createElement("th", null, "Capturada"), React.createElement("th", null))), React.createElement("tbody", null,
    [...porCasa.entries()].map(([casa, lista]) => lista.map((i, n) => React.createElement("tr", { key: i.id, className: i.id === cell.id ? "usada" : "" },
    n === 0 ? React.createElement("td", { className: "casa", rowSpan: lista.length }, casa) : null,
    React.createElement("td", null, i.fonteLabel), React.createElement("td", { className: "od" }, fmtOdd(i.odds)), React.createElement("td", null, "há ", ago(i.mudou)), React.createElement("td", null, "há ", ago(i.capturada)),
    React.createElement("td", null, i.url ? React.createElement("a", { href: i.url, target: "_blank", rel: "noopener" }, "abrir ↗") : "")
    )))
    )),
    React.createElement("div", { className: "pp-meta" }, "A linha destacada é a que está na tabela. Entre várias casas e fontes, vale a captura mais recente; em empate, a maior odd.")
    )
    )
    );
  }





  const MK_TERMOS = [
  [/\bchutes? (?:no|ao) (?:alvo|gol)\b|\bfinaliza(?:ções|coes) (?:no|ao) (?:alvo|gol)\b|\balvo\b/i, "sot"],
  [/\bchutes?\b|\bfinaliza(?:ção|cao|ções|coes)\b/i, "shots"],
  [/\bassist(?:ência|encia|ências|encias)?\b/i, "assists"],
  [/\bdesarmes?\b|\btackles?\b/i, "tackles"],
  [/\bfaltas? (?:cometidas?)?\b/i, "fouls"],
  [/\bfaltas? sofridas?\b/i, "fouls_won"],
  [/\bcart(?:ão|ao|ões|oes)\b/i, "cards"],
  [/\bimpedimentos?\b/i, "offsides"],
  [/\bdefesas?\b/i, "saves"],
  [/\bpasses?\b/i, "passes"],
  [/\bgols?\b|\bmarcar\b|\bmarcador\b/i, "goals_total"]];

  const mercadoDoTexto = (q) => {for (const [re, mk] of MK_TERMOS) if (re.test(q)) return mk;return null;};
  const semMercado = (q) => {let t = q;for (const [re] of MK_TERMOS) t = t.replace(re, " ");return t.replace(/\s+/g, " ").trim();};

  function BuscaBar({ onPartida, onJogador, atual, brBest }) {
    const [q, setQ] = useState("");
    const [res, setRes] = useState(null);
    const [aberto, setAberto] = useState(false);
    const [erroBusca, setErroBusca] = useState("");
    const [previas, setPrevias] = useState({});
    const cachePartida = useRef(new Map());
    const caixa = useRef(null);
    const timer = useRef(null);
    const mkQ = mercadoDoTexto(q);
    useEffect(() => {
      const fora = (e) => {if (caixa.current && !caixa.current.contains(e.target)) setAberto(false);};
      document.addEventListener("mousedown", fora);
      return () => document.removeEventListener("mousedown", fora);
    }, []);


    const vezBusca = useRef(0);
    useEffect(() => {
      clearTimeout(timer.current);
      const n = ++vezBusca.current;
      setRes(null);setPrevias({});setErroBusca("");
      const termo = semMercado(q) || q;
      if (termo.trim().length < 2) return;
      timer.current = setTimeout(async () => {
        try {
          const j = await leJson("/api/props/buscar?q=" + encodeURIComponent(termo.trim()));
          if (n !== vezBusca.current) return;
          setRes(j);setAberto(true);
        } catch (e) {
          if (n !== vezBusca.current) return;
          setRes(null);setErroBusca(e.status === 401 ? "Sessão expirou: entre de novo." : "Busca falhou: " + e.message);
        }
      }, 320);
      return () => clearTimeout(timer.current);
    }, [q]);




    useEffect(() => {
      const js = (res && res.jogadores || []).slice(0, 3);
      if (!js.length) {setPrevias({});return;}
      let vivo = true;
      (async () => {
        const novo = {};
        for (const j of js) {
          try {
            let d = cachePartida.current.get(j.match_id);
            if (!d) {d = await fetch("/api/props/partida/" + j.match_id, { credentials: "include" }).then((x) => x.json());cachePartida.current.set(j.match_id, d);}
            if (!vivo) return;
            const br = new Set((d.books || []).filter((b) => b.br).map((b) => b.key));
            const linhas = [];
            for (const mk of d.markets || []) {
              if (mkQ && mk.market !== mkQ) continue;
              const rows = (mk.rows || []).filter((r) => String(r.playerKey) === "e:" + j.id && (r.side === "over" || r.side === "yes"));
              if (!rows.length) continue;
              const escolhidas = mkQ ? rows.slice(0, 6) : [rows.slice().sort((a, b) => (b.nBooks || 0) - (a.nBooks || 0) || (a.line ?? 0) - (b.line ?? 0))[0]];
              for (const r of escolhidas) {
                let melhor = null,casa = "";
                for (const [k, c] of Object.entries(r.cells || {})) {
                  if (brBest && !br.has(k)) continue;
                  if (!melhor || c.odds > melhor) {melhor = c.odds;casa = c.casa || c.book || "";}
                }
                const justas = tiposDeJusta(d.fairOdds).map((t) => r.fair && r.fair[t.key] && r.fair[t.key].odd != null ? Number(r.fair[t.key].odd) : null);
                const validas = justas.filter((x) => x !== null);
                const maior = validas.length ? Math.max(...validas) : null;
                linhas.push({ market: mk.market, label: mk.label, linha: r.line, side: r.side, melhor, casa, justas, n: r.nBooks || 0, kelly: melhor && maior ? kellyQuarto(melhor, maior) : null });
              }
            }
            novo[j.id + "|" + j.match_id] = mkQ ? linhas : linhas.sort((a, b) => b.n - a.n).slice(0, 6);
          } catch {}
        }
        if (vivo) setPrevias(novo);
      })();
      return () => {vivo = false;};
    }, [res, mkQ, brBest]);
    const nada = res && !(res.partidas || []).length && !(res.jogadores || []).length;
    return React.createElement("div", { className: "pp-busca", ref: caixa },
    React.createElement("div", { className: "campo" },
    React.createElement(Ic, { n: "search" }),
    React.createElement("input", { value: q, onFocus: () => res && setAberto(true), onChange: (e) => {setQ(e.target.value);},
      onKeyDown: (e) => {if (e.key === "Escape") {setAberto(false);e.target.blur();}},
      placeholder: "Buscar partida ou jogador — o jogador já vem com as odds justas; \u201cHaaland chutes\u201d traz todas as linhas" + (atual ? `  ·  agora em ${atual}` : "") }),
    q ? React.createElement("button", { className: "lim", title: "limpar", onClick: () => {setQ("");setRes(null);setAberto(false);} }, "×") : null
    ),
    erroBusca ? React.createElement("div", { className: "res" }, React.createElement("div", { className: "vazio" }, erroBusca)) : null,
    aberto && res ? React.createElement("div", { className: "res" },
    nada ? React.createElement("div", { className: "vazio" }, "Nada com esse nome nas partidas que ainda vão começar.") : null,
    (res.jogadores || []).length ? React.createElement("div", { className: "gr" }, "Jogadores") : null,
    (res.jogadores || []).map((j) =>
    React.createElement("button", { key: j.id + "|" + j.match_id, className: "it", onClick: () => {setAberto(false);onJogador(j, mkQ);} },
    React.createElement("div", { className: "n" }, j.nome, j.time ? React.createElement("span", { style: { fontWeight: 500, opacity: .75 } }, " · ", j.time) : null),
    React.createElement("div", { className: "s" }, j.jogo, " · ", fmtKo(j.kickoff), j.league ? " · " + j.league : ""),
    (() => {
      const linhas = previas[j.id + "|" + j.match_id];
      if (!linhas) return React.createElement("div", { className: "mk" }, (j.mercados || []).slice(0, 6).map((m) => React.createElement("span", { key: m.market }, m.label)));
      if (!linhas.length) return React.createElement("div", { className: "justa" }, "sem odd ", mkQ ? "desse mercado " : "", "para ele nesta partida");
      return React.createElement("table", { className: "pj" }, React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Mercado"), React.createElement("th", null, "Melhor", brBest ? " BR" : ""), React.createElement("th", null, "Legado"), React.createElement("th", null, "Compar."), React.createElement("th", null, "Semi-sharp"), React.createElement("th", null))),
      React.createElement("tbody", null, linhas.map((l, i) => React.createElement("tr", { key: i, className: l.kelly ? "val" : "" },
      React.createElement("td", null, l.label, l.linha != null ? " " + rotuloLado(l.side, l.linha) : ""),
      React.createElement("td", { title: l.casa }, React.createElement("b", null, l.melhor != null ? fmtOdd(l.melhor) : "—")),
      l.justas.map((x, k) => React.createElement("td", { key: k }, x == null ? "—" : fmtOdd(x))),
      React.createElement("td", { className: "k" }, l.kelly ? "vale " + (l.kelly * 100).toFixed(2).replace(".", ",") + "%" : "")
      ))));
    })()
    )),
    (res.partidas || []).length ? React.createElement("div", { className: "gr" }, "Partidas") : null,
    (res.partidas || []).map((p) =>
    React.createElement("button", { key: p.id, className: "it", onClick: () => {setAberto(false);onPartida(p.id);} },
    React.createElement("div", { className: "n" }, p.home, " × ", p.away),
    React.createElement("div", { className: "s" }, fmtKo(p.kickoff), p.league ? " · " + p.league : "")
    ))
    ) : null
    );
  }
  const rotuloLado = (side, linha) => (side === "over" ? "+" : side === "under" ? "-" : "") + (linha != null ? String(linha).replace(".", ",") : "");


  function MesclarModal({ alvo, jogadores, onClose, onFeito }) {
    const [q, setQ] = useState("");
    const [outro, setOutro] = useState(null);
    const [busy, setBusy] = useState(false);
    const [erro, setErro] = useState("");
    const [confirmando, setConfirmando] = useState(null);
    const a = jogadores.find((j) => j.key === alvo.playerKey) || { key: alvo.playerKey, nome: alvo.player, cadastro: String(alvo.playerKey).startsWith("e:"), oddIds: [] };



    const bate = (j) => j.key !== a.key && (!q || norm(j.nome).includes(norm(q)));
    const cadastros = jogadores.filter((j) => j.cadastro && bate(j));
    const soltos = a.cadastro ? jogadores.filter((j) => !j.cadastro && bate(j)) : [];
    const ligar = async (nome, para) => {
      setBusy(true);setErro("");
      try {const r = await postJson("/api/props/ligar-nome", { odd_ids: nome.oddIds, para: Number(String(para.key).slice(2)) });onFeito(r.msg || `"${nome.nome}" agora é "${para.nome}".`);}
      catch (e) {setErro(e.message);} finally
      {setBusy(false);}
    };
    const fundir = async (fica, sai) => {










      setBusy(true);setErro("");



      try {await postJson("/api/props/mesclar-jogadores", { de: Number(String(sai.key).slice(2)), para: Number(String(fica.key).slice(2)), unificaIdProvedor: true, nomeFica: fica.nome });onFeito(`"${sai.nome}" agora é "${fica.nome}".`);}
      catch (e) {setConfirmando(null);setErro("Não gravou: " + e.message);} finally
      {setBusy(false);}
    };
    return React.createElement("div", { className: "pp-modal-bg", onClick: onClose },
    React.createElement("div", { className: "pp-modal", role: "dialog", "aria-label": "Mesclar jogadores", style: { width: "min(520px,100%)" }, onClick: (e) => e.stopPropagation() },
    React.createElement("div", { className: "pp-modal-h" }, React.createElement("div", null, React.createElement("div", { className: "t" }, "Mesclar \"", a.nome, "\""), React.createElement("div", { className: "s" }, "Use quando os dois nomes são a mesma pessoa. As odds passam a ficar numa linha só.")), React.createElement("button", { className: "pp-btn", onClick: onClose }, "Fechar")),
    erro && React.createElement("div", { className: "pp-alert bad", role: "alert" }, erro),
    !a.cadastro && React.createElement("div", { style: { fontSize: 12.5, opacity: .8 } }, "\"", a.nome, "\" ainda não tem cadastro nesta partida (o coletor não o ligou a ninguém). Escolha quem ele é: as odds dele passam para essa pessoa e o nome vira apelido dela."),
    !outro ? React.createElement(React.Fragment, null,
    React.createElement("input", { className: "pp-inp", autoFocus: true, placeholder: "buscar o outro jogador…", value: q, onChange: (e) => setQ(e.target.value) }),
    React.createElement("div", { className: "pp-mlist" }, cadastros.map((j) => React.createElement("button", { key: j.key, className: "pp-btn", style: { justifyContent: "flex-start" }, onClick: () => setOutro(j) }, j.nome)),
    !cadastros.length && React.createElement("div", { className: "pp-empty" }, "Nenhum outro jogador do cadastro nesta partida."),
    soltos.length > 0 && React.createElement("div", { style: { fontSize: 12, opacity: .75, margin: "8px 0 2px" } }, "Sem cadastro (o coletor não ligou a ninguém):"),
    soltos.map((j) => React.createElement("button", { key: j.key, className: "pp-btn", style: { justifyContent: "flex-start", borderStyle: "dashed" }, onClick: () => setOutro(j) }, j.nome, " ", React.createElement("span", { style: { opacity: .6, marginLeft: 6 } }, "sem cadastro"))))
    ) : !a.cadastro || !outro.cadastro ? React.createElement(React.Fragment, null,
    React.createElement("div", { style: { fontSize: 13 } }, !a.cadastro ? React.createElement(React.Fragment, null, "\"", a.nome, "\" é o jogador \"", outro.nome, "\"?") : React.createElement(React.Fragment, null, "\"", outro.nome, "\" é o jogador \"", a.nome, "\"?")),
    React.createElement("div", { style: { fontSize: 12, opacity: .75 } }, "As odds de \"", !a.cadastro ? a.nome : outro.nome, "\" passam para o cadastro de \"", !a.cadastro ? outro.nome : a.nome, "\", e o nome fica gravado como apelido dele nesta partida e no clube: as próximas varreduras já chegam ligadas."),
    React.createElement("div", { style: { display: "flex", gap: 8, flexWrap: "wrap" } },
    React.createElement("button", { className: "pp-btn pri", disabled: busy, onClick: () => !a.cadastro ? ligar(a, outro) : ligar(outro, a) }, "Sim, ligar"),
    React.createElement("button", { className: "pp-btn", disabled: busy, onClick: () => setOutro(null) }, "Voltar")
    )
    ) : React.createElement(React.Fragment, null,
    React.createElement("div", { style: { fontSize: 13 } }, "\"", a.nome, "\" e \"", outro.nome, "\" são a mesma pessoa. Qual nome fica?"),
    React.createElement("div", { style: { fontSize: 12, opacity: .75 } }, "Fica o nome, o cadastro e — se os dois tiverem número do provedor de estatística — o número de quem fica. O outro número passa a apontar para ele, então as leituras futuras caem no cadastro certo."),
    !confirmando ? React.createElement("div", { style: { display: "flex", gap: 8, flexWrap: "wrap" } },
    React.createElement("button", { className: "pp-btn pri", disabled: busy, onClick: () => setConfirmando({ fica: a, sai: outro }) }, "Fica \"", a.nome, "\""),
    React.createElement("button", { className: "pp-btn pri", disabled: busy, onClick: () => setConfirmando({ fica: outro, sai: a }) }, "Fica \"", outro.nome, "\""),
    React.createElement("button", { className: "pp-btn", disabled: busy, onClick: () => setOutro(null) }, "Voltar")
    ) : React.createElement("div", { className: "pp-alert", role: "alertdialog", "aria-label": "Confirmar mescla", style: { display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" } },
    React.createElement("b", { style: { flex: "1 1 100%" } }, "Fica \"", confirmando.fica.nome, "\", sai \"", confirmando.sai.nome, "\"?"),
    React.createElement("button", { className: "pp-btn pri", disabled: busy, autoFocus: true, onClick: () => fundir(confirmando.fica, confirmando.sai) }, "Confirmar"),
    React.createElement("button", { className: "pp-btn", disabled: busy, onClick: () => setConfirmando(null) }, "Voltar"),
    busy && React.createElement("span", { role: "status", style: { flex: "1 1 100%", fontSize: 12.5 } }, "Gravando a mescla… com o banco ocupado pode levar até 1 min. Não recarregue a página.")
    )
    )
    )
    );
  }




  function kellyQuarto(odd, justa) {
    if (!(odd > 1) || !(justa > 1) || !(odd > justa)) return null;
    const f = (odd / justa - 1) / (odd - 1) / 4;
    return f > 0 ? f : null;
  }
  const kellyTxt = (odd, justa) => {const f = kellyQuarto(odd, justa);return f ? `Vale ${(f * 100).toFixed(2).replace(".", ",")}% da banca · ` : "";};


  const colGroup = (c) => c.kind === "house" ? "pa" : c.source;
  const GRP_LBL = { pa: "Cadastro Peixe Esperto", oc_uk: "OddsChecker UK", oc_br: "OddsChecker BR", bb: "BetBurger", casa: "Casa de Apostas", betano: "Betano", betmonitor: "Betmonitor", receba: "Receba", blaze: "Blaze", pixbet: "Pixbet", betesporte: "BETesporte", vivasorte: "Viva Sorte Bet", betgo: "BetGo" };
  const GRP_CLS = { pa: "grp-pa", oc_uk: "grp-uk", oc_br: "grp-br", bb: "grp-bb", casa: "grp-casa", betano: "grp-bta", betmonitor: "grp-bm", receba: "grp-rcb", blaze: "grp-blz", pixbet: "grp-pix", betesporte: "grp-bes", vivasorte: "grp-vs", betgo: "grp-bgo" };

  const FAIR_TYPES = [
  { key: "legacy", label: "Legado", help: "Grupos marcados para o Peixe Props. Usa a maior odd, exceto quando ela supera a segunda já sem juice; nesse caso usa a segunda. Depois aplica o expoente do mercado." },
  { key: "comparative", label: "Comparativa", help: "Todos os grupos de clones disponíveis. Mediana superior do método legado aplicado a todas as combinações de K grupos, com o expoente do mercado. K flutua por linha: é a quantidade de grupos com casa do OddsChecker UK que têm cotação nesta seleção, nunca menos de 4." },
  { key: "semiSharp", label: "Semi-sharp", help: "Média das duas maiores odds semi-sharp, após descartar no máximo uma maior isolada que supere a segunda já sem juice. Com apenas dois grupos, ambos são sempre mantidos. Depois aplica o expoente do mercado." },

  { key: "pinnacle", label: "Pinnacle", help: "Pinnacle sem margem: as duas pernas (Mais e Menos) da MESMA linha do jogador, com a margem tirada pelo power — a mesma conta dos mercados de jogo. Casa em outra linha fica sem justa." },

  { key: "novig", label: "Novig", help: "Novig sem margem: as duas pernas (Mais e Menos) da MESMA linha do jogador na bolsa, com a margem tirada pelo power. Sem as duas pernas, não vota." },
  { key: "prophetx", label: "ProphetX", help: "ProphetX sem margem: as duas pernas (Mais e Menos) da MESMA linha, no preço da bolsa antes da comissão de 2% do lucro, com a margem tirada pelo power. Sem as duas pernas, não vota." }];

  const PAR_FONTE = { pinnacle: "Pinnacle", novig: "Novig", prophetx: "ProphetX" };

  const tiposDeJusta = (meta) => FAIR_TYPES.filter((t) => meta && Array.isArray(meta.tipos) ? meta.tipos.includes(t.key) : !PAR_FONTE[t.key]);


  const VOTO_VELHO_MS = 20 * 60_000;
  function votoVelho(r, key) {
    const em = r && r.fairVotoMaisVelho && r.fairVotoMaisVelho[key];
    if (!(em > 0)) return null;
    const ms = Date.now() - em;
    return ms >= VOTO_VELHO_MS ? Math.round(ms / 60_000) : null;
  }
  function fairTitle(fair, type, meta) {
    const value = fair && fair[type.key];
    if (!value) return "Cálculo indisponível. Atualize a partida.";
    if (PAR_FONTE[type.key]) {
      const nome = PAR_FONTE[type.key];
      if (value.odd == null) return type.help + "\n" + (value.reason === type.key + "_sem_par" ? nome + " não tem as duas pernas desta linha para este jogador agora." : "Cálculo indisponível.");
      return type.help + "\n" + nome + ": Mais " + fmtOdd(value.over) + " / Menos " + fmtOdd(value.under) + (value.bruto ? " (antes da comissão: " + fmtOdd(value.bruto.over) + " / " + fmtOdd(value.bruto.under) + ")" : "") + " → sem margem " + fmtOdd(value.odd) + ".";
    }
    const reasons = { missing_exponent: "Configure o expoente deste mercado em Parâmetros dos Player Props.", few_groups: "É necessário haver cotação de pelo menos dois grupos distintos nesta seleção.", few_legacy_config: "Marque pelo menos dois grupos para o legado no Peixe Admin para definir K.", numeric_range: "O expoente produz um resultado fora do intervalo numérico suportado." };
    const lines = [type.help, `${value.n} grupo(s) com cotação nesta seleção.`];
    if (value.reason) lines.push(reasons[value.reason] || "Cálculo indisponível.");else
    {
      lines.push(`Referência ${value.reference.toFixed(6)} ^ expoente ${fair.exponent} = ${value.odd.toFixed(6)}.`);
      if (type.key === "legacy") lines.push(value.excludedTop ? "A maior odd foi descartada por superar a segunda já sem juice." : "A maior odd foi mantida.");



      if (type.key === "comparative") {
        lines.push("K = " + value.kEffective + " de " + value.n + " grupos · " + value.combinations + " combinação(ões).");
        if (Array.isArray(value.distribuicao) && value.distribuicao.length)
        lines.push("Referência escolhida por: " + value.distribuicao.map((d) => fmtOdd(d.ref) + " em " + d.pct.toFixed(1).replace(".", ",") + "%").join(" · "));
        if (value.poucaVariacao) lines.push("Atenção: com K quase igual ao número de grupos, tirar um grupo quase nunca muda a referência — a comparativa vira o método legado aplicado a todos os grupos.");
        if (value.reducedCoverage) lines.push("Há menos grupos com cotação do que K: todos foram usados.");
      }
      if (type.key === "semiSharp") {
        const name = (key) => ((meta && meta.groups || []).find((g) => g.key === key) || {}).name || key;
        if (value.excludedTop) lines.push(`${name(value.excludedGroup)}: ${fmtOdd(value.excludedOdd)} foi descartada por superar a segunda já sem juice.`);else
        lines.push(value.n === 2 ? "Há apenas dois grupos: ambos foram mantidos." : "A maior odd foi mantida.");
        lines.push(value.groups.map((g, i) => `${name(g)}: ${fmtOdd(value.topOdds[i])}`).join(" + "));
      }
    }
    if (type.key === "comparative") {
      lines.push(value.kFlutuante ?
      "K desta linha: " + value.kEffective + " (" + value.gruposUk + " grupo(s) do OddsChecker UK com cotação aqui; mínimo " + value.kMinimo + ")." :
      `K nominal: ${value.kNominal}; K efetivo: ${value.kEffective}.`);
      if (value.reducedCoverage) lines.push("Há menos grupos que o K nominal: foi usada uma única combinação com todos os grupos disponíveis.");
    }
    return lines.join("\n");
  }





  const ESTAT_MK = { shots: "SH", sot: "SOT", fouls_won: "FS", fouls: "FC", tackles: "TCK" };
  const ESTAT_LBL = { SH: "chutes", SOT: "chutes no alvo", FS: "faltas sofridas", FC: "faltas cometidas", TCK: "desarmes" };
  const ESTAT_PADRAO = { calcGames: 20, calcScope: "club", calcFriendlies: false, calcSameTeamOnly: true, calcExtraTime: false, calcSubGuaranteed: false };
  function estatDaLinha(jog, stat, r) {
    if (!jog) return { estado: "sem" };
    if (!jog.ss) return { estado: "semVinculo", motivo: jog.semVinculo };
    const s = jog.stats && jog.stats[stat];
    if (!s) return { estado: "sem" };
    if (s.buscando) return { estado: "buscando" };
    const a = window.EstatisticaAmostra.daLinha(s, r.side, r.line);
    if (!a) return { estado: "sem_linha", s };
    const melhor = a.melhor || a.amostras[0] || { n: s.n, k: 0, p: 0, odd: null };
    return { estado: "ok", s, lim: a.limiar, amostras: a.amostras, ...melhor, ss: jog.ss };
  }


  const ehSelecaoEstat = (s) => !!(s && s.notes && s.notes.escopo === "selecao");
  const resumoEstat = (c, s) => ["janelas de 10 e 20 como titular", ehSelecaoEstat(s) ? `só a seleção${s.notes.selecao ? " (" + s.notes.selecao + ")" : ""}, nunca o clube` : "só a equipe atual",
  c.calcFriendlies ? "com amistosos" : "sem amistosos", c.calcExtraTime ? "com prorrogação" : "sem prorrogação", c.calcSubGuaranteed ? "substituição garantida" : null,
  ehSelecaoEstat(s) ? "sem teto de tempo" : "até 12 meses"].filter(Boolean).join(" · ");
  const anosTxt = (a) => a < 1 ? "menos de 1 ano" : `${String(a).replace(".", ",")} ${a < 2 ? "ano" : "anos"}`;

  function periodoSelecao(s) {
    const ts = (s.rows || []).map((r) => Number(r.ts)).filter((x) => x > 0);
    if (!ts.length) return null;
    const anos = Math.round((Math.max(...ts) - Math.min(...ts)) / (365.25 * 86400) * 10) / 10;
    return `seleção: ${ts.length} jogo(s) em ${anosTxt(anos)}`;
  }
  const pctTxt = (p) => {const v = p * 100;return v.toFixed(v % 1 === 0 ? 0 : 1).replace(".", ",");};

  function avisosEstat(s, cfg, stat) {
    const w = [],nt = s.notes || {},n = s.n,want = s.want,sel = ehSelecaoEstat(s);
    if (nt.clubeNaoConfirmado) w.push(["warn", "O clube atual não foi confirmado no elenco da partida."]);else
    if (nt.categoriaDivergente) w.push(["warn", `Sem odd estatística: ${nt.categoriaDivergente} — vínculo do time a conferir.`]);else
    if (n < 10) w.push(["warn", `Sem odd estatística: ${n} de 10 jogos válidos necessários ${sel ? "pela seleção" : "no clube atual"}.`]);else
    if (n < 20) w.push(["info", `Foram encontrados ${n} jogos válidos. Só a janela de 10 está completa.`]);
    if (nt.cutoffHit && n < want) w.push(["info", "Teto de 12 meses atingido — jogos mais antigos foram ignorados."]);
    if (nt.pageLimitHit && n < want) w.push(["info", "Limite de varredura de histórico atingido."]);
    if (nt.noData) w.push(["info", `${nt.noData} jogo(s) ignorado(s) por falta de dados estatísticos (não entram na conta).`]);
    if (nt.extraTrimmed) w.push(["info", `${nt.extraTrimmed} jogo(s) com prorrogação: contados só até os 90'.`]);
    if (nt.extraSkipped) w.push(["warn", `${nt.extraSkipped} jogo(s) com prorrogação removido(s) da amostra: ${stat} não tem carimbo de minuto na API, então não dá pra separar os 30' extras. Ligue "Incluir prorrogação" para trazê-los de volta pelos 120'.`]);
    if (nt.otherTeamSkipped) w.push(["info", sel ? `${nt.otherTeamSkipped} jogo(s) de seleção descartado(s) por serem de outra categoria (sub-21, olímpica…) ou de outra seleção.` :
    `${nt.otherTeamSkipped} jogo(s) descartado(s) por serem de equipe anterior.`]);

    if (nt.friendlySkipped) w.push(["info", sel ? `Amistosos fora da conta (${nt.friendlySkipped} na lista lida da seleção).` : `${nt.friendlySkipped} amistoso(s) fora da conta.`]);
    return w;
  }
  function estatTitle(e, stat, cfg) {
    if (e.estado === "semVinculo") return "Odd estatística: jogador ainda sem vínculo no SofaScore — " + (e.motivo || "procurando");
    if (e.estado === "buscando") return "Odd estatística: buscando os jogos dele no SofaScore…";
    if (e.estado === "sem_linha") return "Odd estatística: a extensão calcula só \"pelo menos N\" (over / sim).";
    if (e.estado !== "ok") return "Odd estatística: sem dado para este jogador.";
    const l = [resumoEstat(cfg, e.s), ...(ehSelecaoEstat(e.s) && periodoSelecao(e.s) ? [periodoSelecao(e.s)] : []), ...e.amostras.map((a) => `${a.k} de ${a.n} com ${e.lim} ou mais ${ESTAT_LBL[stat]} · ${pctTxt(a.p)}% · odd ${a.odd ? fmtOdd(a.odd) : "— (nenhum jogo bateu)"}`)];
    avisosEstat(e.s, cfg, stat).slice(0, 3).forEach((x) => l.push(x[1]));
    l.push("Clique para ver jogo a jogo.");
    return l.join("\n");
  }
  const dataCurta = (ts) => {const p = fusoSP.partesSP(ts * 1000);return p ? `${String(p.dia).padStart(2, "0")}/${String(p.mes).padStart(2, "0")}/${String(p.ano).slice(2)}` : "—";};


  function EstatParams({ cfg, onSalvar, onClose }) {
    const [f, setF] = useState({ ...ESTAT_PADRAO, ...cfg });
    useEffect(() => {const k = (e) => {if (e.key === "Escape") onClose();};document.addEventListener("keydown", k);return () => document.removeEventListener("keydown", k);}, [onClose]);
    const ch = (k, v) => setF((x) => ({ ...x, [k]: v }));
    return React.createElement("div", { className: "pp-modal-bg", onClick: onClose },
    React.createElement("div", { className: "pp-modal", style: { width: "min(560px,100%)" }, role: "dialog", "aria-label": "Parâmetros da odd estatística", onClick: (e) => e.stopPropagation() },
    React.createElement("div", { className: "pp-modal-h" },
    React.createElement("div", null, React.createElement("div", { className: "t" }, "Odd estatística — parâmetros"),
    React.createElement("div", { className: "s" }, "A odd é o número de jogos dividido pelos acertos. Usamos a maior odd das janelas completas de 10 e 20 jogos como titular pelo clube atual (em jogo de seleção, pela seleção do jogo, na mesma categoria e sem teto de tempo). Dados do SofaScore.")),
    React.createElement("button", { className: "pp-btn", onClick: onClose }, "Fechar")
    ),
    React.createElement("div", { className: "pp-estat-form" },
    React.createElement("label", { className: "pp-chk" }, React.createElement("input", { id: "estat-amistosos", type: "checkbox", checked: f.calcFriendlies, onChange: (e) => ch("calcFriendlies", e.target.checked) }), "Incluir amistosos"),
    React.createElement("label", { className: "pp-chk" }, React.createElement("input", { id: "estat-prorrog", type: "checkbox", checked: f.calcExtraTime, onChange: (e) => ch("calcExtraTime", e.target.checked) }), "Incluir prorrogação"),
    React.createElement("small", null, f.calcExtraTime ? "Ligado: tudo entra pelos 120'." : "Desligado: em chutes e chutes no alvo o jogo conta só até os 90' (pelo minuto de cada chute); em faltas e desarmes, que não têm minuto, o jogo com prorrogação sai da amostra."),
    React.createElement("label", { className: "pp-chk" }, React.createElement("input", { id: "estat-sub", type: "checkbox", checked: f.calcSubGuaranteed, onChange: (e) => ch("calcSubGuaranteed", e.target.checked) }), "Substituição garantida"),
    React.createElement("small", null, "Soma as estatísticas de quem entrou no lugar dele (A sai e B entra; B sai e C entra). Se ele foi expulso, conta só ele."),
    React.createElement("div", { className: "pp-meta" }, "Fixos, como na extensão: recuo de até 12 meses (jogo de seleção: sem teto, só os jogos pela seleção) e linha \"pelo menos N\" — mais de 1,5 chute é 2 ou mais. A estatística vem do mercado da coluna.")
    ),
    React.createElement("div", { className: "pp-estat-acoes" },
    React.createElement("button", { className: "pp-btn", onClick: () => setF({ ...ESTAT_PADRAO }) }, "Voltar ao padrão"),
    React.createElement("button", { className: "pp-btn pri", onClick: () => {onSalvar({ ...f });onClose();} }, "Aplicar")
    )
    )
    );
  }


  function EstatModal({ alvo, cfg, onClose }) {
    const { row, stat, e, nomeMercado } = alvo;
    useEffect(() => {const k = (ev) => {if (ev.key === "Escape") onClose();};document.addEventListener("keydown", k);return () => document.removeEventListener("keydown", k);}, [onClose]);
    const s = e.s;
    const avisos = avisosEstat(s, cfg, stat);
    const linha = row.line !== null ? `${SIDE_LBL[row.side]} ${row.line}` : SIDE_LBL[row.side];
    return React.createElement("div", { className: "pp-modal-bg", onClick: onClose },
    React.createElement("div", { className: "pp-modal", style: { width: "min(640px,100%)" }, role: "dialog", "aria-label": "Odd estatística jogo a jogo", onClick: (ev) => ev.stopPropagation() },
    React.createElement("div", { className: "pp-modal-h" },
    React.createElement("div", null, React.createElement("div", { className: "t" }, row.player, " · ", nomeMercado, " · ", linha),
    React.createElement("div", { className: "s" }, "Odd estatística · ", e.lim, " ou mais ", ESTAT_LBL[stat], " · SofaScore: ", e.ss.nome || "jogador", " (#", e.ss.id, ")")),
    React.createElement("button", { className: "pp-btn", onClick: onClose }, "Fechar")
    ),
    React.createElement("div", { className: "pp-estat-res" },
    React.createElement("div", { className: "cap" }, "Odd estatística"),
    React.createElement("div", { className: "odd" }, e.odd ? fmtOdd(e.odd) : "—"),
    e.amostras.map((a) => React.createElement("div", { className: "frac", key: a.n }, React.createElement("b", null, a.k, "/", a.n), " jogos cumpridos · ", React.createElement("b", null, pctTxt(a.p), "%"), " · odd ", a.odd ? fmtOdd(a.odd) : "—"))
    ),
    avisos.length > 0 && React.createElement("div", { className: "pp-estat-avisos" }, avisos.map((a, i) => React.createElement("div", { key: i, className: a[0] === "warn" ? "warn" : "" }, a[1]))),
    s.rows.length === 0 ? React.createElement("div", { className: "pp-empty" }, "Nenhum jogo como titular encontrado com esses filtros.") :
    React.createElement("table", { className: "pp-det" }, React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Data"), React.createElement("th", null, "Adversário"), React.createElement("th", { style: { textAlign: "right" } }, stat), React.createElement("th", { style: { textAlign: "right" } }, "≥", e.lim))), React.createElement("tbody", null,
    s.rows.map((r) => {
      const bateu = r.value >= e.lim;
      return React.createElement("tr", { key: r.id, className: bateu ? "" : "miss" },
      React.createElement("td", null, dataCurta(r.ts)),
      React.createElement("td", null, r.isHome ? "" : "@", r.opp,
      r.red ? React.createElement("span", { className: "pp-estat-flag", title: "Expulso neste jogo" }, "🟥") : null,
      r.otherTeam ? React.createElement("span", { className: "pp-estat-flag", title: "Jogo por outra equipe" }, "🔄") : null,
      r.trimmed ? React.createElement("span", { className: "pp-estat-flag", title: "Teve prorrogação — contado só até os 90'" }, "⏱") : null,
      r.aet && !r.trimmed ? React.createElement("span", { className: "pp-estat-flag", title: "Teve prorrogação — os 120' estão na conta" }, "⏱") : null,
      r.subParts && r.subParts.length ? React.createElement("span", { className: "pp-estat-flag", title: "Somado: " + r.subParts.map((x) => `${x.name} ${x.v}`).join(", ") }, "➕") : null,
      r.subUnknown ? React.createElement("span", { className: "pp-estat-flag", title: "Saiu antes do fim, mas a substituição não foi identificada" }, "⚠️") : null,
      r.national ? React.createElement("span", { className: "pp-estat-flag", title: "Jogo por seleção" }, "🌐") : null,
      React.createElement("span", { className: "pp-meta", style: { display: "block" } }, r.tour, r.min ? ` · ${r.min}'` : "")),
      React.createElement("td", { className: "od", style: { textAlign: "right" } }, r.subParts && r.subParts.length ? React.createElement(React.Fragment, null, r.own, React.createElement("span", { style: { color: "var(--mut)", fontWeight: 400 } }, "+", r.extra)) : r.value),
      React.createElement("td", { className: bateu ? "ok" : "no" }, bateu ? "✓" : "✗")
      );
    })
    )),
    React.createElement("div", { className: "pp-meta" }, "🟥 expulso · 🔄 outra equipe · ⏱ prorrogação · ➕ substituto somado · ⚠️ substituição não identificada · 🌐 seleção"),
    React.createElement("div", { className: "pp-meta" }, "Parâmetros: ", resumoEstat(cfg, s), ehSelecaoEstat(s) && periodoSelecao(s) ? " · " + periodoSelecao(s) : "")
    )
    );
  }

  function MarketTable({ mk, books, filters, now, onCell, expandir, podeMesclar, onMesclar, fairMeta, brFirst, brBest, colW, onColW, foco, estat, estatCfg, onEstat, esporte = "football" }) {


    const L = window.LiqEfeito;
    const [, obsTick] = useState(0);
    useEffect(() => {if (!window.obsStore) return;const f = () => obsTick((x) => x + 1);window.obsStore.subs.add(f);window.carregaObs && window.carregaObs();return () => {window.obsStore.subs.delete(f);};}, []);
    const memoObs = new Map();
    const obsDaColuna = (c) => {
      if (!L || !window.obsStore) return null;
      if (!memoObs.has(c.key)) {const casas = [c.book, c.casa, ...(c.houses || [])].filter(Boolean);memoObs.set(c.key, L.obsDaLinha(window.obsStore.lista, casas, mk.market, esporte).length ? casas : null);}
      return memoObs.get(c.key);
    };
    const statMk = ESTAT_MK[mk.market] || null;
    const [linhaDe, setLinhaDe] = useState({});

    const brSet = useMemo(() => new Set(books.filter((b) => b.br).map((b) => b.key)), [books]);



    const favs = useMemo(() => lerFavs(), [books]);
    const cols = useMemo(() => {
      const cs = books.filter((b) => mk.books.includes(b.key) && (!filters.books.length || filters.books.includes(b.key)));
      const alfa = (a, b) => a.book.localeCompare(b.book, "pt-BR", { sensitivity: "base" }) || String(a.key).localeCompare(String(b.key));
      const fav = (b) => favs.has(nomeCasaFav(b.book)) || (b.houses || []).some((h) => favs.has(nomeCasaFav(h))) ? 0 : 1;
      return cs.slice().sort((a, b) => fav(a) - fav(b) || (brFirst ? (b.br ? 1 : 0) - (a.br ? 1 : 0) : 0) || alfa(a, b));
    }, [books, mk, filters.books, brFirst, favs]);

    const [w, setW] = useState(colW || {});
    useEffect(() => {setW(colW || {});}, [colW]);
    const rz = useRef(null);

    const W = (key) => w[key] ? { minWidth: 0 } : undefined;
    const fixw = (key) => w[key] ? " fixw" : "";
    const CW = (key, conteudo) => w[key] ? React.createElement("div", { className: "pp-cw", style: { width: w[key] } }, conteudo) : conteudo;
    const startResize = (e, key) => {
      e.preventDefault();e.stopPropagation();
      const th = e.currentTarget.parentElement;
      const cs = getComputedStyle(th);

      const conteudo = th.getBoundingClientRect().width - parseFloat(cs.paddingLeft || 0) - parseFloat(cs.paddingRight || 0);
      rz.current = { key, startX: e.clientX, startW: conteudo, el: e.currentTarget };
      e.currentTarget.classList.add("on");
      const move = (ev) => {if (!rz.current) return;const nw = Math.max(28, Math.round(rz.current.startW + ev.clientX - rz.current.startX));setW((m) => ({ ...m, [rz.current.key]: nw }));};
      const up = () => {
        window.removeEventListener("mousemove", move);window.removeEventListener("mouseup", up);
        if (rz.current && rz.current.el) rz.current.el.classList.remove("on");
        setW((m) => {if (onColW) onColW(m);return m;});
        rz.current = null;
      };
      window.addEventListener("mousemove", move);window.addEventListener("mouseup", up);
    };
    const Rz = ({ k }) => React.createElement("span", { className: "pp-rz", title: "arraste para mudar a largura (fica salva)", onMouseDown: (e) => startResize(e, k), onDoubleClick: (e) => {e.stopPropagation();setW((m) => {const n = { ...m };delete n[k];if (onColW) onColW(n);return n;});} });

    const lnLeft = w.pl ? { left: w.pl + 17 } : undefined;
    const base = useMemo(() => {
      const q = norm(filters.q || "").trim();
      let rs = mk.rows.filter((r) => (filters.side === "all" || r.side === filters.side || filters.side === "over" && r.side === "yes" || filters.side === "under" && r.side === "no") && (
      !q || norm(r.player).includes(q)));
      if (expandir) rs = rs.filter((r) => filters.line === "" || r.line === Number(filters.line) || r.line === null && filters.line === "x");
      if (filters.books.length || brBest) {
        rs = rs.map((r) => {
          const cells = {};let best = null;
          for (const k of filters.books.length ? filters.books : Object.keys(r.cells)) if (r.cells[k]) {
            cells[k] = r.cells[k];
            if (brBest && !brSet.has(k)) continue;
            if (!best || r.cells[k].odds > best.odds) best = { col: k, odds: r.cells[k].odds };
          }
          return { ...r, cells, best, nBooks: Object.keys(cells).length };
        }).filter((r) => r.nBooks > 0);
      }
      return rs;
    }, [mk, filters, expandir, brBest, brSet]);





    const principalDe = useMemo(() => {
      const med = (xs) => {const v = xs.filter((x) => x > 1).sort((a, b) => a - b);const n = v.length;return n ? n % 2 ? v[(n - 1) / 2] : (v[n / 2 - 1] + v[n / 2]) / 2 : null;};
      const justaDe = (r) => r && r.fair ? med(Object.values(r.fair).map((f) => Number(f && f.odd))) : null;
      const porJog = new Map();
      for (const r of mk.rows || []) {
        if (r.line === null) continue;
        const g = porJog.get(r.playerKey) || new Map();const l = g.get(r.line) || {};
        if (r.side === "over" || r.side === "yes") l.o = r;else if (r.side === "under" || r.side === "no") l.u = r;
        g.set(r.line, l);porJog.set(r.playerKey, g);
      }
      const out = new Map();
      for (const [pk, g] of porJog) {
        let melhor = null;
        for (const [line, { o, u }] of g) {
          if (!o || !u) continue;
          const jo = justaDe(o),ju = justaDe(u);
          let p = null;
          if (jo && ju) p = 1 / jo / (1 / jo + 1 / ju);else if (jo) p = 1 / jo;else if (ju) p = 1 - 1 / ju;else
          {
            const ps = [];
            for (const k of Object.keys(o.cells || {})) {const a = Number(o.cells[k] && o.cells[k].odds),b = Number(u.cells && u.cells[k] && u.cells[k].odds);if (a > 1 && b > 1) ps.push(1 / a / (1 / a + 1 / b));}
            const v = ps.sort((x, y) => x - y);p = v.length ? v.length % 2 ? v[(v.length - 1) / 2] : (v[v.length / 2 - 1] + v[v.length / 2]) / 2 : null;
          }
          if (!(p > 0 && p < 1)) continue;
          const d = Math.abs(p - 0.5),n = Math.max(o.nBooks || 0, u.nBooks || 0);
          if (!melhor || d < melhor.d - 1e-9 || Math.abs(d - melhor.d) <= 1e-9 && (n > melhor.n || n === melhor.n && line < melhor.line)) melhor = { line, d, n };
        }
        if (melhor) out.set(pk, melhor.line);
      }
      return out;
    }, [mk]);
    const rows = useMemo(() => {
      let rs = base;
      if (!expandir) {


        const pref = filters.line === "" || filters.line === "x" ? null : Number(filters.line);
        const grupos = new Map();
        for (const r of rs) {
          const k = r.playerKey + "|" + (r.side === "under" || r.side === "no" ? "u" : "o");
          if (!grupos.has(k)) grupos.set(k, []);
          grupos.get(k).push(r);
        }
        const out = [];
        for (const lista of grupos.values()) {
          const pk = lista[0].playerKey;
          const linhas = [...new Set(lista.map((r) => r.line))];
          let alvo;
          if (linhaDe[pk] !== undefined && linhas.includes(linhaDe[pk])) alvo = linhaDe[pk];else
          if (pref !== null && linhas.includes(pref)) alvo = pref;else
          if (principalDe.has(pk) && linhas.includes(principalDe.get(pk))) alvo = principalDe.get(pk);else
          alvo = lista.slice().sort((a, b) => b.nBooks - a.nBooks || (a.line ?? -1) - (b.line ?? -1))[0].line;
          const r = lista.find((x) => x.line === alvo) || lista[0];
          out.push({ ...r, linhas: linhas.filter((l) => l !== null).sort((a, b) => a - b), fora: pref !== null && alvo !== pref });
        }
        rs = out;
      }
      if (filters.minBooks > 1) rs = rs.filter((r) => r.nBooks >= filters.minBooks);
      if (filters.sort === "best") rs = rs.slice().sort((a, b) => (b.best ? b.best.odds : 0) - (a.best ? a.best.odds : 0));else
      if (filters.sort === "player" || !expandir) rs = rs.slice().sort((a, b) => a.player.localeCompare(b.player, "pt-BR", { sensitivity: "base" }) || (a.line ?? -1) - (b.line ?? -1));
      return rs;
    }, [base, expandir, linhaDe, filters, principalDe]);
    if (!cols.length) return React.createElement("div", { className: "pp-empty" }, "Nenhuma casa selecionada tem esse mercado.");
    if (!rows.length) return React.createElement("div", { className: "pp-empty" }, "Nada bate nos filtros.");
    const staleMs = 3 * 3600e3;
    let prevPlayer = null;
    const colTitle = (c) => c.kind === "raw" ?
    `${c.book} · ${SRC[c.source] ? SRC[c.source].label : c.source} (sem vínculo no cadastro)` :
    `${c.book}${c.kind === "group" ? ` · casas: ${(c.houses || []).join(", ")}` : ""} · fontes: ${(c.sources || []).map((x) => `${x.label} ${x.n}`).join(", ")}`;


    const fonteDaColuna = (c) => (c.kind === "raw" ? [c.source] : (c.sources || []).map((x) => x.source)).filter(Boolean).
    map((f) => SRC[f] && SRC[f].short || f).join("+");

    const rotuloLinha = (r, l) => l !== null && l !== undefined ? `${SIDE_LBL[r.side]} ${linhaTxt(l)}` : SIDE_LBL[r.side];
    const FT = tiposDeJusta(fairMeta);
    return React.createElement("div", { className: "pp-tblwrap" }, React.createElement("table", { className: "pp-tbl" },
    React.createElement("thead", null,
    React.createElement("tr", { className: "bks" }, React.createElement("th", { className: "pl" + fixw("pl"), style: W("pl") }, CW("pl", "Jogador"), React.createElement(Rz, { k: "pl" })), React.createElement("th", { className: "ln" + fixw("ln"), style: { ...(W("ln") || {}), ...(lnLeft || {}) } }, CW("ln", "Linha"), React.createElement(Rz, { k: "ln" })),
    FT.map((t, i) => React.createElement("th", { key: t.key, className: "fair-col" + (i === 0 ? " fair-first" : "") + (i === FT.length - 1 ? " fair-last" : "") + fixw("fair:" + t.key), style: W("fair:" + t.key), title: t.help }, CW("fair:" + t.key, React.createElement(React.Fragment, null, React.createElement("span", { className: "fair-label" }, "Odd justa"), t.label)), React.createElement(Rz, { k: "fair:" + t.key }))),
    statMk ? React.createElement("th", { className: "estat-col" + fixw("estat"), style: W("estat"), title: "Odd estatística (SofaScore): jogos como titular que bateram a linha ÷ jogos considerados — o cálculo da extensão. " + (estatCfg ? resumoEstat(estatCfg) : "") }, CW("estat", React.createElement(React.Fragment, null, React.createElement("span", { className: "fair-label" }, "Odd justa"), "Estatística")), React.createElement(Rz, { k: "estat" })) : null,
    React.createElement("th", { className: "best-col" + fixw("best"), style: W("best"), title: brBest ? "melhor odd entre as casas de regulamentação federal (BR)" : "melhor odd entre todas as casas" }, CW("best", brBest ? React.createElement(React.Fragment, null, "Melhor", React.createElement("span", { className: "pp-brtag" }, "BR")) : "Melhor"), React.createElement(Rz, { k: "best" })),
    cols.map((c) => React.createElement("th", { key: c.key, className: (c.br ? "brcol" : "") + fixw(c.key), style: W(c.key), title: colTitle(c) + (c.br ? " · regulamentação federal (BR)" : "") }, CW(c.key, React.createElement(React.Fragment, null, favs.has(nomeCasaFav(c.book)) ? React.createElement("span", { className: "fav", title: "Favorita (★ na Odds Screen)" }, "★") : null, c.book, React.createElement("span", { className: "pp-colsrc" }, fonteDaColuna(c)))), React.createElement(Rz, { k: c.key }))))
    ),
    React.createElement("tbody", null,
    rows.map((r) => {
      const sep = expandir && filters.sort === "player" && prevPlayer !== null && prevPlayer !== r.playerKey;prevPlayer = r.playerKey;

      const justasR = FT.map((t) => r.fair && r.fair[t.key] && r.fair[t.key].odd != null ? Number(r.fair[t.key].odd) : null).filter((x) => x !== null);
      const maiorJustaR = justasR.length ? Math.max(...justasR) : null;
      return React.createElement("tr", { key: r.key, "data-jogador": r.playerKey, className: (sep ? "sep" : "") + (foco && String(foco) === String(r.playerKey) ? " pp-foco" : "") },
      React.createElement("td", { className: "pl" + fixw("pl"), style: W("pl") }, CW("pl", React.createElement(React.Fragment, null, r.player, podeMesclar ? React.createElement("button", { className: "pp-mg", title: String(r.playerKey).startsWith("e:") ? "Mesclar com outro jogador (mesma pessoa)" : "Sem cadastro: dizer quem é este jogador", onClick: (e) => {e.stopPropagation();onMesclar(r);} }, "⇄") : null))),
      React.createElement("td", { className: "ln" + fixw("ln"), style: { ...(W("ln") || {}), ...(lnLeft || {}) } }, CW("ln", React.createElement(React.Fragment, null, !expandir && r.linhas && r.linhas.length > 1 ?
      React.createElement("select", { className: "pp-lsel" + (r.fora ? " fora" : ""), value: r.line, title: r.fora ? "este jogador não tem a linha escolhida para todos" : "trocar a linha deste jogador", onChange: (e) => {const v = Number(e.target.value);setLinhaDe((m) => ({ ...m, [r.playerKey]: v }));} },
      r.linhas.map((l) => React.createElement("option", { key: l, value: l }, rotuloLinha(r, l)))) :
      rotuloLinha(r, r.line)))),
      FT.map((t, i) => {const f = r.fair && r.fair[t.key];return React.createElement("td", { key: t.key, style: W("fair:" + t.key), className: "fair-col" + (i === 0 ? " fair-first" : "") + (i === FT.length - 1 ? " fair-last" : "") + (!f || f.odd === null ? " missing" : "") + fixw("fair:" + t.key), title: fairTitle(r.fair, t, fairMeta) + (votoVelho(r, t.key) != null ? "\n⏱ Justa com preço velho: o voto mais velho está sem confirmação há " + votoVelho(r, t.key) + " min (não foi cortado)." : "") }, CW("fair:" + t.key, React.createElement(React.Fragment, null, f && f.odd !== null ? fmtOdd(f.odd) : "—", f && f.odd !== null && votoVelho(r, t.key) != null && React.createElement("span", { className: "fair-label", style: { color: "#a35a00", marginTop: 2, marginBottom: 0 } }, "⏱ ", votoVelho(r, t.key), " min"))));}),
      statMk ? (() => {
        const e = estatDaLinha(estat && estat.jogadores ? estat.jogadores[r.playerKey] : null, statMk, r);
        const ok = e.estado === "ok";
        const txt = ok ? e.odd ? fmtOdd(e.odd) : "—" : e.estado === "buscando" ? "…" : "—";
        return React.createElement("td", { className: "estat-col" + (!ok || !e.odd ? " missing" : "") + (ok ? " clic" : "") + fixw("estat"), style: W("estat"), title: estatTitle(e, statMk, estatCfg || ESTAT_PADRAO),
          onClick: ok ? (ev) => {ev.stopPropagation();onEstat && onEstat({ row: r, stat: statMk, e });} : undefined }, CW("estat", React.createElement(React.Fragment, null, txt, ok ? React.createElement("span", { className: "estat-frac" }, e.k, "/", e.n) : null)));
      })() : null,
      (() => {

        const maiorJusta = maiorJustaR;
        const acima = !!(r.best && maiorJusta !== null && r.best.odds > maiorJusta);
        const deQuem = r.best ? (cols.find((c) => c.key === r.best.col) || {}).book || "" : "";
        const dica = (acima ? kellyTxt(r.best.odds, maiorJusta) : "") +
        [deQuem, acima ? `acima da maior odd justa (${fmtOdd(maiorJusta)})` : maiorJusta !== null ? `maior odd justa: ${fmtOdd(maiorJusta)}` : "", brBest ? r.best ? "só casas BR" : "nenhuma casa BR tem esta linha" : ""].filter(Boolean).join(" · ");
        return React.createElement("td", { className: "best-col" + (acima ? " acima" : "") + fixw("best"), style: W("best"), title: dica }, CW("best", r.best ? fmtOdd(r.best.odds) : "—"));
      })(),
      cols.map((c) => {const cell = r.cells[c.key];if (!cell) return React.createElement("td", { key: c.key, className: "od empty" + fixw(c.key), style: W(c.key) }, CW(c.key, "·"));


        const obsCasa = obsDaColuna(c);
        const selo = obsCasa && window.ObsAlerta ? React.createElement(window.ObsAlerta, { casas: obsCasa, mercado: mk.market, esporte, lado: L ? L.ladoDeProp(r.side) : undefined, molde: cell.moldeCasa || cell.molde || undefined, periodo: cell.periodoCasa || undefined }) : null;
        const best = !!(r.best && (!brBest || brSet.has(c.key)) && (r.best.col === c.key || cell.odds >= r.best.odds));
        const stale = now - cell.seen > staleMs;
        const multi = c.kind !== "raw" && ((c.sources || []).length > 1 || (c.houses || []).length > 1);


        const dicaCel = kellyTxt(cell.odds, maiorJustaR) + `${cell.casa || c.book} via ${SRC[cell.source] ? SRC[cell.source].label : cell.source}${cell.tamanho != null ? ` · disponível a esta odd: ${usdP(cell.tamanho)} (taxa já descontada)` : ""} · mudou há ${ago(cell.ts)} · capturada há ${ago(cell.seen)} · clique para ver todas as casas e fontes`;
        return React.createElement("td", { key: c.key, style: W(c.key), "data-odd": cell.odds, className: "od" + (best ? " best" : "") + (stale ? " stale" : "") + fixw(c.key), title: dicaCel, onClick: (e) => {e.stopPropagation();onCell({ ...cell, colName: c.book }, r);} }, CW(c.key, React.createElement(React.Fragment, null, fmtOdd(cell.odds), multi ? React.createElement("span", { className: "sx" }, SRC[cell.source] ? SRC[cell.source].short : "") : null, selo, cell.periodoCasa ? React.createElement("div", { className: "tam" }, cell.periodoCasa === "jogo_pr" ? "Inclui prorrogação" : "90 minutos") : null, cell.tamanho != null ? React.createElement("div", { className: "tam" }, usdP(cell.tamanho)) : null)));})
      );
    })
    )
    ));
  }


  function PlayerPropsTab({ onClose, onNav, admin }) {
    const [partidas, setPartidas] = useState([]);
    const [status, setStatus] = useState(null);

    const R = window.Rota;
    const [sel, setSelRaw] = useState(() => {const m = R && R.get("m", null);return m != null ? Number(m) : lsGet("pp.sel", null);});


    const setSel = (id) => {setSelRaw(id);if (R) R.set({ m: id }, { push: true });};
    const [data, setData] = useState(null);
    const [erro, setErro] = useState("");
    const [loading, setLoading] = useState(false);
    const [mkt, setMktRaw] = useState(() => R && R.get("mk", null) || lsGet("pp.mkt", "sot"));
    const setMkt = (k) => {setMktRaw(k);if (R) R.set({ mk: k }, { push: true });};
    const [filters, setFilters] = useState(() => ({ books: [], side: "all", line: "", q: "", minBooks: 1, sort: "line", ...lsGet("pp.filters", {}) }));
    const [pick, setPick] = useState(() => ({ ...DEF_PICK, ...lsGet("pp.pick", {}), q: "" }));
    const [raw, setRaw] = useState(() => lsGet("pp.raw", false));
    const [auto, setAuto] = useState(true);
    const [pop, setPop] = useState(null);
    const [expandir, setExpandir] = useState(() => lsGet("pp.expand", false));

    const [brFirst, setBrFirstRaw] = useState(() => lsGet("pp.brFirst", true));
    const [colW, setColWRaw] = useState(() => lsGet("pp.colW", {}));
    const prefTimer = useRef({});
    const savePref = (k, v) => {
      lsSet("pp." + k, v);
      clearTimeout(prefTimer.current[k]);
      prefTimer.current[k] = setTimeout(() => {fetch("/api/props/prefs/" + k, { method: "PUT", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ v }) }).catch(() => {});}, 500);
    };
    const setBrFirst = (v) => {setBrFirstRaw(v);savePref("brFirst", v);};
    const [brBest, setBrBestRaw] = useState(() => lsGet("pp.brBest", true));
    const setBrBest = (v) => {setBrBestRaw(v);savePref("brBest", v);};

    const [estatCfg, setEstatCfgRaw] = useState(() => ({ ...ESTAT_PADRAO, ...lsGet("pp.estat", {}) }));
    const setEstatCfg = (c) => {setEstatCfgRaw(c);savePref("estat", c);};
    const [estat, setEstat] = useState(null);
    const [estatAberto, setEstatAberto] = useState(false);
    const [estatDet, setEstatDet] = useState(null);
    const setColW = (m) => {setColWRaw(m);savePref("colW", m);};
    useEffect(() => {
      fetch("/api/props/prefs", { credentials: "include" }).then((r) => r.ok ? r.json() : null).then((p) => {
        if (!p) return;
        if (p.colW && typeof p.colW === "object") {setColWRaw(p.colW);lsSet("pp.colW", p.colW);}
        if (typeof p.brFirst === "boolean") {setBrFirstRaw(p.brFirst);lsSet("pp.brFirst", p.brFirst);}
        if (typeof p.brBest === "boolean") {setBrBestRaw(p.brBest);lsSet("pp.brBest", p.brBest);}
        if (p.estat && typeof p.estat === "object") {const c = { ...ESTAT_PADRAO, ...p.estat };setEstatCfgRaw(c);lsSet("pp.estat", c);}
      }).catch(() => {});
    }, []);
    const [mesclar, setMesclar] = useState(null);
    const [foco, setFoco] = useState(null);
    useEffect(() => {
      if (!R || !R.ouvir) return;
      return R.ouvir(() => {
        const m = R.get("m", null),mk = R.get("mk", null);
        setSelRaw(m != null ? Number(m) : null);
        if (mk) setMktRaw(mk);
        setShowList(m == null);
      });
    }, []);
    const [aviso, setAviso] = useState("");
    const [showList, setShowList] = useState(() => !(R && R.get("m", null) || lsGet("pp.sel", null)));
    const timer = useRef(null);

    const setF = (patch) => setFilters((f) => {const n = { ...f, ...patch };lsSet("pp.filters", { books: n.books, side: n.side, minBooks: n.minBooks, sort: n.sort });return n;});
    useEffect(() => {lsSet("pp.pick", { day: "all", hours: pick.hours, srcs: pick.srcs, sort: pick.sort, onlyOdds: pick.onlyOdds });}, [pick]);
    useEffect(() => {lsSet("pp.raw", raw);}, [raw]);
    useEffect(() => {lsSet("pp.expand", expandir);}, [expandir]);

    const loadPartidas = useCallback(async () => {
      try {const [p, s] = await Promise.all([getJson("/api/props/partidas?all=1", onClose), getJson("/api/props/status?magro=1", onClose)]);setPartidas(p);setStatus(s);setErro("");}
      catch (e) {setErro(e.message);}
    }, [onClose]);


    const pedidoAtual = useRef(0);
    const loadMatch = useCallback(async (id) => {
      const meu = ++pedidoAtual.current;
      if (!id) {setData(null);setLoading(false);return;}
      setLoading(true);
      try {
        const d = await getJson("/api/props/partida/" + id + (raw ? "?raw=1" : ""), onClose);
        if (meu !== pedidoAtual.current) return;
        setData(d);setErro("");if (!d.markets.some((m) => m.market === mkt) && d.markets.length) setMkt(d.markets[0].market);
      }
      catch (e) {if (meu === pedidoAtual.current) setErro(e.message);} finally
      {if (meu === pedidoAtual.current) setLoading(false);}
    }, [onClose, mkt, raw]);

    useEffect(() => {loadPartidas();}, [loadPartidas]);
    useEffect(() => {setData((d) => d && d.match && Number(d.match.id) !== Number(sel) ? null : d);loadMatch(sel);lsSet("pp.sel", sel);}, [sel, raw]);
    useEffect(() => {lsSet("pp.mkt", mkt);setFilters((f) => f.line === "" ? f : { ...f, line: "" });}, [mkt]);
    useEffect(() => {
      clearInterval(timer.current);
      if (auto) timer.current = setInterval(() => {loadPartidas();if (sel) loadMatch(sel);}, 60e3);
      return () => clearInterval(timer.current);
    }, [auto, sel, loadPartidas, loadMatch]);


    useEffect(() => {
      if (!sel || !data) return;
      let vivo = true,t = null;
      const inicio = Date.now();
      const busca = async () => {
        try {
          const r = await postJson("/api/props/estatistica/partida/" + sel, { cfg: estatCfg }, onClose);
          if (!vivo) return;
          setEstat({ ...r, partida: sel });
          const andando = r.faltando > 0 || r.progresso && (r.progresso.fase === "vinculando" || r.progresso.fase === "buscando");
          if (andando && Date.now() - inicio < 20 * 60e3) t = setTimeout(busca, r.fonte && r.fonte.pausadaAte ? 60e3 : 6e3);
        } catch (e) {if (vivo) setEstat({ partida: sel, erro: e.message });}
      };
      busca();
      return () => {vivo = false;clearTimeout(t);};
    }, [sel, estatCfg, data]);

    const curMk = data && data.markets.find((m) => m.market === mkt);

    useEffect(() => {
      if (!foco || !data) return;
      let tentativas = 0;
      const achar = () => {
        const tr = document.querySelector(`tr[data-jogador="${foco}"]`);
        if (tr) {tr.scrollIntoView({ block: "center", behavior: "smooth" });return;}
        if (++tentativas < 20) setTimeout(achar, 120);
      };
      const t = setTimeout(achar, 120);
      const limpa = setTimeout(() => setFoco(null), 6000);
      return () => {clearTimeout(t);clearTimeout(limpa);};
    }, [foco, data, mkt]);
    const collectorStale = status && status.collectorUpdatedAt && status.now - status.collectorUpdatedAt > 5 * 60e3;
    const toggleBook = (k) => setF({ books: filters.books.includes(k) ? filters.books.filter((x) => x !== k) : [...filters.books, k] });

    const booksByGroup = useMemo(() => {const g = { pa: [] };SRC_IDS.forEach((s) => {g[s] = [];});(data ? data.books : []).forEach((b) => (g[colGroup(b)] || (g[colGroup(b)] = [])).push(b));return g;}, [data]);
    const irCasas = (e) => {e && e.preventDefault();if (typeof onNav === "function") onNav("propscasas");};

    return React.createElement("div", { className: "pp-wrap" },
    erro && React.createElement("div", { className: "pp-alert bad" }, React.createElement(Ic, { n: "error" }), erro),
    aviso && React.createElement("div", { className: "pp-alert ok", role: "status", style: { position: "sticky", top: 8, zIndex: 30 } }, React.createElement(Ic, { n: "check_circle" }), aviso),
    admin && status && status.semTabelas && React.createElement("div", { className: "pp-alert" }, React.createElement(Ic, { n: "info" }), "O coletor de player props ainda não rodou (tabelas não existem). Suba o serviço ", React.createElement("b", null, "props-collector"), " no EasyPanel."),
    admin && status && status.collector && status.collector.oc && status.collector.oc.downUntil && React.createElement("div", { className: "pp-alert" }, React.createElement(Ic, { n: "warning" }), "OddsChecker sem sessão até ", new Date(status.collector.oc.downUntil).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }), " — ", status.collector.oc.downMotivo || "motivo não registrado", ". Enquanto isso nenhuma partida recebe UK."),
    admin && status && status.collector && status.collector.discovery && (status.collector.discovery.ligasFalhas || []).length > 0 && React.createElement("div", { className: "pp-alert" }, React.createElement(Ic, { n: "warning" }), "O OddsChecker UK não conseguiu ler ", status.collector.discovery.ligasFalhas.length, " liga(s) na última descoberta: ", status.collector.discovery.ligasFalhas.join(", "), ". Os jogos delas ficam sem UK até a próxima (2 h). Detalhe em Pareamentos → Saúde."),
    admin && status && status.collector && status.collector.sources && status.collector.sources.betano && status.collector.sources.betano.diagMarcador && status.collector.sources.betano.diagMarcador.cobertura &&
    status.collector.sources.betano.diagMarcador.cobertura.semMercadoDeJogador > 3 * Math.max(1, status.collector.sources.betano.diagMarcador.cobertura.comMercadoDeJogador) &&
    (() => {const c = status.collector.sources.betano.diagMarcador.cobertura,sb = status.collector.sources.betano.diagMarcador.sondaBr;return React.createElement("div", { className: "pp-alert" }, React.createElement(Ic, { n: "info" }), "Betano (via OddsPapi, slug ", (c.slugs || []).join(", "), "): só ", c.comMercadoDeJogador, " de ", c.comMercadoDeJogador + c.semMercadoDeJogador, " jogos da resposta vieram com mercado de jogador — os outros chegam só com os mercados principais. ", sb ? sb.noPlano === true ? "A Betano do Brasil (" + sb.slug + ") está no plano: " + sb.comMercadoDeJogador + " de " + sb.jogos + " jogos da Série B com mercado de jogador." : sb.noPlano === false ? "A Betano do Brasil (" + sb.slug + ") não está no plano da OddsPapi (HTTP " + sb.http + ")." : "" : "");})(),
    admin && collectorStale && React.createElement("div", { className: "pp-alert" }, React.createElement(Ic, { n: "warning" }), "Coletor sem sinal há ", ago(status.collectorUpdatedAt), " — confira o serviço props-collector."),

    React.createElement(BuscaBar, { brBest: brBest, atual: data && !showList ? `${data.match.home} × ${data.match.away}` : null,
      onPartida: (id) => {setSel(id);setShowList(false);setFoco(null);},
      onJogador: (j, mk) => {

        const alvo = mk || ((j.mercados || [])[0] || {}).market || null;
        setSelRaw(j.match_id);
        if (alvo) setMktRaw(alvo);
        if (R) R.set({ m: j.match_id, mk: alvo }, { push: true });
        setFoco("e:" + j.id);
        setShowList(false);
      } }),

    data && !showList ? React.createElement("div", { className: "pp-selbar" },

    (() => {
      const lista = partidas.filter((p) => p.kickoff > Date.now() - 3 * 3600e3).slice().sort((a, b) => a.kickoff - b.kickoff || a.id - b.id);
      const i = lista.findIndex((p) => Number(p.id) === Number(sel));
      const vai = (p) => {if (p) {setSel(p.id);setFoco(null);}};
      return React.createElement("span", { className: "pp-nav" },
      React.createElement("button", { className: "pp-btn", disabled: i <= 0, onClick: () => vai(lista[i - 1]), title: "Jogo anterior (pelo horário)", "aria-label": "Jogo anterior" }, React.createElement(Ic, { n: "chevron_left" })),
      React.createElement("select", { "aria-label": "Trocar de jogo", value: i >= 0 ? String(sel) : "", onChange: (e) => vai(lista.find((p) => String(p.id) === e.target.value)) },
      i < 0 && React.createElement("option", { value: "" }, data.match.home, " × ", data.match.away),
      lista.map((p) => React.createElement("option", { key: p.id, value: String(p.id) }, fmtKo(p.kickoff), " · ", p.home, " × ", p.away, p.league ? " · " + p.league : ""))
      ),
      React.createElement("button", { className: "pp-btn", disabled: i < 0 || i >= lista.length - 1, onClick: () => vai(lista[i + 1]), title: "Próximo jogo (pelo horário)", "aria-label": "Próximo jogo" }, React.createElement(Ic, { n: "chevron_right" }))
      );
    })(),
    React.createElement("span", { className: "t" }, data.match.home, " × ", data.match.away),
    React.createElement("span", { className: "ln" }, fmtKo(data.match.kickoff), " · ", data.match.league || ""),
    React.createElement("span", { className: "pp-src" },
    SRC_IDS.map((s) => {const r = data.refs.find((x) => x.source === s);const cls = !r ? "bad" : r.last_error ? "warn" : r.last_scan ? "ok" : "warn";
      return React.createElement("span", { key: s, className: "pill " + cls, title: r ? r.last_error || r.ref : "sem ref desta fonte pra esta partida (não pareada ou fora das ligas)" },
      SRC[s].short, " ", React.createElement("b", null, !r ? "—" : r.last_scan ? `${r.last_odds} odds · há ${ago(r.last_scan)}` : "aguardando"), r && r.next_scan ? React.createElement("span", { style: { opacity: .6 } }, " · próx. ", fmtHora(r.next_scan)) : null
      );})
    ),
    React.createElement("span", { className: "sw" },
    React.createElement("button", { onClick: () => setShowList((v) => !v), title: "a lista completa das partidas; para trocar de jogo, a busca acima é mais rápida" }, React.createElement(Ic, { n: "list" }), showList ? "Fechar lista" : "Todas as partidas"),
    React.createElement("button", { className: auto ? "" : "off", onClick: () => setAuto((v) => !v), title: "atualiza a cada 60 s" }, React.createElement(Ic, { n: auto ? "autorenew" : "pause" }), auto ? "Auto 60s" : "Pausado"),
    React.createElement("button", { onClick: () => {loadPartidas();if (sel) loadMatch(sel);} }, React.createElement(Ic, { n: "refresh" }), "Atualizar"),
    React.createElement("button", { onClick: () => setEstatAberto(true), title: "Parâmetros da odd estatística (SofaScore): " + resumoEstat(estatCfg) }, React.createElement(Ic, { n: "tune" }), "Odd estatística"),
    data.podeMesclar ? React.createElement("button", { title: "Pede ao coletor uma busca na Betano agora, sem esperar o ciclo de 3 horas", onClick: async () => {try {const r = await postJson("/api/props/betano/puxar", {});setAviso(r.msg || "Pedido registrado.");setTimeout(() => setAviso(""), 8000);} catch (e) {setErro(e.message);}} }, React.createElement(Ic, { n: "cloud_download" }), "Puxar Betano agora") : null
    )
    ) : null,

    showList && React.createElement("section", { className: "glass panel", style: { padding: 12 } },
    React.createElement(MatchPicker, { partidas: partidas, sel: sel, onSel: (id) => {setSel(id);setShowList(false);}, pick: pick, setPick: setPick }),
    data && React.createElement("div", { style: { marginTop: 8, textAlign: "right" } }, React.createElement("button", { className: "pp-btn", onClick: () => setShowList(false) }, React.createElement(Ic, { n: "expand_less" }), "Voltar pra ", data.match.home, " × ", data.match.away))
    ),

    data && !showList && React.createElement(React.Fragment, null,
    React.createElement("div", { className: "pp-mkts" },
    data.markets.map((m) => React.createElement("button", { key: m.market, className: m.market === mkt ? "on" : "", onClick: () => setMkt(m.market) }, m.label, React.createElement("span", { className: "n" }, m.rows.length))),
    !data.markets.length && React.createElement("span", { className: "pp-meta" }, "Ainda sem odds pra esta partida.")
    ),

    React.createElement("div", { className: "pp-filters" },
    React.createElement("div", { className: "fg" }, React.createElement("label", null, "Lado"), React.createElement("div", { className: "sel-wrap" }, React.createElement("select", { className: "sel", value: filters.side, onChange: (e) => setF({ side: e.target.value }) }, React.createElement("option", { value: "all" }, "Todos"), React.createElement("option", { value: "over" }, "Over / Sim"), React.createElement("option", { value: "under" }, "Under / Não")), React.createElement(Ic, { n: "arrow_drop_down" }))),
    React.createElement("div", { className: "fg" }, React.createElement("label", null, "Ordenar"), React.createElement("div", { className: "sel-wrap" }, React.createElement("select", { className: "sel", value: filters.sort, onChange: (e) => setF({ sort: e.target.value }) }, React.createElement("option", { value: "line" }, "Linha"), React.createElement("option", { value: "player" }, "Jogador"), React.createElement("option", { value: "best" }, "Melhor odd")), React.createElement(Ic, { n: "arrow_drop_down" }))),
    React.createElement("div", { className: "fg" }, React.createElement("label", null, "Mín. casas"), React.createElement("input", { className: "pp-inp", type: "number", min: "1", max: "30", value: filters.minBooks, onChange: (e) => setF({ minBooks: Math.max(1, Number(e.target.value) || 1) }), style: { minWidth: 80 } })),
    React.createElement("div", { className: "fg" }, React.createElement("label", null, "Jogador"), React.createElement("input", { className: "pp-inp", placeholder: "buscar…", value: filters.q, onChange: (e) => setF({ q: e.target.value }) })),
    React.createElement("div", { className: "fg" }, React.createElement("label", null, "Colunas"), React.createElement("div", { style: { display: "flex", gap: 12 } },
    React.createElement("label", { className: "pp-chk", title: "Desligado: uma coluna por (fonte, casa), como a fonte entrega" }, React.createElement("input", { type: "checkbox", checked: !raw, onChange: (e) => setRaw(!e.target.checked) }), "agrupar pelo cadastro"),
    React.createElement("label", { className: "pp-chk", title: "Ligado: todas as linhas de cada jogador. Desligado: uma linha por jogador, trocável na célula" }, React.createElement("input", { type: "checkbox", checked: expandir, onChange: (e) => setExpandir(e.target.checked) }), "expandir linhas"),
    React.createElement("label", { className: "pp-chk", title: "Grupos de casas com pelo menos uma casa de regulamentação federal (apostável no Brasil) vêm primeiro, em ordem alfabética; depois os demais. Fica salvo para você em qualquer navegador." }, React.createElement("input", { type: "checkbox", checked: brFirst, onChange: (e) => setBrFirst(e.target.checked) }), "casas BR primeiro"),
    React.createElement("label", { className: "pp-chk", title: "Ligado: a coluna Melhor mostra a melhor odd só entre casas de regulamentação federal (apostáveis no Brasil), e o destaque verde vale só para elas — inclusive o de acima da odd justa. Fica salvo para você em qualquer navegador." }, React.createElement("input", { type: "checkbox", checked: brBest, onChange: (e) => setBrBest(e.target.checked) }), "Melhor odd só considera casas BR")
    ))
    ),

    curMk && (curMk.lines || []).length > 0 && React.createElement("div", { className: "pp-lines" },


    React.createElement("span", { className: "rot" }, "Linha"),
    React.createElement("button", { className: filters.line === "" ? "on" : "", onClick: () => setF({ line: "" }) }, expandir ? "Todas" : "Principal de cada um"),
    curMk.lines.map((l) => {const n = new Set(curMk.rows.filter((r) => r.line === l).map((r) => r.playerKey)).size;
      return React.createElement("button", { key: l, className: String(filters.line) === String(l) ? "on" : "", onClick: () => setF({ line: String(l) }), title: `Mais/menos de ${String(l).replace(".", ",")} para todos os jogadores` }, linhaTxt(l), React.createElement("span", { className: "n" }, n));}),
    curMk.rows.some((r) => r.line === null) && React.createElement("button", { className: filters.line === "x" ? "on" : "", onClick: () => setF({ line: "x" }), title: "Seleções sim/não sem número (num mercado de contagem o sim já vira a linha 0,5)" }, "Sem linha")
    ),

    React.createElement("div", { className: "pp-books" },
    (data.books || []).map((b) => React.createElement("button", { key: b.key, className: "bk" + (filters.books.includes(b.key) ? " on" : ""), onClick: () => toggleBook(b.key), title: `${b.n} odds` + (b.kind !== "raw" ? ` · ${(b.houses || []).join(", ")} · ${(b.sources || []).map((x) => x.label).join(" + ")}` : ` · ${SRC[b.source] ? SRC[b.source].label : b.source}`) }, b.book)),
    filters.books.length > 0 && React.createElement("button", { className: "bk", onClick: () => setF({ books: [] }) }, "× todas as casas"),
    !raw && admin && React.createElement("button", { className: "bk lnk", onClick: irCasas, title: "vincular as casas cruas das fontes ao cadastro do Peixe Admin" }, "vincular casas ↗")
    ),

    curMk && React.createElement("div", { className: "pp-fair-note" },
    React.createElement("span", { title: "Na odd justa comparativa, K é medido em cada linha: quantos grupos com casa do OddsChecker UK têm cotação naquela seleção (mínimo 4). Passe o mouse na célula da comparativa para ver o K da linha." }, "Odds justas por grupo de clones · ", data.fairOdds && data.fairOdds.kFlutuante ? "K por linha (grupos do OddsChecker UK, mín. " + data.fairOdds.kMinimo + ")" : "K nominal: " + (data.fairOdds ? data.fairOdds.kNominal : "—")),
    React.createElement("span", { title: "Casas sem grupo vinculado ficam fora dos cálculos. Cada grupo conta uma única vez, mesmo no modo de colunas por fonte." }, "Os filtros de colunas não alteram a base dos cálculos."),
    admin && typeof onNav === "function" && React.createElement("button", { onClick: () => onNav("propsparams") }, "Configurar expoentes"),
    data.fairOdds && data.fairOdds.apiError && React.createElement("span", { title: data.fairOdds.apiError }, "Cadastro da API indisponível: usando último registro salvo.")
    ),
    curMk && ESTAT_MK[curMk.market] && React.createElement("div", { className: "pp-fair-note" },
    React.createElement("span", { title: "Proporção de jogos como titular em que ele bateu a linha — o cálculo da Calculadora de Odd Estatística (extensão), com dados do SofaScore." }, "Odd estatística (SofaScore): ", resumoEstat(estatCfg)),
    React.createElement("button", { onClick: () => setEstatAberto(true) }, "Mudar parâmetros"),
    (() => {
      const es = estat && estat.partida === sel ? estat : null;
      if (!es) return React.createElement("span", null, "calculando…");
      if (es.erro) return React.createElement("span", { style: { color: "var(--down)" } }, es.erro);
      const partes = [];
      if (es.fonte && es.fonte.pausadaAte) partes.push("SofaScore pausado até " + fmtHora(es.fonte.pausadaAte) + " (" + (es.fonte.motivo || "proteção contra bloqueio") + "): a tela mostra o que já foi calculado");
      if (es.faltando > 0) partes.push("buscando " + es.faltando + " no SofaScore" + (es.progresso && es.progresso.total ? " (" + es.progresso.feitos + "/" + es.progresso.total + ")" : ""));
      const semV = Object.values(es.jogadores || {}).filter((j) => !j.ss && j.semVinculo && !/procurando/.test(j.semVinculo)).length;
      if (semV) partes.push(semV + " jogador(es) sem vínculo no SofaScore (passe o mouse no \u201c—\u201d)");
      return partes.length ? React.createElement("span", null, partes.join(" · ")) : null;
    })()
    ),
    loading && !curMk ? React.createElement("div", { className: "skel", style: { height: 240 } }) :
    curMk ? React.createElement(MarketTable, { esporte: data.match && data.match.esporte || "football", mk: curMk, books: data.books, filters: filters, now: data.now, expandir: expandir, podeMesclar: !!data.podeMesclar, onMesclar: (r) => setMesclar(r), onCell: (cell, row) => setPop({ cell, row }), fairMeta: data.fairOdds, brFirst: brFirst, brBest: brBest, colW: colW, onColW: setColW, foco: foco,
      estat: estat && estat.partida === sel ? estat : null, estatCfg: estatCfg, onEstat: (x) => setEstatDet(x) }) : null,
    pop && React.createElement(CellModal, { alvo: { ...pop, mkLabel: curMk ? curMk.label : "" }, onClose: () => setPop(null) }),
    estatDet && React.createElement(EstatModal, { alvo: { ...estatDet, nomeMercado: curMk ? curMk.label : "" }, cfg: estatCfg, onClose: () => setEstatDet(null) }),
    estatAberto && React.createElement(EstatParams, { cfg: estatCfg, onSalvar: setEstatCfg, onClose: () => setEstatAberto(false) }),
    mesclar && React.createElement(MesclarModal, { alvo: mesclar,
      jogadores: (() => {

        const m = new Map();
        (data.markets || []).forEach((mk) => mk.rows.forEach((r) => {
          const j = m.get(r.playerKey) || { key: r.playerKey, nome: r.player, cadastro: String(r.playerKey).startsWith("e:"), oddIds: [] };


          Object.values(r.cells || {}).forEach((c) => (c && c.ids && c.ids.length ? c.ids : c && c.id ? [c.id] : []).forEach((id) => j.oddIds.push(id)));
          m.set(r.playerKey, j);
        }));
        return [...m.values()].sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));
      })(),
      onClose: () => setMesclar(null),
      onFeito: (msg) => {setMesclar(null);setAviso("✅ " + msg);setTimeout(() => setAviso(""), 12000);loadMatch(sel);} })
    ),

    !data && sel && loading && React.createElement("div", { className: "skel", style: { height: 240 } })
    );
  }


  function PropsCasasTab({ onClose }) {
    const [d, setD] = useState(null);
    const [erro, setErro] = useState("");
    const [msg, setMsg] = useState("");
    const [busy, setBusy] = useState(false);
    const [q, setQ] = useState("");
    const [flt, setFlt] = useState("all");
    const [srcF, setSrcF] = useState("all");
    const load = useCallback(async (refresh) => {
      try {setD(await getJson("/api/props/casas" + (refresh ? "?refresh=1" : ""), onClose));setErro("");} catch (e) {setErro(e.message);}
    }, [onClose]);
    useEffect(() => {load(false);}, [load]);

    const vincular = async (b, houseId) => {
      setBusy(true);setMsg("");
      try {await postJson("/api/props/casas/vinculo", { source: b.source, book: b.book, house_id: houseId }, onClose);await load(false);setMsg(houseId ? `✅ ${b.book} (${b.source_label}) → ${(d.houses.find((h) => h.id === Number(houseId)) || {}).name || houseId}` : `Vínculo de ${b.book} removido`);}
      catch (e) {setMsg("❌ " + e.message);} finally
      {setBusy(false);}
    };
    const naoUsar = async (b, flag) => {
      if (flag && !(await confirma(`Não utilizar "${b.book}" (${b.source_label})?\n\nAs odds dela somem do Player Props e o coletor para de gravá-las. Dá pra desfazer aqui depois.`))) return;
      setBusy(true);setMsg("");
      try {await postJson("/api/props/casas/vinculo", { source: b.source, book: b.book, ignored: flag }, onClose);await load(false);setMsg(flag ? `🚫 ${b.book} (${b.source_label}) marcada como "Não utilizar"` : `✅ ${b.book} (${b.source_label}) volta a ser usada`);}
      catch (e) {setMsg("❌ " + e.message);} finally
      {setBusy(false);}
    };
    const autoAll = async (parcial) => {
      setBusy(true);setMsg("");
      try {const r = await postJson("/api/props/casas/auto", { parcial }, onClose);await load(false);setMsg(`✅ ${r.vinculadas} casa(s) vinculada(s) automaticamente`);}
      catch (e) {setMsg("❌ " + e.message);} finally
      {setBusy(false);}
    };

    const houses = d ? d.houses : [];
    const ativas = useMemo(() => houses.filter((h) => h.active), [houses]);
    const inativas = useMemo(() => houses.filter((h) => !h.active), [houses]);
    const rows = useMemo(() => {
      if (!d) return [];
      const qq = norm(q).trim();
      return d.books.filter((b) => (srcF === "all" || b.source === srcF) && (
      flt === "all" || flt === "unlinked" && !b.house_id && !b.ignored || flt === "linked" && !!b.house_id || flt === "sug" && !b.house_id && !b.ignored && b.suggestion || flt === "ignored" && b.ignored) && (
      !qq || norm(b.book).includes(qq) || norm(b.house_name || "").includes(qq) || norm(b.suggestion ? b.suggestion.name : "").includes(qq)));
    }, [d, q, flt, srcF]);
    const nLinked = d ? d.books.filter((b) => b.house_id).length : 0;
    const nIgn = d ? d.books.filter((b) => b.ignored).length : 0;
    const nSug = d ? d.books.filter((b) => !b.house_id && b.suggestion && b.suggestion.how === "exata").length : 0;
    const nSugP = d ? d.books.filter((b) => !b.house_id && b.suggestion && b.suggestion.how === "parcial").length : 0;

    const porCasa = useMemo(() => {const m = new Map();(d ? d.books : []).forEach((b) => {if (b.house_id) {if (!m.has(b.house_id)) m.set(b.house_id, []);m.get(b.house_id).push(b);}});return m;}, [d]);

    return React.createElement("div", { className: "pc-wrap" },
    erro && React.createElement("div", { className: "pp-alert bad" }, React.createElement(Ic, { n: "error" }), erro),
    d && !d.api.keySet && React.createElement("div", { className: "pp-alert bad" }, React.createElement(Ic, { n: "key" }), "Falta a variável ", React.createElement("b", null, "PEIXE_ADMIN_API_KEY"), " no serviço ", React.createElement("b", null, "dashboard"), " (EasyPanel → crawler-odd → dashboard → Ambiente): é a X-Api-Key de uma ApiKey ativa do Peixe Admin (", d.api.base, "). Sem ela a lista de casas do cadastro fica vazia", houses.length ? " (usando o último snapshot salvo)" : "", "."),
    d && d.api.keySet && d.api.error && React.createElement("div", { className: "pp-alert" }, React.createElement(Ic, { n: "cloud_off" }), d.api.error, houses.length ? ` — usando o último snapshot (${houses.length} casas).` : ""),
    d && d.api.ok && React.createElement("div", { className: "pp-alert ok" }, React.createElement(Ic, { n: "cloud_done" }), "Cadastro do Peixe Admin: ", React.createElement("b", null, ativas.length), " casas ativas", inativas.length ? ` (+${inativas.length} inativas)` : "", " · atualizado há ", ago(d.api.at), ". ", React.createElement("a", { href: "#", onClick: (e) => {e.preventDefault();load(true);} }, "recarregar")),
    msg && React.createElement("div", { className: "pp-alert" }, msg),

    React.createElement("div", { className: "pc-stats" },
    React.createElement("span", null, React.createElement("b", null, d ? d.books.length : 0), " casas cruas vistas nas fontes"),
    React.createElement("span", null, React.createElement("b", null, nLinked), " vinculadas"),
    React.createElement("span", null, React.createElement("b", null, d ? d.books.length - nLinked - nIgn : 0), " sem vínculo"),
    nIgn > 0 && React.createElement("span", null, React.createElement("b", null, nIgn), " não utilizada(s)"),
    nSug > 0 && React.createElement("button", { className: "pp-btn pri", disabled: busy, onClick: () => autoAll(false) }, React.createElement(Ic, { n: "auto_fix_high" }), "Vincular ", nSug, " sugestão(ões) exata(s)"),
    nSugP > 0 && React.createElement("button", { className: "pp-btn", disabled: busy, onClick: async () => {if (await confirma(`Aplicar também as ${nSugP} sugestões parciais? Confira depois na lista.`)) autoAll(true);} }, React.createElement(Ic, { n: "auto_fix_normal" }), "+ ", nSugP, " parciais")
    ),

    React.createElement("div", { className: "pp-pick" }, React.createElement("div", { className: "bar" },
    React.createElement("div", { className: "q" }, React.createElement(Ic, { n: "search" }), React.createElement("input", { className: "pp-inp", placeholder: "buscar casa (crua, do cadastro ou sugestão)…", value: q, onChange: (e) => setQ(e.target.value) })),
    React.createElement("div", { className: "sel-wrap" }, React.createElement("select", { className: "sel", value: flt, onChange: (e) => setFlt(e.target.value) }, React.createElement("option", { value: "all" }, "Todas"), React.createElement("option", { value: "unlinked" }, "Sem vínculo"), React.createElement("option", { value: "sug" }, "Sem vínculo, com sugestão"), React.createElement("option", { value: "linked" }, "Vinculadas"), React.createElement("option", { value: "ignored" }, "Não utilizadas")), React.createElement(Ic, { n: "arrow_drop_down" })),
    React.createElement("div", { className: "sel-wrap" }, React.createElement("select", { className: "sel", value: srcF, onChange: (e) => setSrcF(e.target.value) }, React.createElement("option", { value: "all" }, "Todas as fontes"), SRC_IDS.map((s) => React.createElement("option", { key: s, value: s }, SRC[s].label))), React.createElement(Ic, { n: "arrow_drop_down" }))
    )),

    React.createElement("div", { className: "tbl-wrap", style: { maxHeight: "65vh", overflow: "auto", marginBottom: 0 } },
    React.createElement("table", { className: "pc-tbl" },
    React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Fonte"), React.createElement("th", null, "Casa (como a fonte escreve)"), React.createElement("th", null, "Odds ativas"), React.createElement("th", null, "Partidas"), React.createElement("th", null, "Vista há"), React.createElement("th", null, "Casa no cadastro Peixe Esperto"), React.createElement("th", null, "Sugestão"))),
    React.createElement("tbody", null,
    !d ? React.createElement("tr", null, React.createElement("td", { colSpan: 7, className: "pp-empty" }, "carregando…")) : !rows.length ? React.createElement("tr", null, React.createElement("td", { colSpan: 7, className: "pp-empty" }, "Nada aqui.")) : rows.map((b) => {
      const h = b.house_id ? houses.find((x) => x.id === b.house_id) : null;
      const irmas = b.house_id ? (porCasa.get(b.house_id) || []).filter((x) => x.key !== b.key) : [];
      if (b.ignored) return React.createElement("tr", { key: b.key, className: "ign", style: { opacity: .6 } },
      React.createElement("td", null, React.createElement("span", { className: "src " + b.source }, SRC[b.source] ? SRC[b.source].short : b.source)),
      React.createElement("td", null, React.createElement("b", { style: { textDecoration: "line-through" } }, b.book)),
      React.createElement("td", { style: { fontFamily: "var(--f-data)" } }, b.n_odds),
      React.createElement("td", { style: { fontFamily: "var(--f-data)" } }, b.n_matches),
      React.createElement("td", { style: { color: "var(--mut)" } }, b.last_seen ? ago(b.last_seen) : "—"),
      React.createElement("td", null, React.createElement("span", { style: { color: "var(--down)", fontWeight: 600 } }, React.createElement(Ic, { n: "block" }), " Não utilizar"), " ", React.createElement("span", { style: { fontSize: 11, color: "var(--mut)" } }, "— odds ocultas e não gravadas")),
      React.createElement("td", null, React.createElement("button", { className: "pp-btn", disabled: busy, onClick: () => naoUsar(b, false) }, React.createElement(Ic, { n: "undo" }), "Voltar a usar"))
      );
      return React.createElement("tr", { key: b.key, className: b.house_id ? "lk" : "" },
      React.createElement("td", null, React.createElement("span", { className: "src " + b.source }, SRC[b.source] ? SRC[b.source].short : b.source)),
      React.createElement("td", null, React.createElement("b", null, b.book)),
      React.createElement("td", { style: { fontFamily: "var(--f-data)" } }, b.n_odds),
      React.createElement("td", { style: { fontFamily: "var(--f-data)" } }, b.n_matches),
      React.createElement("td", { style: { color: "var(--mut)" } }, b.last_seen ? ago(b.last_seen) : "—"),
      React.createElement("td", null,
      React.createElement("div", { className: "sel-wrap", style: { display: "inline-block" } },
      React.createElement("select", { className: "sel", disabled: busy, value: b.house_id || "", onChange: (e) => vincular(b, e.target.value ? Number(e.target.value) : null) },
      React.createElement("option", { value: "" }, "— sem vínculo (mostra o nome cru) —"),
      ativas.map((x) => React.createElement("option", { key: x.id, value: x.id }, x.name, x.domain ? ` · ${x.domain}` : "")),
      inativas.length ? React.createElement("optgroup", { label: "Inativas no cadastro" }, inativas.map((x) => React.createElement("option", { key: x.id, value: x.id }, x.name))) : null
      ), React.createElement(Ic, { n: "arrow_drop_down" })
      ),
      h && irmas.length ? React.createElement("div", { style: { fontSize: 11, color: "var(--mut)", marginTop: 3 } }, "junto com: ", irmas.map((x) => `${x.book} (${SRC[x.source] ? SRC[x.source].short : x.source})`).join(", ")) : null,
      b.house_id && !h ? React.createElement("div", { style: { fontSize: 11, color: "var(--down)", marginTop: 3 } }, "casa #", b.house_id, " não está mais no cadastro") : null
      ),
      React.createElement("td", null, React.createElement("button", { className: "pp-btn", disabled: busy, title: "Esconder esta casa do Player Props e parar de gravar as odds dela", onClick: () => naoUsar(b, true), style: { marginRight: 6 } }, React.createElement(Ic, { n: "block" }), "Não utilizar"), !b.house_id && b.suggestion ? React.createElement("span", { className: "sug " + b.suggestion.how, title: b.suggestion.how === "exata" ? "nome/alias/domínio iguais" : "nome parecido — confira", onClick: () => !busy && vincular(b, b.suggestion.house_id) }, b.suggestion.name, b.suggestion.how === "parcial" ? " (?)" : "") : b.house_id && h ? React.createElement("span", { className: "pc-house" }, h.logo_url ? React.createElement("img", { src: h.logo_url, alt: "" }) : null, h.name) : React.createElement("span", { style: { color: "var(--mut)" } }, "—"))
      );
    })
    )
    )
    ),
    React.createElement("div", { className: "pp-meta" }, "Na aba Player Props, casas vinculadas à mesma casa do cadastro viram ", React.createElement("b", null, "uma coluna só"), ", com o nome do cadastro. Quando mais de uma fonte traz a mesma casa, cada linha (mercado × jogador × linha) mostra a odd ", React.createElement("b", null, "capturada mais recentemente"), "; se a fonte mais recente não tem aquele mercado, entra a seguinte. Fonte que a casa não vinculou aparece com o nome cru, agrupada pela fonte.")
    );
  }






  const LIGA_SRC_ADD = ["oc_uk", "oc_br", "betano"];

  const ligaNome = (l) => String(l.label || String(l.lkey || "").replace(/-\d{3,}$/, "").split("/").map((w) => w.replace(/-/g, " ")).map((w) => w.replace(/\b\w/g, (c) => c.toUpperCase())).join(" · ")).replace(/\s*\(\d+\)\s*$/, "");

  function PropsLigasTab({ onClose }) {
    const [d, setD] = useState(null);
    const [erro, setErro] = useState("");
    const [msg, setMsg] = useState("");
    const [busy, setBusy] = useState(false);
    const [q, setQ] = useState("");
    const [flt, setFlt] = useState("all");
    const [srcF, setSrcF] = useState("all");
    const [novo, setNovo] = useState({ source: "oc_uk", lkey: "", label: "" });
    const [trocando, setTrocando] = useState(null);
    const load = useCallback(async () => {
      try {setD(await getJson("/api/props/ligas", onClose));setErro("");} catch (e) {setErro(e.message);}
    }, [onClose]);
    useEffect(() => {load();}, [load]);

    const toggle = async (l) => {
      const to = !l.active;
      if (!to && !(await confirma(`Inativar "${ligaNome(l)}" (${l.source_label})?\n\nO coletor para de descobrir partidas dessa liga e as varreduras das partidas atuais dela param em todas as fontes. Dá pra reativar aqui.`))) return;
      setBusy(true);setMsg("");
      try {const r = await postJson("/api/props/ligas/toggle", { id: l.id, active: to }, onClose);await load();setMsg(to ? `✅ ${ligaNome(l)} reativada (${r.refs} varredura(s) retomada(s))` : `⏸️ ${ligaNome(l)} inativada (${r.refs} varredura(s) pausada(s) em ${r.matches} partida(s))`);}
      catch (e) {setMsg("❌ " + e.message);} finally
      {setBusy(false);}
    };
    const add = async (e) => {
      e && e.preventDefault();
      if (!novo.lkey.trim()) return;
      setBusy(true);setMsg("");
      try {const r = await postJson("/api/props/ligas/add", novo, onClose);await load();setNovo({ ...novo, lkey: "", label: "" });setMsg(`✅ Liga incluída: ${r.liga.label || r.liga.lkey} (${SRC[r.liga.source] ? SRC[r.liga.source].label : r.liga.source}) — entra na próxima descoberta`);}
      catch (e) {setMsg("❌ " + e.message);} finally
      {setBusy(false);}
    };
    const renomear = async (l) => {
      const label = await pergunta(`Nome de exibição para ${l.lkey} (${l.source_label}):`, l.label || "");
      if (label === null) return;
      setBusy(true);
      try {await postJson("/api/props/ligas/label", { id: l.id, label }, onClose);await load();} catch (e) {setMsg("❌ " + e.message);} finally {setBusy(false);}
    };

    const rows = useMemo(() => {
      if (!d) return [];
      const qq = norm(q).trim();
      return d.ligas.filter((l) => (srcF === "all" || l.source === srcF) && (
      flt === "all" || flt === "comprop" && l.com_prop || flt === "semprop" && !l.com_prop || flt === "active" && l.active || flt === "inactive" && !l.active || flt === "manual" && l.manual || flt === "upcoming" && l.n_upcoming > 0) && (
      !qq || norm(l.lkey).includes(qq) || norm(l.label || "").includes(qq) || norm(ligaNome(l)).includes(qq))).
      sort((a, b) => b.n_upcoming - a.n_upcoming || b.n_refs - a.n_refs || ligaNome(a).localeCompare(ligaNome(b), "pt-BR", { sensitivity: "base" }));
    }, [d, q, flt, srcF]);
    const nAtivas = d ? d.ligas.filter((l) => l.active).length : 0;
    const nInativas = d ? d.ligas.length - nAtivas : 0;
    const srcsSeen = d ? [...new Set(d.ligas.map((l) => l.source))] : [];

    return React.createElement("div", { className: "pc-wrap" },
    erro && React.createElement("div", { className: "pp-alert bad" }, React.createElement(Ic, { n: "error" }), erro),
    msg && React.createElement("div", { className: "pp-alert" }, msg),
    React.createElement("div", { className: "pc-stats" },
    React.createElement("span", null, React.createElement("b", null, d ? d.ligas.length : 0), " ligas vistas pelas fontes"),
    React.createElement("span", null, React.createElement("b", null, nAtivas), " ativas"),
    React.createElement("span", null, React.createElement("b", null, nInativas), " inativas"),
    React.createElement("span", { style: { color: "var(--mut)" } }, d ? d.ligas.reduce((a, l) => a + Number(l.n_upcoming || 0), 0) : 0, " partidas nas próximas horas"),
    React.createElement("span", { title: "A liga entra na lista quando a casa a anuncia, mas só vale para nós depois que uma varredura grava prop num jogo dela" }, React.createElement("b", null, d ? d.ligas.filter((l) => l.com_prop).length : 0), " já trouxeram prop")
    ),

    React.createElement("form", { className: "pp-pick", onSubmit: add }, React.createElement("div", { className: "bar", style: { alignItems: "center" } },
    React.createElement("span", { className: "sub" }, "Incluir liga"),
    React.createElement("div", { className: "sel-wrap" }, React.createElement("select", { className: "sel", value: novo.source, onChange: (e) => setNovo({ ...novo, source: e.target.value }) }, LIGA_SRC_ADD.map((s) => React.createElement("option", { key: s, value: s }, SRC[s].label))), React.createElement(Ic, { n: "arrow_drop_down" })),
    React.createElement("input", { className: "pp-inp", style: { minWidth: 320 }, placeholder: d && d.addHelp ? d.addHelp[novo.source] : "chave da liga", value: novo.lkey, onChange: (e) => setNovo({ ...novo, lkey: e.target.value }) }),
    React.createElement("input", { className: "pp-inp", placeholder: "nome de exibição (opcional)", value: novo.label, onChange: (e) => setNovo({ ...novo, label: e.target.value }) }),
    React.createElement("button", { className: "pp-btn pri", type: "submit", disabled: busy || !novo.lkey.trim() }, React.createElement(Ic, { n: "add" }), "Incluir")
    )),

    React.createElement("div", { className: "pp-pick" }, React.createElement("div", { className: "bar" },
    React.createElement("div", { className: "q" }, React.createElement(Ic, { n: "search" }), React.createElement("input", { className: "pp-inp", placeholder: "buscar liga (nome ou chave)…", value: q, onChange: (e) => setQ(e.target.value) })),
    React.createElement("div", { className: "sel-wrap" }, React.createElement("select", { className: "sel", value: flt, onChange: (e) => setFlt(e.target.value) }, React.createElement("option", { value: "all" }, "Todas"), React.createElement("option", { value: "comprop" }, "Já trouxeram prop"), React.createElement("option", { value: "semprop" }, "Nunca trouxeram prop"), React.createElement("option", { value: "upcoming" }, "Com partidas próximas"), React.createElement("option", { value: "active" }, "Ativas"), React.createElement("option", { value: "inactive" }, "Inativas"), React.createElement("option", { value: "manual" }, "Incluídas à mão")), React.createElement(Ic, { n: "arrow_drop_down" })),
    React.createElement("div", { className: "sel-wrap" }, React.createElement("select", { className: "sel", value: srcF, onChange: (e) => setSrcF(e.target.value) }, React.createElement("option", { value: "all" }, "Todas as fontes"), SRC_IDS.filter((s) => srcsSeen.includes(s)).map((s) => React.createElement("option", { key: s, value: s }, SRC[s].label))), React.createElement(Ic, { n: "arrow_drop_down" }))
    )),

    React.createElement("div", { className: "tbl-wrap", style: { maxHeight: "60vh", overflow: "auto", marginBottom: 0 } },
    React.createElement("table", { className: "pc-tbl" },
    React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Ativa"), React.createElement("th", null, "Fonte"), React.createElement("th", null, "Liga"), React.createElement("th", null, "Chave na fonte"), React.createElement("th", null, "Nossa liga"), React.createElement("th", null, "Partidas próximas"), React.createElement("th", null, "Com odds"), React.createElement("th", null, "Partidas vistas"), React.createElement("th", null, "Origem"))),
    React.createElement("tbody", null,
    !d ? React.createElement("tr", null, React.createElement("td", { colSpan: 9, className: "pp-empty" }, "carregando…")) : !rows.length ? React.createElement("tr", null, React.createElement("td", { colSpan: 9, className: "pp-empty" }, d.ligas.length ? "Nada aqui." : "O coletor ainda não registrou ligas — elas aparecem na próxima descoberta (até 2 h).")) : rows.map((l) =>
    React.createElement("tr", { key: l.id, style: l.active ? undefined : { opacity: .55 } },
    React.createElement("td", null, React.createElement("label", { className: "pp-chk", title: l.active ? "Clique para inativar" : "Clique para reativar" }, React.createElement("input", { type: "checkbox", checked: !!l.active, disabled: busy, onChange: () => toggle(l) }), " ", l.active ? "sim" : "não")),
    React.createElement("td", null, React.createElement("span", { className: "src " + l.source }, SRC[l.source] ? SRC[l.source].short : l.source)),
    React.createElement("td", null, React.createElement("b", { style: l.active ? undefined : { textDecoration: "line-through" } }, ligaNome(l)), " ", React.createElement("a", { href: "#", title: "renomear", style: { fontSize: 11, color: "var(--mut)" }, onClick: (e) => {e.preventDefault();renomear(l);} }, React.createElement(Ic, { n: "edit" }))),
    React.createElement("td", { style: { fontFamily: "var(--f-data)", fontSize: 11.5, color: "var(--ink-2)" } }, l.lkey),
    React.createElement("td", { style: { minWidth: 220 } }, l.nossa_liga ?
    React.createElement("span", null, React.createElement("b", null, l.nossa_liga.nome), l.nossa_liga.area ? React.createElement("span", { style: { color: "var(--mut)", fontSize: 11 } }, " · ", l.nossa_liga.area) : null, React.createElement("span", { style: { color: "var(--mut)", fontSize: 11 } }, " · ", l.nossa_liga.por === "human" ? "você" : "aprendido"), " ", React.createElement("a", { href: "#", title: "trocar", style: { fontSize: 11, color: "var(--mut)" }, onClick: (e) => {e.preventDefault();setTrocando(trocando === l.id ? null : l.id);} }, React.createElement(Ic, { n: "edit" }))) :
    React.createElement("span", { style: { color: "var(--mut)", fontSize: 11.5 } }, "sem vínculo"),
    (!l.nossa_liga || trocando === l.id) && window.LigaPicker && React.createElement("div", { style: { marginTop: 4 } }, React.createElement(window.LigaPicker, { sport: "football", placeholder: "ligar a…", disabled: busy, onPick: async (liga) => {
        if (!(await confirma(`"${l.rotulo_registro}" (${l.source_label}) é a liga "${liga.display_name}"${liga.area_nome ? ` (${liga.area_nome})` : ""}?`))) return;
        setBusy(true);try {await postJson("/api/admin/er/competicoes/ligar-fonte", { rotulo: l.rotulo_registro, sport: "football", fontes: [l.source], competicao_id: liga.id }, onClose);setTrocando(null);await load();setMsg(`✅ ${l.rotulo_registro} → ${liga.display_name}`);} catch (e) {setMsg("❌ " + e.message);} finally {setBusy(false);}} }))
    ),
    React.createElement("td", { style: { fontFamily: "var(--f-data)" } }, l.n_upcoming),
    React.createElement("td", { style: { fontFamily: "var(--f-data)" } }, l.n_with_odds),
    React.createElement("td", { style: { fontFamily: "var(--f-data)", color: "var(--mut)" } }, l.n_refs),
    React.createElement("td", { style: { color: "var(--mut)", fontSize: 11.5 } }, l.manual ? "incluída à mão" : "descoberta automática")
    ))
    )
    )
    ),
    React.createElement("div", { className: "pp-meta" }, "A liga aparece aqui assim que uma fonte a descobre (OddsChecker UK e BR leem a lista de ligas do site 1× por dia; OddsPapi usa os torneios configurados + os incluídos aqui). ", React.createElement("b", null, "Inativar"), " pausa a liga em todas as fontes: nada novo é descoberto e as partidas atuais dela param de ser varridas. ", React.createElement("b", null, "Incluir"), " força uma página/torneio extra na descoberta — a chave é o caminho da liga no OddsChecker (ex.: ", React.createElement("code", null, "english/premier-league"), ", ", React.createElement("code", null, "brasil/serie-a"), "; pode colar a URL) ou o id do torneio no OddsPapi. Ligas que outra fonte já traz (Casa de Apostas, Betmonitor) seguem as partidas descobertas pelas demais.")
    );
  }




  function PropsParamsTab({ onClose }) {
    const [d, setD] = useState(null);
    const [form, setForm] = useState({});
    const [erro, setErro] = useState("");
    const [msg, setMsg] = useState("");
    const [busy, setBusy] = useState(false);


    const onCloseRef = useRef(onClose);
    useEffect(() => {onCloseRef.current = onClose;}, [onClose]);
    const load = useCallback(async (refresh = false) => {
      try {const r = await getJson("/api/props/params" + (refresh ? "?refresh=1" : ""), (reason) => onCloseRef.current && onCloseRef.current(reason));setD(r);setForm(r.params);setErro("");} catch (e) {setErro(e.message);}
    }, []);
    useEffect(() => {load();}, [load]);
    const keys = d ? Object.keys(d.meta) : [];
    const markets = d && d.fairOdds ? d.fairOdds.markets : [];
    const alphaValue = (v) => v === null || v === undefined || String(v).trim() === "" ? null : Number(String(v).replace(",", "."));

    const CAD = d && d.cadencia ? d.cadencia : null;
    const fontesCad = CAD ? Object.keys(CAD.fontes).filter((f) => CAD.padrao[f]) : [];
    const cadDe = (params, f) => ({ ...(CAD && CAD.padrao[f] || {}), ...(((params || {}).cadencia || {})[f] || {}) });
    const numCad = (v) => Number(String(v ?? "").replace(",", "."));
    const cadIgual = (a, b) => !!CAD && CAD.campos.every((k) => numCad(a[k]) === numCad(b[k]));
    const cadDirty = !!CAD && fontesCad.some((f) => !cadIgual(cadDe(form, f), cadDe(d.params, f)));
    const setCad = (f, k, v) => {setMsg("");setForm((x) => ({ ...x, cadencia: { ...(x.cadencia || {}), [f]: { ...cadDe(x, f), [k]: v } } }));};
    const dirty = d && (keys.some((k) => Number(form[k]) !== Number(d.params[k])) || markets.some((m) => alphaValue((form.fairExponents || {})[m.code]) !== alphaValue((d.params.fairExponents || {})[m.code])) || cadDirty);
    const setAlpha = (code, value) => {setMsg("");setForm((f) => ({ ...f, fairExponents: { ...f.fairExponents, [code]: value } }));};
    const save = async (e) => {
      e && e.preventDefault();
      setBusy(true);setMsg("");

      const corpo = { ...form };
      if (CAD) corpo.cadencia = Object.fromEntries(fontesCad.map((f) => {const v = cadDe(form, f);return [f, cadIgual(v, CAD.padrao[f]) ? null : Object.fromEntries(CAD.campos.map((k) => [k, numCad(v[k])]))];}));
      try {const r = await postJson("/api/props/params", corpo, onClose);setD({ ...d, params: r.params });setForm(r.params);setMsg("✅ Salvo. As odds justas serão recalculadas ao atualizar a partida. A janela de captura e a cadência valem em até 1 minuto.");}
      catch (e2) {setMsg("❌ " + e2.message);} finally
      {setBusy(false);}
    };
    const fmtH = (h) => {const n = Number(h);if (!Number.isFinite(n)) return "";if (n % 24 === 0) return `${n / 24} dia${n / 24 === 1 ? "" : "s"}`;return n > 24 ? `${Math.floor(n / 24)}d ${n % 24}h` : `${n}h`;};
    return React.createElement("div", { className: "pc-wrap" },
    erro && React.createElement("div", { className: "pp-alert bad" }, React.createElement(Ic, { n: "error" }), erro),
    msg && React.createElement("div", { className: "pp-alert" }, msg),
    React.createElement("form", { onSubmit: save },
    React.createElement("div", { className: "tbl-wrap", style: { marginBottom: 12 } },
    React.createElement("table", { className: "pc-tbl" },
    React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Parâmetro"), React.createElement("th", null, "Valor"), React.createElement("th", null, "Padrão"), React.createElement("th", null, "O que faz"))),
    React.createElement("tbody", null,
    !d ? React.createElement("tr", null, React.createElement("td", { colSpan: 4, className: "pp-empty" }, "carregando…")) : keys.map((k) => React.createElement("tr", { key: k },
    React.createElement("td", null, React.createElement("b", null, d.meta[k].label)),
    React.createElement("td", { style: { whiteSpace: "nowrap" } },
    React.createElement("input", { className: "pp-inp", type: "number", min: d.meta[k].min, max: d.meta[k].max, step: 1, style: { width: 90, fontFamily: "var(--f-data)" }, value: form[k] ?? "", onChange: (e) => setForm({ ...form, [k]: e.target.value }) }),
    React.createElement("span", { style: { marginLeft: 8, color: "var(--mut)", fontSize: 11.5 } }, "= ", fmtH(form[k]))
    ),
    React.createElement("td", { style: { fontFamily: "var(--f-data)", color: "var(--mut)" } }, d.defaults[k], " ", React.createElement("a", { href: "#", style: { fontSize: 11, marginLeft: 6 }, onClick: (e) => {e.preventDefault();setForm({ ...form, [k]: d.defaults[k] });} }, "usar padrão")),
    React.createElement("td", { style: { color: "var(--ink-2)", fontSize: 12 } }, d.meta[k].help)
    ))
    )
    )
    ),
    CAD && fontesCad.length > 0 && React.createElement("section", { className: "pp-fair-settings", style: { marginBottom: 14 } },
    React.createElement("h3", null, "Cadência de captura por fonte"),
    React.createElement("p", null, "De quanto em quanto tempo cada fonte é lida, pela distância do jogo: ", React.createElement("b", null, "longe"), " (mais de X horas do início), ", React.createElement("b", null, "meio"), " e ", React.createElement("b", null, "perto"), " (menos de Y horas). Na Betano (OddsPapi, cobrada por requisição) a vez é de cada torneio, pelo jogo dele mais próximo, e cada chamada leva até 5 torneios."),
    CAD.agendaBetano && React.createElement("div", { className: "pp-meta", style: { marginBottom: 8 } }, "Betano agora: ",
    React.createElement("b", null, CAD.agendaBetano.torneios), " torneio(s) — ", CAD.agendaBetano.faixa.longe, " longe · ", CAD.agendaBetano.faixa.meio, " no meio · ", CAD.agendaBetano.faixa.perto, " perto",
    CAD.agendaBetano.proximaChamada ? React.createElement(React.Fragment, null, " · próxima chamada às ", new Date(CAD.agendaBetano.proximaChamada).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })) : null,
    CAD.consumoBetano ? React.createElement(React.Fragment, null, " · hoje: ", React.createElement("b", null, CAD.consumoBetano.hoje), " requisição(ões)", CAD.consumoBetano.mediaDia != null ? React.createElement(React.Fragment, null, " (média ", Math.round(CAD.consumoBetano.mediaDia), "/dia, plano ", CAD.consumoBetano.planoMes, "/mês)") : null) : null
    ),
    CAD.ignoradas && CAD.ignoradas.length > 0 && React.createElement("div", { className: "pp-alert bad" }, React.createElement(Ic, { n: "error" }), "O coletor recusou e ficou no padrão: ", CAD.ignoradas.join(" · ")),
    React.createElement("div", { className: "tbl-wrap" }, React.createElement("table", { className: "pc-tbl" },
    React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Fonte"), React.createElement("th", null, "Longe"), React.createElement("th", null, "Meio"), React.createElement("th", null, "Perto"), React.createElement("th", null))),
    React.createElement("tbody", null, fontesCad.map((f) => {
      const v = cadDe(form, f),p = CAD.padrao[f];
      const inp = (k, w = 58) => React.createElement("input", { id: `cad-${f}-${k}`, className: "pp-inp", inputMode: "decimal", "aria-label": `${CAD.fontes[f]} ${k}`, style: { width: w, fontFamily: "var(--f-data)" }, value: v[k] ?? "", onChange: (e) => setCad(f, k, e.target.value), disabled: busy });
      return React.createElement("tr", { key: f },
      React.createElement("td", null, React.createElement("b", null, CAD.fontes[f])),
      React.createElement("td", { style: { whiteSpace: "nowrap" } }, "mais de ", inp("faixaLongeH", 52), " h: a cada ", inp("cadaLongeH"), " h"),
      React.createElement("td", { style: { whiteSpace: "nowrap" } }, "a cada ", inp("cadaMeioH"), " h"),
      React.createElement("td", { style: { whiteSpace: "nowrap" } }, "menos de ", inp("faixaPertoH", 52), " h: a cada ", inp("cadaPertoH"), " h"),
      React.createElement("td", { style: { fontSize: 11.5, color: "var(--mut)", whiteSpace: "nowrap" } }, cadIgual(v, p) ? "padrão" : React.createElement("a", { href: "#", onClick: (e) => {e.preventDefault();setForm((x) => ({ ...x, cadencia: { ...(x.cadencia || {}), [f]: { ...p } } }));} }, "usar padrão (", p.cadaLongeH, "/", p.cadaMeioH, "/", p.cadaPertoH, " h)"))
      );
    }))
    ))
    ),
    d && d.fairOdds && React.createElement("section", { className: "pp-fair-settings" },
    React.createElement("h3", null, "Expoentes das odds justas"),
    React.createElement("p", null, "Cadastre um expoente por mercado. O mesmo valor será usado nas três colunas: ", React.createElement("b", null, "odd justa = odd de referência elevada ao expoente"), ". Em branco, o mercado fica sem cálculo."),
    React.createElement("div", { className: "pp-fair-summary" },
    React.createElement("span", { title: d.fairOdds.legacyGroups.map((g) => g.name).join(", ") }, React.createElement("b", null, "K nominal: ", d.fairOdds.kNominal), " · grupos marcados para o legado"),
    React.createElement("span", { title: d.fairOdds.semiSharpGroups.map((g) => g.name).join(", ") }, React.createElement("b", null, d.fairOdds.semiSharpGroups.length, " grupos semi-sharp"), " · usa os 2 com maiores odds disponíveis"),
    React.createElement("button", { className: "pp-btn", type: "button", disabled: busy || dirty, onClick: () => load(true), title: dirty ? "Salve ou desfaça as alterações antes de atualizar os grupos" : "Recarregar as marcações do Peixe Admin" }, React.createElement(Ic, { n: "refresh" }), "Atualizar grupos")
    ),
    d.fairOdds.apiError && React.createElement("div", { className: "pp-alert", title: d.fairOdds.apiError }, "Não foi possível atualizar o cadastro na API. Os grupos exibidos vêm do último registro salvo."),
    React.createElement("div", { className: "tbl-wrap" }, React.createElement("table", { className: "pc-tbl" },
    React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Mercado"), React.createElement("th", null, "Expoente"))),
    React.createElement("tbody", null, markets.map((m) => React.createElement("tr", { key: m.code },
    React.createElement("td", null, React.createElement("b", null, m.label)),
    React.createElement("td", null, React.createElement("input", { className: "pp-inp", "aria-label": `Expoente de ${m.label}`, inputMode: "decimal", placeholder: "Não definido", style: { width: 150, fontFamily: "var(--f-data)" }, value: (form.fairExponents || {})[m.code] ?? "", onChange: (e) => setAlpha(m.code, e.target.value), disabled: busy }))
    )))
    ))
    ),
    React.createElement("div", { className: "bar", style: { display: "flex", gap: 8, alignItems: "center" } },
    React.createElement("button", { className: "pp-btn pri", type: "submit", disabled: busy || !dirty }, React.createElement(Ic, { n: "save" }), "Salvar"),
    dirty && React.createElement("button", { className: "pp-btn", type: "button", disabled: busy, onClick: () => setForm(d.params) }, "Desfazer")
    )
    ),
    React.createElement("div", { className: "pp-meta" }, "Os valores ficam no banco (props_status) e valem pra todas as fontes. A janela de captura define quando a partida entra na fila: com 72 h, um jogo de sábado entra na quarta. Partida já iniciada sai da lista e para de ser varrida.")
    );
  }

  window.PlayerPropsTab = PlayerPropsTab;
  window.PropsCasasTab = PropsCasasTab;
  window.PropsLigasTab = PropsLigasTab;
  window.PropsParamsTab = PropsParamsTab;
})();