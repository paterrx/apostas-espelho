// =====================================================================
// [07/10] issue #66: ESCOLHER UM CADASTRO É ESCOLHER PELO NÚMERO, NÃO PELO NOME.
//
// O "Mover" de uma grafia (Identidades → Grafias) listava os destinos só pelo nome: com homônimos aparecem dois botões
// "Galatasaray" iguais (#1094 futebol e #2470708 basquete, os dois TUR), a busca pelo número não achava nada e o clique
// movia na hora. O operador acertou pela ordem da busca. Aqui fica o padrão de toda escolha de clube/jogador da tela:
//   - termoDaBusca("#2470708" ou "2470708") acha o cadastro pelo número (como o LigaPicker, issue #48);
//   - rotuloEntidade(e) diz "#id · país · esporte" (e o time, para jogador), o que separa homônimos;
//   - confirmaMover(...) escreve a pergunta antes de mover, com o número dos dois lados.
// Carregado no index.html e por require no servidor e nos testes.
// =====================================================================
(function (raiz) {
  const ESPORTE_PT = { football: "futebol", basketball: "basquete", tennis: "tênis", ice_hockey: "hóquei", hockey: "hóquei",
    baseball: "beisebol", american_football: "futebol americano", volleyball: "vôlei", handball: "handebol", esports: "eSports" };

  /** Texto digitado → { id } quando é um número (com ou sem "#"), e sempre o texto para nome/grafia. */
  function termoDaBusca(q) {
    const t = String(q == null ? "" : q).trim();
    const m = /^#?\s*(\d{1,12})$/.exec(t);
    return { texto: t, id: m ? Number(m[1]) : null };
  }

  const nomeEsporte = (e) => (e && (e.esporte_nome || ESPORTE_PT[e.sport] || e.sport)) || "";

  // [18/10] issue #129: nação do Reino Unido fica GBR na coluna country e a nação na área (paisDaArea, paisPorGente.js).
  // O que a tela mostra como país do cadastro é a área quando houver (ENG, SCO...); senão, a coluna country. O "País…"
  // gravava ENG e o card e o cabeçalho seguiam em GBR (Manchester Basketball (F) #4072180; 462 clubes em ENG/SCO/WAL/NIR).
  const paisMostrado = (e) => (e && (e.area_code || e.country)) || "";

  // [20/10] issue #132: no esporte individual (er_sport.tipo) o competidor do jogo é kind='team' por modelo (er_event
  // home/away), mas é uma pessoa: a tela o chama de "atleta" e o filtro "Jogadores" o inclui. O kind não muda: as ações
  // (juntar, separar jogos, país) seguem as do 'team'.
  const ehAtleta = (e) => !!(e && e.kind === "team" && e.esporte_tipo === "individual");
  /** "jogador" | "atleta" | "clube" — o que a tela diz do cadastro. */
  const papelEntidade = (e) => (e && e.kind === "player") ? "jogador" : ehAtleta(e) ? "atleta" : "clube";
  const iconeEntidade = (e) => papelEntidade(e) === "clube" ? "🛡️ " : "👤 ";

  /** "#2470708 · TUR · basquete" — o que distingue dois cadastros de mesmo nome. */
  function rotuloEntidade(e) {
    if (!e) return "";
    const partes = ["#" + e.id, paisMostrado(e) || "sem país"];
    const esp = nomeEsporte(e);
    if (esp) partes.push(esp);
    if (e.kind === "player") partes.push(e.time_do_jogador ? "time: " + e.time_do_jogador : "time não deduzido");
    return partes.join(" · ");
  }

  /** Pergunta antes de mover a linha de grafia: texto, escopo e os dois cadastros com número. */
  function confirmaMover(alias, escopo, de, para) {
    return 'Mover a grafia "' + alias + '" (' + (escopo || "sem escopo") + ")\n\n" +
      "de   " + (de && de.display_name) + " (" + rotuloEntidade(de) + ")\n" +
      "para " + (para && para.display_name) + " (" + rotuloEntidade(para) + ")?\n\n" +
      "Fica gravada como decisão sua; dá para mover de volta pelo mesmo botão.";
  }

  const api = { termoDaBusca, rotuloEntidade, confirmaMover, nomeEsporte, paisMostrado, ehAtleta, papelEntidade, iconeEntidade };
  if (typeof module === "object" && module.exports) module.exports = api;
  else raiz.escolhaEntidade = api;
})(typeof window !== "undefined" ? window : globalThis);
