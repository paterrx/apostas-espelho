
const{useState,useEffect,useMemo,useCallback,useRef}=React;
const Ic=({n,...p})=>React.createElement("span",{className:"ms-icon",...p},n);


function useRota(k,padrao,push){
const[v,setV]=useState(()=>window.Rota?window.Rota.get(k,padrao):padrao);
useEffect(()=>window.Rota?window.Rota.ouvir(()=>setV(window.Rota.get(k,padrao))):undefined,[k]);
const set=(nv)=>setV((atual)=>{const x=typeof nv==='function'?nv(atual):nv;if(window.Rota)window.Rota.set({[k]:x===padrao?null:x},{push:!!push});return x;});
return[v,set];
}

function usePrefServidor(k,padrao){
const lk='pref.'+k;
const[v,setV]=useState(()=>{try{const x=localStorage.getItem(lk);return x==null?padrao:JSON.parse(x);}catch(e){return padrao;}});
const t=useRef(null);


useEffect(()=>{leJson('/api/props/prefs').then((p)=>{if(p&&p[k]!=null){setV(p[k]);try{localStorage.setItem(lk,JSON.stringify(p[k]));}catch(e){}}}).catch((e)=>console.error('[pref '+k+'] leitura:',e.message));},[]);
const salvar=(nv)=>{setV(nv);try{localStorage.setItem(lk,JSON.stringify(nv));}catch(e){}clearTimeout(t.current);
t.current=setTimeout(()=>leJson('/api/props/prefs/'+k,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({v:nv})}).catch((e)=>console.error('[pref '+k+'] gravação:',e.message)),500);};
return[v,salvar];
}

const CASA_FIXED={'SportingBet':'#f5b544','Betboo':'#ff8da0','Betano':'#ff8a3d','superbet':'#ff6fae','BetsSon':'#cfbdff','bet365':'#52ffac','Betnacional':'#a5eeff','KTO':'#00daf8','estrelabet':'#a5eeff','Novibet':'#e8ddff'};
function casaColor(c){if(CASA_FIXED[c])return CASA_FIXED[c];const h=[...c].reduce((a,x)=>a+x.charCodeAt(0),0)%360;return`hsl(${h} 75% 68%)`;}
function timeAgo(d){if(!d)return'';const s=Math.floor((Date.now()-new Date(d).getTime())/1000);if(s<60)return'agora';if(s<3600)return`${Math.floor(s/60)}min`;if(s<86400)return`${Math.floor(s/3600)}h`;return`${Math.floor(s/86400)}d`;}
function fmtNum(n){return Number(n).toLocaleString('pt-BR');}




const VAZIO='\x1e';
const rotulo=(v)=>v===VAZIO?'(vazio)':v;







const MAPA_BUSCA=[['\u00e5','a'],['\u00f8','o'],['\u00e6','ae'],['\u0153','oe'],['\u00df','ss'],['\u00f0','d'],['\u00fe','th'],['\u0142','l'],['\u0111','d'],['\u0131','i']];
function normBusca(txt){
let v=String(txt==null?'':txt).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
for(const[de,para]of MAPA_BUSCA)v=v.split(de).join(para);
return v;
}

const ordenaOpcoes=(a,b)=>a===VAZIO?-1:b===VAZIO?1:(a||'').localeCompare(b||'','pt-BR',{sensitivity:'base'});

function MultiSelect({items,selected,onChange,counts}){
const[open,setOpen]=useState(false),[q,setQ]=useState('');const ref=useRef();
useEffect(()=>{const h=(e)=>{if(ref.current&&!ref.current.contains(e.target))setOpen(false);};document.addEventListener('mousedown',h);return()=>document.removeEventListener('mousedown',h);},[]);

useEffect(()=>{if(selected.length===0)setQ('');},[selected.length]);

const filtered=useMemo(()=>{const nq=normBusca(q);return nq?items.filter((i)=>normBusca(rotulo(i)).includes(nq)):items;},[items,q]);



const toggle=(i)=>onChange((prev)=>{const base=Array.isArray(prev)?prev:selected;return base.includes(i)?base.filter((s)=>s!==i):[...base,i];});
const txt=selected.length===0?'Todas':selected.length<=2?selected.map(rotulo).join(', '):`${selected.length} selecionadas`;
return React.createElement("div",{className:"ms",ref:ref},
React.createElement("div",{className:"ms-btn"+(selected.length?' has':''),onClick:()=>setOpen(!open)},
React.createElement("span",{style:{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}},txt),
selected.length>0&&React.createElement("span",{className:"badge"},selected.length),
React.createElement(Ic,{n:"arrow_drop_down"})
),
open&&React.createElement("div",{className:"ms-pop"},
React.createElement("div",{className:"ms-search"},React.createElement("input",{placeholder:"Buscar…",value:q,onChange:(e)=>setQ(e.target.value),autoFocus:true})),
React.createElement("div",{className:"ms-acts"},React.createElement("span",{onClick:()=>onChange([...items])},"Selecionar todos"),React.createElement("span",{onClick:()=>onChange([])},"Limpar")),
React.createElement("div",{className:"ms-list"},filtered.map((item)=>{const on=selected.includes(item);return(
React.createElement("div",{key:item,className:"ms-item",onClick:()=>toggle(item)},
React.createElement("span",{className:"box"+(on?' on':'')},React.createElement(Ic,{n:"check"})),
React.createElement("span",{style:item===VAZIO?{fontStyle:'italic',opacity:.75}:null},rotulo(item)),counts&&counts[item]!==undefined&&React.createElement("span",{className:"ic"},fmtNum(counts[item]))
));}),
filtered.length===0&&React.createElement("div",{style:{padding:14,textAlign:'center',color:'var(--on-surface-variant)',fontSize:12}},"Nenhum")
)
)
);
}

function Metric({k,v,s,c,icon}){return React.createElement("div",{className:"metric rise",style:{'--mc':c}},React.createElement("div",{className:"bg-ic"},React.createElement(Ic,{n:icon})),React.createElement("div",{className:"k"},k),React.createElement("div",{className:"v"},v),s&&React.createElement("div",{className:"s"},s));}

function Sparkline({points,times}){


const[hover,setHover]=useState(null);const wrapRef=useRef();
if(!points||points.length<2)return null;
const w=260,h=64,pad=6;
const min=Math.min(...points),max=Math.max(...points);
const range=max-min||1;
const step=(w-pad*2)/(points.length-1);
const xy=points.map((v,i)=>[pad+i*step,h-pad-(v-min)/range*(h-pad*2)]);
const d=xy.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
const last=points[points.length-1],first=points[0];
const up=last>=first;
const col=up?'var(--up)':'var(--down)';
const area=`M${xy[0][0]},${h-pad} `+xy.map((p)=>'L'+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ')+` L${xy[xy.length-1][0]},${h-pad} Z`;

const onMove=(e)=>{
const rect=wrapRef.current.getBoundingClientRect();
const relX=(e.clientX-rect.left)/rect.width*w;
let idx=Math.round((relX-pad)/step);
idx=Math.max(0,Math.min(points.length-1,idx));
setHover(idx);
};
return React.createElement("div",{className:"spark-wrap",ref:wrapRef,onMouseMove:onMove,onMouseLeave:()=>setHover(null)},
React.createElement("svg",{className:"spark",viewBox:`0 0 ${w} ${h}`,preserveAspectRatio:"none"},
React.createElement("defs",null,React.createElement("linearGradient",{id:"sg",x1:"0",y1:"0",x2:"0",y2:"1"},React.createElement("stop",{offset:"0%",stopColor:col,stopOpacity:"0.28"}),React.createElement("stop",{offset:"100%",stopColor:col,stopOpacity:"0"}))),
React.createElement("path",{d:area,fill:"url(#sg)"}),
React.createElement("path",{d:d,fill:"none",stroke:col,strokeWidth:"2",strokeLinejoin:"round",strokeLinecap:"round"}),
hover!==null&&React.createElement("line",{x1:xy[hover][0],y1:pad,x2:xy[hover][0],y2:h-pad,stroke:"var(--on-surface-variant)",strokeWidth:"1",strokeDasharray:"3 3",opacity:"0.5"}),
xy.map((p,i)=>React.createElement("circle",{key:i,cx:p[0],cy:p[1],r:hover===i?4:i===xy.length-1?3:1.8,fill:col,stroke:hover===i?'var(--surface)':'none',strokeWidth:hover===i?1.5:0}))
),
hover!==null&&React.createElement("div",{className:"spark-tip",style:{left:`${xy[hover][0]/w*100}%`}},
React.createElement("span",{className:"st-val"},points[hover].toFixed(2)),
hover>0&&times&&times[hover-1]&&React.createElement("span",{className:"st-time"},timeAgo(times[hover-1])),
hover===0&&React.createElement("span",{className:"st-time"},"inicial")
)
);
}



function kellyQuarto(o){const fair=Number(o.fair_odds),odd=Number(o.odds);if(!(fair>1)||!(odd>1))return 0;const p=1/fair,b=odd-1;const q=(b*p-(1-p))/b*0.25;return isFinite(q)?q:0;}



const normCasaObs=(s)=>String(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'');
const obsStore={lista:[],em:0,subs:new Set(),carregando:null};
function carregaObs(forca){
if(!forca&&(obsStore.carregando||Date.now()-obsStore.em<5*60e3))return obsStore.carregando;
const seq=obsStore.seq=(obsStore.seq||0)+1;
obsStore.carregando=fetch('/api/obs-liquidacao',{credentials:'include'}).then((r)=>r.ok?r.json():[]).then((l)=>{if(seq!==obsStore.seq)return;obsStore.lista=Array.isArray(l)?l:[];obsStore.em=Date.now();}).
catch(()=>{obsStore.em=Date.now();}).finally(()=>{obsStore.carregando=null;obsStore.subs.forEach((f)=>{try{f();}catch(e){}});});
return obsStore.carregando;
}


const ESPORTE_OBS={football:'Futebol',basketball:'Basquete',tennis:'Tênis',hockey:'Hóquei no gelo',baseball:'Beisebol',nfl:'Futebol americano',volleyball:'Vôlei',esports:'E-sports',mma:'MMA',boxing:'Boxe',handball:'Handebol',darts:'Dardos',cricket:'Críquete',snooker:'Sinuca'};
const esporteObs=(s)=>{const t=String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();if(!t)return null;
if(/futebol|soccer|^football$/.test(t))return'football';if(/basquete|basket/.test(t))return'basketball';if(/tenis|tennis/.test(t)&&!/mesa|table/.test(t))return'tennis';
if(/hoquei|hockey/.test(t))return'hockey';if(/beisebol|baseball/.test(t))return'baseball';
if(/americano|american|nfl|ncaaf/.test(t))return'nfl';if(/volei|volley/.test(t))return'volleyball';if(/e-?sports?|cs2|dota|valorant|league of legends/.test(t))return'esports';
if(/mma|ufc|artes marciais/.test(t))return'mma';if(/boxe|boxing/.test(t))return'boxing';if(/handebol|andebol|handball/.test(t))return'handball';
if(/dardos|darts/.test(t))return'darts';if(/criquete|cricket/.test(t))return'cricket';if(/sinuca|snooker/.test(t))return'snooker';return'outro';};
function obsPara(casas,mercado,esporte){
const ns=(casas||[]).map(normCasaObs).filter(Boolean);
if(!ns.length)return[];
const e=esporteObs(esporte);
return obsStore.lista.filter((o)=>ns.includes(o.casa_norm)&&(o.mercado==='*'||mercado&&o.mercado===mercado)&&(!o.esporte||!e||o.esporte===e));
}




const SIMBOLO_LIQ={bloqueia:'×',contra:'−',a_favor:'+',pendente:'!',misto:'±'};
const LADO_ROT={mais:'Mais',menos:'Menos',sim:'Sim',nao:'Não',casa:'Casa',fora:'Fora',empate:'Empate',nenhum:'Nenhum',favorito:'Favorito (odd < 2,00)',azarao:'Azarão (odd ≥ 2,00)','*':'Todos os lados'};
const CLASSE_ROT={sem_efeito:'sem efeito',a_favor:'a favor',contra:'contra (alerta)',bloqueia:'bloqueia',pendente:'sem classificação'};
const ROTULO_LIQ={bloqueia:'Bloqueia: este lado sai do EV',contra:'Contra: a regra da casa pode piorar este lado — confira antes de apostar',a_favor:'A favor: a regra da casa só melhora este lado (o EV mostrado é o mínimo)',pendente:'Sem classificação: confira antes de apostar'};
function ObsAlerta({casa,casas,mercado,esporte,lado,liq,periodo,molde}){
const[,tick]=useState(0);
useEffect(()=>{const f=()=>tick((x)=>x+1);obsStore.subs.add(f);carregaObs();return()=>{obsStore.subs.delete(f);};},[]);
const L=window.LiqEfeito;
const porId=new Map(obsStore.lista.map((o)=>[o.id,o]));
let classe,itens;

if(liq){classe=liq.classe;itens=(liq.itens||[]).map((i)=>({o:porId.get(i.id)||(i.texto?{casa:'Sistema',mercado:'*',texto:i.texto}:null),classe:i.classe})).filter((i)=>i.o);}else


if(L){const r=L.resumo(molde?obsStore.lista:obsStore.lista.filter((o)=>!o.molde_casa),{casas:casas||[casa],mercado,esporte,lado,periodo,molde});if(!r)return null;classe=r.classe;itens=r.itens;

if(r.varia){const ld=Object.entries(r.porLado).filter(([l])=>l!=='*').map(([l,c])=>(LADO_ROT[l]||l)+': '+CLASSE_ROT[c]).join(' · ');
const txtV='Varia por lado — '+ld+'\n'+itens.map((i)=>'• '+i.o.casa+' · '+(i.o.esporte?ESPORTE_OBS[i.o.esporte]+' · ':'')+(i.o.mercado==='*'?'Todos os mercados':i.o.mercado_nome||i.o.mercado)+': '+i.o.texto+'\n   → '+Object.entries(i.porLado||{}).map(([l,c])=>(LADO_ROT[l]||l)+': '+CLASSE_ROT[c]).join(' · ')).join('\n');
return React.createElement("span",{className:"obs-alerta liq-misto",title:txtV,"aria-label":txtV,role:"img",onClick:(e)=>e.stopPropagation()},"±");}}else
{const l=obsPara(casas||[casa],mercado,esporte).filter((o)=>!o.molde_casa||molde&&L&&L.normMolde(o.molde_casa)===L.normMolde(molde));if(!l.length)return null;classe='pendente';itens=l.map((o)=>({o,classe:'pendente'}));}
if(!classe||classe==='sem_efeito')return null;
const nomeEf=(i)=>i.porLado&&Object.keys(i.porLado).length?Object.entries(i.porLado).map(([l,c])=>(LADO_ROT[l]||l)+': '+CLASSE_ROT[c]).join(' · '):i.classe==='sem_efeito'?'sem efeito no EV':ROTULO_LIQ[i.classe]||i.classe;
const txt=(lado?ROTULO_LIQ[classe]:ROTULO_LIQ[classe].replace('este lado','todos os lados'))+'\n'+itens.map((i)=>'• '+i.o.casa+' · '+(i.o.esporte?ESPORTE_OBS[i.o.esporte]+' · ':'')+(i.o.mercado==='*'?'Todos os mercados':i.o.mercado_nome||i.o.mercado)+': '+i.o.texto+'\n   → '+nomeEf(i)).join('\n');
return React.createElement("span",{className:"obs-alerta liq-"+classe,title:txt,"aria-label":txt,role:"img",onClick:(e)=>e.stopPropagation()},SIMBOLO_LIQ[classe]||'!');
}
window.ObsAlerta=ObsAlerta;


const EV_AGUARDANDO_TXT='Aguardando confirmação da casa: a linha não veio na última leitura da casa (sem a casa dizer que tirou). Sai se faltar de novo na leitura seguinte (30–60 s); até lá fica apagada e o robô não aposta nela.';


window.obsStore=obsStore;window.carregaObs=carregaObs;



const ALVOS_LIQ=[['*','Todos os mercados da observação'],['@jogo','Só mercados de jogo/time'],['@jogador','Só mercados de jogador']];
const LADOS_LIQ=[['*','Todos os lados'],['mais','Mais'],['menos','Menos'],['sim','Sim'],['nao','Não'],['casa','Casa'],['fora','Fora'],['empate','Empate'],['nenhum','Nenhum'],['favorito','Favorito (odd < 2,00)'],['azarao','Azarão (odd ≥ 2,00)']];
const CLASSES_LIQ=[['sem_efeito','Sem efeito'],['a_favor','A favor'],['contra','Contra (alerta)'],['bloqueia','Bloqueia']];
function LiqChips({efeitos}){
const L=window.LiqEfeito;
if(!efeitos||!efeitos.length)return React.createElement("span",{className:"liq-chip pendente"},"sem classificação");
return React.createElement("span",{style:{display:'inline-flex',flexWrap:'wrap',gap:4}},efeitos.map((e,i)=>React.createElement("span",{key:i,className:'liq-chip '+(L?L.classeDe(e.classe):e.classe),title:L?L.descreveEfeito(e):e.classe},
(e.alvo!=='*'?e.alvo==='@jogo'?'jogo · ':e.alvo==='@jogador'?'jogador · ':e.alvo+' · ':'')+(e.lado==='*'?'':e.lado+': ')+((CLASSES_LIQ.find((c)=>c[0]===(L?L.classeDe(e.classe):e.classe))||[])[1]||e.classe))));
}
function LiqEditor({obs,mercados,onSalvo,onCancela}){
const L=window.LiqEfeito;
const[rows,setRows]=useState(()=>(obs.efeitos&&obs.efeitos.length?obs.efeitos:[{alvo:'*',lado:'*',classe:'sem_efeito'}]).map((e)=>({alvo:e.alvo,lado:e.lado,classe:L?L.classeDe(e.classe):e.classe})));
const[msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
const muda=(i,patch)=>setRows(rows.map((r,j)=>j===i?{...r,...patch}:r));
const alvos=obs.mercado==='*'?[...ALVOS_LIQ,...mercados.map((m)=>[m.code,m.nome])]:[['*','Este mercado']];
const salva=async()=>{setBusy(true);setMsg('');try{const r=await fetch('/api/admin/obs-liquidacao/'+obs.id+'/efeitos',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({efeitos:rows})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Erro');onSalvo(d.msg);}catch(e){setMsg('❌ '+e.message);}finally{setBusy(false);}};
return React.createElement("div",{style:{background:'var(--paper-2, #f4f7f8)',border:'1px solid var(--line)',borderRadius:10,padding:10,display:'grid',gap:8}},
React.createElement("div",{style:{fontSize:12.5,color:'var(--ink-2)'}},"O que esta regra faz com o EV, contra a Pinnacle. O mais específico vale (mercado e lado exatos antes de \"todos\"). ",React.createElement("b",null,"A favor")," e ",React.createElement("b",null,"Contra")," não mudam o EV nem o Kelly (contra é alerta para você analisar); ",React.createElement("b",null,"Bloqueia")," tira o lado do EV."),
rows.map((r,i)=>React.createElement("div",{key:i,style:{display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}},
React.createElement("select",{id:'liq-alvo-'+obs.id+'-'+i,value:r.alvo,onChange:(e)=>muda(i,{alvo:e.target.value})},alvos.map(([v,t])=>React.createElement("option",{key:v,value:v},t))),
React.createElement("select",{id:'liq-lado-'+obs.id+'-'+i,value:r.lado,onChange:(e)=>muda(i,{lado:e.target.value})},LADOS_LIQ.map(([v,t])=>React.createElement("option",{key:v,value:v},t))),
React.createElement("select",{id:'liq-classe-'+obs.id+'-'+i,value:r.classe,onChange:(e)=>muda(i,{classe:e.target.value})},CLASSES_LIQ.map(([v,t])=>React.createElement("option",{key:v,value:v},t))),
React.createElement("button",{className:"btn-sm",onClick:()=>setRows(rows.filter((_,j)=>j!==i)),disabled:rows.length<2,title:"Tirar esta linha"},"✕")
)),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center'}},
React.createElement("button",{className:"btn-sm",onClick:()=>setRows([...rows,{alvo:'*',lado:'mais',classe:'contra'}])},"+ lado"),
React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:salva},"Salvar e aprovar"),
React.createElement("button",{className:"btn-sm",onClick:onCancela},"Cancelar"),
msg&&React.createElement("span",{style:{fontSize:12.5}},msg)
)
);
}


function LiqLogicas({onMudou}){
const[d,setD]=useState(null),[aberta,setAberta]=useState(null),[msg,setMsg]=useState('');
const load=async()=>{try{const r=await fetch('/api/admin/liq/regras',{credentials:'include'});setD(r.ok?await r.json():{regras:[]});}catch(e){setD({regras:[]});}};
useEffect(()=>{load();},[]);
const muda=async(codigo,aprovada)=>{const r=await fetch('/api/admin/liq/regras/'+encodeURIComponent(codigo),{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({aprovada})});const x=await r.json();setMsg(r.ok?'✅ '+x.msg:'❌ '+(x.error||'Erro'));load();onMudou&&onMudou();};
if(!d)return React.createElement("div",{className:"ev-sub"},"Carregando as lógicas…");
const nOk=d.regras.filter((r)=>r.aprovada).length;
return React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{style:{margin:'0 0 4px'}},"Lógicas (",nOk," de ",d.regras.length," aprovadas)"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8,maxWidth:820}},"Cada observação foi lida pelo texto e caiu numa ou mais lógicas. Aprovar a lógica aprova todas as observações dela — e as que forem cadastradas depois. Clique numa linha para ver exemplos.",d.semLogica?` ${d.semLogica} observação(ões) sem lógica precisam de classificação manual.`:''),
msg&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6}},msg),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Lógica"),React.createElement("th",null,"O que faz com o EV"),React.createElement("th",null,"Obs."),React.createElement("th",null,"Casas"),React.createElement("th",null))),React.createElement("tbody",null,
d.regras.map((r)=>React.createElement(React.Fragment,{key:r.codigo},React.createElement("tr",{onClick:()=>setAberta(aberta===r.codigo?null:r.codigo),style:{cursor:'pointer'}},
React.createElement("td",{style:{maxWidth:320}},React.createElement("b",null,r.nome)),React.createElement("td",{style:{fontSize:12.5,maxWidth:380}},r.efeito),
React.createElement("td",{className:"ev-num"},r.obs),React.createElement("td",{className:"ev-num",title:r.casas.join(', ')},r.casas.length),
React.createElement("td",{style:{whiteSpace:'nowrap'},onClick:(e)=>e.stopPropagation()},r.aprovada?React.createElement(React.Fragment,null,React.createElement("span",{className:"liq-chip a_favor"},"aprovada")," ",React.createElement("button",{className:"btn-sm",onClick:()=>muda(r.codigo,false)},"Retirar")):React.createElement("button",{className:"btn-sm b-green",onClick:()=>muda(r.codigo,true)},"Aprovar"))),
aberta===r.codigo&&React.createElement("tr",null,React.createElement("td",{colSpan:5,style:{background:'var(--paper-2, #f4f7f8)',fontSize:12.5}},
React.createElement("div",{style:{marginBottom:4}},React.createElement("b",null,"Casas:")," ",r.casas.join(', ')),
r.exemplos.map((x,i)=>React.createElement("div",{key:i,style:{marginTop:3}},"• ",React.createElement("b",null,x.casa),x.esporte?' · '+(ESPORTE_OBS[x.esporte]||x.esporte):''," · ",x.mercado==='*'?'todos os mercados':x.mercado,": ",x.texto))
))))
)))
);
}



function CoberturaLiquidacao(){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[pedido,setPedido]=useState(0),[busca,setBusca]=useState(''),[limite,setLimite]=useState(50);
useEffect(()=>{
if(!pedido)return;
let vivo=true,t;const ac=new AbortController();
const ler=async()=>{try{const j=await leJson('/api/admin/liq/cobertura?min=60',{signal:ac.signal});if(!vivo)return;setD(j);setErro('');if(j.atualizando)t=setTimeout(ler,2000);}catch(e){if(vivo)setErro(e.message);}};
ler();return()=>{vivo=false;ac.abort();clearTimeout(t);};
},[pedido]);
const q=normCasaObs(busca),lacunas=(d&&d.lacunas||[]).filter((x)=>!q||normCasaObs([x.casa,x.fonte,x.esporte,x.mercado,x.periodo].join(' ')).includes(q));
const estados={sem_obs:'Sem observação',pendente:'Sem efeito classificado',nao_aprovado:'Sem aprovação'};
return React.createElement("div",{style:{marginBottom:18,padding:'12px 14px',border:'1px solid var(--line-2)',borderRadius:10}},
React.createElement("h3",{style:{margin:'0 0 6px'}},"Cobertura das regras de liquidação"),
React.createElement("div",{style:{fontSize:12.5,marginBottom:8}},"Contagem completa das seleções ativas lidas nos últimos 60 minutos, por casa, esporte, mercado e período. Meta: nenhuma combinação sem regra classificada e aprovada."),
React.createElement("button",{className:"btn-sm",disabled:!!(d&&d.atualizando&&!erro),onClick:()=>setPedido(pedido+1)},d&&d.atualizando&&!erro?'Contando…':'Verificar cobertura'),
d&&d.atualizando&&React.createElement("span",{role:"status",style:{fontSize:12.5,marginLeft:8}},d.estado==='na_fila'?'Esperando outra contagem terminar.':'Consultando as casas; o resultado aparecerá aqui.'),
erro&&React.createElement("div",{role:"alert",style:{color:'#b91c1c',marginTop:8}},"A cobertura não pôde ser atualizada: ",erro),
d&&d.erro&&React.createElement("div",{role:"alert",style:{color:'#b91c1c',marginTop:8}},"A nova contagem falhou: ",d.erro,". O resultado abaixo é o anterior."),
d&&d.geradoEm&&React.createElement(React.Fragment,null,
React.createElement("div",{style:{fontSize:12.5,marginTop:8}},"Leitura iniciada em ",new Date(d.geradoEm).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'})," · concluída em ",(d.duracaoMs/1000).toFixed(1)," s · ",d.total," combinações · ",d.resumo.ok||0," cobertas · ",d.lacunas.length," com lacuna."),
React.createElement("input",{"aria-label":"Filtrar lacunas da liquidação",placeholder:"Casa, esporte ou mercado",value:busca,onChange:(e)=>{setBusca(e.target.value);setLimite(50);},style:{marginTop:8,minWidth:250}}),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Esporte"),React.createElement("th",null,"Mercado / período"),React.createElement("th",null,"Seleções"),React.createElement("th",null,"Jogos"),React.createElement("th",null,"Falta"))),React.createElement("tbody",null,
lacunas.slice(0,limite).map((x,i)=>React.createElement("tr",{key:[x.fonte,x.casa,x.esporte,x.mercado,x.periodo,x.jogador,i].join('|')},React.createElement("td",null,x.casa||x.fonte),React.createElement("td",null,ESPORTE_OBS[x.esporte]||x.esporte||'Sem esporte'),React.createElement("td",null,x.mercado," · ",x.periodo,x.jogador?' · jogador':''),React.createElement("td",{className:"ev-num"},x.selecoes),React.createElement("td",{className:"ev-num"},x.jogos),React.createElement("td",null,estados[x.estado]||x.estado)))
))),
lacunas.length>limite&&React.createElement("button",{className:"btn-sm",onClick:()=>setLimite(limite+50)},"Mostrar mais (",limite," de ",lacunas.length,")"),
!lacunas.length&&React.createElement("div",{style:{fontSize:12.5,marginTop:6}},q?'Nenhuma lacuna corresponde ao filtro.':'Nenhuma lacuna nesta leitura.')
)
);
}






function LiqRespostasFishbot(){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[msg,setMsg]=useState(''),[casaAberta,setCasaAberta]=useState(null),[ed,setEd]=useState(null),[busy,setBusy]=useState(false),[extras,setExtras]=useState([]),[nova,setNova]=useState('');
const load=()=>leJson('/api/admin/liq/respostas').then((j)=>{setD(j);setErro('');}).catch((e)=>setErro(e.message));
useEffect(()=>{load();},[]);
const post=(url,corpo)=>leJson(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(corpo),prazoMs:0});
if(!d)return React.createElement("div",{style:{margin:'0 0 14px',fontSize:13}},erro?React.createElement(React.Fragment,null,"❌ As respostas para o FishBot não carregaram: ",erro," ",React.createElement("button",{className:"btn-sm",onClick:load},"Tentar de novo")):React.createElement("span",{className:"ev-sub"},"Carregando as respostas para o FishBot…"));
const cat=d.catalogo,cobradas=cat.perguntas.filter((p)=>p.cobra).map((p)=>p.chave);
const perg=(k)=>cat.perguntas.find((p)=>p.chave===k)||{chave:k,rotulo:k,tipo:'',ajuda:''};
const nomeEsp=(e)=>e===cat.todos?'Todos os esportes':(cat.esportes.find((x)=>x.chave===e)||{}).nome||e;

const casas=[...d.casas,...extras.filter((x)=>!d.casas.some((c)=>c.fonte===x.fonte)).map((x)=>({fonte:x.fonte,casa:x.casa,grupos:[],respostas:[],apagadas:[],semResposta:cobradas,avisos:[],conflitos:[],divergentes:[],observacoes:[],resolucaoPropria:false,doPadrao:[],regraPropria:[],seguePadrao:'sem nenhuma resposta: a regra da casa ainda não foi lida'}))];
const PROPRIA=cat.propria.valor,ehPropria=(v)=>v===PROPRIA;
const rotuloSimNao=(p,v)=>(p.rotulos||{})[String(v)]||(v?'Sim':'Não');
const valorInicial=(p)=>p.tipo==='opcao'?p.valores[0].valor:p.tipo==='booleano'||p.tipo==='verdadeiro'?true:p.tipo==='cartoes'?{amarelo:'',vermelho:''}:'';
const abre=(c,p,r)=>{setMsg('');setEd({fonte:c.fonte,casa:c.casa,pergunta:p.chave,esporte:r?r.esporte:cat.todos,valor:r&&r.valor!=null?r.valor:valorInicial(p),provaUrl:r&&r.provaUrl||'',provaTrecho:r&&r.provaTrecho||'',obsId:r&&r.obsId||'',novo:!r});};
const num=(x)=>x===''||x==null?NaN:Number(String(x).replace(',','.'));
const salva=async()=>{const p=perg(ed.pergunta);
const valor=ehPropria(ed.valor)?PROPRIA:p.tipo==='numero'?num(ed.valor):p.tipo==='cartoes'?{amarelo:num(ed.valor.amarelo),vermelho:num(ed.valor.vermelho)}:ed.valor;
setBusy(true);
try{const r=await post('/api/admin/liq/respostas',{fonte:ed.fonte,casa:ed.casa,esporte:ed.esporte,pergunta:ed.pergunta,valor,provaUrl:ed.provaUrl,provaTrecho:ed.provaTrecho,obsId:ed.obsId||null});setMsg('✅ '+r.msg);setEd(null);await load();}
catch(e){setMsg('❌ Não salvei. '+e.message);}finally{setBusy(false);}};
const apaga=async(c,p,r)=>{
if(!(await window.confirma(`Apagar a resposta de ${c.casa} para "${p.rotulo}" (${nomeEsp(r.esporte)})?\n\nSe a casa segue a Pinnacle, a pergunta passa a valer pela regra da Pinnacle; para deixá-la pendente, marque "regra própria".`)))return;
setBusy(true);
try{const x=await post('/api/admin/liq/respostas/apagar',{fonte:c.fonte,esporte:r.esporte,pergunta:r.pergunta});setMsg('✅ '+x.msg);await load();}
catch(e){setMsg('❌ Não apaguei. '+e.message);}finally{setBusy(false);}};

const campoValor=(p)=>ehPropria(ed.valor)?React.createElement("b",null,cat.propria.rotulo):p.tipo==='opcao'?React.createElement("select",{value:ed.valor,onChange:(e)=>setEd({...ed,valor:e.target.value})},p.valores.map((v)=>React.createElement("option",{key:v.valor,value:v.valor},v.rotulo))):
p.tipo==='booleano'?React.createElement("select",{value:String(ed.valor),onChange:(e)=>setEd({...ed,valor:e.target.value==='true'})},[true,false].map((v)=>React.createElement("option",{key:String(v),value:String(v)},rotuloSimNao(p,v)))):
p.tipo==='verdadeiro'?React.createElement("b",null,rotuloSimNao(p,true)):
p.tipo==='numero'?React.createElement("span",null,React.createElement("input",{type:"number",min:p.acimaDe,max:p.max,step:"any",value:ed.valor,onChange:(e)=>setEd({...ed,valor:e.target.value}),style:{width:90}})," ",p.unidade||''," ",React.createElement("span",{className:"ev-sub"},"(mais que ",p.acimaDe,", até ",p.max,")")):
p.tipo==='cartoes'?React.createElement("span",null,['amarelo','vermelho'].map((k)=>React.createElement("label",{key:k,style:{marginRight:10}},k," ",React.createElement("input",{type:"number",min:p.min,max:p.max,step:"any",value:ed.valor[k],onChange:(e)=>setEd({...ed,valor:{...ed.valor,[k]:e.target.value}}),style:{width:70}})))):
React.createElement("span",{className:"ev-sub"},"tipo de pergunta desconhecido: atualize a página");
const CHIP={semente:'sem_efeito',manual:'a_favor',derivada:'pendente'};
const TIT={semente:'Dado inicial: resposta provada na regra escrita da casa (levantamento do FishBot)',manual:'Gravada na tela por uma pessoa',derivada:'Saiu do código de lógica de uma observação aprovada do Radar: confira o texto da observação'};
const formulario=(c,p)=>React.createElement("tr",null,React.createElement("td",{colSpan:3,style:{background:'var(--paper-2)'}},
React.createElement("div",{style:{display:'flex',gap:10,flexWrap:'wrap',alignItems:'center',fontSize:13}},
React.createElement("b",null,ed.novo?'Responder':'Corrigir',": ",p.rotulo),
p.porEsporte?React.createElement("select",{value:ed.esporte,disabled:!ed.novo,title:ed.novo?'Esporte em que a resposta vale':'Para outro esporte, use "Outro esporte"',onChange:(e)=>setEd({...ed,esporte:e.target.value})},React.createElement("option",{value:cat.todos},nomeEsp(cat.todos)),cat.esportes.map((e)=>React.createElement("option",{key:e.chave,value:e.chave},e.nome))):React.createElement("span",{className:"ev-sub"},nomeEsp(cat.todos)),
campoValor(p),
p.aceitaPropria&&React.createElement("label",{title:"A casa tem uma regra diferente que não cabe nas opções (ex.: 'pode anular', regra por mercado). A pergunta fica pendente para marcação à mão e NÃO liquida como a Pinnacle.",style:{fontSize:12.5}},React.createElement("input",{type:"checkbox",checked:ehPropria(ed.valor),onChange:(e)=>setEd({...ed,valor:e.target.checked?PROPRIA:valorInicial(p)})})," regra própria que o robô não executa")
),
React.createElement("div",{className:"ev-sub",style:{margin:'4px 0 6px'}},p.ajuda),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'flex-start'}},
React.createElement("input",{placeholder:p.prova?'link da regra escrita da casa (obrigatório)':'link da regra da casa (opcional)',value:ed.provaUrl,maxLength:cat.limites.url,onChange:(e)=>setEd({...ed,provaUrl:e.target.value}),style:{minWidth:300,flex:'1 1 300px'}}),
React.createElement("select",{value:ed.obsId||'',onChange:(e)=>setEd({...ed,obsId:e.target.value?Number(e.target.value):''}),title:"A observação do Radar que sustenta a resposta",style:{maxWidth:420}},
React.createElement("option",{value:""},"sem observação ligada"),
c.observacoes.map((o)=>React.createElement("option",{key:o.id,value:o.id},"nº ",o.id," · ",o.esporte?ESPORTE_OBS[o.esporte]||o.esporte:'todos os esportes',o.mercado!=='*'?' · '+o.mercado:''," · ",o.texto.slice(0,90)))
)
),
React.createElement("textarea",{placeholder:"trecho da regra, entre aspas (o que prova a resposta)",value:ed.provaTrecho,maxLength:cat.limites.trecho,onChange:(e)=>setEd({...ed,provaTrecho:e.target.value}),rows:2,style:{width:'100%',marginTop:6}}),
React.createElement("div",{style:{marginTop:6}},React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:salva},"Salvar")," ",React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>setEd(null)},"Cancelar"))
));
const detalhe=(c)=>React.createElement("div",{style:{padding:'6px 0 12px'}},
!c.referencia&&!c.resolucaoPropria&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6}},c.seguePadrao==='segue'?React.createElement(React.Fragment,null,"Pergunta que esta casa não responde liquida pela regra da Pinnacle (marcada \"segue a Pinnacle\" abaixo)."):React.createElement(React.Fragment,null,React.createElement("b",null,"Esta casa não segue a Pinnacle")," (",c.seguePadrao,"): o que não tem resposta fica pendente.")),
c.referencia&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6}},React.createElement("b",null,"Casa de referência:")," as respostas daqui valem nas outras casas em toda pergunta que elas não respondem."),
c.conflitos.map((x,i)=>React.createElement("div",{key:'c'+i,style:{fontSize:12.5,color:'#B3423A',marginBottom:4}},"⚠️ Conflito em \"",perg(x.pergunta).rotulo,"\" (",nomeEsp(x.esporte),"): a resposta em vigor é \"",x.valorRotulo,"\", mas a observação nº ",x.obsId," (lógica ",x.codigo,") diz \"",x.valorDaObsRotulo,"\". Nada foi mudado: confira a regra da casa e corrija a resposta ou a observação.")),
c.divergentes.map((x,i)=>React.createElement("div",{key:'d'+i,style:{fontSize:12.5,color:'#B3423A',marginBottom:4}},"⚠️ As observações nº ",x.obs.join(' e nº ')," respondem valores diferentes para \"",perg(x.pergunta).rotulo,"\" (",nomeEsp(x.esporte),"): nenhuma virou resposta.")),
c.avisos.map((x,i)=>React.createElement("div",{key:'a'+i,style:{fontSize:12.5,color:'#B3423A',marginBottom:4}},"⚠️ \"",perg(x.pergunta).rotulo,"\" (",nomeEsp(x.esporte),") não vai para o FishBot: ",x.motivo,".")),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Pergunta"),React.createElement("th",null,"Resposta"),React.createElement("th",null))),React.createElement("tbody",null,
cat.perguntas.map((p)=>{const rs=c.respostas.filter((r)=>r.pergunta===p.chave),dp=(c.doPadrao||[]).filter((x)=>x.pergunta===p.chave),cobra=p.cobra&&!c.resolucaoPropria,editando=ed&&ed.fonte===c.fonte&&ed.pergunta===p.chave;
return React.createElement(React.Fragment,{key:p.chave},React.createElement("tr",null,
React.createElement("td",{style:{maxWidth:300,verticalAlign:'top'},title:p.ajuda},React.createElement("b",null,p.rotulo),!p.cobra&&React.createElement("div",{className:"ev-sub"},"complemento: não é cobrada")),
React.createElement("td",{style:{fontSize:13,verticalAlign:'top'}},
rs.map((r)=>React.createElement("div",{key:r.id,style:{marginBottom:6}},
p.porEsporte&&React.createElement("span",{className:"pill"},nomeEsp(r.esporte))," ",React.createElement("b",null,r.valorRotulo)," ",React.createElement("span",{className:'liq-chip '+(CHIP[r.origem]||'pendente'),title:TIT[r.origem]||''},r.origem),
r.provaUrl?React.createElement(React.Fragment,null," ",React.createElement("a",{href:r.provaUrl,target:"_blank",rel:"noopener",style:{fontSize:12}},"regra da casa")):p.prova&&React.createElement("span",{style:{color:'#B3423A',fontSize:12}}," sem o link da regra"),
r.obs&&(r.obs.desativada?React.createElement("span",{style:{color:'#B3423A',fontSize:12}}," · observação nº ",r.obs.id," desativada"):React.createElement("span",{style:{fontSize:12},title:r.obs.texto}," · observação nº ",r.obs.id)),
React.createElement("span",{style:{whiteSpace:'nowrap'}}," ",React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>abre(c,p,r)},"Corrigir")," ",React.createElement("button",{className:"btn-sm b-red",disabled:busy,onClick:()=>apaga(c,p,r)},"Apagar")),
r.provaTrecho&&React.createElement("div",{className:"ev-sub",style:{maxWidth:900}},r.provaTrecho),
r.obs&&!r.obs.desativada&&React.createElement("div",{className:"ev-sub",style:{maxWidth:900}},"Observação nº ",r.obs.id,": ",r.obs.texto),
React.createElement("div",{className:"ev-sub"},r.por||'',r.atualizado?' · '+r.atualizado:'')
)),
dp.map((x,i)=>React.createElement("div",{key:'p'+i,style:{marginBottom:6},title:x.provaTrecho||''},
p.porEsporte&&React.createElement("span",{className:"pill"},rs.length||dp.length>1||x.esporte!==cat.todos?x.esporte===cat.todos?'Demais esportes':nomeEsp(x.esporte):nomeEsp(x.esporte))," ",React.createElement("b",null,x.valorRotulo)," ",React.createElement("span",{className:"liq-chip pendente",title:"A casa não diz: vale a regra escrita da Pinnacle. Para mudar, responda a pergunta nesta casa (ou marque 'regra própria')."},"segue a Pinnacle"),
x.provaUrl&&React.createElement(React.Fragment,null," ",React.createElement("a",{href:x.provaUrl,target:"_blank",rel:"noopener",style:{fontSize:12}},"regra da Pinnacle"))
)),
!rs.length&&!dp.length&&(cobra?React.createElement("span",{style:{color:'#B3423A',fontWeight:600}},"sem resposta — a tip fica pendente"):React.createElement("span",{className:"ev-sub"},"sem resposta",c.resolucaoPropria&&p.cobra?' (bolsa: o resultado é o que o mercado pagou)':'')),
(rs.length>0||dp.length>0)&&p.porEsporte&&cobra&&!rs.some((r)=>r.esporte===cat.todos)&&!dp.some((x)=>x.esporte===cat.todos)&&React.createElement("div",{className:"ev-sub"},"nos outros esportes: sem resposta — a tip fica pendente")
),
React.createElement("td",{style:{whiteSpace:'nowrap',verticalAlign:'top'}},(!rs.length||p.porEsporte)&&React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>abre(c,p,null)},rs.length?'Outro esporte':'Responder'))
),editando&&formulario(c,p));})
))),
c.apagadas.length>0&&React.createElement("div",{className:"ev-sub",style:{marginTop:4}},"Apagadas na tela (não voltam sozinhas): ",c.apagadas.map((a)=>`${perg(a.pergunta).rotulo} (${nomeEsp(a.esporte)})${a.por?' por '+a.por:''}`).join('; '))
);
const r=d.resumo;
return React.createElement("div",{style:{margin:'0 0 18px'}},
React.createElement("h3",{style:{margin:'0 0 4px'}},"Respostas para o FishBot (",r.dosGruposComPendencia," de ",r.dosGrupos," casas dos grupos com pergunta sem resposta)"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8,maxWidth:900}},"O FishBot liquida sozinho o resultado das tips e pergunta aqui a regra de cada casa (ex.: a prop de jogador conta a prorrogação?). Cada resposta precisa do link da regra escrita da casa; a casa que já tem resposta aqui e é calada numa pergunta liquida, nessa pergunta, pela regra escrita da Pinnacle (a casa de referência; decisão de 13/11) — a não ser que a pergunta esteja marcada \"regra própria\" ou a casa seja \"de regra própria\". A casa sem nenhuma resposta não segue ninguém: a tip que depender dela fica pendente para marcação à mão. Meta: zero pergunta sem resposta nas casas dos grupos (",r.perguntasPendentes," hoje).",d.erroDoPerfil?' ❌ O perfil dos grupos não carregou ('+d.erroDoPerfil+'): as casas dos grupos podem estar faltando.':''),
erro&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6}},"❌ Não atualizei a lista: ",erro),
msg&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6}},msg),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Grupos do FishBot"),React.createElement("th",null,"Respostas"),React.createElement("th",null,"Sem resposta"),React.createElement("th",null))),React.createElement("tbody",null,
casas.map((c)=>React.createElement(React.Fragment,{key:c.fonte},React.createElement("tr",{onClick:()=>{setCasaAberta(casaAberta===c.fonte?null:c.fonte);setEd(null);},style:{cursor:'pointer'}},
React.createElement("td",null,React.createElement("b",null,c.casa),React.createElement("div",{className:"ev-sub"},c.fonte)),
React.createElement("td",{style:{fontSize:12.5}},c.grupos.length?c.grupos.join(', '):React.createElement("span",{className:"ev-sub"},"nenhum")),
React.createElement("td",{className:"ev-num"},c.respostas.length,c.conflitos.length+c.avisos.length+c.divergentes.length>0&&React.createElement("span",{title:"Há conflito ou resposta que não vai para o FishBot: abra para ver",style:{color:'#B3423A'}}," ⚠️")),
React.createElement("td",{style:{fontSize:12.5,maxWidth:620}},c.resolucaoPropria?React.createElement("span",{className:"ev-sub"},"bolsa: o resultado é o que o mercado pagou"):c.semResposta.length?React.createElement("span",{style:{color:c.grupos.length?'#B3423A':'inherit'}},c.semResposta.length,": ",c.semResposta.map((k)=>perg(k).rotulo).join(' · ')):React.createElement("span",{className:"liq-chip a_favor"},"nenhuma"),
(c.regraPropria||[]).length>0&&React.createElement("div",{className:"ev-sub"},"regra própria (pendente por decisão): ",c.regraPropria.map((k)=>perg(k).rotulo).join(' · ')),
(c.doPadrao||[]).length>0&&React.createElement("div",{className:"ev-sub"},c.doPadrao.length," pela regra da Pinnacle")),
React.createElement("td",{style:{whiteSpace:'nowrap'}},React.createElement("button",{className:"btn-sm"},casaAberta===c.fonte?'Fechar':'Abrir'))
),casaAberta===c.fonte&&React.createElement("tr",null,React.createElement("td",{colSpan:5},detalhe(c)))))
))),
d.outrasCasas.length>0&&React.createElement("div",{style:{marginTop:8,display:'flex',gap:8,alignItems:'center',fontSize:12.5}},
React.createElement("select",{value:nova,onChange:(e)=>setNova(e.target.value)},React.createElement("option",{value:""},"Outra casa (das que o EV+ já viu)…"),d.outrasCasas.filter((x)=>!extras.some((y)=>y.fonte===x.fonte)).map((x)=>React.createElement("option",{key:x.fonte,value:x.fonte},x.casa," (",x.fonte,")"))),
React.createElement("button",{className:"btn-sm",disabled:!nova,onClick:()=>{const x=d.outrasCasas.find((y)=>y.fonte===nova);if(x){setExtras([...extras,x]);setCasaAberta(x.fonte);setNova('');}}},"Acrescentar")
)
);
}
function ObsLiquidacaoTab(){
const[lista,setLista]=useState(null),[op,setOp]=useState({casas:[],mercados:[],esportes:[]}),[f,setF]=useState({casa:'',mercado:'*',esporte:'',texto:''}),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false);

const[filtroEf,setFiltroEf]=useState('todas'),[editando,setEditando]=useState(null),[buscaObs,setBuscaObs]=useState('');

const[faltando,setFaltando]=useState(null);

const[moldes,setMoldes]=useState([]);
useEffect(()=>{const c=(f.casa||'').trim();if(!c){setMoldes([]);return;}const t=setTimeout(()=>leJson('/api/admin/obs-liquidacao/moldes?casa='+encodeURIComponent(c)).then((d)=>setMoldes(d.moldes||[])).catch((e)=>setMsg('❌ Mercados da casa não carregaram: '+e.message)),400);return()=>clearTimeout(t);},[f.casa]);
useEffect(()=>{leJson('/api/admin/obs-liquidacao/faltando').then(setFaltando).catch((e)=>setMsg('❌ Casas sem observação não carregaram: '+e.message));},[lista]);
const load=async()=>{try{const r=await fetch('/api/obs-liquidacao',{credentials:'include'});setLista(r.ok?await r.json():[]);}catch(e){setLista([]);};carregaObs(true);};
const estadoEf=(o)=>!o.efeitos||!o.efeitos.length?'pendente':o.efeitos.every((e)=>e.aprovado)?'aprovado':'aprovar';
const qObs=normCasaObs(buscaObs);
const listaF=(lista||[]).filter((o)=>(filtroEf==='todas'||(filtroEf==='bloqueia'?o.efeitos&&o.efeitos.some((e)=>e.classe==='bloqueia'):filtroEf==='contra'?o.efeitos&&o.efeitos.some((e)=>e.classe==='contra'||e.classe==='calculo'):estadoEf(o)===filtroEf))&&(
!qObs||normCasaObs(o.casa+' '+o.texto+' '+(o.mercado_nome||o.mercado)).includes(qObs)));
const contaEf=(k)=>(lista||[]).filter((o)=>estadoEf(o)===k).length;
const aprova=async(ids)=>{if(!ids.length)return;const r=await fetch('/api/admin/obs-liquidacao/aprovar',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids})});const d=await r.json();setMsg(r.ok?'✅ '+d.msg:'❌ '+(d.error||'Erro'));load();};
useEffect(()=>{load();leJson('/api/admin/obs-liquidacao/opcoes').then((d)=>setOp({casas:d.casas||[],mercados:d.mercados||[],esportes:d.esportes||[]})).catch((e)=>setMsg('❌ Opções do formulário não carregaram: '+e.message));},[]);
const salva=async()=>{setBusy(true);setMsg('');try{const r=await fetch('/api/admin/obs-liquidacao',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(f)});const d=await r.json();setMsg(r.ok?'✅ '+d.msg:'❌ '+(d.error||'Erro'));if(r.ok){setF({casa:'',mercado:'*',esporte:'',texto:'',molde_casa:''});load();}}catch(e){setMsg('❌ '+e.message);}finally{setBusy(false);}};
const apaga=async(o)=>{if(!(await confirma('Desativar a observação de '+o.casa+'?')))return;const r=await fetch('/api/admin/obs-liquidacao/'+o.id+'/apagar',{method:'POST',credentials:'include'});const d=await r.json();setMsg(r.ok?'✅ '+d.msg:'❌ '+(d.error||'Erro'));load();};
const nomeM=(c)=>c==='*'?'Todos os mercados':(op.mercados.find((m)=>m.code===c)||{}).nome||c;
const nomeE=(c)=>c?ESPORTE_OBS[c]||c:'Todos os esportes';
return React.createElement("div",{style:{maxWidth:1500}},
React.createElement("h2",{style:{margin:'0 0 6px'}},"Observações de liquidação"),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:14,maxWidth:760}},"Regra de liquidação de uma casa que muda o valor da aposta (ex.: na Polymarket, jogador que não entra em campo dá NÃO em vez de anular). Onde a casa aparecer nesse mercado — Super Odds, EV+, Odds Screen, Player Props — aparece um selo com o efeito no EV daquele lado: ",React.createElement("span",{className:"obs-alerta liq-bloqueia",style:{cursor:'default'}},"!")," bloqueia, ",React.createElement("span",{className:"obs-alerta liq-contra",style:{cursor:'default'}},"−")," contra (alerta; o EV não muda), ",React.createElement("span",{className:"obs-alerta liq-a_favor",style:{cursor:'default'}},"+")," a favor (o EV mostrado é o mínimo), ",React.createElement("span",{className:"obs-alerta liq-pendente",style:{cursor:'default'}},"!")," sem classificação, ",React.createElement("span",{className:"obs-alerta liq-misto",style:{cursor:'default'}},"±")," varia por lado (cabeçalho de coluna e card, que não sabem o lado: passe o mouse para ver cada um). Regra sem efeito não aparece. Ao cadastrar, o efeito é sugerido pelo texto e espera aprovação."),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'flex-start',marginBottom:10}},
React.createElement("input",{id:"obs-casa",list:"obs-casas",placeholder:"casa (como aparece na tela)",value:f.casa,onChange:(e)=>setF({...f,casa:e.target.value}),style:{minWidth:200}}),
React.createElement("datalist",{id:"obs-casas"},op.casas.map((c)=>React.createElement("option",{key:c,value:c}))),
React.createElement("select",{id:"obs-esporte",value:f.esporte||'',onChange:(e)=>setF({...f,esporte:e.target.value}),title:"Esporte em que a regra vale"},
React.createElement("option",{value:""},"Todos os esportes"),
op.esportes.map((e)=>React.createElement("option",{key:e.code,value:e.code},e.nome))
),
React.createElement("select",{id:"obs-mercado",value:f.mercado,onChange:(e)=>setF({...f,mercado:e.target.value})},
React.createElement("option",{value:"*"},"Todos os mercados"),
React.createElement("optgroup",{label:"Jogador"},op.mercados.filter((m)=>m.escopo==='jogador').map((m)=>React.createElement("option",{key:m.code,value:m.code},m.nome))),
React.createElement("optgroup",{label:"Jogo e time"},op.mercados.filter((m)=>m.escopo!=='jogador').map((m)=>React.createElement("option",{key:m.code,value:m.code},m.nome)))
),
React.createElement("textarea",{id:"obs-texto",placeholder:"observação (ex.: jogador que não entra em campo = NÃO; só 90 min)",value:f.texto,onChange:(e)=>setF({...f,texto:e.target.value}),rows:2,style:{flex:'1 1 320px',minWidth:260}}),
React.createElement("input",{id:"obs-fonte",placeholder:"link da regra da casa (opcional)",value:f.fonte||'',onChange:(e)=>setF({...f,fonte:e.target.value}),style:{minWidth:220}}),
React.createElement("input",{id:"obs-molde",list:"obs-moldes",placeholder:"mercado da casa (opcional)",title:"Só quando a casa tem dois mercados dela que caem no mesmo mercado nosso e liquidam diferente: a regra vale quando a odd mostrada veio deste mercado da casa. Vazio = todos.",value:f.molde_casa||'',onChange:(e)=>setF({...f,molde_casa:e.target.value}),style:{minWidth:220}}),
React.createElement("datalist",{id:"obs-moldes"},moldes.map((m)=>React.createElement("option",{key:m.molde,value:m.molde},m.mercado?'→ '+m.mercado:''))),
React.createElement("button",{className:"btn-sm b-green",disabled:busy||!f.casa.trim()||!f.texto.trim(),onClick:salva},"Cadastrar")
),
faltando&&faltando.casas&&React.createElement("div",{style:{margin:'0 0 12px',padding:'10px 12px',border:'1px solid var(--line-2)',borderRadius:10,fontSize:13,maxWidth:1100,background:faltando.casas.length?'color-mix(in srgb,#B3423A 7%,transparent)':'transparent'}},
React.createElement("b",null,"Casas no ar sem nenhuma observação: ",faltando.casas.length)," ",React.createElement("span",{style:{color:'var(--on-surface-variant)'}},"(meta: zero — casa nova entra aqui até ter a regra dela cadastrada)"),
faltando.casas.length>0&&React.createElement("div",{style:{marginTop:6,display:'flex',gap:6,flexWrap:'wrap'}},faltando.casas.map((c)=>React.createElement("span",{key:c.casa,className:"pill",title:c.tipo},c.casa,c.ev7d?` · ${c.ev7d} EVs em 7 dias`:'')))
),
msg&&React.createElement("div",{style:{fontSize:13,marginBottom:10}},msg),
React.createElement(LiqRespostasFishbot,null),
React.createElement(CoberturaLiquidacao,null),
React.createElement(LiqLogicas,{onMudou:load}),
React.createElement("h3",{style:{margin:'0 0 4px'}},"Observações"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:6}},"Para exceções: \"Efeito\" troca o que uma observação faz (vale só para ela e já entra aprovada)."),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'center',margin:'4px 0 8px'}},
React.createElement("div",{className:"seg",style:{display:'inline-flex'}},[['aprovar',`Esperando lógica (${contaEf('aprovar')})`],['pendente',`Sem classificação (${contaEf('pendente')})`],['aprovado',`Aprovadas (${contaEf('aprovado')})`],['bloqueia','Bloqueia'],['contra','Contra'],['todas','Todas']].map(([k,t])=>React.createElement("button",{key:k,className:'segb'+(filtroEf===k?' on':''),onClick:()=>setFiltroEf(k)},t))),
React.createElement("input",{id:"obs-busca",placeholder:"Buscar casa, mercado, texto…",value:buscaObs,onChange:(e)=>setBuscaObs(e.target.value),style:{minWidth:220}})

),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Esporte"),React.createElement("th",null,"Mercado"),React.createElement("th",null,"Observação"),React.createElement("th",null,"Efeito no EV"),React.createElement("th",null))),React.createElement("tbody",null,
listaF.map((o)=>React.createElement(React.Fragment,{key:o.id},React.createElement("tr",null,React.createElement("td",null,React.createElement("b",null,o.casa),React.createElement("div",{className:"ev-sub"},o.por||'')),React.createElement("td",{style:{fontSize:12.5}},nomeE(o.esporte)),React.createElement("td",{style:{fontSize:12.5}},o.mercado==='*'?'Todos os mercados':o.mercado_nome||o.mercado,o.molde_casa&&React.createElement("div",{className:"ev-sub",title:"A regra vale quando a odd veio deste mercado da casa"},"na casa: ",o.molde_casa)),React.createElement("td",{style:{fontSize:13}},o.texto,o.fonte&&React.createElement(React.Fragment,null," ",React.createElement("a",{href:o.fonte,target:"_blank",rel:"noopener",style:{fontSize:12}},"regra da casa"))),
React.createElement("td",{style:{fontSize:12,minWidth:180}},React.createElement(LiqChips,{efeitos:o.efeitos}),React.createElement("div",{className:"ev-sub"},estadoEf(o)==='aprovado'?'aprovado':estadoEf(o)==='aprovar'?'esperando a lógica':'')),
React.createElement("td",{style:{whiteSpace:'nowrap'}},React.createElement("button",{className:"btn-sm",onClick:()=>setEditando(editando===o.id?null:o.id)},"Efeito")," ",React.createElement("button",{className:"btn-sm",onClick:()=>setF({id:o.id,casa:o.casa,mercado:o.mercado,esporte:o.esporte||'',texto:o.texto,fonte:o.fonte||'',molde_casa:o.molde_casa||''})},"Texto")," ",React.createElement("button",{className:"btn-sm b-red",onClick:()=>apaga(o)},"Desativar"))),
editando===o.id&&React.createElement("tr",null,React.createElement("td",{colSpan:6},React.createElement(LiqEditor,{obs:o,mercados:op.mercados,onSalvo:(m)=>{setMsg('✅ '+m);setEditando(null);load();},onCancela:()=>setEditando(null)}))))),
lista&&!listaF.length&&React.createElement("tr",null,React.createElement("td",{colSpan:6,style:{color:'var(--on-surface-variant)'}},lista.length?'Nenhuma observação neste filtro.':'Nenhuma observação cadastrada.'))
))),
f.id&&React.createElement("div",{style:{fontSize:12.5,marginTop:8}},"Editando a observação #",f.id," (",nomeE(f.esporte)," · ",nomeM(f.mercado),") — ",React.createElement("button",{className:"btn-sm",onClick:()=>setF({casa:'',mercado:'*',esporte:'',texto:'',molde_casa:''})},"cancelar"))
);
}

function OddCard({odd,index}){
const cc=casaColor(odd.casa);
const bp=odd.original_odds>0?Math.round((odd.odds-odd.original_odds)/odd.original_odds*100):null;
const[hist,setHist]=useState(null);
const[expanded,setExpanded]=useState(false);

useEffect(()=>{let alive=true;
const p=new URLSearchParams({odd_id:odd.odd_id,casa:odd.casa});if(odd.runner_id)p.set('runner_id',odd.runner_id);
fetch(`/api/history?${p}`,{credentials:'include'}).then((r)=>r.json()).then((d)=>{if(alive)setHist(Array.isArray(d)?d:[]);}).catch(()=>{if(alive)setHist([]);});
return()=>{alive=false;};
},[odd.odd_id,odd.casa,odd.runner_id]);


const series=useMemo(()=>{
if(!hist||!hist.length)return[];
const vals=[];
if(hist[0].old_value!=null)vals.push(Number(hist[0].old_value));
hist.forEach((h)=>vals.push(Number(h.new_value)));
return vals;
},[hist]);

const hasHist=series.length>=2;

return React.createElement("div",{className:"card rise"+(hasHist?' has-hist':'')+(expanded?' expanded':''),style:{animationDelay:`${Math.min(index*22,260)}ms`,'--cc':cc},
onClick:()=>{if(hasHist)setExpanded((e)=>!e);}},
React.createElement("div",{className:"topbar"}),
React.createElement("div",{className:"card-head"},
React.createElement("div",{className:"tags"},React.createElement("span",{className:"tag tag-casa"},odd.casa),React.createElement(ObsAlerta,{casa:odd.casa,mercado:odd.mercado_cat,esporte:odd.sport}),odd.boost_label&&React.createElement("span",{className:"tag tag-label"},odd.boost_label),(odd.tipo_aposta==='bet_builder'||odd.tipo_aposta==='multipla')&&React.createElement("span",{className:"tag tag-label",title:odd.tipo_aposta==='bet_builder'?'Várias pernas do mesmo jogo':'Seleções de jogos diferentes'},odd.tipo_aposta==='bet_builder'?'Bet Builder':'Múltipla'),odd.live&&React.createElement("span",{className:"tag tag-live"},React.createElement("span",{className:"live-dot"}),"AO VIVO")),
React.createElement("span",{className:"ago"},timeAgo(odd.createdAt))
),
(odd.sport||odd.competition)&&React.createElement("div",{className:"meta"},odd.sport&&React.createElement(React.Fragment,null,React.createElement(Ic,{n:"sports_soccer"}),React.createElement("span",null,odd.sport)),odd.competition&&React.createElement(React.Fragment,null,React.createElement(Ic,{n:"emoji_events",className:"ms-icon trophy"}),React.createElement("span",null,odd.competition))),
odd.event_name&&React.createElement("div",{className:"ev"},odd.event_name),
odd.market_name&&!(odd.runner_name||'').includes('\n')&&odd.market_name.trim().toLowerCase()!==(odd.runner_name||'').trim().toLowerCase()&&odd.market_name.trim().toLowerCase()!==(odd.event_name||'').trim().toLowerCase()&&React.createElement("div",{className:"mkt"},odd.market_name),
(odd.runner_name||'').includes('\n')?
React.createElement("div",{className:"bet combo"},React.createElement("span",{className:"pin"},"🎯"),React.createElement("span",{className:"pernas"},(odd.runner_name||'').split('\n').map((p,i)=>React.createElement("span",{className:"perna",key:i},p.replace(/^\s*•\s*/,''))))):
React.createElement("div",{className:"bet"},React.createElement("span",{className:"pin"},"🎯"),odd.runner_name),
React.createElement("div",{className:"foot"},
React.createElement("div",{className:"odds"},
odd.original_odds>0&&React.createElement(React.Fragment,null,React.createElement("span",{className:"o-orig"},Number(odd.original_odds).toFixed(2)),React.createElement(Ic,{n:"arrow_right_alt",className:"ms-icon o-arr"})),
React.createElement("span",{className:"o-new"},Number(odd.odds).toFixed(2))
),
hasHist&&(()=>{const MAX=8;const trunc=series.length>MAX;const comp=trunc?series.slice(-MAX):series;const base=trunc?series.length-MAX:0;return React.createElement("div",{className:"hist-compact"},trunc&&React.createElement("span",{className:"hc-more"},"…"),comp.map((v,ci)=>{const i=base+ci;const prev=i>0?series[i-1]:null;const cls=prev==null?'':v>prev?'up':v<prev?'down':'eq';return React.createElement("span",{key:i,className:"hc-step"},React.createElement("span",{className:"hc-val "+cls},v.toFixed(2)),ci<comp.length-1&&React.createElement(Ic,{n:"chevron_right",className:"ms-icon hc-arr"}));}),React.createElement(Ic,{n:expanded?"expand_less":"expand_more",className:"ms-icon hc-toggle"}));})(),


bp>0&&React.createElement("span",{className:"pct"+(bp>=20?' hi':'')},"+",bp,"%"),

odd.limite_aposta>0&&React.createElement("span",{className:"o-lim",style:{fontSize:'11px',opacity:.8,marginLeft:'6px',whiteSpace:'nowrap'},title:'Aposta máxima que a casa aceita neste boost'+(odd.limite_pagamento>0?' · prêmio máximo '+Number(odd.limite_pagamento).toLocaleString('pt-BR'):'')+(odd.limite_moeda?' ('+String(odd.limite_moeda).toUpperCase()+')':'')},"máx. ",String(odd.limite_moeda||'').toLowerCase()==='usd'?'US$ ':String(odd.limite_moeda||'').toLowerCase()==='brl'?'R$ ':'',Number(odd.limite_aposta).toLocaleString('pt-BR'))
),

!(odd.fair_odds>0)&&!odd.live&&React.createElement("div",{className:"justa",title:"Por que esta Super Odd não tem justa",style:{opacity:.75}},React.createElement("span",{className:"j-ico"},"📊"),React.createElement("span",{className:"j-txt"},"Sem justa: ",odd.justa_motivo||'aguardando cálculo')),odd.fair_odds>0&&React.createElement("div",{className:"justa"},React.createElement("span",{className:"j-ico"},"📊"),React.createElement("span",{className:"j-txt",title:"A justa do motor do EV+ (P6j: Pinnacle sem margem + bolsas, decisão de 30/10) — a MESMA justa da odd comum daquele mercado; a idade é a da leitura que fez a justa"},"Justa: ",React.createElement("b",null,Number(odd.fair_odds).toFixed(2))),(()=>{const k=kellyQuarto(odd);return k>0?React.createElement("span",{className:"j-kelly"},"Kelly ¼: ",(k*100).toFixed(2),"%"):null;})(),odd.ev_pct!=null&&React.createElement("span",{className:"j-ev "+(Number(odd.ev_pct)>=0?'pos':'neg')},"EV ",Number(odd.ev_pct)>=0?'+':'',Number(odd.ev_pct).toFixed(1),"%"),odd.fair_min!=null&&React.createElement("span",{title:"Idade da justa: quando o motor calculou com os preços da Pinnacle daquele momento. O site ao vivo pode ter se movido desde então — defasagem, não erro de conta.",style:{fontSize:'10.5px',color:Number(odd.fair_min)>3?'#8a6110':'var(--on-surface-variant)',fontWeight:Number(odd.fair_min)>3?700:400,marginLeft:4}},Number(odd.fair_min)>3?'⚠ ':'',"há ",odd.fair_min,"min")),
expanded&&hasHist&&React.createElement("div",{className:"hist-panel",onClick:(e)=>e.stopPropagation()},
React.createElement("div",{className:"hp-head"},React.createElement("span",null,"Histórico de odds"),React.createElement("span",{className:"hp-n"},hist.length," alteração",hist.length>1?'es':'')),
React.createElement(Sparkline,{points:series,times:hist.map((h)=>h.createdAt)}),
React.createElement("div",{className:"hp-rows"},[...hist].reverse().map((h,i)=>{const ov=h.old_value!=null?Number(h.old_value):null;const nv=Number(h.new_value);const cls=ov==null?'':nv>ov?'up':nv<ov?'down':'eq';const diff=ov!=null?nv-ov:null;return(
React.createElement("div",{key:i,className:"hp-row"},React.createElement("span",{className:"hp-time"},timeAgo(h.createdAt)),React.createElement("span",{className:"hp-move"},ov!=null&&React.createElement("span",{className:"hp-old"},ov.toFixed(2)),React.createElement(Ic,{n:"arrow_right_alt",className:"ms-icon hp-arr"}),React.createElement("span",{className:"hp-new "+cls},nv.toFixed(2))),diff!=null&&diff!==0&&React.createElement("span",{className:"hp-diff "+cls},diff>0?'+':'',diff.toFixed(2))));
}))
),
(odd.url||odd.casa_url)&&React.createElement("div",{className:"go",onClick:(e)=>e.stopPropagation()},React.createElement("a",{href:odd.url||odd.casa_url,target:"_blank",rel:"noopener noreferrer"},"Ir para aposta ",React.createElement(Ic,{n:"open_in_new"})))
);
}

function LabelModal({casa,allLabels,current,onSave,onClose}){
const[sel,setSel]=useState(current||[]);

const toggle=(l)=>setSel((prev)=>prev.includes(l)?prev.filter((s)=>s!==l):[...prev,l]);
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:440}},
React.createElement("h3",{style:{fontFamily:'var(--f-display)',fontSize:17,fontWeight:700,color:'var(--navy-900)',marginBottom:4}},"Filtrar labels"),
React.createElement("p",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:16}},"Casa ",React.createElement("b",{style:{color:'var(--navy-900)'}},casa)," — labels que vão pros adms"),
allLabels.length===0?React.createElement("p",{style:{color:'var(--on-surface-variant)',fontSize:13}},"Nenhum label ativo nessa casa"):allLabels.map((l)=>{const on=sel.includes(l);return(
React.createElement("div",{key:l,onClick:()=>toggle(l),style:{display:'flex',alignItems:'center',gap:10,padding:'9px 6px',cursor:'pointer',fontSize:13.5,borderRadius:8}},
React.createElement("span",{style:{width:19,height:19,borderRadius:5,border:'1.5px solid var(--line-2)',display:'grid',placeItems:'center',flexShrink:0,background:on?'var(--teal-deep)':'#fff',color:'#fff'}},on&&React.createElement(Ic,{n:"check"})),
React.createElement("span",null,l)
));}),
React.createElement("div",{style:{display:'flex',gap:9,marginTop:20}},
React.createElement("button",{className:"btn-sm b-green",style:{flex:1,padding:10},onClick:()=>{onSave(sel);onClose();}},"Salvar"),
React.createElement("button",{className:"btn-sm b-red",style:{flex:1,padding:10},onClick:onClose},"Cancelar")
)
)
);
}

function StatusTab({onClose}){
const[data,setData]=useState(null),[q,setQ]=useState(''),[only,setOnly]=useState('all');
const load=async()=>{try{const r=await fetch('/api/admin/status',{credentials:'include'});if(r.status===401){onClose('relogin');return;}setData(await r.json());}catch(e){console.error(e);}};
useEffect(()=>{load();const i=setInterval(load,30000);return()=>clearInterval(i);},[]);
if(!data)return React.createElement("div",{style:{textAlign:'center',padding:40,color:'var(--on-surface-variant)'}},"Carregando…");
const ativas=data.casas.filter((c)=>c.enabled);
const silentN=ativas.filter((c)=>c.silent).length,okN=ativas.length-silentN;
let casas=ativas.filter((c)=>!q||c.name.toLowerCase().includes(q.toLowerCase()));
if(only==='silent')casas=casas.filter((c)=>c.silent);else if(only==='ok')casas=casas.filter((c)=>!c.silent);
casas=[...casas].sort((a,b)=>{if(a.silent!==b.silent)return a.silent?-1:1;const an=a.lastNotificationAt?new Date(a.lastNotificationAt).getTime():0;const bn=b.lastNotificationAt?new Date(b.lastNotificationAt).getTime():0;return an-bn;});
return React.createElement(React.Fragment,null,
React.createElement("div",{style:{display:'flex',gap:10,flexWrap:'wrap',marginBottom:16}},
React.createElement("div",{style:{flex:1,minWidth:150,background:'#E4F6EF',border:'1px solid #A9E1CC',borderRadius:12,padding:'13px 17px'}},
React.createElement("div",{style:{display:'flex',alignItems:'center',gap:6,fontSize:11.5,color:'#0F6E56',fontWeight:600,textTransform:'uppercase',letterSpacing:.4}},React.createElement(Ic,{n:"check_circle"}),"Alertando normal"),
React.createElement("div",{style:{fontFamily:'var(--f-display)',fontSize:27,fontWeight:800,color:'#0F6E56',marginTop:2}},okN)
),
React.createElement("div",{style:{flex:1,minWidth:150,background:silentN>0?'#FDECEC':'var(--paper-2)',border:'1px solid '+(silentN>0?'#F0C4C4':'var(--line-2)'),borderRadius:12,padding:'13px 17px'}},
React.createElement("div",{style:{display:'flex',alignItems:'center',gap:6,fontSize:11.5,color:silentN>0?'#A32D2D':'var(--mut)',fontWeight:600,textTransform:'uppercase',letterSpacing:.4}},React.createElement(Ic,{n:"notifications_off"}),"Mudas (>",data.thresholdHours,"h sem alerta)"),
React.createElement("div",{style:{fontFamily:'var(--f-display)',fontSize:27,fontWeight:800,color:silentN>0?'#A32D2D':'var(--mut)',marginTop:2}},silentN)
)
),
React.createElement("div",{className:"adm-filters"},
React.createElement("input",{className:"adm-inp",placeholder:"Buscar casa…",value:q,onChange:(e)=>setQ(e.target.value)}),
React.createElement("div",{className:"seg"},[['all','Todas'],['silent','Mudas'],['ok','OK']].map(([v,l])=>React.createElement("button",{key:v,className:"segb"+(only===v?' on':''),onClick:()=>setOnly(v)},l))),
React.createElement("button",{className:"btn-sm b-amber",onClick:load},React.createElement(Ic,{n:"refresh"}),"Atualizar")
),

React.createElement("h3",{style:{margin:'4px 0 4px',fontSize:15}},"Casas do crawler (Super Odds)"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--mut)',marginBottom:8}},"Ciclo e alerta das Super Odds. A leitura de Player Props da mesma casa é outro leitor (o coletor, na tabela de baixo): uma casa pode estar ok aqui e parada lá."),
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},
React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Layout"),React.createElement("th",null,"Último alerta"),React.createElement("th",null,"Último ciclo"),React.createElement("th",null,"Status"))),
React.createElement("tbody",null,casas.map((c)=>React.createElement("tr",{key:c.name},
React.createElement("td",{style:{fontWeight:600}},React.createElement("span",{className:"sdot",style:{background:c.silent?'var(--error)':'var(--primary)'}}),c.name),
React.createElement("td",{className:"mono-sm"},c.layout),
React.createElement("td",null,c.lastNotificationAt?React.createElement("span",{title:new Date(c.lastNotificationAt).toLocaleString('pt-BR')},timeAgo(c.lastNotificationAt)):React.createElement("span",{style:{color:'var(--error)',fontWeight:600}},"nunca")),
React.createElement("td",null,c.lastRunAt?React.createElement("span",{title:new Date(c.lastRunAt).toLocaleString('pt-BR'),style:{fontSize:12.5}},timeAgo(c.lastRunAt)):React.createElement("span",{style:{opacity:.5}},"—"),c.lastRunNote&&React.createElement("div",{className:"runnote",title:c.lastRunNote},c.lastRunNote)),
React.createElement("td",null,c.silent?React.createElement("span",{style:{color:'var(--error)',fontWeight:700}},"⚠️ muda"):React.createElement("span",{style:{color:'var(--primary)',fontWeight:700}},"✅ ok"))
))))
),

React.createElement("h3",{style:{margin:'22px 0 4px',fontSize:15}},"Fontes do coletor (Player Props e bolsas)"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--mut)',marginBottom:8}},"Parada = ligada e sem leitura ok há mais de 3 h. A conta vale desde o último OK, mesmo de antes do reinício do coletor",data.coletor&&data.coletor.startedAt?' (subiu '+new Date(data.coletor.startedAt).toLocaleString('pt-BR')+')':'',"; sem OK conhecido, recomeça na subida. Falhando = nenhum OK desde a subida e já com erro. Descoberta = jogos que a última descoberta",data.coletor&&data.coletor.descobertaEm?' ('+new Date(data.coletor.descobertaEm).toLocaleString('pt-BR')+')':''," pôs na fila; a fonte só lê esses. Erro ou queda (menos de 5% do maior dia dela em 14 dias) aparece aqui e na Saúde."),
data.coletorErro?React.createElement("div",{className:"err-box"},"Não leu o status do coletor: ",data.coletorErro):!data.coletor?React.createElement("div",{style:{color:'var(--mut)'}},"O coletor ainda não publicou o status."):
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},
React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Última leitura ok"),React.createElement("th",null,"Último erro"),React.createElement("th",null,"Descoberta"),React.createElement("th",null,"Status"))),
React.createElement("tbody",null,data.coletor.fontes.filter((f)=>!q||f.fonte.toLowerCase().includes(q.toLowerCase())).filter((f)=>only==='silent'?f.semLeitura||f.falhando:only==='ok'?!(f.semLeitura||f.falhando):true).map((f)=>React.createElement("tr",{key:f.fonte},
React.createElement("td",{style:{fontWeight:600}},React.createElement("span",{className:"sdot",style:{background:f.semLeitura?'var(--error)':f.falhando?'var(--warn, #d97706)':'var(--primary)'}}),f.fonte),
React.createElement("td",null,f.desdeOk?React.createElement("span",{title:new Date(f.desdeOk).toLocaleString('pt-BR')},timeAgo(f.desdeOk),f.okAntesDaSubida?' (antes do reinício)':''):React.createElement("span",{style:{color:'var(--error)',fontWeight:600}},"nenhuma desde a subida")),

React.createElement("td",null,f.erro?React.createElement("div",{className:"runnote",title:f.erro},f.erroEm?timeAgo(f.erroEm)+' · ':'',f.erro):f.erroSuperado?React.createElement("div",{className:"runnote",style:{opacity:.5},title:'Já superado por leitura ok mais nova: '+f.erroSuperado.erro},"— ",React.createElement("span",{style:{fontSize:11}},"(último erro ",f.erroSuperado.em?timeAgo(f.erroSuperado.em):'de antes do reinício',", já superado)")):React.createElement("span",{style:{opacity:.5}},"—")),
React.createElement("td",null,(()=>{const dp=(data.coletor.descobertas||[]).find((x)=>x.fonte===f.fonte);const n=(data.coletor.achados||{})[f.fonte];
return dp?React.createElement("div",{className:"runnote",title:dp.motivo,style:{color:'var(--error)'}},dp.tipo==='queda'?'⚠️ queda: ':'⚠️ erro: ',dp.motivo):n!=null?React.createElement("span",null,n," jogo(s)"):React.createElement("span",{style:{opacity:.5}},"—");})()),
React.createElement("td",null,f.semLeitura?React.createElement("span",{style:{color:'var(--error)',fontWeight:700}},"⚠️ parada há ",f.horas," h"):f.falhando?React.createElement("span",{style:{color:'var(--warn, #d97706)',fontWeight:700}},"⚠️ falhando desde a subida"):React.createElement("span",{style:{color:'var(--primary)',fontWeight:700}},"✅ ok"))
))))
)
);
}






function FontesChaves(){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[editando,setEditando]=useState(null),[valor,setValor]=useState(''),[busy,setBusy]=useState(''),[msg,setMsg]=useState({}),[mestra,setMestra]=useState('');

const[campos,setCampos]=useState({});
const load=async()=>{try{const r=await fetch('/api/admin/fontes/credenciais',{credentials:'include'});const j=await r.json();if(!r.ok)throw new Error(j.error||'HTTP '+r.status);setD(j);setErro('');}catch(e){setErro(String(e.message||e));}};
useEffect(()=>{load();},[]);
const testar=async(f)=>{setBusy(f);try{const r=await fetch('/api/admin/fontes/credenciais/'+f+'/testar',{method:'POST',credentials:'include'});const j=await r.json();setMsg((m)=>({...m,[f]:r.ok?j.ok?'Funciona: '+j.msg:'Recusada: '+j.msg:'Não testou: '+(j.error||r.status)}));await load();}catch(e){setMsg((m)=>({...m,[f]:'Não testou: '+(e.message||e)}));}finally{setBusy('');}};
const salvar=async(f,comCampos)=>{setBusy(f);try{const r=await fetch('/api/admin/fontes/credenciais/'+f,{method:'PUT',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(comCampos?{campos}:{valor})});const j=await r.json();if(!r.ok)throw new Error(j.error||'HTTP '+r.status);setValor('');setCampos({});setEditando(null);setMsg((m)=>({...m,[f]:'Chave salva. Testando…'}));await load();await testar(f);}catch(e){setMsg((m)=>({...m,[f]:'Não salvou: '+(e.message||e)}));}finally{setBusy('');}};
const remover=async(f,nome)=>{if(!(await confirma('Remover a chave de '+nome+'? A fonte para de ler até outra chave ser salva.')))return;setBusy(f);try{const r=await fetch('/api/admin/fontes/credenciais/'+f,{method:'DELETE',credentials:'include'});if(!r.ok)throw new Error('HTTP '+r.status);setMsg((m)=>({...m,[f]:'Chave removida.'}));await load();}catch(e){setMsg((m)=>({...m,[f]:'Não removeu: '+(e.message||e)}));}finally{setBusy('');}};
const gerarMestra=()=>{const b=new Uint8Array(32);crypto.getRandomValues(b);setMestra(btoa(String.fromCharCode(...b)));};
const dataHora=(v)=>v?new Date(String(v).includes('T')?v:String(v).replace(' ','T')+'Z').toLocaleString('pt-BR'):'';
if(!d)return erro?React.createElement("div",{className:"err-box",style:{marginBottom:12}},"Chaves de API: ",erro):null;
return React.createElement("div",{style:{marginBottom:22}},
React.createElement("h3",{style:{margin:'6px 0 4px',fontSize:15}},"Chaves de API das fontes"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--mut)',marginBottom:8,maxWidth:760}},"A chave é guardada cifrada e não aparece de novo depois de salva: a tela mostra só os 4 últimos caracteres. Para trocar, cole a nova por cima. O coletor passa a usar a chave nova em até 1 minuto."),
!d.mestraConfigurada&&React.createElement("div",{className:"err-box",style:{marginBottom:10,maxWidth:760}},
React.createElement("b",null,"Falta a chave mestra.")," Ela cifra as chaves das fontes e é a única coisa que vai no ambiente. Crie a variável ",React.createElement("code",null,"CREDENCIAIS_CHAVE")," com o mesmo valor nos serviços ",React.createElement("b",null,"dashboard")," e ",React.createElement("b",null,"props-collector")," (EasyPanel → Ambiente) e implante os dois.",
React.createElement("div",{style:{marginTop:6}},mestra?React.createElement(React.Fragment,null,React.createElement("div",{style:{fontSize:12}},"Valor gerado aqui no seu navegador (não passa pelo servidor). Copie agora: ele não fica salvo em lugar nenhum."),React.createElement("input",{id:"fch-mestra",readOnly:true,value:mestra,onFocus:(e)=>e.target.select(),style:{width:'100%',maxWidth:520,fontFamily:'var(--mono,monospace)'}})):React.createElement("button",{className:"btn-sm",onClick:gerarMestra},"Gerar um valor para a chave mestra"))
),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Chave"),React.createElement("th",null,"Teste"),React.createElement("th",null))),React.createElement("tbody",null,
d.fontes.map((f)=>React.createElement("tr",{key:f.fonte},
React.createElement("td",null,React.createElement("b",null,f.nome),React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)'}},f.ajuda)),
React.createElement("td",{style:{fontSize:12.5}},f.salva?React.createElement(React.Fragment,null,React.createElement("span",{style:{fontFamily:'var(--mono,monospace)'}},f.campos?React.createElement(React.Fragment,null,"usuário ",f.final||''," · senha ••••••••"):React.createElement(React.Fragment,null,"••••••••",f.final||'')),React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)'}},"salva ",dataHora(f.atualizado),f.atualizadoPor?' por '+f.atualizadoPor:'')):
f.naVariavelAntiga?React.createElement("span",{title:'Vem da variável '+f.variavelAntiga+' do coletor. Cadastre aqui para trocar pela tela.'},"na variável de ambiente antiga"):React.createElement("span",{style:{color:'var(--mut)'}},"sem chave"),
editando===f.fonte&&f.campos&&React.createElement("div",{style:{display:'flex',gap:6,marginTop:6,flexWrap:'wrap',alignItems:'center'}},f.campos.map((c)=>c.arquivo?

React.createElement("span",{key:c.id,style:{display:'inline-flex',gap:6,alignItems:'center',flexWrap:'wrap'}},React.createElement("textarea",{id:'fch-'+f.fonte+'-'+c.id,autoComplete:"off",spellCheck:false,placeholder:c.rotulo+' — cole o arquivo inteiro ou carregue o .txt',"aria-label":c.rotulo,value:campos[c.id]||'',onChange:(e)=>{const v=e.target.value;setCampos((s)=>({...s,[c.id]:v}));},rows:3,style:{minWidth:260,fontFamily:'var(--mono,monospace)',fontSize:11,WebkitTextSecurity:'disc'}}),React.createElement("label",{className:"btn-sm",style:{cursor:'pointer'}},"Carregar o arquivo .txt",React.createElement("input",{id:'fch-'+f.fonte+'-'+c.id+'-arq',type:"file",accept:".txt,.pem,.key,text/plain",style:{display:'none'},onChange:(e)=>{const a=e.target.files&&e.target.files[0];if(!a)return;const r=new FileReader();r.onload=()=>setCampos((s)=>({...s,[c.id]:String(r.result||'')}));r.readAsText(a);e.target.value='';}})),campos[c.id]?React.createElement("span",{style:{fontSize:11.5,color:'var(--mut)'}},String(campos[c.id]).length," caracteres",/-----END [A-Z ]*PRIVATE KEY-----/.test(String(campos[c.id]))?' · arquivo completo':' · ainda sem o -----END'):null):
React.createElement("input",{key:c.id,id:'fch-'+f.fonte+'-'+c.id,type:c.senha?'password':'text',autoComplete:"off",spellCheck:false,placeholder:c.rotulo,"aria-label":c.rotulo,value:campos[c.id]||'',onChange:(e)=>{const v=e.target.value;setCampos((s)=>({...s,[c.id]:v}));},style:{minWidth:180}})),React.createElement("button",{className:"btn-sm b-green",disabled:busy===f.fonte||f.campos.some((c)=>!String(campos[c.id]||'').trim())||!d.mestraConfigurada,onClick:()=>salvar(f.fonte,true)},busy===f.fonte?'Salvando…':'Salvar'),React.createElement("button",{className:"btn-sm",onClick:()=>{setEditando(null);setCampos({});}},"Cancelar")),
editando===f.fonte&&!f.campos&&React.createElement("div",{style:{display:'flex',gap:6,marginTop:6,flexWrap:'wrap'}},React.createElement("input",{id:'fch-'+f.fonte,type:"password",autoComplete:"off",spellCheck:false,placeholder:"Cole a chave",value:valor,onChange:(e)=>setValor(e.target.value),style:{minWidth:240}}),React.createElement("button",{className:"btn-sm b-green",disabled:busy===f.fonte||valor.trim().length<8||!d.mestraConfigurada,onClick:()=>salvar(f.fonte)},busy===f.fonte?'Salvando…':'Salvar'),React.createElement("button",{className:"btn-sm",onClick:()=>{setEditando(null);setValor('');}},"Cancelar")),
msg[f.fonte]&&React.createElement("div",{style:{fontSize:12,marginTop:4}},msg[f.fonte]),
f.coletorErro&&React.createElement("div",{style:{fontSize:12,marginTop:4,color:'var(--error)'}},"O coletor não conseguiu ler a chave: ",f.coletorErro),
f.salva&&f.coletorUsa&&f.coletorUsa!=='cadastro'&&!f.coletorErro&&React.createElement("div",{style:{fontSize:11.5,marginTop:4,color:'var(--mut)'}},"O coletor ainda usa ",f.coletorUsa==='variavel'?'a variável antiga':'nenhuma chave',"; troca em até 1 min.")
),
React.createElement("td",{style:{fontSize:12}},f.testeOk==null?React.createElement("span",{style:{color:'var(--mut)'}},"—"):React.createElement("span",{style:{color:f.testeOk?'var(--up)':'var(--error)',fontWeight:600}},f.testeOk?'funciona':'recusada'),f.testadoEm&&React.createElement("div",{style:{fontSize:11,color:'var(--mut)'}},dataHora(f.testadoEm),f.testeMsg?' · '+f.testeMsg:'')),
React.createElement("td",null,React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},
editando!==f.fonte&&React.createElement("button",{className:"btn-sm",disabled:!d.mestraConfigurada,onClick:()=>{setEditando(f.fonte);setValor('');setCampos({});}},f.salva?'Trocar':'Cadastrar'),
f.salva&&React.createElement("button",{className:"btn-sm",disabled:busy===f.fonte,onClick:()=>testar(f.fonte)},"Testar"),
f.salva&&React.createElement("button",{className:"btn-sm b-red",disabled:busy===f.fonte,onClick:()=>remover(f.fonte,f.nome)},"Remover")
))
))
)))
);
}




const fmtCada=(h)=>{const m=Math.round(Number(h)*60);if(!(m>0))return'—';if(m<60)return m+' min';const hh=m/60;return(Number.isInteger(hh)?hh:hh.toFixed(1).replace('.',','))+' h';};
function FonteFrequencia({f,onSalvo}){
const[ed,setEd]=useState(false),[v,setV]=useState({}),[busy,setBusy]=useState(false),[erro,setErro]=useState('');
const c=f.cadencia;
const iguais=c&&c.cadaPertoH===c.cadaMeioH&&c.cadaMeioH===c.cadaLongeH;
const abrir=()=>{setV({feed:f.feedSeg!=null?Math.round(f.feedSeg/60*100)/100:'',perto:c?Math.round(c.cadaPertoH*60):'',meio:c?Math.round(c.cadaMeioH*60):'',longe:c?Math.round(c.cadaLongeH*60):''});setErro('');setEd(true);};
const salvar=async()=>{setBusy(true);setErro('');try{
const body={};
if(f.feedSeg!=null)body.feedCadaSeg={[f.chave]:Math.round(Number(String(v.feed).replace(',','.'))*60)};
if(c)body.cadencia={[f.chave]:{cadaPertoH:Number(String(v.perto).replace(',','.'))/60,cadaMeioH:Number(String(v.meio).replace(',','.'))/60,cadaLongeH:Number(String(v.longe).replace(',','.'))/60}};
const r=await fetch('/api/props/params',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'HTTP '+r.status);
setEd(false);onSalvo&&onSalvo();}catch(e){setErro(String(e.message||e));}finally{setBusy(false);}};
if(!ed)return React.createElement("div",{style:{display:'flex',gap:6,alignItems:'flex-start'}},
React.createElement("div",null,f.feedSeg!=null&&React.createElement("div",{title:"Mercados de jogo (feed lido em laço próprio)"},"jogo: ",React.createElement("b",null,fmtCada(f.feedSeg/3600)),f.feedEditado?'':' (padrão)'),
f.tempoRealOpcional&&React.createElement("label",{title:"Com o canal ao vivo da casa: o preço novo grava no banco em ~1 s, em vez de esperar a volta do feed (liga e desliga sem reiniciar o coletor; o coletor aplica em até 30 s)",style:{display:'flex',gap:4,alignItems:'center',cursor:'pointer'}},React.createElement("input",{type:"checkbox",checked:!!f.tempoReal,disabled:busy,onChange:async(e)=>{const on=e.target.checked;setBusy(true);setErro('');try{const r=await fetch('/api/props/params',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({tempoReal:{[f.chave]:on}})});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'HTTP '+r.status);onSalvo&&onSalvo();}catch(x){setErro(String(x.message||x));}finally{setBusy(false);}}}),"tempo real pelo canal"),
c&&(iguais?React.createElement("div",{title:"Props de jogador, em todas as faixas"},"props: ",React.createElement("b",null,fmtCada(c.cadaPertoH))):
React.createElement("div",{title:`Props: perto = menos de ${c.faixaPertoH} h do jogo; longe = mais de ${c.faixaLongeH} h`},"props: perto ",React.createElement("b",null,fmtCada(c.cadaPertoH))," · meio ",React.createElement("b",null,fmtCada(c.cadaMeioH))," · longe ",React.createElement("b",null,fmtCada(c.cadaLongeH)))),
f.feedSeg==null&&!c&&React.createElement("span",{style:{opacity:.5}},"—")),
(f.feedSeg!=null||c)&&React.createElement("button",{className:"btn-sm",onClick:abrir,title:"Mudar a frequência","aria-label":'Mudar a frequência de '+f.nome,style:{padding:'2px 6px'}},React.createElement(Ic,{n:"edit"}))
);
const campo=(k,rot)=>React.createElement("label",{style:{display:'flex',gap:4,alignItems:'center'}},rot,React.createElement("input",{id:'freq-'+f.chave+'-'+k,type:"number",min:"0.5",step:"0.5",value:v[k],onChange:(e)=>setV((x)=>({...x,[k]:e.target.value})),style:{width:64}}),"min");
return React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:4}},
f.feedSeg!=null&&campo('feed','jogo'),
c&&React.createElement(React.Fragment,null,campo('perto','props perto'),campo('meio','meio'),campo('longe','longe')),
erro&&React.createElement("div",{style:{color:'var(--error)',fontSize:11.5}},erro),
React.createElement("div",{style:{display:'flex',gap:4}},React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:salvar},busy?'Salvando…':'Salvar'),React.createElement("button",{className:"btn-sm",onClick:()=>setEd(false)},"Cancelar"))
);
}




function CorretorasCard(){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[busy,setBusy]=useState(''),[pct,setPct]=useState({}),[msg,setMsg]=useState({});
const load=async()=>{try{const r=await fetch('/api/admin/corretoras',{credentials:'include'});const j=await r.json();if(!r.ok)throw new Error(j.error||'HTTP '+r.status);setD(j);setErro('');}catch(e){setErro(String(e.message||e));}};
useEffect(()=>{load();},[]);
const salva=async(c,via,pctManual)=>{setBusy(c.fonte);try{const r=await fetch('/api/admin/corretoras',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({fonte:c.fonte,via,pctManual:pctManual===''||pctManual==null?null:Number(String(pctManual).replace(',','.'))})});const j=await r.json();if(!r.ok)throw new Error(j.error||'HTTP '+r.status);setMsg((m)=>({...m,[c.fonte]:'Salvo. Vale na próxima volta do EV+ (até 30 s).'}));await load();}catch(e){setMsg((m)=>({...m,[c.fonte]:'Não salvou: '+(e.message||e)}));}finally{setBusy('');}};
if(!d)return erro?React.createElement("div",{className:"err-box",style:{marginBottom:12}},"Corretoras: ",erro):null;
const nomeDe=(id)=>(d.corretoras.find((c)=>c.id===id)||{}).nome||id;
return React.createElement("div",{style:{margin:'6px 0 16px'}},
React.createElement("h3",{style:{margin:'6px 0 4px',fontSize:15}},"Apostar via corretora"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--mut)',marginBottom:8,maxWidth:980}},d.observacao),
d.corretoras.map((c)=>React.createElement("div",{key:c.id,style:{fontSize:12.5,marginBottom:8}},
React.createElement("b",null,c.nome)," · link do jogo: ",React.createElement("span",{className:"mono-sm"},c.modeloLink)," · regras da conta: ",c.regrasEm?Date.now()-c.regrasEm>3600e3?React.createElement("b",{style:{color:'#B26B00'}},c.nRegras," lidas ",timeAgo(new Date(c.regrasEm).toISOString())," — velhas (o login da conta falhou?): o EV+ usa as últimas e tira essas linhas do robô"):React.createElement(React.Fragment,null,c.nRegras," lidas ",timeAgo(new Date(c.regrasEm).toISOString())):React.createElement("b",{style:{color:'#B26B00'}},"ainda não lidas (cadastre o usuário e a senha da Apexium acima)"),
c.descontos&&c.descontos.length>0&&React.createElement("div",{style:{color:'var(--mut)',marginTop:2}},c.descontos.map((x,i)=>React.createElement("span",{key:i,style:{marginRight:10}},x.quem,": ",x.efeito,x.onde!=='tudo'?' ('+x.onde+')':'')))
)),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Apostar via corretora"),React.createElement("th",{title:"Só vale enquanto as regras da conta não forem lidas"},"% de desconto (reserva)"),React.createElement("th",null))),
React.createElement("tbody",null,d.casas.map((c)=>React.createElement("tr",{key:c.fonte},
React.createElement("td",{style:{fontWeight:600}},c.nome),
React.createElement("td",null,React.createElement("label",{style:{display:'flex',alignItems:'center',gap:6}},React.createElement("input",{type:"checkbox",checked:!!c.via,disabled:busy===c.fonte||!c.corretoras.length,onChange:(e)=>salva(c,e.target.checked?c.corretoras[0]:null,c.pctManual)}),c.via?'via '+nomeDe(c.via):'não (odd e link da casa)')),
React.createElement("td",null,c.via?React.createElement("span",{style:{display:'flex',gap:6,alignItems:'center'}},React.createElement("input",{className:"adm-inp",style:{width:80},placeholder:"—",value:pct[c.fonte]!=null?pct[c.fonte]:c.pctManual!=null?String(c.pctManual).replace('.',','):'',onChange:(e)=>setPct((p)=>({...p,[c.fonte]:e.target.value}))}),"%",React.createElement("button",{className:"btn-sm",disabled:busy===c.fonte,onClick:()=>salva(c,c.via,pct[c.fonte]!=null?pct[c.fonte]:c.pctManual)},"Salvar"),c.manualEm&&React.createElement("span",{style:{color:'var(--mut)'}},"desde ",new Date(c.manualEm).toLocaleDateString('pt-BR'))):React.createElement("span",{style:{opacity:.5}},"—")),
React.createElement("td",{style:{fontSize:12,color:'var(--mut)'}},msg[c.fonte]||'')
)))))
);
}

function FonteAfiliado({f,onSalvo}){
const[ed,setEd]=useState(false),[v,setV]=useState(f.afiliado||''),[msg,setMsg]=useState(''),[erro,setErro]=useState(false),[busy,setBusy]=useState(false);
useEffect(()=>{if(!ed)setV(f.afiliado||'');},[f.afiliado,ed]);
const salva=async()=>{setBusy(true);setMsg('');setErro(false);try{const r=await fetch('/api/admin/fontes/afiliado',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({fonte:f.chave,ref:v})});const j=await r.json();if(!r.ok)throw new Error(j.error||'HTTP '+r.status);setEd(false);setMsg(j.ref?'Salva. Link fica assim: '+j.exemplo:'Ref removida.');onSalvo&&onSalvo();}catch(e){setErro(true);setMsg(String(e.message||e));}finally{setBusy(false);}};
if(!ed)return React.createElement("span",{style:{display:'inline-flex',gap:6,alignItems:'center',flexWrap:'wrap'}},f.afiliado?React.createElement("code",{className:"mono-sm"},f.afiliado):React.createElement("span",{style:{color:'var(--mut)'}},"—"),React.createElement("button",{className:"btn-sm",onClick:()=>{setEd(true);setMsg('');},"aria-label":'Editar ref de afiliado de '+f.nome,title:"Editar ref de afiliado"},React.createElement(Ic,{n:"edit"})),msg&&React.createElement("div",{style:{fontSize:11,color:'var(--mut)',flexBasis:'100%'}},msg));
return React.createElement("span",{style:{display:'inline-flex',gap:6,alignItems:'center',flexWrap:'wrap'}},
React.createElement("input",{id:'afiliado-'+f.chave,className:"adm-inp",style:{width:180},placeholder:"?ref=CODIGO",value:v,autoFocus:true,onChange:(e)=>setV(e.target.value),onKeyDown:(e)=>{if(e.key==='Enter')salva();if(e.key==='Escape')setEd(false);}}),
React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:salva},busy?'Salvando…':'Salvar'),
React.createElement("button",{className:"btn-sm",onClick:()=>{setEd(false);setV(f.afiliado||'');setMsg('');}},"Cancelar"),
msg&&React.createElement("div",{style:{fontSize:11,color:erro?'var(--error)':'var(--mut)',flexBasis:'100%'}},msg)
);
}

function FontesTab({onClose}){
const[data,setData]=useState(null),[erro,setErro]=useState(''),[q,setQ]=useState(''),[only,setOnly]=useState('all'),[salvando,setSalvando]=useState('');
const load=async()=>{try{const r=await fetch('/api/admin/fontes',{credentials:'include'});if(r.status===401){onClose('relogin');return;}const j=await r.json();if(!r.ok)throw new Error(j.error||'HTTP '+r.status);setData(j);setErro('');}catch(e){setErro(String(e.message||e));}};
useEffect(()=>{load();const i=setInterval(load,15000);return()=>clearInterval(i);},[]);
const troca=async(tipo,chave,nome,ligada)=>{
if(!ligada&&!(await confirma(`Desligar ${nome}? Ela para de ser lida até você religar.`)))return;
setSalvando(tipo+':'+chave);
try{const r=await fetch('/api/admin/fontes',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({tipo,chave,ligada})});const j=await r.json();if(!r.ok)throw new Error(j.error||'HTTP '+r.status);await load();}
catch(e){setErro(`${nome}: ${e.message||e}`);}finally{setSalvando('');}
};
if(!data)return erro?React.createElement("div",{className:"empty",style:{padding:'40px 20px'}},React.createElement("div",{className:"em-t"},"Não carregou"),React.createElement("div",null,erro)):React.createElement("div",{style:{textAlign:'center',padding:40,color:'var(--on-surface-variant)'}},"Carregando…");
const chave=(l)=>l.slice().sort().join(',');
const pedidas=data.coletor.filter((f)=>!f.ligada).map((f)=>f.chave);
const aplicou=data.coletorAplicou&&Array.isArray(data.coletorAplicou.desligadas)&&chave(data.coletorAplicou.desligadas)===chave(pedidas);
const Chave=({on,busy,onClick,label})=>React.createElement("button",{className:"btn-sm "+(on?'b-green':'b-red'),disabled:busy,onClick:onClick,style:{minWidth:104},"aria-label":label},React.createElement(Ic,{n:on?'toggle_on':'toggle_off'}),busy?'Salvando…':on?'Ligada':'Desligada');
const quando=(d)=>d?React.createElement("span",{title:new Date(d).toLocaleString('pt-BR')},timeAgo(d)):React.createElement("span",{style:{opacity:.5}},"—");
const filtra=(l)=>l.filter((x)=>(!q||x.nome.toLowerCase().includes(q.toLowerCase()))&&(only==='all'||(only==='on'?x.ligada:!x.ligada)));
const casas=filtra(data.crawler);
const mb=(b)=>b>=1e9?(b/1e9).toFixed(2)+' GB':(b/1e6).toFixed(b>=1e7?0:1)+' MB';
const bandaIni=data.bandaCrawler&&data.bandaCrawler.janela?data.bandaCrawler.janela.inicio:null;
return React.createElement(React.Fragment,null,
erro&&React.createElement("div",{className:"err-box",style:{marginBottom:12,color:'var(--error)',fontWeight:600}},erro),
React.createElement("div",{className:"adm-filters"},
React.createElement("input",{className:"adm-inp",placeholder:"Buscar fonte…",value:q,onChange:(e)=>setQ(e.target.value)}),
React.createElement("div",{className:"seg"},[['all','Todas'],['on','Ligadas'],['off','Desligadas']].map(([v,l])=>React.createElement("button",{key:v,className:"segb"+(only===v?' on':''),onClick:()=>setOnly(v)},l))),
React.createElement("button",{className:"btn-sm b-amber",onClick:load},React.createElement(Ic,{n:"refresh"}),"Atualizar")
),
React.createElement(FontesChaves,null),
React.createElement(CorretorasCard,null),
React.createElement("h3",{style:{margin:'6px 0 4px',fontSize:15}},"Player Props e catálogo (coletor)"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--mut)',marginBottom:8}},"Desligada: sem descoberta, sem leitura de odds e sem catálogo. O coletor aplica em até 30 s — ",
pedidas.length===0?'nenhuma desligada.':aplicou?React.createElement("b",{style:{color:'var(--primary)'}},"aplicado pelo coletor."):React.createElement("b",{style:{color:'#B26B00'}},"aguardando o coletor aplicar…"),
data.alteradoPor&&data.alteradoPor.em&&React.createElement(React.Fragment,null," Última mudança ",timeAgo(data.alteradoPor.em),data.alteradoPor.por?` por ${data.alteradoPor.por}`:'',".")
),
React.createElement("div",{className:"tbl-wrap"},
React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Proxy"),React.createElement("th",null,"Frequência"),React.createElement("th",{title:"Vai no fim de todo link desta fonte no EV+, na Odds Screen e nas props. Começa com ?, ex.: ?ref=CODIGO"},"Ref. de afiliado"),React.createElement("th",null,"Última leitura"),React.createElement("th",null,"Último erro"),React.createElement("th",{style:{width:120}},"Situação"))),
React.createElement("tbody",null,filtra(data.coletor).map((f)=>React.createElement("tr",{key:f.chave,style:{opacity:f.ligada?1:.6}},
React.createElement("td",{style:{fontWeight:600}},React.createElement("span",{className:"sdot",style:{background:f.ligada?'var(--primary)':'var(--mut)'}}),f.nome),
React.createElement("td",{title:f.proxy.como,style:{fontSize:12.5}},f.proxy.usa?React.createElement("b",{style:{color:'#B26B00'}},"Sim"):React.createElement("span",{style:{color:'var(--mut)'}},"Não")),
React.createElement("td",{style:{fontSize:12.5}},React.createElement(FonteFrequencia,{f:f,onSalvo:load})),
React.createElement("td",{style:{fontSize:12.5}},React.createElement(FonteAfiliado,{f:f,onSalvo:load})),
React.createElement("td",{title:[f.leituraJogo&&`Mercados de jogo: ${new Date(f.leituraJogo).toLocaleString('pt-BR')}`,f.leituraProps&&`Props: ${new Date(f.leituraProps).toLocaleString('pt-BR')}`].filter(Boolean).join(' · ')},quando(f.ultimaLeitura),f.leituraJogo&&f.leituraProps&&React.createElement("div",{style:{fontSize:11,color:'var(--mut)'}},"jogo ",timeAgo(f.leituraJogo)," · props ",timeAgo(f.leituraProps))),
React.createElement("td",{style:{fontSize:12,maxWidth:360,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'},title:f.ultimoErro||''},f.ultimoErro?React.createElement(React.Fragment,null,quando(f.ultimoErroEm)," · ",f.ultimoErro):React.createElement("span",{style:{opacity:.5}},"—")),
React.createElement("td",null,React.createElement(Chave,{on:f.ligada,busy:salvando==='coletor:'+f.chave,label:(f.ligada?'Desligar ':'Ligar ')+f.nome,onClick:()=>troca('coletor',f.chave,f.nome,!f.ligada)}))
))))
),
React.createElement("h3",{style:{margin:'18px 0 4px',fontSize:15}},"Super Odds (crawler)"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--mut)',marginBottom:8}},"Vale na próxima volta do crawler. ",data.crawler.filter((c)=>c.ligada).length," de ",data.crawler.length," casas ligadas.",
' ',"Proxy = banda medida pelo crawler desde ",bandaIni?new Date(bandaIni).toLocaleString('pt-BR',{hour:'2-digit',minute:'2-digit',day:'2-digit',month:'2-digit'}):'—',data.bandaCrawler&&data.bandaCrawler.janela?` (${mb(data.bandaCrawler.janela.totalBytes)} no total)`:''," e ontem; casa lida por navegador remoto não entra na medição — a cobrança oficial é o painel do FloppyData."),
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},
React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Layout"),React.createElement("th",null,"Proxy"),React.createElement("th",null,"Última odd"),React.createElement("th",null,"Última volta"),React.createElement("th",{style:{width:120}},"Situação"))),
React.createElement("tbody",null,casas.map((c)=>React.createElement("tr",{key:c.nome,style:{opacity:c.ligada?1:.6}},
React.createElement("td",{style:{fontWeight:600}},React.createElement("span",{className:"sdot",style:{background:c.ligada?'var(--primary)':'var(--mut)'}}),c.nome),
React.createElement("td",{className:"mono-sm"},c.layout),
React.createElement("td",{style:{fontSize:12.5,whiteSpace:'nowrap'}},c.proxyBytes||c.proxyBytesOntem?React.createElement(React.Fragment,null,React.createElement("b",{style:{color:'#B26B00'}},"Sim")," · ",mb(c.proxyBytes||0),c.proxyBytesOntem!=null?React.createElement("span",{style:{color:'var(--mut)'}}," · ontem ",mb(c.proxyBytesOntem)):null):React.createElement("span",{style:{color:'var(--mut)'}},c.proxyBytes==null?'sem medição':'—')),
React.createElement("td",null,quando(c.ultimaOdd)),
React.createElement("td",null,quando(c.ultimaVolta),c.nota&&React.createElement("div",{className:"runnote",title:c.nota},c.nota)),
React.createElement("td",null,React.createElement(Chave,{on:c.ligada,busy:salvando==='crawler:'+c.nome,label:(c.ligada?'Desligar ':'Ligar ')+c.nome,onClick:()=>troca('crawler',c.nome,c.nome,!c.ligada)}))
))))
)
);
}

function LogsTab({onClose}){
const[logs,setLogs]=useState(null),[q,setQ]=useState(''),[auto,setAuto]=useState(true),[open,setOpen]=useState({});
const load=async()=>{try{const p=new URLSearchParams();if(q)p.set('search',q);const r=await fetch('/api/admin/logs?'+p,{credentials:'include'});if(r.status===401){onClose('relogin');return;}setLogs(await r.json());}catch(e){setLogs([]);}};
useEffect(()=>{load();},[]);
useEffect(()=>{if(!auto)return;const i=setInterval(load,15000);return()=>clearInterval(i);},[auto,q]);
if(!logs)return React.createElement("div",{style:{textAlign:'center',padding:40,color:'var(--on-surface-variant)'}},"Carregando…");
return React.createElement(React.Fragment,null,
React.createElement("div",{className:"adm-filters"},
React.createElement("input",{className:"adm-inp",placeholder:"Buscar no log…",value:q,onChange:(e)=>setQ(e.target.value),onKeyDown:(e)=>e.key==='Enter'&&load()}),
React.createElement("div",{className:"act auto"+(auto?'':' off'),onClick:()=>setAuto(!auto),style:{padding:'8px 14px'}},React.createElement("span",{className:"ring pulse-dot"}),React.createElement("span",{className:"lbl"},auto?'Auto 15s':'Pausado')),
React.createElement("button",{className:"btn-sm b-amber",onClick:load},React.createElement(Ic,{n:"refresh"}),"Atualizar")
),
logs.length===0?
React.createElement("div",{className:"empty",style:{padding:'40px 20px'}},React.createElement("div",{className:"em-ic"},React.createElement(Ic,{n:"check_circle"})),React.createElement("div",{className:"em-t"},"Sem logs"),React.createElement("div",null,"Nenhum erro registrado",q?' pra essa busca':'',". Se acabou de subir o crawler, os logs aparecem conforme forem ocorrendo.")):
React.createElement("div",{className:"logfeed"},logs.map((l)=>React.createElement("div",{key:l.id,className:"logrow"+(l.level==='fatal'?'':''),onClick:()=>setOpen((o)=>({...o,[l.id]:!o[l.id]}))},
React.createElement("div",{className:"logtop"},
React.createElement("span",{className:"lvl "+(l.level==='fatal'?'fatal':'error')},l.level),
React.createElement("span",{className:"logtitle"},l.title),
React.createElement("span",{className:"logtime",title:new Date(l.createdAt).toLocaleString('pt-BR')},timeAgo(l.createdAt))
),
open[l.id]&&l.body&&React.createElement("pre",{className:"logbody"},l.body)
)))
);
}














function PareamentosTab({onClose}){
const[sub,setSub]=useRota('aba','resolver');
const[fila,setFila]=useState(null);
const load=async()=>{try{const r=await fetch('/api/admin/fila',{credentials:'include'});if(r.status===401){onClose('relogin');return;}setFila(await r.json());}catch(e){setFila({total:0,casos:[]});}};
useEffect(()=>{load();},[]);



const[resolvidos,setResolvidos]=useState({});
const n=fila?contaFila(fila,resolvidos).total:null;
const abas=[['resolver','Resolver'+(n?` (${n})`:'')],['jogos','Jogos'],['identidades','Identidades'],['ligas','Ligas'],['esportes','Esportes'],['areas','Áreas'],['mercados','Mercados'],['saude','Saúde']];
return React.createElement("div",null,
React.createElement("div",{className:"seg",style:{marginBottom:18,display:'inline-flex'}},abas.map(([v,l])=>React.createElement("button",{key:v,className:"segb"+(sub===v?' on':''),onClick:()=>setSub(v)},l))),
sub==='resolver'&&React.createElement(FilaSection,{fila:fila,recarregar:load,onClose:onClose,resolvidos:resolvidos,setResolvidos:setResolvidos}),
sub==='jogos'&&React.createElement(JogosSection,{onClose:onClose}),
sub==='identidades'&&React.createElement(IdentidadesSection,{onClose:onClose}),
sub==='ligas'&&React.createElement(LigasSection,{onClose:onClose}),
sub==='esportes'&&React.createElement(EsportesSection,{onClose:onClose}),
sub==='areas'&&React.createElement(AreasSection,{onClose:onClose}),
sub==='mercados'&&React.createElement(MercadosSection,{onClose:onClose}),
sub==='saude'&&React.createElement(React.Fragment,null,React.createElement(VigiasPropsPainel,null),React.createElement(RegistroSection,{onClose:onClose}))
);
}





function JogosSection({onClose}){
const hoje=fusoSP.diaSP(new Date());
const[q,setQ]=useState(''),[dia,setDia]=useState(''),[res,setRes]=useState(null),[busy,setBusy]=useState(false);
const buscar=async()=>{setBusy(true);try{const u=new URLSearchParams();if(q.trim())u.set('q',q.trim());if(dia)u.set('dia',dia);const r=await fetch('/api/admin/er/jogos?'+u.toString(),{credentials:'include'});if(r.status===401){onClose('relogin');return;}setRes(await r.json());}catch(e){setRes({jogos:[],erro:e.message});}finally{setBusy(false);}};
useEffect(()=>{buscar();},[]);
const fmt=(x)=>{if(!x)return'—';const t=new Date(x);return isNaN(t.getTime())?'—':t.toLocaleString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});};
const lista=res&&res.jogos||[];
const dups=lista.filter((j)=>j.duplicadoDe).length;
const[casasDe,setCasasDe]=useState(null),[casas,setCasas]=useState(null),[msgJ,setMsgJ]=useState('');
const abreCasas=async(j)=>{setCasasDe(j);setCasas(null);setMsgJ('');setHoraEd(null);try{const r=await fetch('/api/admin/er/jogos/'+j.er_id+'/casas',{credentials:'include'});setCasas(await r.json());}catch(e){setCasas({error:e.message});}};



const[horaEd,setHoraEd]=useState(null);
const mudaHora=()=>{setMsgJ('');setHoraEd({texto:casas&&casas.jogo&&casas.jogo.kickoff_utc?fusoSP.fmtSP(casas.jogo.kickoff_utc).slice(4):'',data:null});};
const confereHora=()=>{
if(!horaEd||!horaEd.texto.trim())return setMsgJ('❌ digite a hora de São Paulo (ex.: 08/10 20:05)');
const lida=fusoSP.lerHoraSP(horaEd.texto,casas&&casas.jogo&&casas.jogo.kickoff_utc);
if(lida.erro)return setMsgJ('❌ '+lida.erro);
setMsgJ('');setHoraEd({...horaEd,data:lida.data});};
const gravaHora=async()=>{
if(!horaEd||!horaEd.data)return;
try{const r=await fetch('/api/admin/er/jogos/'+casasDe.er_id+'/hora',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({hora:horaEd.texto})});const j=await r.json();if(r.ok){setHoraEd(null);abreCasas(casasDe);}setMsgJ(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));}catch(e){setMsgJ('❌ '+e.message);}};
const desamarra=async(c)=>{if(!(await confirma(`"${c.source}" não é este jogo?\n\nA amarração é apagada e fica travada: essa referência não volta para este jogo. Se a odd também está no jogo errado por causa do nome do time, corrija a grafia em Identidades.`)))return;
try{const r=await fetch('/api/admin/er/jogos/desamarrar',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({event_id:casasDe.er_id,source:c.source,external_id:c.external_id})});const j=await r.json();setMsgJ(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok)abreCasas(casasDe);}catch(e){setMsgJ('❌ '+e.message);}};
return React.createElement("div",null,
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:12}},"Os jogos que o sistema tem cadastrados. Sem filtro mostra das últimas 6 horas até os próximos 3 dias; buscando por time, até 30 dias à frente; \"#23885\" abre o jogo pelo número, em qualquer data."),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',marginBottom:14}},
React.createElement("input",{className:"inp",placeholder:"time ou #jogo (ex.: Huracán, #23885)",value:q,onChange:(e)=>setQ(e.target.value),onKeyDown:(e)=>{if(e.key==='Enter')buscar();},style:{minWidth:220}}),
React.createElement("input",{className:"inp",type:"date",value:dia,max:undefined,onChange:(e)=>setDia(e.target.value)}),
React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:buscar},busy?'Buscando…':'Buscar'),
(q||dia)&&React.createElement("button",{className:"btn-sm",onClick:()=>{setQ('');setDia('');setTimeout(buscar,0);}},"Limpar")
),
res&&res.erro&&React.createElement("div",{className:"toast"},"❌ ",res.erro),
res&&React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},lista.length," jogo(s)",dups?` · ${dups} cadastrado(s) em duplicidade`:''),
casasDe&&React.createElement("div",{onClick:()=>setCasasDe(null),style:{position:'fixed',inset:0,background:'rgba(0,0,0,.35)',zIndex:60,display:'flex',alignItems:'center',justifyContent:'center',padding:16}},
React.createElement("div",{onClick:(e)=>e.stopPropagation(),style:{background:'var(--surface,#fff)',borderRadius:12,padding:'16px 18px',maxWidth:760,width:'100%',maxHeight:'85vh',overflow:'auto'}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',gap:10,alignItems:'baseline'}},React.createElement("b",{style:{fontSize:15}},casasDe.casa," x ",casasDe.fora),React.createElement("button",{className:"btn-sm",onClick:()=>setCasasDe(null)},"Fechar")),
casas&&casas.jogo&&React.createElement("div",{style:{display:'flex',gap:10,alignItems:'center',flexWrap:'wrap',marginTop:6,fontSize:13}},"Hora do jogo: ",React.createElement("b",null,fusoSP.fmtSP(casas.jogo.kickoff_utc))," ",React.createElement("span",{style:{color:'var(--on-surface-variant)',fontSize:12}},"(São Paulo)"),React.createElement("button",{className:"btn-sm",onClick:mudaHora},"Hora…")),
casas&&casas.jogo&&horaEd&&React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap',marginTop:6,fontSize:13,padding:'8px 10px',border:'1px solid var(--outline-variant,#ccc)',borderRadius:8}},
!horaEd.data?React.createElement(React.Fragment,null,"Nova hora (São Paulo, dia/mês hora, ex.: 08/10 20:05 — confira na fonte oficial):",
React.createElement("input",{value:horaEd.texto,autoFocus:true,onChange:(e)=>setHoraEd({texto:e.target.value,data:null}),onKeyDown:(e)=>{if(e.key==='Enter')confereHora();},style:{width:120}}),
React.createElement("button",{className:"btn-sm",onClick:confereHora},"Conferir"),React.createElement("button",{className:"btn-sm",onClick:()=>setHoraEd(null)},"Voltar")):
React.createElement(React.Fragment,null,"Mudar a hora do jogo para ",React.createElement("b",null,fusoSP.fmtSP(horaEd.data))," (São Paulo)? Vale para o crawler, o coletor e as partidas de props deste jogo; fontes que continuarem na hora antiga seguem neste mesmo jogo.",
React.createElement("button",{className:"btn-sm",autoFocus:true,onClick:gravaHora},"Confirmar"),React.createElement("button",{className:"btn-sm",onClick:()=>setHoraEd({...horaEd,data:null})},"Voltar"))
),
casas&&!!(casas.horasPorGente||[]).length&&React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginTop:4}},"Mudada por gente: ",(casas.horasPorGente||[]).map((h)=>`${h.antesSP} → ${h.depoisSP} (${h.por})`).join(' · ')),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',margin:'6px 0 10px'}},"Cada linha é uma fonte amarrada a este jogo, com o que ela mandou (horas de São Paulo). Se uma for de outro jogo, use ",React.createElement("b",null,"Não é este jogo"),": a amarração sai e não volta."),
msgJ&&React.createElement("div",{className:"toast"},msgJ),
!casas?React.createElement("div",null,"Carregando…"):casas.error?React.createElement("div",null,"❌ ",casas.error):React.createElement(React.Fragment,null,
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"O que mandou"),React.createElement("th",null,"Como"),React.createElement("th",null))),React.createElement("tbody",null,
(casas.casas||[]).map((c)=>React.createElement("tr",{key:c.source+c.external_id},
React.createElement("td",{className:"mono-sm"},c.source),
React.createElement("td",{style:{fontSize:12.5}},c.raw_home||'?'," x ",c.raw_away||'?',c.raw_kickoff?React.createElement("span",{className:"mono-sm",style:{color:'var(--on-surface-variant)'}}," · ",fusoSP.fmtSP(c.raw_kickoff)):''),
React.createElement("td",{style:{fontSize:12}},c.created_by==='human'?'você':c.created_by==='source'?'id da casa':'automático'),
React.createElement("td",null,React.createElement("button",{className:"btn-sm",onClick:()=>desamarra(c)},"Não é este jogo"))
)),
!(casas.casas||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:4,style:{color:'var(--on-surface-variant)'}},"Nenhuma fonte amarrada por id."))
))),
!!(casas.partidas||[]).length&&React.createElement("div",{style:{fontSize:12.5,marginTop:10}},"Partidas do Player Props neste jogo: ",(casas.partidas||[]).map((m)=>`${m.home} x ${m.away}${m.league?' ('+m.league+')':''}${m.kickoff?' · '+fusoSP.fmtSP(m.kickoff):''}`).join(' · ')),
!!(casas.refs||[]).length&&React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginTop:6}},"Hora que cada fonte do coletor manda agora: ",(casas.refs||[]).map((r)=>`${r.source} ${r.kickoff?fusoSP.fmtSP(r.kickoff):'sem hora'}`).join(' · ')),
!!(casas.travas||[]).length&&React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginTop:8}},"Travadas fora deste jogo: ",(casas.travas||[]).map((t)=>t.source).join(', '))
)
)
),
React.createElement("div",{style:{overflowX:'auto'}},React.createElement("table",{className:"tbl",style:{fontSize:13}},
React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Quando"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Campeonato"),React.createElement("th",{style:{textAlign:'right'}},"Casas"),React.createElement("th",null,"Props"),React.createElement("th",null,"Pinnacle"),React.createElement("th",null),React.createElement("th",null))),
React.createElement("tbody",null,lista.map((j)=>React.createElement("tr",{key:j.id,style:j.duplicadoDe?{background:'#fff7ed'}:null},
React.createElement("td",{style:{whiteSpace:'nowrap'}},fmt(j.quando)),
React.createElement("td",null,React.createElement("b",null,j.casa)," x ",React.createElement("b",null,j.fora)," ",React.createElement("span",{className:"mono-sm",style:{color:'var(--on-surface-variant)',fontSize:11}},"#",j.id)),
React.createElement("td",null,j.campeonato||'—'),
React.createElement("td",{style:{textAlign:'right'}},j.casas),
React.createElement("td",null,j.props?'sim':'—'),
React.createElement("td",null,j.pinnacle?'sim':'—'),
React.createElement("td",null,j.duplicadoDe?React.createElement("span",{style:{color:'#b45309',fontWeight:600}},"mesmo jogo que #",j.duplicadoDe):''),
React.createElement("td",null,j.er_id?React.createElement("button",{className:"btn-sm",onClick:()=>abreCasas(j)},"Quem está aqui"):'')
)))
))
);
}






const ROTULO_STATUS=(s)=>({merged:'fundido'})[String(s||'')]||'';
const comPonto=(x)=>x?' · '+x:'';
const TIPO_ROTULO={jogador:'Jogador',numero_selecao_clube:'Número no cadastro errado',selecao_e_clube:'Seleção e clube',mercado_conflito:'Mercado em conflito',grafia_repetida:'Nome repetido na fonte',jogador_dois_lados:'Jogador nos dois times',evento:'Jogo',duplicado:'Time duplicado',mercado:'Mercado sem vínculo',mercado_jogo:'Mercado de jogo',liga_duplicada:'Liga duplicada',liga_misturada:'Liga misturada',esporte:'Esporte sem cadastro',liga_solta:'Liga sem cadastro',liga_sem_catalogo:'Liga fora do catálogo',liga_invadida:'Jogo na liga de outro país',id_provedor:'Número de provedor',esporte_da_liga:'Esporte da liga não bate',fusao_sem_prova:'Juntados sem prova',hora_jogo:'Hora do jogo',pinnacle_sem_traducao:'Pinnacle sem tradução',casa_sem_leitura:'Casa sem leitura'};
const TIPO_COR={jogador:'#8a5410',evento:'#3c4f8a',duplicado:'#1c6b52',mercado:'#6b4a7a',mercado_jogo:'#4a5a8a',liga_duplicada:'#2f6f8f',liga_misturada:'#a3402a',esporte:'#5a6b1c',liga_solta:'#8a5a10',liga_sem_catalogo:'#7a3f6b',liga_invadida:'#a3402a',id_provedor:'#5b3f8a',pinnacle_sem_traducao:'#b0471c',casa_sem_leitura:'#9a5b13'};

function contaFila(fila,resolvidos){
const porTipo={};let total=0;
for(const c of fila&&fila.casos||[]){if(resolvidos&&resolvidos[c.chave])continue;total++;porTipo[c.tipo]=(porTipo[c.tipo]||0)+1;}
return{total,porTipo};
}
function FilaSection({fila,recarregar,onClose,resolvidos,setResolvidos}){
const[busy,setBusy]=useState('');

const recarregarDepois=()=>{setTimeout(()=>{try{recarregar();}catch(e){}},1200);};
const[msg,setMsg]=useState('');
const[desf,setDesf]=useState(null);


const confirma=(texto,opcoes)=>{setMsg('');setDesf(null);return window.confirma(texto,opcoes);};
const[filtro,setFiltro]=useRota('fr','');
const[verJog,setVerJog]=useState(null),[jogs,setJogs]=useState(null),[qJog,setQJog]=useState('');
const[selJ,setSelJ]=useState({}),[princJ,setPrincJ]=useState('');
const[criar,setCriar]=useState(null);
const[dupVer,setDupVer]=useState(null);
const[ligaVer,setLigaVer]=useState(null);
const abrirDup=async(c)=>{setDupVer({caso:c,dados:null});
try{const ids=c.chave.split(':').slice(1);
const ds=await Promise.all(ids.map((id)=>fetch('/api/admin/er/entidade/'+id,{credentials:'include'}).then((r)=>r.json())));
setDupVer((v)=>v&&v.caso.chave===c.chave?{...v,dados:ds}:v);}
catch(e){setDupVer((v)=>v&&v.caso.chave===c.chave?{...v,dados:{erro:e.message}}:v);}};
const abrirCriar=async(c)=>{setCriar({caso:c,nome:c.titulo,tipo:'contagem',ehLinha:false,base:'',linha:'',cat:null});
try{const r=await fetch('/api/admin/mercados/props',{credentials:'include'});const d=await r.json();setCriar((k)=>k&&k.caso.chave===c.chave?{...k,cat:d.catalogo||[]}:k);}catch(e){}};


const acaoEsporte=async(c,code)=>{setBusy(c.chave);setMsg('');
try{const r=await fetch('/api/admin/er/cadastros/esporte/apelido',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({grafia:c.grafia,esporte:code||null})});
const j=await r.json();setMsg(r.ok?'\u2705 '+j.msg:'\u274c '+(j.error||'Erro'));if(r.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('\u274c '+e.message);}finally{setBusy('');}};

const criaEsporte=async(c)=>{
const nome=await pergunta('Nome do esporte novo (como vai aparecer nas telas):',c.titulo||c.grafia||'');if(!nome||!nome.trim())return;
const individual=await confirma('"'+nome.trim()+'" é disputado um contra um (tênis, luta, x1)?',{sim:'Individual (um contra um)',nao:'Coletivo (times)'});
const code=nome.normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'').slice(0,32);
setBusy(c.chave);setMsg('');
try{const r=await fetch('/api/admin/er/cadastros/esporte/novo',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({code,nome:nome.trim(),tipo:individual?'individual':'coletivo',grafia:c.grafia})});
const j=await r.json();setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};


const acaoFusao=async(c,acao)=>{setBusy(c.chave);setMsg('');
try{const r=await fetch('/api/admin/er/fusoes/'+c.fusao.diario+'/'+acao,{method:'POST',credentials:'include'});const j=await r.json();
setMsg(r.ok?'✅ '+(j.msg||'feito'):'❌ '+(j.error||'Erro'));if(r.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
const acaoMoverJogos=async(c,liga)=>{if(!liga||!liga.id)return;setBusy(c.chave);setMsg('');
try{const r=await fetch('/api/admin/er/jogos/liga',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:c.jogosIds||[],liga_id:liga.id})});
const j=await r.json();setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};



const textoJuntar=(de,para,tipoNome)=>'Juntar '+de+' dentro de '+para+'?\n\nOs apelidos e os jogos do primeiro passam para o '+(tipoNome||'segundo cadastro')+'. A fusão fica registrada e pode ser desfeita em "Clubes e jogadores juntados", no topo da guia Identidades.';
const rotuloLado=(l)=>l?'"'+(l.nome||l.display_name||'#'+l.id)+'" (#'+l.id+(l.jogos!=null?', '+l.jogos+' jogo(s)':'')+(l.pais?', '+l.pais:'')+')':'?';
const acaoIdProvedor=async(c,acao,numero)=>{
if(acao==='tirar'&&!(await confirma('Tirar o número '+numero+' de "'+c.idProvedor.alvo.nome+'"? Ele não volta sozinho.')))return;

const ip=c.idProvedor,num=(ip.numeros||[]).find((x)=>String(x.numero)===String(numero));
if(acao==='executar'&&ip.acao==='juntar'&&!(await confirma(textoJuntar((ip.lados||[]).length?'os cadastros '+(ip.lados||[]).map(rotuloLado).join(', '):'os cadastros com o número '+ip.provedor,ip.fica?'#'+ip.fica:'um só'))))return;
if(acao==='confirmar'&&num&&num.jaDe&&!(await confirma(textoJuntar('"'+ip.alvo.nome+'" (#'+ip.alvo.id+')','o cadastro #'+num.jaDe+', que já tem o número '+num.numero+' ('+(num.nome||num.nomeDaCasa||'')+')')+'\n\nOs outros números saem deste cadastro.')))return;
setBusy(c.chave);setMsg('');
try{const r=await fetch('/api/admin/er/provedores/decidir',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({chave:c.chave,acao,numero})});
const j=await r.json();setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
const acaoCriarManual=async(c)=>{const nome=await pergunta('Nome da liga manual (como deve aparecer no Odds Radar):',c.nomeSugerido||c.rotulo);if(!nome)return;setBusy(c.chave);setMsg('');
try{const r=await fetch('/api/admin/er/competicoes/criar-manual',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({esporte:c.sportSolto,nome,rotulo:c.rotulo,fontes:(c.fontesDetalhe||[]).map((f)=>f.fonte),...(c.areaCode?{area_code:c.areaCode}:{})})});
const j=await r.json();

if(r.ok&&j.id&&(c.grafias||[]).length>1)await ligaGrafias({...c,grafias:c.grafias.slice(1)},j.id);
setMsg(r.ok?'\u2705 '+j.msg:'\u274c '+(j.error||'Erro'));if(r.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('\u274c '+e.message);}finally{setBusy('');}};

const acaoEsporteDaLiga=async(c,esporte)=>{setBusy(c.chave);setMsg('');
try{const r=await fetch('/api/admin/er/esporte-da-liga',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({competicao:c.incongruencia.competicao,esporte:esporte||''})});
const j=await r.json();setMsg(r.ok?'\u2705 '+j.msg:'\u274c '+(j.error||'Erro'));if(r.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('\u274c '+e.message);}finally{setBusy('');}};

const grafiasDoCartao=(c)=>c.grafias&&c.grafias.length?c.grafias:[{rotulo:c.rotulo,sport:c.sportSolto,fontes:(c.fontesDetalhe||[]).map((f)=>f.fonte)}];
const ligaGrafias=async(c,ligaId)=>{const falhas=[];let ultima='';
for(const g of grafiasDoCartao(c)){
const r=await fetch('/api/admin/er/competicoes/ligar-fonte',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({competicao_id:ligaId,rotulo:g.rotulo,sport:g.sport||c.sportSolto,fontes:g.fontes})});
const j=await r.json().catch(()=>({}));if(r.ok)ultima=j.msg||'';else falhas.push(g.rotulo+': '+(j.error||'erro'));}
return{falhas,ultima};};


const textoLigar=(c,liga)=>{const gs=grafiasDoCartao(c);return(gs.length>1?'Ligar as '+gs.length+' grafias deste torneio':'Ligar "'+semIdLiga(gs[0].rotulo)+'"')+
' ('+[...new Set(gs.flatMap((g)=>g.fontes||[]))].join(', ')+') à liga "'+(liga.display_name||liga.nome||'#'+liga.id)+'"'+(liga.area_nome?' ('+liga.area_nome+')':'')+'?\n\n'+(
gs.length>1?gs.map((g)=>'• '+semIdLiga(g.rotulo)).join('\n')+'\n\n':'')+'Os jogos sem liga com essa grafia entram nela agora. Se o nome não for de vários países, a grafia passa a valer para todas as fontes. Dá para desfazer pelo × da grafia na aba Ligas.';};
const acaoLigarGrafia=async(c,liga)=>{if(!liga||!liga.id)return;if(!(await confirma(textoLigar(c,liga))))return;setBusy(c.chave);setMsg('');
try{const{falhas,ultima}=await ligaGrafias(c,liga.id);const n=grafiasDoCartao(c).length;
setMsg(falhas.length?'❌ '+falhas.join(' · '):'✅ '+(n>1?n+' grafias ligadas. ':'')+ultima);
if(!falhas.length){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};



const acaoMoverGrafia=async(c,rotulo,liga)=>{if(!liga||!liga.id)return;setBusy(c.chave+rotulo);setMsg('');
try{const r=await fetch('/api/admin/er/competicoes/mover-grafia',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({de:c.ligaId,rotulo,destino_id:liga.id})});
const j=await r.json().catch(()=>({}));
setMsg(r.ok?'\u2705 '+(j.msg||'Jogos movidos.'):'\u274c '+(j.error||'Erro'));
if(r.ok)recarregar();}
catch(e){setMsg('\u274c '+e.message);}finally{setBusy('');}};
const acaoNaoEhLiga=async(c)=>{if(!(await confirma('"'+grafiasDoCartao(c).map((g)=>semIdLiga(g.rotulo)).join('", "')+'" não é liga? Some da lista.')))return;setBusy(c.chave);setMsg('');
try{let r,j;for(const g of grafiasDoCartao(c)){r=await fetch('/api/admin/er/competicoes/ignorar-grafia',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({rotulo:g.rotulo,sport:g.sport||c.sportSolto})});
j=await r.json();if(!r.ok)break;}
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};


const acaoLigarCatalogo=async(c,opt)=>{if(!opt)return;setBusy(c.chave);setMsg('');
try{const r=await fetch('/api/admin/er/competicoes/ligar-catalogo',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({id:c.ligaId,fonte:opt.fonte,fonte_id:opt.fonte_id})});
const j=await r.json().catch(()=>({}));
if(r.ok){setMsg('\u2705 '+(j.msg||'Ligada ao cat\u00e1logo.'));recarregar();return;}
if(j.dono_id){

if(!(await confirma(`O n\u00famero do cat\u00e1logo j\u00e1 \u00e9 de "${j.dono_nome}". Juntar "${c.titulo||'#'+c.ligaId}" dentro de "${j.dono_nome}"?\n\nOs jogos e os apelidos de time passam para "${j.dono_nome}", e o nome da primeira vira apelido dela.`))){setMsg('Nada gravado: as duas ligas continuam separadas.');return;}
const f=await fetch('/api/admin/er/competicoes/fundir',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({de:c.ligaId,para:j.dono_id})});
const jf=await f.json().catch(()=>({}));
setMsg(f.ok?`\u2705 Juntada em "${j.dono_nome}". ${jf.msg||''}`:'\u274c '+(jf.error||'Erro'));
if(f.ok){setResolvidos((v)=>({...v,[c.chave]:1}));recarregarDepois();}return;
}
setMsg('\u274c '+(j.error||'Erro'));}
catch(e){setMsg('\u274c '+e.message);}finally{setBusy('');}};
const semAc=(s)=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const abrirJog=async(c)=>{setVerJog(c);setJogs(null);setQJog('');setSelJ({});setPrincJ('');
try{const r=await fetch(`/api/admin/er/partida/${c.evento}/jogadores`,{credentials:'include'});const d=await r.json();setJogs(r.ok?d:{error:d.error||'Erro'});}
catch(e){setJogs({error:e.message});}};

const juntarSel=async()=>{const ids=Object.keys(selJ).filter((k)=>selJ[k]).map(Number);const para=Number(princJ||ids[0]);
const marcados=(jogs&&jogs.jogadores||[]).filter((p)=>ids.includes(Number(p.id)));const fica=marcados.find((p)=>Number(p.id)===para);
if(ids.length<2||!fica)return;
if(!(await confirma(`Juntar ${ids.length} cadastros em "${fica.nome}"?\n\n`+marcados.filter((p)=>Number(p.id)!==para).map((p)=>'• '+p.nome).join('\n')+'\n\nApelidos, presenças e odds passam para o que fica. A fusão fica registrada e pode ser desfeita em Identidades, \"Clubes e jogadores juntados\".')))return;
setBusy('juntar');setMsg('');let ok=0;const erros=[];
for(const id of ids){if(id===para)continue;
try{const r=await fetch('/api/admin/er/fundir',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({de:id,para})});const j=await r.json();if(r.ok)ok++;else erros.push(j.error||'erro');}
catch(e){erros.push(e.message);}}
setBusy('');setMsg(erros.length?`❌ ${ok} juntado(s), ${erros.length} com erro: ${erros.join(' | ')}`:`✅ ${ok} cadastro(s) juntado(s) em "${fica.nome}". O cartão sai no próximo ciclo.`);
if(verJog)abrirJog(verJog);recarregar();};
const agir=async(caso,acao,alvo)=>{
if(caso.tipo==='duplicado'&&acao==='escolher'){
const lados=caso.lados||[],para=lados.find((l)=>Number(l.id)===Number(alvo)),de=lados.find((l)=>Number(l.id)!==Number(alvo));
if(!(await confirma(de&&para?textoJuntar(rotuloLado(de),rotuloLado(para),'segundo clube'):textoJuntar('os dois cadastros de "'+caso.titulo+'"','#'+alvo))))return;
}
setBusy(caso.chave);setMsg('');
try{
const r=await fetch('/api/admin/fila/acao',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({chave:caso.chave,ids:caso.ids,acao,alvo})});
const d=await r.json();
setMsg(r.ok?'✅ '+(d.msg||'Feito.'):'❌ '+(d.error||'Erro'));
setDesf(r.ok&&d.desfazer?d.desfazer:null);

if(r.ok){setResolvidos((v)=>({...v,[caso.chave]:1}));recarregarDepois();setTimeout(()=>{try{recarregar();}catch(e){}},20000);}else
recarregar();
}catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}
};
if(fila===null)return React.createElement("div",{style:{textAlign:'center',padding:48,color:'var(--on-surface-variant)'}},"Carregando…");
const fmt=(x)=>{if(!x)return null;const t=new Date(x);return isNaN(t.getTime())?null:t.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});};
const casos=(fila.casos||[]).filter((c)=>(!filtro||c.tipo===filtro)&&!resolvidos[c.chave]);
const conta=contaFila(fila,resolvidos);
const tipos=Object.entries(conta.porTipo);
if(!conta.total)return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg,desf&&React.createElement("button",{className:"btn-sm",style:{marginLeft:10},onClick:async()=>{const x=desf;setDesf(null);try{const r=await fetch(x.url,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(x.body)});const j=await r.json();setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));recarregar();}catch(e){setMsg('❌ '+e.message);}}},desf.rotulo||'Desfazer')),
React.createElement("div",{className:"empty",style:{padding:48}},React.createElement("div",{className:"em-ic"},React.createElement(Ic,{n:"task_alt"})),
React.createElement("div",{className:"em-t"},"Nada esperando por você"),
React.createElement("div",null,"Quando o sistema não conseguir decidir sozinho — dois jogadores no mesmo nome, um jogo que não casou, um clube cadastrado duas vezes — o caso aparece aqui."))
);
return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg,desf&&React.createElement("button",{className:"btn-sm",style:{marginLeft:10},onClick:async()=>{const x=desf;setDesf(null);try{const r=await fetch(x.url,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(x.body)});const j=await r.json();setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));recarregar();}catch(e){setMsg('❌ '+e.message);}}},desf.rotulo||'Desfazer')),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:12}},"Cada cartão é uma decisão. Sua resposta vira permanente — o automático não contesta mais.",
fila&&fila.guardadosSemDemanda&&fila.guardadosSemDemanda.id_provedor>0&&React.createElement("span",{title:"Só sobe cartão de time ou jogador com jogo nos próximos 7 dias em que exista odd de jogador ativa ou Super Odd. O resto volta sozinho quando tiver."}," · ",fila.guardadosSemDemanda.id_provedor," cartão(ões) de número guardado(s): o time ou jogador não tem jogo com odd à vista.")),
fila&&(fila.lentas||[]).length>0&&React.createElement("div",{style:{fontSize:12,color:'#a3402a',marginBottom:10},title:"Etapas do cálculo da fila acima de 1,5 s. A tela não espera o recálculo, mas a lista demora a se atualizar depois de cada decisão."},"Fila calculada em ",
Math.round((fila.totalMs||0)/100)/10," s — etapa lenta: ",fila.lentas.map((l)=>l.etapa+' '+Math.round(l.ms/100)/10+' s').join(', ')),
tipos.length>1&&React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',marginBottom:14}},
React.createElement("button",{className:"btn-sm"+(filtro===''?' b-green':''),onClick:()=>setFiltro('')},"Tudo (",conta.total,")"),
tipos.map(([t,q])=>React.createElement("button",{key:t,className:"btn-sm"+(filtro===t?' b-green':''),onClick:()=>setFiltro(t)},TIPO_ROTULO[t]||t," (",q,")"))
),
criar&&React.createElement("div",{onClick:()=>setCriar(null),style:{position:'fixed',inset:0,background:'rgba(0,0,0,.35)',zIndex:60,display:'flex',alignItems:'center',justifyContent:'center',padding:16}},
React.createElement("div",{onClick:(e)=>e.stopPropagation(),role:"dialog","aria-label":"Criar mercado",style:{background:'#fff',borderRadius:12,padding:18,width:'min(560px,100%)',maxHeight:'85vh',overflowY:'auto',display:'flex',flexDirection:'column',gap:10}},
React.createElement("b",{style:{fontSize:15}},"Criar mercado para \"",criar.caso.titulo,"\""),
React.createElement("label",{style:{display:'flex',flexDirection:'column',gap:4,fontSize:12.5,color:'var(--on-surface-variant)'}},"Nome na tela de props",
React.createElement("input",{value:criar.nome,onChange:(e)=>setCriar({...criar,nome:e.target.value}),style:{padding:'8px 10px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:13.5,color:'inherit'}})),
React.createElement("label",{style:{display:'flex',gap:8,alignItems:'flex-start',fontSize:13}},
React.createElement("input",{type:"checkbox",checked:criar.ehLinha,onChange:(e)=>setCriar({...criar,ehLinha:e.target.checked}),style:{marginTop:3}}),
React.createElement("span",null,"É uma ",React.createElement("b",null,"linha fixa")," de um mercado que já existe. Ex.: \"Anytime\" é Gols 0,5, \"Marcar 2 ou mais\" é Gols 1,5.")),
criar.ehLinha?React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}},
React.createElement("select",{value:criar.base,onChange:(e)=>setCriar({...criar,base:e.target.value}),style:{padding:'7px 8px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:13}},
React.createElement("option",{value:""},criar.cat===null?'carregando…':'mercado base…'),
(criar.cat||[]).filter((k)=>k.tipo==='contagem'&&!k.base).map((k)=>React.createElement("option",{key:k.code,value:k.code},k.nome))
),
React.createElement("span",{style:{fontSize:13}},"acima de"),
React.createElement("input",{value:criar.linha,onChange:(e)=>setCriar({...criar,linha:e.target.value}),placeholder:"0,5",style:{width:80,padding:'7px 8px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:13}})
):
React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:6}},
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"Que tipo de aposta é?"),
[['contagem','Contagem com linha','chutes, cartões, gols: tem "acima de 0,5 / 1,5". Um "sim" de outra casa vira acima de 0,5.'],['sim_nao','Sim ou não','não é contagem de nada.'],['ordem','Ordem','primeiro ou último a fazer algo.'],['combinado','Combinado','soma de duas estatísticas, como marca ou assiste.']].map(([v,t,d])=>
React.createElement("label",{key:v,style:{display:'flex',gap:8,alignItems:'flex-start',fontSize:13}},
React.createElement("input",{type:"radio",name:"tipoMercadoNovo",checked:criar.tipo===v,onChange:()=>setCriar({...criar,tipo:v}),style:{marginTop:3}}),
React.createElement("span",null,React.createElement("b",null,t),": ",React.createElement("span",{style:{color:'var(--on-surface-variant)'}},d))))
),
React.createElement("div",{style:{display:'flex',gap:8,justifyContent:'flex-end'}},
React.createElement("button",{className:"btn-sm",onClick:()=>setCriar(null)},"Cancelar"),
React.createElement("button",{className:"btn-sm b-green",disabled:!criar.nome||criar.ehLinha&&(!criar.base||!criar.linha)||busy===criar.caso.chave,
onClick:()=>{const k=criar;setCriar(null);agir(k.caso,'criar',{nome:k.nome,tipo:k.ehLinha?'contagem':k.tipo,base:k.ehLinha?k.base:null,linha:k.ehLinha?k.linha:null});}},"Criar mercado")
)
)
),
ligaVer&&React.createElement(LigaConteudoModal,{ids:ligaVer.ids,titulo:ligaVer.caso.titulo,onClose:()=>setLigaVer(null),onFeito:(m)=>{setMsg(m);setLigaVer(null);recarregar();}}),
dupVer&&React.createElement("div",{onClick:()=>setDupVer(null),style:{position:'fixed',inset:0,background:'rgba(0,0,0,.35)',zIndex:60,display:'flex',alignItems:'center',justifyContent:'center',padding:16}},
React.createElement("div",{onClick:(e)=>e.stopPropagation(),role:"dialog","aria-label":"Comparar cadastros",style:{background:'#fff',borderRadius:12,padding:18,width:'min(980px,100%)',maxHeight:'88vh',overflowY:'auto',display:'flex',flexDirection:'column',gap:10}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'baseline',gap:10}},
React.createElement("b",{style:{fontSize:15}},dupVer.caso.titulo),
React.createElement("button",{className:"btn-sm",onClick:()=>setDupVer(null)},"Fechar")
),
dupVer.caso.causa&&React.createElement("div",{style:{fontSize:12.5,padding:'6px 10px',borderRadius:8,background:'rgba(180,120,20,.08)'}},dupVer.caso.causa),
dupVer.dados===null?React.createElement("span",{style:{fontSize:13}},"Carregando…"):dupVer.dados.erro?React.createElement("span",{style:{fontSize:13}},"❌ ",dupVer.dados.erro):
React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))',gap:12}},
dupVer.dados.map((d,i)=>{const e=d.entidade||{};return React.createElement("div",{key:i,style:{border:'1px solid var(--line-2)',borderRadius:10,padding:10,display:'flex',flexDirection:'column',gap:6,minWidth:0}},
React.createElement("div",null,React.createElement("b",null,i===0?'Sai':'Fica',": ",e.display_name)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",e.id)),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},e.sport||'—'," · ",escolhaEntidade.paisMostrado(e)||'país ?',comPonto(ROTULO_STATUS(e.status)),e.legacy_id?` · legado #${e.legacy_id}`:''),
(d.ids||[]).length>0&&React.createElement("div",{style:{fontSize:12}},"ids das fontes: ",(d.ids||[]).map((x)=>`${x.source} ${x.external_id}${x.raw_name?' ('+x.raw_name+')':''}`).join(' · ')),
React.createElement("div",{style:{fontSize:11.5,fontWeight:700,textTransform:'uppercase',color:'var(--on-surface-variant)',marginTop:4}},"Jogos (",(d.jogos||[]).length,")"),
React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:2,maxHeight:260,overflowY:'auto',fontSize:12.5}},
(d.jogos||[]).slice(0,40).map((j)=>React.createElement("div",{key:j.id,style:{display:'flex',gap:8}},React.createElement("span",{className:"mono-sm",style:{whiteSpace:'nowrap',color:'var(--on-surface-variant)'}},String(j.kickoff_utc||'').slice(0,16).replace('T',' ')),React.createElement("span",null,j.home," x ",j.away,j.competicao&&React.createElement("span",{style:{color:'var(--on-surface-variant)'}}," · ",j.competicao)))),
!(d.jogos||[]).length&&React.createElement("span",{style:{color:'var(--on-surface-variant)'}},"nenhum jogo")
),
React.createElement("div",{style:{fontSize:11.5,fontWeight:700,textTransform:'uppercase',color:'var(--on-surface-variant)',marginTop:4}},"Grafias e escopos"),
React.createElement("div",{style:{fontSize:12,display:'flex',flexDirection:'column',gap:1,maxHeight:140,overflowY:'auto'}},
(d.apelidos||[]).slice(0,30).map((a,k)=>React.createElement("div",{key:k},React.createElement("span",null,a.alias_norm)," ",React.createElement("span",{className:"mono-sm",style:{color:'var(--on-surface-variant)',fontSize:11}},a.scope_key," · ",a.source||a.created_by)))
)
);})
)
)
),
verJog&&React.createElement("div",{onClick:()=>setVerJog(null),style:{position:'fixed',inset:0,background:'rgba(0,0,0,.35)',zIndex:60,display:'flex',alignItems:'center',justifyContent:'center',padding:16}},
React.createElement("div",{onClick:(e)=>e.stopPropagation(),role:"dialog","aria-label":"Jogadores da partida",style:{background:'#fff',borderRadius:12,padding:18,width:'min(540px,100%)',maxHeight:'80vh',display:'flex',flexDirection:'column',gap:10}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'baseline',gap:10}},
React.createElement("b",{style:{fontSize:15}},"Quem é \"",verJog.titulo,"\"?"),
React.createElement("button",{className:"btn-sm",onClick:()=>setVerJog(null)},"Fechar")
),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"Jogadores já vistos em ",verJog.onde,". Clique no certo para vincular. Se dois ou mais cadastros forem a mesma pessoa, marque-os e use ",React.createElement("b",null,"Juntar"),"."),
React.createElement("input",{value:qJog,onChange:(e)=>setQJog(e.target.value),placeholder:"filtrar por nome…",autoFocus:true,style:{padding:'8px 10px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:13.5}}),
React.createElement("div",{style:{overflowY:'auto',display:'flex',flexDirection:'column',gap:4,minHeight:80}},
jogs===null?React.createElement("span",{style:{fontSize:13}},"Carregando…"):
jogs.error?React.createElement("span",{style:{fontSize:13}},"❌ ",jogs.error):
(jogs.jogadores||[]).filter((p)=>!qJog||semAc(p.nome).includes(semAc(qJog))).map((p)=>
React.createElement("div",{key:p.id,style:{display:'flex',gap:8,alignItems:'center'}},
React.createElement("input",{type:"checkbox","aria-label":'marcar '+p.nome,checked:!!selJ[p.id],onChange:(e)=>setSelJ((x)=>({...x,[p.id]:e.target.checked}))}),
React.createElement("button",{className:"btn-sm",style:{textAlign:'left',justifyContent:'flex-start',flex:1},disabled:busy===verJog.chave,
onClick:()=>{const c=verJog;setVerJog(null);agir(c,'escolher',p.id);}},p.nome,p.time?` · ${p.time}`:''," ",React.createElement("span",{className:"mono-sm",style:{fontSize:10.5,color:'var(--on-surface-variant)'}},"#",p.id))
)),
jogs&&!jogs.error&&!(jogs.jogadores||[]).length&&React.createElement("span",{style:{fontSize:13}},"Nenhum jogador registrado nesta partida ainda.")
),
(()=>{const ids=Object.keys(selJ).filter((k)=>selJ[k]);if(ids.length<2||!jogs||jogs.error)return null;const marcados=(jogs.jogadores||[]).filter((p)=>ids.includes(String(p.id)));
return React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap',borderTop:'1px solid var(--line-2)',paddingTop:10}},
React.createElement("span",{style:{fontSize:13}},"Juntar ",ids.length," marcados, ficando"),
React.createElement("select",{value:princJ||ids[0],onChange:(e)=>setPrincJ(e.target.value)},marcados.map((p)=>React.createElement("option",{key:p.id,value:p.id},p.nome,p.time?` · ${p.time}`:''))),
React.createElement("button",{className:"btn-sm b-green",disabled:busy==='juntar',onClick:juntarSel},"Juntar")
);})()
)
),
React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:10}},
casos.map((c)=>React.createElement("div",{key:c.chave,style:{background:'#fff',border:'1px solid var(--line-2)',borderLeft:'4px solid '+(TIPO_COR[c.tipo]||'var(--line-2)'),borderRadius:10,padding:'14px 16px'}},
React.createElement("div",{style:{display:'flex',gap:10,flexWrap:'wrap',alignItems:'baseline',marginBottom:4}},
React.createElement("span",{className:"pill",style:{background:(TIPO_COR[c.tipo]||'#666')+'18',color:TIPO_COR[c.tipo]||'inherit',fontWeight:600}},TIPO_ROTULO[c.tipo]||c.tipo,c.tipo==='mercado'&&c.alvo?c.alvo==='jogador'?' · de jogador':' · de jogo':''),
React.createElement("b",{style:{fontSize:16}},c.titulo),
c.legado&&React.createElement("span",{className:"mono-sm",style:{color:'var(--on-surface-variant)',fontSize:11}},"fila antiga")
),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:10}},
c.onde,(c.fontes||[]).length?` · ${c.fontes.length>2?c.fontes.length+' casas':c.fontes.join(', ')}`:'',fmt(c.quando)?` · ${fmt(c.quando)}`:''
),
React.createElement("div",{style:{fontSize:13.5,marginBottom:c.evidencia?4:8}},c.pergunta),
c.evidencia&&React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},c.tipo==='id_provedor'&&c.idProvedor&&!['jogador_numeros','time_numeros'].includes(c.idProvedor.acao)?React.createElement("b",null,c.idProvedor.auto?'O que o sistema concluiu: ':'Por que o sistema não decidiu sozinho: '):null,c.evidencia),
(c.tipo==='liga_solta'||c.tipo==='mercado')&&(c.grafias||[]).length>0&&React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)',marginBottom:6},title:"O número entre parênteses ou colchetes é o id naquela casa: serve de chave do vínculo, não faz parte do nome."},"Como cada casa escreve: ",
c.grafias.map((g,i)=>React.createElement("span",{key:i},i>0?' · ':'',React.createElement("b",null,(g.fontes||[]).join(', '))," “",semIdLiga(g.rotulo),"”"))
),


c.tipo!=='liga_misturada'&&(c.jogosLista||[]).length>0&&React.createElement("div",{style:{fontSize:12.5,border:'1px solid var(--line-2)',borderRadius:8,padding:'6px 10px',marginBottom:8,display:'flex',flexDirection:'column',gap:2}},
c.jogosLista.map((j,i)=>React.createElement("div",{key:i},typeof j==='string'?j:j&&j.jogo||''))
),

c.tipo==='id_provedor'&&c.idProvedor&&React.createElement("div",{style:{fontSize:12.5,border:'1px solid var(--line-2)',borderRadius:8,padding:'6px 10px',marginBottom:8}},


c.idProvedor.tipo==='jogador'&&c.idProvedor.jogosMarcados?
React.createElement(React.Fragment,null,
React.createElement("div",{style:{fontWeight:600,marginBottom:2}},
c.idProvedor.modo==='separar'?React.createElement("span",{style:{color:'#b45309'}},"Este cadastro tem jogos de mais de uma pessoa. "):null,"Jogos com odd neste cadastro",
c.idProvedor.nPresencas>c.idProvedor.jogosMarcados.length?' (os '+c.idProvedor.jogosMarcados.length+' mais recentes de '+c.idProvedor.nPresencas+')':''," e de quem é cada um, pelo clube da ficha:"
),
c.idProvedor.jogosMarcados.map((j,i)=>React.createElement("div",{key:i,style:{color:'var(--on-surface-variant)'}},j.texto,j.de?React.createElement("b",{style:{color:'#1d4ed8'}}," → ",j.de):React.createElement("span",{style:{opacity:.7}}," → sem clube de ficha (fica aqui)"))),
React.createElement("div",{style:{marginTop:4,color:'var(--on-surface-variant)'}},"Clube gravado no cadastro: ",React.createElement("b",null,c.idProvedor.clubeDoCadastro||'nenhum'),c.idProvedor.clubeForaDosJogos?React.createElement("span",{style:{color:'#b45309'}}," — não joga nenhum destes jogos"):null)
):
c.idProvedor.tipo==='jogador'?
React.createElement("div",{style:{fontWeight:600,marginBottom:2}},"No nosso cadastro, este jogador ",c.idProvedor.clubeDoCadastro?React.createElement(React.Fragment,null,"é do ",React.createElement("b",null,c.idProvedor.clubeDoCadastro)):'ainda não tem clube',(c.idProvedor.jogosDoCadastro||[]).length>0?' e apareceu com odd em:':'. Nenhum jogo gravado com ele.'):
React.createElement("div",{style:{fontWeight:600,marginBottom:2}},"No nosso cadastro",c.idProvedor.paisDoCadastro?' ('+c.idProvedor.paisDoCadastro+')':'',", este time ",(c.idProvedor.jogosDoCadastro||[]).length>0?'joga:':'não tem jogo gravado.'),
!(c.idProvedor.tipo==='jogador'&&c.idProvedor.jogosMarcados)&&(c.idProvedor.jogosDoCadastro||[]).map((j,i)=>React.createElement("div",{key:i,style:{color:'var(--on-surface-variant)'}},j))
),

c.tipo==='id_provedor'&&c.idProvedor&&React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(230px,1fr))',gap:8,marginBottom:8}},
c.idProvedor.numeros.map((n)=>React.createElement("div",{key:n.numero,style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'8px 10px',fontSize:12.5,background:c.idProvedor.fica===n.numero?'rgba(15,157,110,.06)':undefined}},
React.createElement("div",{style:{fontWeight:600,marginBottom:2}},n.nome||n.nomeDaCasa||'(sem nome no provedor)'," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",n.numero),c.idProvedor.fica===n.numero&&React.createElement("span",{style:{marginLeft:6,color:'#0a6b4c',fontSize:11}},"fica neste cadastro")),
n.completo&&n.completo!==n.nome&&React.createElement("div",{style:{color:'var(--on-surface-variant)'}},n.completo),
n.nomeDaCasa&&n.nomeDaCasa!==n.nome&&React.createElement("div",{style:{color:'var(--on-surface-variant)'}},"a casa escreveu: ",n.nomeDaCasa),

n.veredito&&React.createElement("div",{style:{marginTop:4,padding:'4px 7px',borderRadius:6,fontSize:12,background:n.veredito.acao==='fica'?'rgba(15,157,110,.10)':n.veredito.acao==='pessoa'?'rgba(180,83,9,.10)':'rgba(29,78,216,.08)',color:n.veredito.acao==='fica'?'#0a6b4c':n.veredito.acao==='pessoa'?'#b45309':'#1d4ed8'}},

React.createElement("b",null,(c.idProvedor.tipo==='jogador'?
{fica:'É o jogador deste cadastro',sai:'É outra pessoa'+(n.veredito.para?' → '+n.veredito.para:''),juntar:'É a mesma pessoa de '+n.veredito.com,separar:'É outra pessoa: '+(n.veredito.jogos!=null?n.veredito.jogos+' jogo(s) dela vão para ':'os jogos dela vão para ')+(n.veredito.para||'um cadastro novo'),pessoa:'O sistema não tem como saber',aguarda:'Esperando os dados do provedor'}:
{fica:'É o clube deste cadastro',sai:'É outro clube'+(n.veredito.para?' → '+n.veredito.para:''),juntar:'É o mesmo clube de '+n.veredito.com,separar:'É outro clube: os jogos dele vão para '+(n.veredito.para||'um cadastro novo'),pessoa:'O sistema não tem como saber',aguarda:'Esperando os dados do provedor'})[n.veredito.acao]||n.veredito.acao)," — ",n.veredito.motivo),
React.createElement("div",{style:{color:'var(--on-surface-variant)'}},[n.clube,n.nascimento?'nasc. '+n.nascimento.split('-').reverse().join('/'):null,n.sexo==='f'?'feminino':n.sexo==='m'&&!n.sufixo?'masculino · principal':null,n.sufixo].filter(Boolean).join(' · ')||(n.semFicha?'o provedor não devolveu ficha deste número':'sem ficha do provedor')),


(n.torneios||[]).length>0&&React.createElement("div",{style:{marginTop:3,color:'#1d4ed8'}},"no provedor joga: ",n.torneios.slice(0,4).join(' · '),n.torneios.length>4?' …':''),
n.ligasApi&&n.ligasApi.length>0&&React.createElement("div",{style:{marginTop:3,color:'#1d4ed8'}},"API-Football: ",n.ligasApi.slice(0,4).join(' · ')),
n.paisApi&&React.createElement("div",{style:{color:'var(--on-surface-variant)'}},"país no provedor: ",n.paisApi),
n.adversariosEmComum!=null&&React.createElement("div",{style:{color:n.adversariosEmComum?'#0a6b4c':'#b45309'}},n.adversariosEmComum?n.adversariosEmComum+' adversário(s) deste cadastro':'não joga contra nenhum adversário deste cadastro'),
React.createElement("div",{style:{color:'var(--on-surface-variant)'}},"veio de: ",(n.casas||[]).join(', '),n.jogos!=null?' · '+n.jogos+' jogo(s) do próprio clube':'')
))
),
c.tipo==='id_provedor'&&c.idProvedor&&(c.idProvedor.sai||[]).length>0&&React.createElement("div",{style:{fontSize:12.5,marginBottom:8,color:'var(--on-surface-variant)'}},"Plano: ",
c.idProvedor.sai.map((x)=>x.nome+' (#'+x.numero+') vira cadastro novo'+(x.clube?' em '+x.clube:'')+' com '+x.jogos+' jogo(s)').join('; '),"."),
c.tipo==='id_provedor'&&c.idProvedor&&c.idProvedor.lados&&React.createElement("div",{style:{fontSize:12.5,marginBottom:8,color:'var(--on-surface-variant)'}},"Cadastros: ",
c.idProvedor.lados.map((l)=>l.nome+' (#'+l.id+', '+l.jogos+' jogo(s)'+(l.id===c.idProvedor.fica?', fica':'')+')').join(' · ')),
c.tipo==='duplicado'&&c.lados&&React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:8,marginBottom:8}},
c.lados.map((l,i)=>React.createElement("div",{key:l.id,style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'8px 10px',fontSize:12.5}},
React.createElement("div",{style:{fontWeight:600,marginBottom:2}},i===0?'Sai':'Fica',": ",l.nome," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",l.id)),
React.createElement("div",{style:{color:'var(--on-surface-variant)'}},l.esporte||'—'," · ",l.pais||'país ?',comPonto(ROTULO_STATUS(l.status))," · ",l.jogos," jogo(s)"),
l.competicoes.length>0&&React.createElement("div",{style:{color:'var(--on-surface-variant)'}},"competições: ",l.competicoes.join(', '),l.totalCompeticoes>l.competicoes.length?` e mais ${l.totalCompeticoes-l.competicoes.length}`:''),
l.apiFootball&&React.createElement("div",{style:{color:'var(--on-surface-variant)'}},"API-Football: clube #",l.apiFootball)
))
),
c.tipo==='esporte_da_liga'&&c.incongruencia&&React.createElement("div",{style:{marginBottom:8}},
React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:8,marginBottom:8}},
React.createElement("div",{style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'8px 10px',fontSize:12.5}},
React.createElement("div",{style:{fontWeight:600}},c.incongruencia.esporteComp.cadastro?"A liga cadastrada é de":"O nome da competição diz"),
React.createElement("div",{style:{fontSize:14,margin:'2px 0'}},c.incongruencia.esporteComp.nome),
React.createElement("div",{style:{color:'var(--on-surface-variant)'}},"se for isto: os jogos desta competição e os cadastros que nasceram deles passam para este esporte")
),
React.createElement("div",{style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'8px 10px',fontSize:12.5}},
React.createElement("div",{style:{fontWeight:600}},"As casas mandam como"),
React.createElement("div",{style:{fontSize:14,margin:'2px 0'}},c.incongruencia.esporteCasa.nome),
React.createElement("div",{style:{color:'var(--on-surface-variant)'}},c.incongruencia.casas.join(', '))
)
),
(c.incongruencia.exemplos||[]).length>0&&React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"jogos: ",c.incongruencia.exemplos.join(' · '))
),
c.tipo==='duplicado'&&c.causa&&React.createElement("div",{style:{fontSize:12.5,marginBottom:8,padding:'6px 10px',borderRadius:8,background:'rgba(180,120,20,.08)'}},c.causa),
(c.tipo==='liga_duplicada'||c.tipo==='liga_misturada')&&c.ligas&&React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:8,marginBottom:8}},
c.ligas.map((l)=>React.createElement("div",{key:l.id,style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'8px 10px',fontSize:12.5}},
React.createElement("div",{style:{fontWeight:600}},l.nome," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",l.id)),
React.createElement("div",{style:{color:'var(--on-surface-variant)'}},l.pais||'país ?'," · times: ",(l.paises||[]).join(', ')||'país ?'," · ",l.times," times · ",l.jogos," jogos",l.periodo?` · ${l.periodo}`:'',l.copa?' · copa':'',l.internacional?' · internacional':'')
))
),
c.tipo==='liga_misturada'&&(c.grafias||[]).length>0&&React.createElement("div",{style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'8px 10px',marginBottom:8}},
React.createElement("div",{style:{fontSize:11.5,fontWeight:700,textTransform:'uppercase',color:'var(--on-surface-variant)',marginBottom:6}},"Como cada fonte chamou estes jogos"),
(c.grafias||[]).map((g)=>React.createElement("div",{key:g.rotulo,style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap',padding:'4px 0',borderTop:'1px solid var(--line)'}},
React.createElement("span",{style:{fontSize:12.5,minWidth:220}},React.createElement("b",null,semIdLiga(g.rotulo))," ",React.createElement("span",{style:{color:'var(--on-surface-variant)'}},"· ",g.n," jogo(s)")),
React.createElement(LigaPicker,{sport:c.sportMix,excluir:c.ligaId,placeholder:"mandar para…",disabled:busy===c.chave+g.rotulo,onPick:async(l)=>{
if(await confirma(`Mandar os ${g.n} jogo(s) de "${semIdLiga(g.rotulo)}" para "${l.display_name}"?`))acaoMoverGrafia(c,g.rotulo,l);
}})
))
),

c.tipo==='fusao_sem_prova'&&(c.jogosFusao||[]).length>0&&React.createElement("div",{style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'8px 10px',marginBottom:8,fontSize:12.5}},
React.createElement("div",{style:{fontSize:11.5,fontWeight:700,textTransform:'uppercase',color:'var(--on-surface-variant)',marginBottom:6}},"Os jogos, como estão agora em \"",c.fusao.para,"\""),
c.jogosFusao.map((g,i)=>React.createElement("div",{key:i,style:{padding:'3px 0',borderTop:i?'1px solid var(--line)':'none'}},
React.createElement("b",null,g.jogo)," · ",fmt(g.quando),g.liga?` · ${semIdLiga(g.liga)}`:'',
' ',g.situacao==='copia'?React.createElement("span",{style:{color:'#15803d'}},"· \"",c.fusao.para,"\" já tinha este mesmo jogo"):
g.situacao==='copia_viva'?React.createElement("span",{style:{color:'#b45309'}},"· existe outra cópia deste jogo em \"",c.fusao.para,"\""):
null,
(g.casas||[]).length>0&&React.createElement("div",{style:{color:'var(--on-surface-variant)',fontSize:11.5}},"como as casas escreveram: ",g.casas.join(' · '))
))
),
c.tipo==='liga_misturada'&&(c.jogosLista||[]).length>0&&React.createElement("div",{style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'8px 10px',marginBottom:8,fontSize:12.5}},
React.createElement("div",{style:{fontSize:11.5,fontWeight:700,textTransform:'uppercase',color:'var(--on-surface-variant)',marginBottom:6}},"Jogos desta liga (os ",c.jogosLista.length," mais recentes)"),
c.jogosLista.map((g,i)=>React.createElement("div",{key:i,style:{padding:'2px 0'}},fmt(g.quando)," · ",React.createElement("b",null,g.jogo),g.rotulo?React.createElement("span",{style:{color:'var(--on-surface-variant)'}}," · a casa chamou de “",g.rotulo,"”"):null))
),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'center'}},
(c.candidatos||[]).length===0&&(c.acoes||[]).includes('escolher')&&React.createElement("span",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"sem candidato parecido"),
(c.candidatos||[]).map((k,i)=>React.createElement("button",{key:i,className:"btn-sm b-green",disabled:busy===c.chave,onClick:()=>agir(c,'escolher',k.id),title:k.duplicados>1?`Este jogo está cadastrado ${k.duplicados} vezes no mesmo horário`:''},
k.nome,fmt(k.quando)?` · ${fmt(k.quando)}`:'',k.competicao?` · ${k.competicao}`:'',k.nota!=null&&c.tipo!=='mercado'?` · ${Math.round(k.nota*100)}%`:'',k.duplicados>1?` · cadastrado ${k.duplicados}x`:''
)),
c.mercadoJogo&&React.createElement(EscolhaMercadoJogo,{opcoes:c.mercadoJogo.opcoes,soMercado:!!c.mercadoJogo.soMercado,inicial:c.mercadoJogo.sugerido,disabled:busy===c.chave,onSalvar:(alvo)=>agir(c,'escolher',alvo)}),
c.tipo==='mercado'&&c.alvo!=='jogo'&&React.createElement("button",{className:"btn-sm",disabled:busy===c.chave,onClick:()=>abrirCriar(c)},"Não está na lista? Criar mercado"),
c.tipo==='jogador'&&c.evento&&React.createElement("button",{className:"btn-sm",disabled:busy===c.chave,onClick:()=>abrirJog(c)},"Ver outros jogadores do jogo"),
c.tipo==='duplicado'&&React.createElement("button",{className:"btn-sm",disabled:busy===c.chave,onClick:()=>abrirDup(c)},"Ver jogos dos dois"),
(c.tipo==='liga_duplicada'||c.tipo==='liga_misturada')&&React.createElement("button",{className:"btn-sm",disabled:busy===c.chave,onClick:()=>setLigaVer({caso:c,ids:c.ligas.map((l)=>l.id)})},c.tipo==='liga_misturada'?'Ver e separar':'Ver as duas ligas'),
c.tipo==='esporte'&&React.createElement("select",{disabled:busy===c.chave,defaultValue:"","aria-label":"esporte desta grafia",
onChange:(e)=>{const v=e.target.value;e.target.value='';if(v==='__novo')criaEsporte(c);else if(v)acaoEsporte(c,v==='__nao'?null:v);},
style:{padding:'6px 9px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:12.5,maxWidth:300}},
React.createElement("option",{value:""},"escolher o esporte…"),
(c.opcoes||[]).map((o)=>React.createElement("option",{key:o.code,value:o.code},o.nome)),
React.createElement("option",{value:"__novo"},"➕ é um esporte que ainda não existe: criar"),
React.createElement("option",{value:"__nao"},"não é esporte (categoria de aposta)")
),
c.tipo==='liga_sem_catalogo'&&((c.opcoesCatalogo||[]).length?
React.createElement("select",{disabled:busy===c.chave,defaultValue:"","aria-label":"liga do catálogo",
onChange:(e)=>{const i=e.target.value;e.target.value='';if(i!=='')acaoLigarCatalogo(c,(c.opcoesCatalogo||[])[Number(i)]);},
style:{padding:'6px 9px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:12.5,maxWidth:360}},
React.createElement("option",{value:""},"escolher a liga do catálogo…"),
(c.opcoesCatalogo||[]).map((o,i)=>React.createElement("option",{key:o.fonte+o.fonte_id,value:i},o.nome,o.tipo==='Cup'?' · copa':'',o.nota>=0.8?' · parece esta':''))
):
React.createElement("span",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"sem liga deste esporte neste país no catálogo")),

c.tipo==='liga_solta'&&(c.apiDiz||[]).length>0&&React.createElement("div",{style:{flexBasis:'100%',fontSize:12.5,marginBottom:4}},
React.createElement("b",null,"A API de dados diz:")," ",(c.apiDiz||[]).map((a,i)=>React.createElement("span",{key:a.fonte+a.ligaId+i},i?' · ':'',a.nome||'liga '+a.ligaId,a.pais?` (${a.pais})`:''," — ",a.jogos," jogo(s), ",a.fonte,a.competicao?React.createElement(React.Fragment,null," — é a nossa liga #",a.competicao):' — essa liga ainda não está no nosso cadastro'))
),
c.tipo==='liga_solta'&&(c.apiDiz||[]).filter((a)=>a.competicao&&!(c.sugestoesLiga||[]).some((l)=>l.id===a.competicao)).map((a)=>React.createElement("button",{key:'api'+a.competicao,className:"btn-sm b-green",disabled:busy===c.chave,title:"A liga que a API de dados dá para estes jogos",onClick:()=>acaoLigarGrafia(c,{id:a.competicao,nome:a.nome})},
a.nome||'liga #'+a.competicao," · pela API (",a.jogos," jogo(s))")),

c.tipo==='liga_solta'&&(c.sugestoesLiga||[]).map((l)=>React.createElement("button",{key:l.id,className:"btn-sm b-green",disabled:busy===c.chave,title:"Liga do catálogo em que esses times já têm jogos",onClick:()=>acaoLigarGrafia(c,l)},
l.nome,l.area?` · ${l.area}`:''," · ",l.times," de ",c.timesVistos," times")),

c.tipo==='fusao_sem_prova'&&c.fusao&&(c.fusao.porJogos?React.createElement(React.Fragment,null,
React.createElement("button",{className:"btn-sm b-green",disabled:busy===c.chave,onClick:()=>acaoFusao(c,'confirmar')},"Sim, são jogos de \"",c.fusao.para,"\""),
React.createElement("button",{className:"btn-sm b-red",disabled:busy===c.chave,onClick:()=>acaoFusao(c,'desfazer')},"Não, são de outro clube: separar")
):React.createElement(React.Fragment,null,
React.createElement("button",{className:"btn-sm b-green",disabled:busy===c.chave,onClick:()=>acaoFusao(c,'confirmar')},"Sim, é o mesmo clube"),
React.createElement("button",{className:"btn-sm b-red",disabled:busy===c.chave,onClick:()=>acaoFusao(c,'desfazer')},"Não, são dois: separar de novo")
)),
c.tipo==='liga_invadida'&&c.destino&&React.createElement("button",{className:"btn-sm b-green",disabled:busy===c.chave,onClick:()=>acaoMoverJogos(c,c.destino)},"Mover para ",c.destino.nome," (",c.destino.pais,")"),
c.tipo==='liga_invadida'&&React.createElement(LigaPicker,{sport:c.sportSolto,placeholder:"outra liga…",disabled:busy===c.chave,onPick:(l)=>acaoMoverJogos(c,l)}),
c.tipo==='id_provedor'&&c.idProvedor&&(['separar','juntar','time_variante','time_homonimo','numero_duplicado','numero_de_outro'].includes(c.idProvedor.acao)||['time_numeros','jogador_numeros'].includes(c.idProvedor.acao)&&c.idProvedor.auto)&&React.createElement("button",{className:"btn-sm b-green",disabled:busy===c.chave,title:"É o que o sistema faria sozinho na próxima faxina; aqui você adianta.",onClick:()=>acaoIdProvedor(c,'executar')},"Fazer o recomendado: ",{separar:'cada pessoa no seu cadastro',juntar:'juntar os cadastros',time_variante:'tirar o número da outra variante',time_homonimo:'tirar o número do outro clube',numero_duplicado:'um número vale pelo outro',numero_de_outro:'tirar o número que é de outra pessoa'}[c.idProvedor.acao]||(c.idProvedor.passos||[]).filter((p)=>!['pessoa','aguarda'].includes(p.acao)).map((p)=>({fica:'#'+p.numero+' fica',sai:'#'+p.numero+' sai'+(p.para?' → '+p.para.nome:''),juntar:'juntar com #'+(p.com&&p.com.id),separar:(p.jogos||0)+' jogo(s) → '+(p.para&&p.para.id?'#'+p.para.id:'cadastro novo')})[p.acao]).join(' · ')+(c.idProvedor.renomear?' · renomear para "'+c.idProvedor.renomear+'"':'')),

c.tipo==='id_provedor'&&c.idProvedor&&c.idProvedor.acao!=='juntar'&&c.idProvedor.modo!=='separar'&&c.idProvedor.numeros.map((n)=>React.createElement("button",{key:'c'+n.numero,className:"btn-sm",disabled:busy===c.chave,title:n.jaDe?'Este cadastro é este clube/esta pessoa; o número '+n.numero+' já é do cadastro #'+n.jaDe+', então os dois cadastros são juntados e os outros números saem':'Este cadastro é esta pessoa/este clube (número '+n.numero+'); os outros números saem daqui',onClick:()=>acaoIdProvedor(c,'confirmar',n.numero)},"É ",(n.nome||n.nomeDaCasa||'#'+n.numero)+(n.clube?' ('+n.clube+')':n.paisApi?' ('+n.paisApi+')':n.rotuloVariante&&!/(F)|Udd/.test(n.nome||'')?' ('+n.rotuloVariante+')':'')+(n.nascimento?' · '+n.nascimento.split('-').reverse().join('/'):''),n.jaDe?' — mesmo cadastro que #'+n.jaDe:'')),
c.tipo==='id_provedor'&&c.idProvedor&&c.idProvedor.numeros.map((n)=>React.createElement("button",{key:'t'+n.numero,className:"btn-sm b-red",disabled:busy===c.chave,title:'Tirar o número '+n.numero+' deste cadastro (não volta sozinho)',onClick:()=>acaoIdProvedor(c,'tirar',n.numero)},"Não é ",(n.nome||n.nomeDaCasa||'#'+n.numero)+(n.clube?' ('+n.clube+')':n.paisApi?' ('+n.paisApi+')':'')+(n.nascimento?' · '+n.nascimento.split('-').reverse().join('/'):''))),
c.tipo==='liga_solta'&&React.createElement(LigaPicker,{sport:c.sportSolto,placeholder:"ligar a…",disabled:busy===c.chave,onPick:(l)=>acaoLigarGrafia(c,l)}),
c.tipo==='esporte_da_liga'&&c.incongruencia&&React.createElement(React.Fragment,null,
React.createElement("button",{className:"btn-sm b-green",disabled:busy===c.chave,onClick:()=>acaoEsporteDaLiga(c,c.incongruencia.esporteComp.code)},"É ",c.incongruencia.esporteComp.nome," — corrigir os jogos"),
React.createElement("button",{className:"btn-sm",disabled:busy===c.chave,title:"A casa está certa; se faltar liga neste esporte, crie na aba Ligas",onClick:()=>acaoEsporteDaLiga(c,'')},"Está certo como ",c.incongruencia.esporteCasa.nome),
React.createElement("div",{className:"sel-wrap",style:{display:'inline-block'}},React.createElement("select",{className:"sel",defaultValue:"",disabled:busy===c.chave,onChange:(e)=>{if(e.target.value)acaoEsporteDaLiga(c,e.target.value);}},
React.createElement("option",{value:""},"outro esporte…"),(c.opcoes||[]).map((o)=>React.createElement("option",{key:o.code,value:o.code},o.nome))
))
),
c.tipo==='liga_solta'&&c.esporteSemApi&&React.createElement("button",{className:"btn-sm",disabled:busy===c.chave,title:"Este esporte não tem API de ligas: a liga é cadastrada à mão. Cria no catálogo manual, cadastra agora e liga esta grafia.",onClick:()=>acaoCriarManual(c)},"Criar liga manual \"",semIdLiga(c.rotulo),"\""),
c.tipo==='liga_solta'&&c.provisoria&&!c.esporteSemApi&&React.createElement("button",{className:"btn-sm",disabled:busy===c.chave,title:"A competição não existe no catálogo da API: cria como liga complementar (com o país), cadastra agora e liga esta grafia e as das outras casas. Antes, confira em 'ligar a…' se ela não existe com outro nome.",onClick:()=>acaoCriarManual(c)},"Criar liga \"",c.nomeSugerido||semIdLiga(c.rotulo),"\"",c.areaCode?' ('+c.areaCode+')':''),
c.tipo==='liga_solta'&&React.createElement("button",{className:"btn-sm b-red",disabled:busy===c.chave,onClick:()=>acaoNaoEhLiga(c)},"Não é liga"),
(c.botoes||[]).map((b)=>React.createElement("button",{key:b.acao,className:'btn-sm '+(b.cor||''),disabled:busy===c.chave,title:b.title||'',onClick:async()=>{if(b.confirma&&!(await confirma(b.confirma)))return;agir(c,b.acao);}},b.rotulo)),
(c.acoes||[]).includes('novo')&&React.createElement("button",{className:"btn-sm",disabled:busy===c.chave,title:"Nenhum dos nomes: cria um jogador novo com este nome",onClick:()=>agir(c,'novo')},"Novo jogador"),
(c.acoes||[]).includes('manter')&&React.createElement("button",{className:"btn-sm b-green",disabled:busy===c.chave,title:"Está certo assim: as grafias são a mesma aposta e continuam ligadas; a pergunta não volta",onClick:()=>agir(c,'manter')},c.rotuloManter||'Manter assim'),
(c.acoes||[]).includes('ignorar')&&React.createElement("button",{className:"btn-sm b-red",disabled:busy===c.chave,onClick:()=>agir(c,'ignorar')},c.rotuloIgnorar||'Ignorar'),

c.semDecisao&&React.createElement("span",{style:{fontSize:12.5,color:'var(--on-surface-variant)',fontStyle:'italic'}},c.semDecisao),
busy===c.chave&&React.createElement("span",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"…")
)
))
)
);
}











function LigaConteudoModal({ids,titulo,onClose,onFeito}){


const[dados,setDados]=useState(null),[busy,setBusy]=useState(false),[erro,setErro]=useState(''),[sel,setSel]=useState({}),[destino,setDestino]=useState(null);
useEffect(()=>{
Promise.all(ids.map((id)=>fetch('/api/admin/er/ligas/'+id+'/conteudo',{credentials:'include'}).then((r)=>r.json()))).then(setDados).catch((e)=>setErro(e.message));
},[ids.join(',')]);
const post=async(url,body)=>{setBusy(true);setErro('');
try{const r=await fetch(url,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json();
if(!r.ok){setErro(j.error||'Erro');return;}onFeito('✅ '+(j.msg||'Feito.'));}
catch(e){setErro(e.message);}finally{setBusy(false);}};
const ok=dados&&!dados.some((d)=>d.error);
const comuns=ok&&dados.length===2?new Set(dados[0].times.map((t)=>t.id).filter((id)=>dados[1].times.some((u)=>u.id===id))):new Set();
const fmtD=(x)=>{const d=new Date(x);return isNaN(d)?'—':d.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit',year:'2-digit'});};
const marcarGrupo=(ts)=>setSel((s0)=>{const n={...s0};const todos=ts.every((t)=>n[t.id]);ts.forEach((t)=>{n[t.id]=!todos;});return n;});
const selIds=Object.keys(sel).filter((k)=>sel[k]).map(Number);
const rot={fontSize:11.5,fontWeight:700,textTransform:'uppercase',color:'var(--on-surface-variant)',letterSpacing:'.03em'};
return React.createElement("div",{onClick:onClose,style:{position:'fixed',inset:0,background:'rgba(0,0,0,.35)',zIndex:60,display:'flex',alignItems:'center',justifyContent:'center',padding:16}},
React.createElement("div",{onClick:(e)=>e.stopPropagation(),role:"dialog","aria-label":"Conteúdo da liga",style:{background:'#fff',borderRadius:12,padding:18,width:'min(1120px,100%)',maxHeight:'90vh',overflowY:'auto',display:'flex',flexDirection:'column',gap:10}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'baseline',gap:10}},React.createElement("b",{style:{fontSize:15}},titulo),React.createElement("button",{className:"btn-sm",onClick:onClose},"Fechar")),
erro&&React.createElement("div",{style:{fontSize:13,color:'#b91c1c'}},"❌ ",erro),
!dados?React.createElement("span",{style:{fontSize:13}},"Carregando…"):React.createElement(React.Fragment,null,
ok&&dados.length===2&&React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'center',fontSize:13}},
React.createElement("span",null,React.createElement("b",null,comuns.size)," times jogam nas duas (fundo verde)."),
React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:async()=>{if(await confirma(`Juntar "${dados[0].liga.nome}" em "${dados[1].liga.nome}"?\n\nOs jogos e os apelidos passam para a segunda.`))post('/api/admin/er/competicoes/fundir',{de:dados[0].liga.id,para:dados[1].liga.id});}},"Juntar em \"",dados[1].liga.nome,"\""),
React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:async()=>{if(await confirma(`Juntar "${dados[1].liga.nome}" em "${dados[0].liga.nome}"?\n\nOs jogos e os apelidos passam para a segunda.`))post('/api/admin/er/competicoes/fundir',{de:dados[1].liga.id,para:dados[0].liga.id});}},"Juntar em \"",dados[0].liga.nome,"\""),
React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>post('/api/admin/er/competicoes/decisao',{tipo:'diferentes',a:dados[0].liga.id,b:dados[1].liga.id})},"São ligas diferentes")
),
React.createElement("div",{style:{display:'grid',gridTemplateColumns:`repeat(${dados.length},minmax(0,1fr))`,gap:12}},
dados.map((d,i)=>d.error?React.createElement("div",{key:i},"❌ ",d.error):React.createElement("div",{key:i,style:{border:'1px solid var(--line-2)',borderRadius:10,padding:10,display:'flex',flexDirection:'column',gap:8,minWidth:0}},
React.createElement("div",null,React.createElement("b",null,d.liga.nome)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",d.liga.id," · ",d.liga.chave)),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},d.liga.pais||'país ?'," · ",d.totais.times," times · ",d.totais.jogos," jogos",d.periodo?` · ${d.periodo}`:''),
React.createElement("div",{style:rot},"Como as fontes escrevem"),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:4,fontSize:12}},
[...d.grafias.superOdds.map((g)=>({...g,o:'Super Odds'})),...d.grafias.props.map((g)=>({...g,o:'Player Props'})),...d.apelidos.map((a)=>({rotulo:a.alias_norm,n:null,o:a.created_by==='human'?'apelido seu':'apelido'}))].map((g,k)=>
React.createElement("span",{key:k,style:{border:'1px solid var(--line-2)',borderRadius:99,padding:'1px 8px'}},semIdLiga(g.rotulo)," ",React.createElement("span",{style:{color:'var(--on-surface-variant)',fontSize:11}},g.o,g.n?` · ${g.n}`:'')))
),
dados.length===1&&d.grupos.length>1&&React.createElement(React.Fragment,null,
React.createElement("div",{style:{...rot,color:'#a3402a'}},"Grupos de times que não se cruzam"),
d.grupos.map((g,k)=>React.createElement("div",{key:k,style:{border:'1px dashed var(--line-2)',borderRadius:8,padding:'6px 8px',fontSize:12.5}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',gap:6,flexWrap:'wrap',alignItems:'baseline'}},
React.createElement("b",null,g.liga?`Jogam também em "${g.liga.nome}"${g.liga.pais?` (${g.liga.pais})`:''}`:'Sem outra liga conhecida'),
React.createElement("button",{className:"btn-sm",onClick:()=>marcarGrupo(g.times)},"marcar grupo")
),
React.createElement("div",{style:{color:'var(--on-surface-variant)'}},g.times.length," times · ",g.jogos," jogo(s) só entre eles · ",g.times.slice(0,8).map((t)=>t.nome).join(', '),g.times.length>8?'…':'')
))
),
React.createElement("div",{style:rot},"Times (",d.times.length,")"),
React.createElement("div",{style:{maxHeight:260,overflowY:'auto',fontSize:12.5,display:'flex',flexDirection:'column',gap:1}},
d.times.map((t)=>React.createElement("label",{key:t.id,style:{display:'flex',gap:6,alignItems:'baseline',background:comuns.has(t.id)?'rgba(20,140,80,.12)':'transparent',borderRadius:4,padding:'1px 4px'}},
dados.length===1&&React.createElement("input",{type:"checkbox",checked:!!sel[t.id],onChange:(e)=>setSel((x)=>({...x,[t.id]:e.target.checked}))}),
React.createElement("span",null,t.nome),
React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},t.pais||'país ?'," · ",t.jogos," jogo(s)",t.outras.length?` · também em: ${t.outras.join(', ')}`:'')
))
),
React.createElement("div",{style:rot},"Jogos recentes"),
React.createElement("div",{style:{maxHeight:220,overflowY:'auto',fontSize:12.5}},d.jogos.map((j)=>React.createElement("div",{key:j.id},React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},fmtD(j.quando))," ",j.home," x ",j.away)))
))
),
ok&&dados.length===1&&React.createElement("div",{style:{borderTop:'1px solid var(--line-2)',paddingTop:10,display:'flex',gap:8,flexWrap:'wrap',alignItems:'center',fontSize:13}},
React.createElement("span",null,"Separar os jogos entre os ",React.createElement("b",null,selIds.length)," times marcados para"),
destino?React.createElement("span",null,React.createElement("b",null,destino.display_name),destino.area_nome||destino.country?` (${destino.area_nome||destino.country})`:''," · #",destino.id," ",React.createElement("button",{className:"btn-sm",onClick:()=>setDestino(null)},"trocar")):
React.createElement(React.Fragment,null,React.createElement(LigaPicker,{excluir:dados[0].liga.id,placeholder:"buscar liga existente (nome, país ou #id)…",onPick:(l)=>setDestino(l),disabled:busy}),React.createElement("span",{style:{color:'var(--on-surface-variant)'}},"ou, sem escolher, uma liga nova")),
React.createElement("button",{className:"btn-sm b-green",disabled:busy||selIds.length<2,onClick:async()=>{const body={id:dados[0].liga.id,times:selIds};
if(destino)body.destino_id=Number(destino.id);else{const nome=await pergunta('Nome da liga nova');if(!nome)return;body.nome=nome;body.pais=((await pergunta('País com 3 letras (vazio = sem país)',''))||'').trim();}
post('/api/admin/er/competicoes/separar',body);}},"Separar"),
React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>post('/api/admin/er/competicoes/decisao',{tipo:'nao_misturada',id:dados[0].liga.id})},"Está certo assim")
)
)
)
);
}

function LigasSection({onClose}){
const[q,setQ]=useState(''),[d,setD]=useState(null),[msg,setMsg]=useState(''),[busy,setBusy]=useState(''),[aberta,setAberta]=useState(null),[ver,setVer]=useState(null),[areas,setAreas]=useState([]),[cad,setCad]=useState(null);
useEffect(()=>{leJson('/api/admin/er/cadastros').then((j)=>{setAreas(j.areas||[]);setCad(j);}).catch((e)=>setMsg('❌ Áreas e cadastros não carregaram: '+e.message));},[]);

const vezLoad=useRef(0);
const load=async()=>{const n=++vezLoad.current;try{const r=await fetch('/api/admin/er/competicoes'+(q.trim()?'?q='+encodeURIComponent(q.trim()):''),{credentials:'include'});if(r.status===401){onClose('relogin');return;}const j=await r.json();if(n===vezLoad.current)setD(r.ok?j:{error:j.error||'Erro'});}catch(e){if(n===vezLoad.current)setD({error:e.message});}};
useEffect(()=>{const t=setTimeout(load,350);return()=>clearTimeout(t);},[q]);
const post=async(url,body,chave)=>{setBusy(chave);setMsg('');
try{const r=await fetch(url,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json();
setMsg(r.ok?'✅ '+(j.msg||'Feito.'):'❌ '+(j.error||'Erro'));if(r.ok)load();return r.ok;}
catch(e){setMsg('❌ '+e.message);return false;}finally{setBusy('');}};
const ligas=d&&d.ligas||[];
const rotuloLiga=(x)=>`${x.display_name}${x.country?` (${x.country})`:''} · #${x.id}`;
return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg),
ver&&React.createElement(LigaConteudoModal,{ids:[ver.id],titulo:ver.display_name,onClose:()=>setVer(null),onFeito:(m)=>{setMsg(m);setVer(null);load();}}),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:12,maxWidth:920}},"Cada liga é ",React.createElement("b",null,"um cadastro"),". Cada fonte escreve a liga do seu jeito (\"Norway - Eliteserien\", \"Eliteserien\", \"Liga de Elite\"), e essas grafias são ",React.createElement("b",null,"apelidos")," da liga. Os apelidos de time valem dentro da liga cadastrada: apelido de liga solto ou liga duplicada é o que faz um clube virar dois. O sistema aprende sozinho quando um jogo fecha; aqui você liga o que ficou solto, tira apelido errado e junta liga duplicada."),
React.createElement(FusoesRecentes,{kind:"competition",titulo:"Ligas juntadas"}),
React.createElement("input",{value:q,onChange:(e)=>setQ(e.target.value),placeholder:"buscar liga ou apelido…",style:{padding:'8px 10px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:13.5,minWidth:280,marginBottom:12}}),
!d?React.createElement("div",{style:{fontSize:13}},"Carregando…"):d.error?React.createElement("div",{style:{fontSize:13}},"❌ ",d.error):React.createElement(React.Fragment,null,
d.soltosErro&&React.createElement("div",{style:{fontSize:12.5,color:'#b91c1c',marginBottom:12}},"❌ A lista de grafias soltas falhou: ",d.soltosErro),
(d.soltos||[]).length>0&&React.createElement("div",{style:{marginBottom:20}},
React.createElement("h3",{className:"sec-t"},"Grafias de liga sem cadastro (",d.soltos.length,")"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Mandadas pelas fontes nos últimos 7 dias e que ainda não são liga, apelido nem vínculo da fonte. Cada linha mostra a casa que mandou e jogos de exemplo, para você saber o que tem dentro. Digite para buscar a liga e clique nela: o vínculo vale para aquela casa (e para id de torneio sem nome, como \"544\", é o único jeito). Se for uma liga nova de verdade, deixe: ela nasce sozinha no primeiro jogo."),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Grafia"),React.createElement("th",null,"Casa · jogos de exemplo (7 dias)"),React.createElement("th",null,"É a liga"))),React.createElement("tbody",null,
d.soltos.map((x)=>React.createElement("tr",{key:x.norm},
React.createElement("td",null,React.createElement("b",null,semIdLiga(x.rotulo)),x.numerico&&React.createElement("div",{style:{fontSize:11.5,color:'#b45309'}},"id de torneio sem nome: não vira liga, só vínculo da casa"),x.pais&&React.createElement("div",{style:{fontSize:11.5,color:'#b45309'}},"é nome de país, não de liga: a casa manda o país no lugar da competição. O jogo fica sem liga até outra fonte dizer qual é."),React.createElement("div",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},x.sport," · ",x.n," partida(s)"),
React.createElement("button",{className:"btn-sm",style:{marginTop:4},disabled:busy===x.norm,title:"Some da lista para sempre (combo, categoria de aposta, país)",onClick:async()=>{if(await confirma(`"${semIdLiga(x.rotulo)}" não é liga? Some da lista.`))post('/api/admin/er/competicoes/ignorar-grafia',{rotulo:x.rotulo,sport:x.sport},x.norm);}},"não é liga")),
React.createElement("td",{style:{fontSize:12}},x.fontes.map((f)=>React.createElement("div",{key:f.fonte,style:{marginBottom:2}},React.createElement("b",null,f.fonte)," · ",f.n,": ",React.createElement("span",{style:{color:'var(--on-surface-variant)'}},f.exemplos.join(' · ')||'—')))),
React.createElement("td",{style:{minWidth:280}},x.pais?React.createElement("span",{style:{fontSize:12,color:'var(--on-surface-variant)'}},"—"):React.createElement(LigaPicker,{sport:x.sport,placeholder:"digite para buscar a liga…",disabled:busy===x.norm,onPick:async(l)=>{if(await confirma(`"${semIdLiga(x.rotulo)}" (${x.fontes.map((f)=>f.fonte).join(', ')}) é a liga "${l.display_name}"${l.area_nome?` (${l.area_nome})`:''}?`))post('/api/admin/er/competicoes/ligar-fonte',{rotulo:x.rotulo,sport:x.sport,fontes:x.fontes.map((f)=>f.fonte),competicao_id:l.id},x.norm);}}))
))
)))
),
React.createElement("h3",{className:"sec-t"},"Ligas cadastradas (",ligas.length,ligas.length===150?', as 150 com mais jogos — busque para ver outras':'',")"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Liga"),React.createElement("th",null,"Esporte e área"),React.createElement("th",null,"Jogos (30 dias)"),React.createElement("th",null,"Apelidos"),React.createElement("th",null))),React.createElement("tbody",null,
ligas.map((l)=>React.createElement(React.Fragment,{key:l.id},
React.createElement("tr",null,
React.createElement("td",null,React.createElement("b",null,l.display_name)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",l.id," · ",l.sport),l.api_liga&&React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},"API-Football: ",l.api_liga.split('|')[1]||'liga'," · id ",l.api_liga.split('|')[0]),React.createElement("div",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},l.canonical_key)),
React.createElement("td",{style:{fontSize:12.5}},React.createElement("div",null,l.esporte_nome||React.createElement("span",{style:{color:'var(--danger,#B3261E)'}},"esporte sem cadastro (",l.sport,")")),
areas.length?React.createElement("select",{value:l.area_code||'',disabled:busy==='a'+l.id,"aria-label":'área de '+l.display_name,onChange:(e)=>post('/api/admin/er/competicoes/area',{id:l.id,area:e.target.value},'a'+l.id),style:{maxWidth:190,fontSize:12}},
React.createElement("option",{value:""},"sem área"),areas.map((a)=>React.createElement("option",{key:a.code,value:a.code},a.name_pt," · ",a.code))):
React.createElement("span",{className:"mono-sm"},l.area_nome?`${l.area_nome} · ${l.area_code}`:l.country||'sem área')),
React.createElement("td",{className:"mono-sm"},l.jogos),
React.createElement("td",{style:{whiteSpace:'nowrap'}},l.apelidos.length," ",React.createElement("button",{className:"btn-sm",onClick:()=>setAberta(aberta===l.id?null:l.id)},aberta===l.id?'Fechar':'Ver')),
React.createElement("td",null,React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},
React.createElement("button",{className:"btn-sm",onClick:()=>setVer(l)},"Ver conteúdo"),
React.createElement(LigaPicker,{sport:l.sport,excluir:l.id,placeholder:"juntar em…",disabled:busy==='f'+l.id,onPick:async(dest)=>{
if(await confirma(`Juntar "${l.display_name}" dentro de "${dest.display_name}"?\n\nOs jogos e os apelidos de time passam para a segunda liga, e o nome da primeira vira apelido dela.`))post('/api/admin/er/competicoes/fundir',{de:l.id,para:dest.id},'f'+l.id);}}),
React.createElement("button",{className:"btn-sm",disabled:busy==='e'+l.id,onClick:async()=>{const nome=await pergunta('Nome da liga',l.display_name);if(nome===null)return;post('/api/admin/er/competicoes/editar',{id:l.id,display_name:nome,country:l.country||''},'e'+l.id);}},"Editar")
))
),
aberta===l.id&&React.createElement("tr",null,React.createElement("td",{colSpan:5,style:{paddingLeft:24}},
!!(l.porFonte||[]).length&&React.createElement("div",{style:{marginBottom:10}},
React.createElement("div",{style:{fontSize:12.5,fontWeight:600,marginBottom:4}},"Grafia por fonte"),
React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginBottom:6}},"O que cada fonte chama de \"",l.display_name,"\". Se a grafia de uma fonte for de outra liga, mova: a decisão vale sobre o automático."),
React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:4}},l.porFonte.map((f)=>React.createElement("div",{key:f.source+f.external_id,style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap',fontSize:12.5}},
React.createElement("span",{className:"mono-sm"},f.source.slice(5)),React.createElement("b",null,f.raw_name||f.external_id),React.createElement("span",{style:{color:'var(--on-surface-variant)',fontSize:11}},f.created_by==='human'?'você':'aprendido'),
React.createElement(LigaPicker,{sport:l.sport,excluir:l.id,placeholder:"mover para…",disabled:busy==='gf'+f.external_id,onPick:(dest)=>post('/api/admin/er/competicoes/grafia-fonte',{source:f.source,external_id:f.external_id,para:dest.id},'gf'+f.external_id)}),
React.createElement("button",{className:"btn-sm",title:"A fonte deixa de ter vínculo para esta grafia",disabled:busy==='gf'+f.external_id,onClick:async()=>{if(await confirma(`Remover o vínculo de ${f.source.slice(5)} para "${f.raw_name||f.external_id}"?`))post('/api/admin/er/competicoes/grafia-fonte',{source:f.source,external_id:f.external_id,para:0},'gf'+f.external_id);}},"×")
)))
),
!l.apelidos.length&&React.createElement("span",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"Sem apelidos: vale só o nome do cadastro."),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:6}},l.apelidos.map((a)=>React.createElement("span",{key:a.alias_norm+a.scope_key,style:{display:'inline-flex',gap:6,alignItems:'center',border:'1px solid var(--line-2)',borderRadius:99,padding:'2px 4px 2px 10px',fontSize:12}},
a.alias_norm,React.createElement("span",{style:{color:'var(--on-surface-variant)',fontSize:11}},a.created_by==='human'?'você':'aprendido',Number(a.ambiguous)?' · disputado':''),
React.createElement("button",{className:"btn-sm",title:"Tirar este apelido da liga","aria-label":'tirar '+a.alias_norm,disabled:busy==='r'+a.alias_norm,onClick:()=>post('/api/admin/er/competicoes/rotulo/remover',{competicao_id:l.id,rotulo:a.alias_norm},'r'+a.alias_norm)},"×")
)))
))
))
)))
),
cad&&React.createElement(CatalogoReferencia,{d:cad})
);
}





const semIdLiga=(t)=>String(t||'').replace(/\s*\(\d+\)\s*$/,'');
window.semIdLiga=semIdLiga;
function LigaPicker({sport,excluir,placeholder,onPick,disabled}){
const[q,setQ]=useState(''),[lista,setLista]=useState([]),[aberto,setAberto]=useState(false),[carregando,setCarregando]=useState(false);

const caixa=useRef(null),[pos,setPos]=useState(null);
const mede=()=>{const r=caixa.current&&caixa.current.getBoundingClientRect();setPos(r?{top:r.bottom+2,left:r.left,width:Math.max(r.width,320)}:null);};
const abre=()=>{mede();setAberto(true);};




const visivel=()=>{const el=caixa.current;if(!el)return false;const r=el.getBoundingClientRect();if(r.bottom<0||r.top>window.innerHeight)return false;
for(let p=el.parentElement;p&&p!==document.body;p=p.parentElement){const s=getComputedStyle(p);if(!/(auto|scroll|hidden)/.test(s.overflowY+s.overflowX))continue;
const q=p.getBoundingClientRect();if(r.bottom<q.top+4||r.top>q.bottom-4||r.right<q.left||r.left>q.right)return false;}return true;};
useEffect(()=>{if(!aberto)return;const f=()=>{if(!visivel()){setAberto(false);if(caixa.current)caixa.current.blur();return;}mede();};window.addEventListener('scroll',f,true);window.addEventListener('resize',f);
return()=>{window.removeEventListener('scroll',f,true);window.removeEventListener('resize',f);};},[aberto]);

const vezLista=useRef(0),[erroLista,setErroLista]=useState('');
useEffect(()=>{if(!aberto)return;const n=++vezLista.current;const t=setTimeout(async()=>{setCarregando(true);
try{const j=await leJson('/api/admin/er/competicoes?so=1&q='+encodeURIComponent(q.trim()));if(n!==vezLista.current)return;
const todas=(j.ligas||[]).filter((l)=>l.id!==excluir);const mesmo=sport?todas.filter((l)=>l.sport===sport):todas;
setErroLista('');setLista((mesmo.length?mesmo:todas).slice(0,20));}catch(e){if(n===vezLista.current){setLista([]);setErroLista('Busca falhou: '+e.message);}}finally{if(n===vezLista.current)setCarregando(false);}},250);return()=>clearTimeout(t);},[q,aberto]);
return React.createElement("div",{style:{position:'relative',display:'inline-block',minWidth:240,width:'100%',maxWidth:340}},
React.createElement("input",{value:q,disabled:disabled,placeholder:placeholder||'buscar liga…',"aria-label":placeholder||'buscar liga',ref:caixa,onFocus:abre,onBlur:()=>setTimeout(()=>setAberto(false),150),onChange:(e)=>setQ(e.target.value),style:{padding:'6px 9px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:12.5,width:'100%'}}),
aberto&&React.createElement("div",{style:pos?{position:'fixed',zIndex:1000,top:pos.top,left:pos.left,width:pos.width,background:'var(--surface,#fff)',border:'1px solid var(--line-2)',borderRadius:8,boxShadow:'0 6px 20px rgba(0,0,0,.14)',maxHeight:Math.max(160,window.innerHeight-pos.top-12),overflowY:'auto'}:{position:'absolute',zIndex:30,top:'100%',left:0,right:0,background:'var(--surface,#fff)',border:'1px solid var(--line-2)',borderRadius:8,boxShadow:'0 6px 20px rgba(0,0,0,.14)',maxHeight:320,overflowY:'auto'}},
carregando&&React.createElement("div",{style:{padding:8,fontSize:12}},"buscando…"),
!carregando&&erroLista&&React.createElement("div",{style:{padding:8,fontSize:12,color:'var(--error,#b3261e)'}},"❌ ",erroLista),
!carregando&&!erroLista&&!lista.length&&React.createElement("div",{style:{padding:8,fontSize:12,color:'var(--on-surface-variant)'}},"nenhuma liga com \"",q,"\""),
lista.map((l)=>React.createElement("div",{key:l.id,onMouseDown:(e)=>{e.preventDefault();setAberto(false);setQ('');onPick(l);},style:{padding:'6px 9px',cursor:'pointer',borderBottom:'1px solid var(--line)',fontSize:12.5}},
React.createElement("b",null,l.display_name)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",l.id),
React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},l.esporte_nome||l.sport," · ",l.area_nome||l.country||'sem área',l.api_liga?` · API: ${l.api_liga.split('|')[1]||'liga'}`:''," · ",l.jogos," jogos em 30 dias")
))
)
);
}

window.LigaPicker=LigaPicker;
function CatalogoReferencia({d}){
const st=d.catalogoStatus&&d.catalogoStatus.fontes||{};const cont=new Map((d.catalogo||[]).map((c)=>[c.fonte+'|'+c.esporte,c]));const nomeEsp=Object.fromEntries((d.esportes||[]).map((e)=>[e.code,e.name_pt]));
const linhas=Object.entries(st).map(([k,v])=>{const fonte=k.split(':')[0];const c=cont.get(fonte+'|'+v.esporte)||{};return{k,fonte,v,c};});


const temApi=new Set((d.catalogo||[]).filter((c)=>String(c.fonte).startsWith('api-')).map((c)=>c.esporte));
const ehOficial=(fonte,esporte)=>String(fonte).startsWith('api-')||!temApi.has(esporte);
return React.createElement("div",{style:{marginTop:24}},
React.createElement("h3",{className:"sec-t"},"Catálogo de ligas de referência"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8,maxWidth:920}},"A liga do Odds Radar é o nosso cadastro; estas são as ligas dos provedores, que provam qual liga é qual (id, nome, país, tipo, temporada). A API-Sports usa a mesma conta da API-Football, cada esporte com a própria assinatura. O TheSportsDB cobre tênis, e-sports, dardos e outros, lido liga por liga pelo número. O coletor confere a cada 30 minutos e renova cada fonte uma vez por semana. ",React.createElement("b",null,"Cada esporte tem UMA fonte de ligas"),": onde a API-Sports cobre, é ela; o TheSportsDB vale só nos esportes que ela não cobre. Com duas fontes no mesmo esporte a mesma liga nasce duas vezes, então o que estiver marcado como \"sai\" é descartado na origem e apagado da tabela."),
!linhas.length?React.createElement("div",{style:{fontSize:13,marginBottom:18}},"O catálogo ainda não rodou (o coletor faz a primeira carga 1 minuto depois de iniciar)."):
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:20}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Esporte"),React.createElement("th",null,"Fonte"),React.createElement("th",null,"Ligas"),React.createElement("th",null,"Assinatura"),React.createElement("th",null,"Situação"))),React.createElement("tbody",null,
linhas.map(({k,fonte,v,c})=>React.createElement("tr",{key:k},
React.createElement("td",null,nomeEsp[v.esporte]||v.esporte),
React.createElement("td",{className:"mono-sm"},fonte," ",ehOficial(fonte,v.esporte)?
React.createElement("span",{className:"pill",style:{background:'rgba(28,107,82,.12)',color:'#1c6b52',fontSize:10.5}},"oficial"):
React.createElement("span",{className:"pill",style:{background:'rgba(179,38,30,.10)',color:'var(--danger,#B3261E)',fontSize:10.5},title:"este esporte já tem fonte oficial: estas ligas saem da tabela"},"sai")),
React.createElement("td",{className:"mono-sm"},Number(c.ligas||0),Number(c.sem_area||0)?React.createElement("span",{style:{color:'var(--on-surface-variant)'}}," · ",c.sem_area," sem área"):''),
React.createElement("td",{style:{fontSize:12}},v.plano?`${v.plano} · ${v.usadas||0}/${v.limiteDia||'?'} hoje`:'—'),
React.createElement("td",{style:{fontSize:12}},v.erro?React.createElement("span",{style:{color:'var(--danger,#B3261E)'}},v.erro):v.pulado?v.pulado:v.cursor!=null?v.completou?'volta completa':`percorrendo as ligas pelo número: até o ${v.cursor}${v.importadas?` · ${v.importadas} novas nesta rodada`:''}`:v.importadas?`${v.importadas} importadas agora`:'ok',v.aviso?React.createElement("div",null,v.aviso):'')
))
)))
);
}





const normTxt=(t)=>String(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const useCadastros=(onClose)=>{
const[d,setD]=useState(null),[msg,setMsg]=useState(''),[busy,setBusy]=useState('');
const load=async()=>{try{const r=await fetch('/api/admin/er/cadastros',{credentials:'include'});if(r.status===401){onClose('relogin');return;}setD(await r.json());}catch(e){setD({error:e.message});}};
useEffect(()=>{load();},[]);
const post=async(url,body,chave)=>{setBusy(chave);setMsg('');
try{const r=await fetch(url,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json();
setMsg(r.ok?'✅ '+(j.msg||'Feito.'):'❌ '+(j.error||'Erro'));if(r.ok)load();return r.ok;}catch(e){setMsg('❌ '+e.message);return false;}finally{setBusy('');}};
return{d,msg,busy,post,load};
};



function EsportesSection({onClose}){
const{d,msg,busy,post}=useCadastros(onClose);
const[novo,setNovo]=useState({code:'',nome:'',tipo:'coletivo'});
if(!d)return React.createElement("div",{style:{fontSize:13}},"Carregando…");
if(d.error)return React.createElement("div",{style:{fontSize:13}},d.pendente?'⏳ ':'❌ ',d.error);
const pend=(d.grafiasSemEsporte||[]).filter((g)=>!g.marcadaComoNaoEsporte),marc=(d.grafiasSemEsporte||[]).filter((g)=>g.marcadaComoNaoEsporte);
return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:14,maxWidth:920}},React.createElement("b",null,"Toda liga e todo time pertencem a um esporte.")," Cada fonte escreve o esporte do seu jeito (\"Fut. Americano\", \"NFL\"); a grafia é apelido do esporte. Grafia que o cadastro não conhece fica aqui até você ligar ao esporte, marcar como categoria de aposta ou criar o esporte."),

React.createElement("h3",{className:"sec-t"},"Grafias de esporte pendentes (",pend.length,")"),
!pend.length?React.createElement("div",{style:{fontSize:13,marginBottom:18}},"Nenhuma: toda grafia recebida é de um esporte cadastrado."):
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:12}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Grafia"),React.createElement("th",null,"Cadastros e jogos"),React.createElement("th",null,"É o esporte"))),React.createElement("tbody",null,
pend.map((g)=>React.createElement("tr",{key:g.grafia},
React.createElement("td",null,React.createElement("b",null,g.grafia)),
React.createElement("td",{className:"mono-sm"},g.n),
React.createElement("td",null,React.createElement("select",{value:"",disabled:busy===g.grafia,"aria-label":'esporte de '+g.grafia,onChange:(e)=>{const v=e.target.value;if(!v)return;post('/api/admin/er/cadastros/esporte/apelido',{grafia:g.grafia,esporte:v==='__nao'?null:v},g.grafia);}},
React.createElement("option",{value:""},"escolher…"),React.createElement("option",{value:"__nao"},"não é esporte (categoria de aposta)"),
d.esportes.map((e)=>React.createElement("option",{key:e.code,value:e.code},e.name_pt))))
))
))),
marc.length>0&&React.createElement("details",{style:{fontSize:12.5,marginBottom:20}},React.createElement("summary",{style:{cursor:'pointer'}},"Marcadas como \"não é esporte\" (",marc.length,") — categoria de aposta, não pendência"),
React.createElement("div",{style:{marginTop:6,display:'flex',flexDirection:'column',gap:4}},marc.map((g)=>React.createElement("div",{key:g.grafia},React.createElement("b",null,g.grafia)," · ",g.n," cadastro(s) e jogo(s) ",React.createElement("button",{className:"btn-sm",disabled:busy===g.grafia,onClick:()=>post('/api/admin/er/cadastros/esporte/apelido',{grafia:g.grafia,remover:true},g.grafia)},"desfazer"))))
),

React.createElement("h3",{className:"sec-t"},"Esportes (",d.esportes.length,")"),
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:16}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Esporte"),React.createElement("th",null,"Tipo"),React.createElement("th",{title:"Confronto: jogo entre dois lados (mandante x visitante). Evento: corrida ou torneio, a aposta é em quem vence (F1, golfe) — o sistema não cria times a partir do nome."},"Formato do evento"),React.createElement("th",null,"Fonte das ligas"),React.createElement("th",null,"Ligas"),React.createElement("th",null,"Times"),React.createElement("th",null,"Jogos (30 dias)"),React.createElement("th",null,"Grafias reconhecidas"))),React.createElement("tbody",null,
d.esportes.map((e)=>React.createElement("tr",{key:e.code},
React.createElement("td",null,React.createElement("b",null,e.name_pt)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},e.code)),
React.createElement("td",{style:{fontSize:12.5}},e.tipo),

React.createElement("td",null,React.createElement("select",{value:e.formato||'confronto',disabled:busy==='fmt:'+e.code,"aria-label":'formato do evento de '+e.name_pt,onChange:(ev)=>post('/api/admin/er/cadastros/esporte/formato',{code:e.code,formato:ev.target.value},'fmt:'+e.code)},
React.createElement("option",{value:"confronto"},"confronto (A x B)"),React.createElement("option",{value:"evento"},"evento (corrida, torneio)")),e.formatoPor==='human'?React.createElement("span",{className:"mono-sm",style:{fontSize:10.5,marginLeft:4,color:'var(--on-surface-variant)'}},"você"):null),

React.createElement("td",{style:{fontSize:12.5}},e.fonteLigas?React.createElement("span",{style:{color:e.fonteLigas.tipo==='nenhuma'?'#a3402a':e.fonteLigas.tipo==='manual'?'#8a5410':'inherit'}},e.fonteLigas.nome,e.fonteLigas.ligas?` · ${e.fonteLigas.ligas} no catálogo`:'',e.fonteLigas.complemento?` · +${e.fonteLigas.complemento} complemento manual`:''):'—',e.fonteLigas&&e.fonteLigas.tipo!=='api'&&e.fonteLigas.tipo!=='tsdb'&&['esports','tennis','darts','snooker','cycling','golf','cricket','table_tennis','mma'].includes(e.code)&&React.createElement("button",{className:"btn-sm",style:{marginLeft:8},disabled:busy===e.code,title:"Traz a lista deste esporte do TheSportsDB numa chamada; a faxina converte o cadastro manual em vínculo ou complemento",onClick:()=>post('/api/admin/er/catalogo/tsdb/restaurar',{esporte:e.code},e.code)},"Restaurar TheSportsDB")),
React.createElement("td",{className:"mono-sm"},e.ligas),React.createElement("td",{className:"mono-sm"},e.times),React.createElement("td",{className:"mono-sm"},e.jogos),
React.createElement("td",{style:{fontSize:12,color:'var(--on-surface-variant)'}},e.apelidos.map((a)=>a.grafia+(a.por==='human'?' (você)':'')).join(' · '))
))
))),

React.createElement("h3",{className:"sec-t"},"Novo esporte"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Código curto em minúsculas (ex.: ",React.createElement("code",null,"darts"),", ",React.createElement("code",null,"table_tennis"),"), nome em português e se é coletivo (times) ou individual (jogadores, como tênis). Depois ligue as grafias das fontes a ele na lista de pendências."),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'center'}},
React.createElement("input",{id:"esp-novo-code",value:novo.code,onChange:(e)=>setNovo({...novo,code:e.target.value}),placeholder:"código",style:{padding:'7px 10px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:13,width:150}}),
React.createElement("input",{id:"esp-novo-nome",value:novo.nome,onChange:(e)=>setNovo({...novo,nome:e.target.value}),placeholder:"nome em português",style:{padding:'7px 10px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:13,width:220}}),
React.createElement("select",{id:"esp-novo-tipo",value:novo.tipo,onChange:(e)=>setNovo({...novo,tipo:e.target.value})},React.createElement("option",{value:"coletivo"},"coletivo"),React.createElement("option",{value:"individual"},"individual")),
React.createElement("button",{className:"btn-sm b-green",disabled:busy==='novo'||!novo.code.trim()||!novo.nome.trim(),onClick:async()=>{if(await post('/api/admin/er/cadastros/esporte/novo',novo,'novo'))setNovo({code:'',nome:'',tipo:'coletivo'});}},"Criar esporte")
)
);
}



function AreasSection({onClose}){
const{d,msg}=useCadastros(onClose);
const[filtro,setFiltro]=useState(''),[soUsadas,setSoUsadas]=useState(false);


const[abertas,setAbertas]=useState({}),[dentro,setDentro]=useState({});
const abrirArea=async(code)=>{
setAbertas((a)=>({...a,[code]:!a[code]}));
if(dentro[code])return;
try{const r=await fetch('/api/admin/er/areas/'+encodeURIComponent(code)+'/conteudo',{credentials:'include'});
const j=await r.json();setDentro((x)=>({...x,[code]:r.ok?j:{erro:j.error||'Erro'}}));}
catch(e){setDentro((x)=>({...x,[code]:{erro:e.message}}));}};
if(!d)return React.createElement("div",{style:{fontSize:13}},"Carregando…");
if(d.error)return React.createElement("div",{style:{fontSize:13}},d.pendente?'⏳ ':'❌ ',d.error);
const nomeTipo={mundo:'mundo',continente:'continente',nacao:'nação',pais:'país'};
const fn=normTxt(filtro);const todas=d.areas||[];
const areas=todas.filter((a)=>(!soUsadas||Number(a.ligas)+Number(a.times)>0||a.tipo!=='pais')&&(!fn||normTxt(a.name_pt+' '+a.code).includes(fn)));
const porTipo=todas.reduce((m,a)=>(m[a.tipo]=(m[a.tipo]||0)+1,m),{});
return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:14,maxWidth:920}},React.createElement("b",null,"Toda liga e todo time pertencem a uma área"),": Mundo › continente › país › nação esportiva. Estão cadastrados todos os ",porTipo.pais||0," países (ISO 3166), as ",porTipo.nacao||0," nações do Reino Unido, ",porTipo.continente||0," continentes e o Mundo. O jogo pertence à liga, e é pela liga que o time ganha área. A área de uma liga se corrige na aba ",React.createElement("b",null,"Ligas"),"."),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Sem área agora: ",React.createElement("b",null,d.semArea.ligas)," liga(s) e ",React.createElement("b",null,d.semArea.times)," time(s). O crawler preenche a cada 5 minutos pelo rótulo da liga e pelas ligas em que o time joga, e reconfere a área automática das ligas com a regra de hoje.",
d.preenchimento&&React.createElement("span",null," Última rodada: ",new Date(d.preenchimento.em).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}),", área em ",d.preenchimento.ligas," liga(s) e ",d.preenchimento.times," time(s)",d.preenchimento.revistas?`, ${d.preenchimento.revistas} liga(s) corrigida(s)`:'',d.preenchimento.erro?React.createElement("b",{style:{color:'var(--danger,#B3261E)'}}," · falhou em ",d.preenchimento.erro):'',".")),
React.createElement("h3",{className:"sec-t"},"Áreas (",todas.length,")"),
React.createElement("div",{style:{display:'flex',gap:10,alignItems:'center',flexWrap:'wrap',marginBottom:8}},
React.createElement("input",{id:"cad-area-filtro",value:filtro,onChange:(e)=>setFiltro(e.target.value),placeholder:"buscar área…",style:{padding:'7px 10px',border:'1px solid var(--line-2)',borderRadius:8,fontSize:13}}),
React.createElement("label",{style:{fontSize:12.5,display:'inline-flex',gap:6,alignItems:'center'}},React.createElement("input",{id:"cad-area-usadas",type:"checkbox",checked:soUsadas,onChange:(e)=>setSoUsadas(e.target.checked)}),"só países com liga ou time"),
React.createElement("span",{style:{fontSize:12,color:'var(--on-surface-variant)'}},"mostrando ",areas.length," de ",todas.length)
),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null),React.createElement("th",null,"Área"),React.createElement("th",null,"Tipo"),React.createElement("th",null,"Dentro de"),React.createElement("th",null,"Ligas"),React.createElement("th",null,"Times"))),React.createElement("tbody",null,
areas.map((a)=>{const cont=dentro[a.code];return React.createElement(React.Fragment,{key:a.code},
React.createElement("tr",null,
React.createElement("td",{style:{width:34}},Number(a.ligas||0)+Number(a.times||0)>0&&
React.createElement("button",{className:"btn-sm",style:{padding:'2px 8px'},onClick:()=>abrirArea(a.code),title:"ver as ligas desta área"},abertas[a.code]?'▾':'▸')),
React.createElement("td",null,React.createElement("b",null,a.name_pt)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},a.code)),
React.createElement("td",{style:{fontSize:12.5}},nomeTipo[a.tipo]||a.tipo),React.createElement("td",{className:"mono-sm"},a.pai||'—'),
React.createElement("td",{className:"mono-sm"},Number(a.ligas||0)),React.createElement("td",{className:"mono-sm"},Number(a.times||0))
),
abertas[a.code]&&React.createElement("tr",null,React.createElement("td",{colSpan:6,style:{background:'var(--surface-2,#f6f7f9)',padding:'10px 14px'}},
!cont?React.createElement("div",{style:{fontSize:12.5}},"Carregando…"):cont.erro?React.createElement("div",{style:{fontSize:12.5}},"❌ ",cont.erro):
!(cont.ligas||[]).length?React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"Nenhuma liga nesta área. Times: ",cont.times||0,"."):
React.createElement("div",null,
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:6}},cont.ligas.length," liga(s) e ",cont.times," time(s) nesta área. Liga sem id de catálogo é duplicata em potencial. A área se corrige na aba ",React.createElement("b",null,"Ligas"),"."),
React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))',gap:6}},
cont.ligas.map((l)=>React.createElement("div",{key:l.id,style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'6px 9px',fontSize:12.5,background:'var(--surface,#fff)'}},
React.createElement("div",null,React.createElement("b",null,l.display_name)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",l.id)),
React.createElement("div",{style:{color:'var(--on-surface-variant)'}},l.sport," · ",Number(l.jogos30||0)," jogo(s) em 30 dias · ",Number(l.catalogo)?'catálogo':'sem catálogo',l.area_por==='human'?' · área sua':'')
))
)
)
))
);})
)))
);
}




function FusoesRecentes({kind,titulo}){
const[d,setD]=useState(null),[aberto,setAberto]=useState(false),[msg,setMsg]=useState(''),[busy,setBusy]=useState(0);
const load=async()=>{try{const r=await fetch('/api/admin/er/fusoes?dias=14&kind='+encodeURIComponent(kind||''),{credentials:'include'});setD(await r.json());}catch(e){setD({error:e.message});}};
useEffect(()=>{if(aberto)load();},[aberto]);
const desfazer=async(f)=>{
if(!(await confirma(`Desfazer a fusão de "${f.de_nome}" em "${f.para_nome}"?\n\nO que era de "${f.de_nome}" volta para ele, e o par fica marcado como diferente: o automático não junta os dois de novo.`)))return;
setBusy(f.id);setMsg('');
try{const r=await fetch(`/api/admin/er/fusoes/${f.id}/desfazer`,{method:'POST',credentials:'include'});const j=await r.json();setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok)load();}
catch(e){setMsg('❌ '+e.message);}finally{setBusy(0);}};
const nomeTipo={team:'clube',player:'jogador',competition:'liga'};
const lista=d&&d.fusoes||[];
return React.createElement("details",{open:aberto,onToggle:(e)=>setAberto(e.currentTarget.open),style:{marginBottom:14,fontSize:13}},
React.createElement("summary",{style:{cursor:'pointer',fontWeight:600}},titulo," nos últimos 14 dias, com botão de desfazer"),
msg&&React.createElement("div",{className:"toast"},msg),
!d?React.createElement("div",{style:{marginTop:6}},"Carregando…"):d.error?React.createElement("div",{style:{marginTop:6}},"❌ ",d.error):!lista.length?React.createElement("div",{style:{marginTop:6,color:'var(--on-surface-variant)'}},"Nenhuma fusão com diário neste período. As fusões anteriores a 15/09 não têm diário e não podem ser desfeitas por aqui."):
React.createElement("div",{className:"tbl-wrap",style:{marginTop:8}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Quando"),React.createElement("th",null,"Tipo"),React.createElement("th",null,"Saiu"),React.createElement("th",null,"Ficou"),React.createElement("th",null,"Quem"),React.createElement("th",null))),React.createElement("tbody",null,
lista.map((f)=>React.createElement("tr",{key:f.id},
React.createElement("td",{className:"mono-sm"},new Date(f.feito_em).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})),
React.createElement("td",{style:{fontSize:12}},nomeTipo[f.kind]||f.kind),
React.createElement("td",null,f.de_nome," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",f.from_id)),
React.createElement("td",null,f.para_nome," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"#",f.to_id)),
React.createElement("td",{style:{fontSize:12}},String(f.por||'').startsWith('auto')?'automático':f.por),
React.createElement("td",null,f.desfeito_em?React.createElement("span",{style:{fontSize:12,color:'var(--on-surface-variant)'}},"desfeita"):React.createElement("button",{className:"btn-sm",disabled:busy===f.id,onClick:()=>desfazer(f)},"Desfazer"))
))
)))
);
}

function IdentidadesSection({onClose}){
const[q,setQ]=useState(''),[tipo,setTipo]=useState(''),[res,setRes]=useState(null);
const[sel,setSel]=useState(null),[raio,setRaio]=useState(null);
const[msg,setMsg]=useState(''),[busy,setBusy]=useState('');
const[alvoQ,setAlvoQ]=useState(''),[alvoRes,setAlvoRes]=useState(null),[modo,setModo]=useState(null);
const[sepSel,setSepSel]=useState({});
const[grafiaNova,setGrafiaNova]=useState(''),[grafiaEscopos,setGrafiaEscopos]=useState(null),[grafiaEscopo,setGrafiaEscopo]=useState('');
const[nomeLivre,setNomeLivre]=useState(''),[desf,setDesf]=useState(null);




const vezBusca=useRef({res:0,alvo:0});

const[buscando,setBuscando]=useState(false);
const buscar=async(termo,kind,setter,chave)=>{const n=++vezBusca.current[chave];const t=(termo||'').trim();if(chave==='res')setBuscando(false);if(t.length<2){setter(null);return;}
if(chave==='res')setBuscando(true);
try{const j=await leJson('/api/admin/er/buscar?q='+encodeURIComponent(t)+(kind||''));
if(n===vezBusca.current[chave])setter(j.resultados||[]);}
catch(e){if(e.status===401){onClose('relogin');return;}if(n===vezBusca.current[chave]){setter(null);setMsg('❌ Busca falhou: '+e.message);}}finally
{if(chave==='res'&&n===vezBusca.current[chave])setBuscando(false);}};

useEffect(()=>{vezBusca.current.res++;setRes(null);const t=setTimeout(()=>buscar(q,tipo?'&papel='+tipo:'',setRes,'res'),350);return()=>clearTimeout(t);},[q,tipo]);

useEffect(()=>{vezBusca.current.alvo++;setAlvoRes(null);const t=setTimeout(()=>buscar(alvoQ,sel?'&kind='+sel.kind:'',setAlvoRes,'alvo'),350);return()=>clearTimeout(t);},[alvoQ,sel&&sel.id]);


const abrir=async(e)=>{setSel(e);setRaio(null);setModo(null);setSepSel({});setAlvoQ('');setAlvoRes(null);
try{const j=await leJson('/api/admin/er/entidade/'+e.id);setRaio(j);if(j&&j.entidade)setSel((s)=>s&&s.id===e.id?{...s,display_name:j.entidade.display_name}:s);}
catch(err){if(err.status===401){onClose('relogin');return;}setRaio({error:err.message});}};
const recarregar=()=>{if(sel)abrir(sel);};
const fundir=async(destino)=>{
const tipoNome=escolhaEntidade.papelEntidade({...sel,...(raio&&raio.entidade||{})});
if(!(await confirma('Juntar "'+sel.display_name+'" ('+escolhaEntidade.rotuloEntidade({...sel,...(raio&&raio.entidade||{})})+') dentro de "'+destino.display_name+'" ('+escolhaEntidade.rotuloEntidade(destino)+')?\n\nOs apelidos e '+(sel.kind==='player'?'as odds':'os jogos')+' passam para o segundo '+tipoNome+'. A fusão fica registrada e pode ser desfeita em \"Clubes e jogadores juntados\", no topo desta guia.')))return;
setBusy('f');setMsg('');
try{const r=await fetch('/api/admin/er/fundir',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({de:sel.id,para:destino.id})});const j=await r.json();
setMsg(r.ok?'✅ "'+j.de+'" agora aponta para "'+j.para+'"'+(j.eventosFundidos?' — '+j.eventosFundidos+' jogo(s) duplicado(s) viraram um':'')+'.':'❌ '+(j.error||'Erro'));
if(r.ok){vezBusca.current.res++;vezBusca.current.alvo++;setModo(null);setQ('');setRes(null);setAlvoRes(null);abrir(destino);}
}catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};

const moverApelido=async(alias,escopo,destino)=>{
if(!(await confirma(escolhaEntidade.confirmaMover(alias,escopo,{...sel,...(raio&&raio.entidade||{})},destino))))return;
setBusy('a'+alias+'|'+escopo);setMsg('');


const corpo=sel.legacy_id&&destino.legacy_id?
{alias,escopo,de:sel.legacy_id,para:destino.legacy_id}:
{alias,escopo,de_entidade:sel.id,para_entidade:destino.id};
try{const r=await fetch('/api/admin/er/apelido/mover',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify(corpo)});const j=await r.json();
setMsg(r.ok?'✅ "'+alias+'" ('+(escopo||'sem escopo')+') agora é de "'+(j.para||destino.display_name)+'"'+(j.ficam?' — '+j.ficam+' linha(s) de "'+alias+'" em outros escopos ficaram aqui':'')+'.':'❌ '+(j.error||'Erro'));
if(r.ok){setModo(null);setAlvoQ('');recarregar();}
}catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};

const abrirGrafiaNova=async()=>{
if(modo==='grafia'){setModo(null);return;}
setModo('grafia');setGrafiaNova('');setGrafiaEscopos(null);setGrafiaEscopo('');
try{const r=await fetch('/api/admin/er/apelido/escopos/'+sel.id,{credentials:'include'});const j=await r.json();
const l=r.ok?j.escopos||[]:[];setGrafiaEscopos(l);setGrafiaEscopo(l[0]||'');if(!r.ok)setMsg('❌ '+(j.error||'Erro'));}catch(e){setMsg('❌ '+e.message);}};
const adicionarGrafia=async()=>{
if(!(await confirma('Gravar "'+grafiaNova.trim()+'" em '+grafiaEscopo+' como grafia de "'+sel.display_name+'" ('+escolhaEntidade.rotuloEntidade({...sel,...(raio&&raio.entidade||{})})+')?')))return;
setBusy('g');setMsg('');
try{const r=await fetch('/api/admin/er/apelido/adicionar',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({entity_id:sel.id,grafia:grafiaNova.trim(),escopo:grafiaEscopo})});const j=await r.json();
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setModo(null);setGrafiaNova('');recarregar();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};


const trocarNome=async(nome,origem)=>{
const novo=String(nome||'').trim();if(!novo)return;
if(!(await confirma('Trocar o nome de "'+sel.display_name+'" ('+escolhaEntidade.rotuloEntidade({...sel,...(raio&&raio.entidade||{})})+') para "'+novo+'"?\n\nFica como escolha sua: nenhuma regra automática troca este nome. Dá para desfazer no aviso.')))return;
setBusy('n');setMsg('');setDesf(null);
try{const r=await fetch('/api/admin/er/entidade/'+sel.id+'/nome',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({nome:novo,origem,esperado:raio&&raio.entidade&&raio.entidade.display_name||sel.display_name})});const j=await r.json();
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){if(j.desfazer)setDesf(j.desfazer);setModo(null);setNomeLivre('');recarregar();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
const desfazerNome=async()=>{const x=desf;setDesf(null);setMsg('');
try{const r=await fetch(x.url,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(x.body)});const j=await r.json();
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok)recarregar();}
catch(e){setMsg('❌ '+e.message);}};
const opcoesNome=raio&&raio.entidade?nomeExibicao.opcoesDeNome({atual:raio.entidade.display_name,provedores:raio.provedores,ids:raio.ids,apelidos:raio.apelidos}):[];
const separar=async()=>{
const ids=Object.keys(sepSel).filter((k)=>sepSel[k]).map(Number);
if(!ids.length)return setMsg('❌ marque os jogos que saem');

if(jogador||!sel.legacy_id){
const nomeNovo=await pergunta('Nome do cadastro novo para os '+ids.length+' jogo(s) marcados:',sel.display_name+' (2)');
if(!nomeNovo)return;
setBusy('s');setMsg('');
try{const r=await fetch('/api/admin/er/separar-registro',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({entity_id:sel.id,event_ids:ids,nome:nomeNovo})});const j=await r.json();
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setModo(null);setSepSel({});recarregar();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}
return;
}
const legIds=(raio&&raio.jogos||[]).filter((j)=>ids.includes(j.id)&&j.legacy_id).map((j)=>j.legacy_id);
if(legIds.length<ids.length)return setMsg('❌ '+(ids.length-legIds.length)+' jogo(s) marcado(s) são só do Player Props: para eles use "o outro clube já tem cadastro" ou o botão da liga');
const nome=await pergunta('Nome do cadastro novo para os '+legIds.length+' jogo(s) marcados:',sel.display_name+' (2)');
if(!nome)return;

const paisOrigem=escolhaEntidade.paisMostrado(raio&&raio.entidade);
const pais=await pergunta('País de "'+nome+'" (código de 3 letras, ex.: TUR, ou o nome):',paisOrigem);
if(pais===null)return;
if(!pais.trim())return setMsg('❌ diga o país do cadastro novo (nada foi gravado)');
setBusy('s');setMsg('');
try{const r=await fetch('/api/admin/er/separar',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({team_id:sel.legacy_id,event_ids:legIds,nome,pais:pais.trim()})});const j=await r.json();
setMsg(r.ok?'✅ "'+nome+'" criado com '+j.movidos+' jogo(s). Confira os apelidos: os que forem dele, mova aqui embaixo.':'❌ '+(j.error||'Erro'));
if(r.ok){setModo(null);setSepSel({});recarregar();}
}catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
const trocarTime=async(destino)=>{
const ids=Object.keys(sepSel).filter((k)=>sepSel[k]).map(Number);
if(!ids.length)return setMsg('❌ marque na lista de jogos os que são de "'+destino.display_name+'"');
if(!(await confirma('Os '+ids.length+' jogo(s) marcados saem de "'+sel.display_name+'" e passam para "'+destino.display_name+'" ('+escolhaEntidade.rotuloEntidade(destino)+'). Os dois ficam marcados como clubes diferentes. Confirmar?')))return;
setBusy('s');setMsg('');
try{const r=await fetch('/api/admin/er/jogos/trocar-time',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({event_ids:ids,de:sel.id,para:destino.id})});const j=await r.json();
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setModo(null);setSepSel({});setAlvoQ('');recarregar();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
const fmt=(x)=>{if(!x)return'—';const t=new Date(x);return isNaN(t.getTime())?'—':t.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});};

const ligasDoCadastro=(()=>{const m=new Map();for(const j of raio&&raio.jogos||[]){if(!j.competicao_id)continue;const x=m.get(j.competicao_id)||{id:j.competicao_id,nome:j.competicao,n:0};x.n++;m.set(j.competicao_id,x);}return[...m.values()].sort((a,b)=>b.n-a.n);})();
const separarLiga=async(l)=>{
const nome=await pergunta('Nome do OUTRO clube (o que joga '+l.nome+'), diferente de "'+sel.display_name+'" (ex.: o nome que a casa ou a ficha usa, ou com o país):\n\nOs '+l.n+' jogo(s) dessa liga saem de "'+sel.display_name+'" e vão para ele.','');
if(!nome||nome.trim().length<2)return;

const sem=(t)=>String(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
if(sem(nome)===sem(sel.display_name))return setMsg('❌ "'+nome.trim()+'" é o nome deste cadastro: dê ao outro clube um nome que o distinga (ex.: "'+sel.display_name+' (MYS)"). Dois cadastros com o mesmo nome puxam jogo um do outro.');
setBusy('s');setMsg('');
try{const r=await fetch('/api/admin/er/separar-liga',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({entity_id:sel.id,competition_id:l.id,nome:nome.trim()})});const j=await r.json();
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setModo(null);setSepSel({});recarregar();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
const Onde=({lista})=>!lista||!lista.length?React.createElement("span",{className:"mono-sm",style:{opacity:.5}},"sem odd ativa"):
React.createElement("span",{style:{display:'inline-flex',gap:4}},lista.map((o)=>React.createElement("span",{key:o,className:"mono-sm",style:{fontSize:10.5,padding:'1px 6px',borderRadius:99,background:o==='Player Props'?'#E8F0FE':'#E6F7F2',color:o==='Player Props'?'#1A4A8A':'#0B5C48'}},o)));
const Cartao=({e,onClick,cor})=>React.createElement("button",{key:e.id,className:"btn-sm"+(cor||''),onClick:onClick,style:{textAlign:'left',display:'block'}},
React.createElement("div",null,escolhaEntidade.iconeEntidade(e),e.display_name),

React.createElement("div",{className:"mono-sm",style:{opacity:.65,fontSize:11}},
escolhaEntidade.rotuloEntidade(e)," · ",e.kind==='player'?e.n_presencas||0:e.n_jogos||0," jogo(s) · ",e.n_apelidos||0," grafia(s)"
),
React.createElement("div",{style:{marginTop:3}},React.createElement(Onde,{lista:e.onde}))
);
const ent=raio&&raio.entidade;
const jogador=sel&&sel.kind==='player';
const papel=sel?escolhaEntidade.papelEntidade({...sel,...(ent||{})}):'';
return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg,desf&&React.createElement("button",{className:"btn-sm",style:{marginLeft:10},onClick:desfazerNome},desf.rotulo||'Desfazer')),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:12}},"Procure um clube ",
React.createElement("b",null,"ou um jogador")," para ver tudo que aponta para ele. Use quando uma odd parecer de outro time ou de outra pessoa."
),
React.createElement(FusoesRecentes,{kind:"identidades",titulo:"Clubes e jogadores juntados"}),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',marginBottom:14,flexWrap:'wrap'}},
React.createElement("input",{className:"inp",value:q,onChange:(e)=>setQ(e.target.value),placeholder:"Nome — ex.: Paris, Vasco, Haaland, Garuda",style:{maxWidth:420}}),
React.createElement("div",{style:{display:'flex',gap:6}},
[['','Tudo'],['clube','Clubes'],['jogador','Jogadores']].map(([k,r])=>
React.createElement("button",{key:k,className:"btn-sm"+(tipo===k?' b-green':''),onClick:()=>setTipo(k)},r))
)
),
res&&res.length>0&&React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:8,marginBottom:18}},
res.map((e)=>React.createElement(Cartao,{key:e.id,e:e,cor:sel&&sel.id===e.id?' b-green':'',onClick:()=>abrir(e)}))
),
buscando&&!res&&q.trim().length>=2&&React.createElement("div",{role:"status",style:{color:'var(--on-surface-variant)',fontSize:13.5,marginBottom:18}},"Buscando “",q.trim(),"”…"),
res&&res.length===0&&q.length>=2&&React.createElement("div",{style:{color:'var(--on-surface-variant)',fontSize:13.5,marginBottom:18}},"Ninguém com esse nome no registro."),

sel&&React.createElement("div",{style:{background:'#fff',border:'1px solid var(--line-2)',borderRadius:12,padding:'16px 18px'}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',gap:12,flexWrap:'wrap',alignItems:'baseline'}},
React.createElement("div",null,
React.createElement("h3",{className:"sec-t",style:{margin:0}},escolhaEntidade.iconeEntidade({...sel,...(ent||{})}),sel.display_name),
React.createElement("div",{className:"mono-sm",style:{color:'var(--on-surface-variant)',fontSize:12}},"entidade #",
sel.id," · ",papel,ent?comPonto(ROTULO_STATUS(ent.status)):'',escolhaEntidade.paisMostrado(ent)?' · '+escolhaEntidade.paisMostrado(ent):'',
jogador&&' · time: '+(ent&&ent.time_do_jogador||'não deduzido'),
!jogador&&(sel.legacy_id?' · tem cadastro no Super Odds':' · só no registro (nasceu do coletor de props)')
),
React.createElement("div",{style:{marginTop:4}},React.createElement(Onde,{lista:sel.onde})),

raio&&raio.nome&&React.createElement("div",{className:"mono-sm",style:{color:'var(--on-surface-variant)',fontSize:12,marginTop:4}},"nome · ",
raio.nome.por==='gente'?'escolha de gente (nenhuma regra troca)':'pela regra',
raio.nome.historico.length>0&&React.createElement("span",null," · histórico: ",raio.nome.historico.slice(0,4).map((h,i)=>React.createElement("span",{key:i},i?' · ':'',new Date(h.em).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})," \"",h.de||'—',"\"→\"",h.para||'—',"\" (",String(h.por||'').startsWith('auto')?'regra':h.por||h.kind,")")))
),

!jogador&&raio&&raio.pais&&React.createElement("div",{className:"mono-sm",style:{color:'var(--on-surface-variant)',fontSize:12,marginTop:4}},"país ",
raio.pais.area||escolhaEntidade.paisMostrado(ent)||'—'," · ",raio.pais.por==='gente'?'escolha de gente (o automático não troca)':'pela regra (ligas e ficha)',
raio.pais.historico.length>0&&React.createElement("span",null," · histórico: ",raio.pais.historico.slice(0,4).map((h,i)=>React.createElement("span",{key:i},i?' · ':'',new Date(h.em).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})," ",h.de||'—',"→",h.para||'—'," (",h.por||h.kind,")")))
)
),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap'}},
React.createElement("button",{className:"btn-sm",onClick:()=>{setModo(modo==='fundir'?null:'fundir');setAlvoQ('');}},"É a mesma pessoa/clube que…"),
React.createElement("button",{className:"btn-sm",onClick:()=>setModo(modo==='separar'?null:'separar')},jogador?'Separar presenças':'Separar jogos'),

React.createElement("button",{className:"btn-sm",disabled:!ent,title:!ent?'Carregando a ficha…':'Escolher o nome que a tela mostra',onClick:()=>{setModo(modo==='nome'?null:'nome');setNomeLivre('');}},"Trocar nome"),


!jogador&&React.createElement("button",{className:"btn-sm",disabled:busy==='p'||!ent,title:!ent?'Carregando a ficha…':'',onClick:async()=>{
if(!ent)return;
const v=await pergunta('País de "'+sel.display_name+'" (código de 3 letras, ex.: THA, ou o nome). Vazio devolve o país para a regra (ligas e ficha).',escolhaEntidade.paisMostrado(ent));
if(v===null)return;
const voltarRegra=!v.trim();
if(voltarRegra&&!(await confirma('Tirar o país escolhido de "'+sel.display_name+'"'+(escolhaEntidade.paisMostrado(ent)?' ('+escolhaEntidade.paisMostrado(ent)+')':'')+' e devolver para a regra (ligas e ficha)?')))return;
setBusy('p');setMsg('');
try{const r=await fetch('/api/admin/er/time/'+sel.id+'/pais',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({pais:v,voltarRegra})});const j=await r.json();
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok)recarregar();}catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}}},"País…")
)
),

modo==='fundir'&&React.createElement("div",{style:{marginTop:14,padding:14,background:'var(--surface-2,#f3f5f1)',borderRadius:8}},
React.createElement("div",{style:{fontSize:13.5,marginBottom:8}},"Este cadastro vira ponteiro para o que você escolher. Escolha o que ",React.createElement("b",null,"FICA"),":"),
React.createElement("input",{className:"inp",value:alvoQ,onChange:(e)=>setAlvoQ(e.target.value),placeholder:'Nome do '+papel+' que fica',style:{maxWidth:360}}),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:8,marginTop:10}},
(alvoRes||[]).filter((t)=>t.id!==sel.id).map((t)=>React.createElement(Cartao,{key:t.id,e:t,cor:" b-amber",onClick:()=>busy!=='f'&&fundir(t)}))
)
),

modo==='nome'&&ent&&React.createElement("div",{style:{marginTop:14,padding:14,background:'var(--surface-2,#f3f5f1)',borderRadius:8}},
React.createElement("div",{style:{fontSize:13.5,marginBottom:8}},"Qual nome fica? Hoje: ",React.createElement("b",null,ent.display_name),". O nome escolhido aparece em todas as telas (inclusive como candidato no Resolver) e fica como decisão sua: nenhuma regra automática troca. As grafias e os números não mudam."),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:6}},
opcoesNome.map((o)=>React.createElement("button",{key:o.nome,className:"btn-sm b-amber",disabled:busy==='n',onClick:()=>trocarNome(o.nome,o.origem),style:{textAlign:'left'}},"Fica \"",
o.nome,"\" ",React.createElement("span",{className:"mono-sm",style:{opacity:.65,fontSize:11}},"· ",o.origem))),
!opcoesNome.length&&React.createElement("span",{style:{fontSize:12,color:'var(--on-surface-variant)'}},"Nenhum número de provedor nem grafia com outro nome: escreva abaixo.")
),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:8,alignItems:'center',marginTop:10}},
React.createElement("input",{className:"inp",value:nomeLivre,onChange:(e)=>setNomeLivre(e.target.value),placeholder:"Ou escreva o nome",style:{maxWidth:320}}),
React.createElement("button",{className:"btn-sm b-green",disabled:busy==='n'||nomeLivre.trim().length<2,onClick:()=>trocarNome(nomeLivre,'digitado')},"Usar este nome")
)
),

modo==='separar'&&React.createElement("div",{style:{marginTop:14,padding:14,background:'var(--surface-2,#f3f5f1)',borderRadius:8}},

!jogador&&ligasDoCadastro.length>1&&React.createElement("div",{style:{marginBottom:12}},
React.createElement("div",{style:{fontSize:13.5,marginBottom:6}},React.createElement("b",null,"Dois clubes no mesmo cadastro?")," Escolha a liga do ",React.createElement("b",null,"outro")," clube e dê o nome dele. Os jogos dessa liga, as grafias que as casas usam nela e a cópia no Super Odds vão para o cadastro novo; os dois ficam marcados como clubes diferentes."),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:6}},ligasDoCadastro.map((l)=>React.createElement("button",{key:l.id,className:"btn-sm b-amber",disabled:busy==='s',onClick:()=>separarLiga(l)},"Os ",l.n," jogo(s) de ",l.nome," são de outro clube")))
),
React.createElement("div",{style:{fontSize:13.5,marginBottom:8}},jogador?React.createElement(React.Fragment,null,"Marque os jogos em que apareceu ",React.createElement("b",null,"OUTRA")," pessoa com este nome. As presenças e as odds desses jogos vão para um cadastro novo."):React.createElement(React.Fragment,null,"Ou marque na lista de jogos, um a um, os que ",React.createElement("b",null,"NÃO")," são deste clube. Eles vão para um cadastro novo.")),
React.createElement("button",{className:"btn-sm b-green",disabled:busy==='s',onClick:separar},"Separar marcados"),

!jogador&&React.createElement("div",{style:{marginTop:12}},
React.createElement("div",{style:{fontSize:13.5,marginBottom:6}},"O outro clube ",React.createElement("b",null,"já tem cadastro"),"? Procure-o e os jogos marcados passam para ele."),
React.createElement("input",{className:"inp",value:alvoQ,onChange:(e)=>setAlvoQ(e.target.value),placeholder:"Nome do clube que recebe os jogos",style:{maxWidth:360}}),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:8,marginTop:10}},
(alvoRes||[]).filter((t)=>t.id!==sel.id).map((t)=>React.createElement(Cartao,{key:t.id,e:t,cor:" b-amber",onClick:()=>busy!=='s'&&trocarTime(t)}))
)
)
),

React.createElement("h4",{style:{margin:'18px 0 6px',fontSize:14}},"Grafias (",(raio&&raio.apelidos||[]).length,") ",React.createElement("button",{className:"btn-sm b-green",style:{marginLeft:8},onClick:abrirGrafiaNova},"+ Grafia")),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Como as casas escrevem este nome. Se uma for de outro, mova — separar jogos não leva as grafias junto. O escopo diz ",

React.createElement("i",null,"onde")," a grafia vale (uma competição, um país, um elenco, um jogo)."
),

modo==='grafia'&&React.createElement("div",{style:{margin:'0 0 12px',padding:14,background:'var(--surface-2,#f3f5f1)',borderRadius:8}},
React.createElement("div",{style:{fontSize:13.5,marginBottom:8}},"Escreva como a casa escreve (ex.: ",React.createElement("i",null,"Galatasaray Women"),"). O texto é normalizado igual à leitura das casas; se a grafia já for de outro cadastro, nada é gravado e a resposta diz de quem é."),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:8,alignItems:'center'}},
React.createElement("input",{className:"inp",value:grafiaNova,onChange:(e)=>setGrafiaNova(e.target.value),placeholder:"Grafia nova",style:{maxWidth:280}}),
React.createElement("select",{className:"inp",value:grafiaEscopo,onChange:(e)=>setGrafiaEscopo(e.target.value),style:{maxWidth:320}},
(grafiaEscopos||[]).map((sc)=>React.createElement("option",{key:sc,value:sc},sc))
),
React.createElement("button",{className:"btn-sm b-green",disabled:busy==='g'||!grafiaNova.trim()||!grafiaEscopo,onClick:adicionarGrafia},"Adicionar")
),
grafiaEscopos&&!grafiaEscopos.length&&React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginTop:6}},"Este cadastro não tem país, liga nem jogo para a grafia valer: dê o país (País…) primeiro.")
),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Grafia"),React.createElement("th",null,"Escopo"),React.createElement("th",null,"Origem"),React.createElement("th",null))),React.createElement("tbody",null,
(raio&&raio.apelidos||[]).map((a,i)=>React.createElement("tr",{key:i},
React.createElement("td",null,React.createElement("b",null,a.alias_norm)),
React.createElement("td",{className:"mono-sm",style:{fontSize:11}},a.scope_key||'—'),
React.createElement("td",{className:"mono-sm",style:{fontSize:11}},a.created_by==='human'?'✍️ você':a.source||a.created_by||'auto',a.ambiguous?' · ambígua':''),
React.createElement("td",null,React.createElement("button",{className:"btn-sm",title:"Move só esta linha (grafia neste escopo)",onClick:()=>{const k='apelido:'+a.alias_norm+'|'+(a.scope_key||'');setModo(modo===k?null:k);setAlvoQ('');}},"Mover"),
modo==='apelido:'+a.alias_norm+'|'+(a.scope_key||'')&&React.createElement("div",{style:{marginTop:8}},
React.createElement("input",{className:"inp",value:alvoQ,onChange:(e)=>setAlvoQ(e.target.value),placeholder:jogador?'Para qual jogador? (nome ou #número)':'Para qual clube? (nome ou #número)',style:{maxWidth:280}}),
React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)',marginTop:4}},"Vai só \"",a.alias_norm,"\" em ",a.scope_key||'sem escopo',(()=>{const n=(raio.apelidos||[]).filter((b)=>b.alias_norm===a.alias_norm).length-1;return n>0?' — as outras '+n+' linha(s) desta grafia ficam':'';})(),"."),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:6,marginTop:6}},
(alvoRes||[]).filter((t)=>t.id!==sel.id).map((t)=>React.createElement(Cartao,{key:t.id,e:t,cor:" b-amber",onClick:()=>busy!=='a'+a.alias_norm+'|'+(a.scope_key||null)&&moverApelido(a.alias_norm,a.scope_key||null,t)})),
alvoQ.trim().length>=2&&alvoRes&&!alvoRes.filter((t)=>t.id!==sel.id).length&&React.createElement("span",{style:{fontSize:12,color:'var(--on-surface-variant)'}},"nenhum ",papel," com \"",alvoQ.trim(),"\" (dá para buscar pelo #número)")
))
)
)),
raio&&!(raio.apelidos||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:4,style:{color:'var(--on-surface-variant)'}},"Nenhuma grafia registrada."))
))),

!!(raio&&raio.ids||[]).length&&React.createElement(React.Fragment,null,
React.createElement("h4",{style:{margin:'18px 0 6px',fontSize:14}},"IDs das casas (",raio.ids.length,")"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"ID"),React.createElement("th",null,"Nome lá"))),React.createElement("tbody",null,
raio.ids.map((x,i)=>React.createElement("tr",{key:i},React.createElement("td",{className:"mono-sm"},x.source),React.createElement("td",{className:"mono-sm"},x.external_id),React.createElement("td",null,x.raw_name||'—')))
)))
),

jogador?
React.createElement(React.Fragment,null,
React.createElement("h4",{style:{margin:'18px 0 6px',fontSize:14}},"Jogos em que apareceu (",(raio&&raio.presencas||[]).length,")"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"É daqui que o time do jogador é deduzido: o time verdadeiro aparece em todos os jogos, cada adversário só num."),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,modo==='separar'&&React.createElement("th",null),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Quando"),React.createElement("th",null,"Odds"))),React.createElement("tbody",null,
(raio&&raio.presencas||[]).map((p)=>React.createElement("tr",{key:p.id},modo==='separar'&&React.createElement("td",null,React.createElement("input",{type:"checkbox",checked:!!sepSel[p.id],onChange:(ev)=>setSepSel((s)=>({...s,[p.id]:ev.target.checked}))})),React.createElement("td",null,p.home," x ",p.away),React.createElement("td",{className:"mono-sm"},fmt(p.kickoff_utc)),React.createElement("td",{className:"mono-sm"},p.odds||0))),
raio&&!(raio.presencas||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:3,style:{color:'var(--on-surface-variant)'}},"Nenhum jogo ainda."))
)))
):
React.createElement(React.Fragment,null,
React.createElement("h4",{style:{margin:'18px 0 6px',fontSize:14}},"Jogos (",(raio&&raio.jogos||[]).length,")"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,modo==='separar'&&React.createElement("th",null),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Liga"),React.createElement("th",null,"Quando"),React.createElement("th",null,"Onde"))),React.createElement("tbody",null,
(raio&&raio.jogos||[]).map((e)=>React.createElement("tr",{key:e.id},
modo==='separar'&&React.createElement("td",null,React.createElement("input",{type:"checkbox",checked:!!sepSel[e.id],onChange:(ev)=>setSepSel((s)=>({...s,[e.id]:ev.target.checked}))})),
React.createElement("td",null,e.home," x ",e.away),React.createElement("td",{style:{fontSize:12.5}},e.competicao||React.createElement("span",{style:{opacity:.5}},"sem liga")),React.createElement("td",{className:"mono-sm"},fmt(e.kickoff_utc)),
React.createElement("td",null,React.createElement(Onde,{lista:[e.legacy_id?'Super Odds':null,e.em_props?'Player Props':null].filter(Boolean)}))
)),
raio&&!(raio.jogos||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:5,style:{color:'var(--on-surface-variant)'}},"Nenhum jogo ainda."))
)))
),
raio===null&&React.createElement("div",{style:{color:'var(--on-surface-variant)',padding:12}},"Carregando…"),
raio&&raio.error&&React.createElement("div",{style:{color:'var(--red,#b00)',padding:12}},raio.error)
)
);
}





function FonteJogosPainel(){
const[d,setD]=useState(null),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
const load=async()=>{try{const r=await fetch('/api/admin/er/jogos-fonte',{credentials:'include'});setD(await r.json());}catch(e){setD({error:e.message});}};
useEffect(()=>{load();const t=setInterval(load,30000);return()=>clearInterval(t);},[]);
const troca=async(modo)=>{
if(!(await confirma(modo==='registro'?'Passar o Super Odds a ler os jogos do registro?\n\nPareamento das casas, Pinnacle e odd justa passam a usar o cadastro único, o mesmo do Player Props. O cadastro antigo continua recebendo cópia: dá para voltar a qualquer momento.':'Voltar o Super Odds para o cadastro antigo?')))return;
setBusy(true);setMsg('');
try{const r=await fetch('/api/admin/er/jogos-fonte',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({modo})});const j=await r.json();setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));load();}
catch(e){setMsg('❌ '+e.message);}finally{setBusy(false);}};
if(!d||d.error)return null;
const ev=d.evLote||{},m=d.matcher||{},pn=d.pinnacle||{};
const fmt=(x)=>x?new Date(x).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'—';
const erroNovo=m.erro&&new Date(m.erroEm||0)>new Date(m.okEm||0);
return React.createElement("div",{style:{marginBottom:22,border:'1px solid var(--line-2)',borderRadius:10,padding:'12px 14px'}},
React.createElement("h3",{className:"sec-t",style:{marginTop:0}},"De onde o Super Odds lê os jogos"),
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement("div",{style:{fontSize:13.5,marginBottom:6}},"Agora: ",React.createElement("b",null,d.modo==='registro'?'registro (cadastro único, o mesmo do Player Props)':'cadastro antigo do Super Odds'),d.desde?` · desde ${fmt(d.desde)}`:''),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8,maxWidth:900}},"Vale para o pareamento das casas, a sincronização da Pinnacle e a odd justa. Enquanto esta chave existir, o cadastro antigo continua recebendo cópia de todo jogo e time; por isso voltar é imediato e não perde nada."),
React.createElement("div",{style:{fontSize:12.5,marginBottom:8,lineHeight:1.6}},"Última volta do pareamento: ",
fmt(m.okEm)," · ",m.pareados??'—'," pareados · ",m.revisao??'—'," para revisão",erroNovo?React.createElement("b",{style:{color:'var(--danger,#B3261E)'}}," · erro: ",m.erro):'',React.createElement("br",null),
pn.em&&React.createElement(React.Fragment,null,"Última volta da Pinnacle: ",fmt(pn.em)," · ",pn.eventosPinnacle??'—'," jogos na casa · ",pn.canonicos??'—'," nossos · id copiado para o registro: ",Number(pn.copiadosPorLegado||0)," pelo cadastro antigo, ",Number(pn.copiadosPorTimes||0)," pelos times e horário",pn.erroCopia?React.createElement("b",{style:{color:'var(--danger,#B3261E)'}}," · erro na cópia: ",pn.erroCopia):'',React.createElement("br",null)),"Último cálculo de odd justa em lote: ",
fmt(ev.em)," · ",ev.comEv??'—'," odds com justa de ",ev.olhadas??'—'," olhadas",ev.modo?` (lendo ${ev.modo==='registro'?'o registro':'o cadastro antigo'})`:'',
d.estoque&&React.createElement(React.Fragment,null,React.createElement("br",null),"Agora: ",React.createElement("b",null,d.estoque.justas)," odds com odd justa de ",d.estoque.visiveis," visíveis · jogos com vínculo da Pinnacle: ",d.estoque.pinnacleRegistro," no registro, ",d.estoque.pinnacleLegado," no cadastro antigo",d.estoque.faltamNoRegistro?React.createElement("span",{style:{color:'#b45309'}}," · ",d.estoque.faltamNoRegistro," ainda faltam no registro (a troca deve esperar chegar a zero)"):' · nenhum faltando no registro')
),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap'}},
d.modo!=='registro'&&React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:()=>troca('registro')},"Usar o registro"),
d.modo==='registro'&&React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>troca('legado')},"Voltar para o cadastro antigo")
)
);
}


function VigiasPropsPainel(){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[v,setV]=useState(null),[erroV,setErroV]=useState(''),[cob,setCob]=useState(null),[erroCob,setErroCob]=useState('');
useEffect(()=>{let vivo=true,t;const ler=async()=>{try{await Promise.all([
leJson('/api/ev/estado').then((j)=>{if(vivo){setD(j);setErro('');}}).catch((e)=>{if(vivo)setErro(e.message);}),
leJson('/api/admin/vigias-props').then((j)=>{if(vivo){setV(j);setErroV('');}}).catch((e)=>{if(vivo)setErroV(e.message);}),
leJson('/api/admin/liq/cobertura/estado').then((j)=>{if(vivo){setCob(j);setErroCob('');}}).catch((e)=>{if(vivo)setErroCob(e.message);})]
);}finally{if(vivo)t=setTimeout(ler,30000);}};ler();return()=>{vivo=false;clearTimeout(t);};},[]);
const p=d&&d.tempos&&d.tempos.propsVolta,w=d&&d.tempos&&d.tempos.propsWorker,m=d&&d.tempos&&d.tempos.propsMotor;
const ret=p&&p.retrato,rit=p&&p.ritmo;
const atrasoProp=d&&d.tempos&&d.tempos.atrasoTela&&d.tempos.atrasoTela.prop;
const diagnosticoProp=d&&d.tempos&&d.tempos.atrasoProps;
const negativas=d&&d.tempos&&d.tempos.negativasCompactas;
const memoriaJogo=d&&d.memoriaMotor;
const histProps=m&&m.historicoJusta;
const rotuloOrigem={medidas:'Mudança de preço',trocasDeOrigem:'Troca de origem',semIdentidade:'Identidade indisponível',semHorario:'Horário indisponível',foraDaJanela:'Relógio fora da janela'};
const linhas=[['Partidas sem primeira montagem',p&&Number.isFinite(p.partidas)?Math.max(0,p.partidas-p.partidasNoCache):null],['Mudanças esperando há mais de 60 s',p&&p.pendentesMais60S],['Montagens que saíram da worker',w&&w.noProcesso],['Erros da worker desde a subida',w&&w.erros],['Montagens adiadas por falha da worker',w&&w.adiadas],['Falhas de leitura da Estatística',p&&p.estatistica&&p.estatistica.erros],['Falhas do retrato das props (gravar ou ler)',ret?ret.erros:null],['Falhas do histórico de justas das props',histProps&&histProps.erros],['Motor de props fora do ar',m?Number(!m.ligado):null],['Falhas de compactação das linhas de jogo',negativas&&negativas.ligada?negativas.erros:null],['Operações de memória dos jogos acima de 2 s',negativas&&negativas.ligada?negativas.lentas:null]];
return React.createElement("div",{style:{marginBottom:22}},React.createElement("h3",{className:"sec-t"},"Vigias das props · meta zero"),
React.createElement("div",{style:{fontSize:12.5,marginBottom:8}},"Atraso da mudança até o recálculo: ",p?Math.max(p.esperaMaxRapidasS||0,p.esperaMaxLentasS||0)+' s':'sem leitura',". Os contadores de erro valem desde a subida do motor."),
React.createElement("div",{style:{fontSize:12.5,marginBottom:8}},"Props, da alteração no banco à publicação no EV+ (",diagnosticoProp?'mesma cotação':'origem ainda sem diagnóstico',"): ",atrasoProp&&atrasoProp.n?atrasoProp.n+' alterações · mediana '+(atrasoProp.p50Ms/1000).toFixed(1)+' s · 90% até '+(atrasoProp.p90Ms/1000).toFixed(1)+' s · máximo '+(atrasoProp.maxMs/1000).toFixed(1)+' s':'ainda sem amostras de mudança de odd',"."),
diagnosticoProp&&React.createElement("details",{style:{fontSize:12.5,marginBottom:10}},React.createElement("summary",null,"Origem das alterações observadas nas props"),
React.createElement("div",null,diagnosticoProp.observadas," alterações observadas · ",diagnosticoProp.medidas," medidas · ",diagnosticoProp.trocasDeOrigem," trocas de fonte ou registro."),
React.createElement("div",{style:{color:diagnosticoProp.semIdentidade||diagnosticoProp.semHorario||diagnosticoProp.foraDaJanela?'#ad6a00':undefined}},"Sem identidade: ",diagnosticoProp.semIdentidade," · sem horário de alteração: ",diagnosticoProp.semHorario," · fora da janela do medidor: ",diagnosticoProp.foraDaJanela,"."),
React.createElement("ul",null,(diagnosticoProp.ultimas||[]).slice(-8).reverse().map((x,i)=>React.createElement("li",{key:String(x.em)+'|'+i},rotuloOrigem[x.tipo]||x.tipo,": ",x.depois&&x.depois.casa||x.depois&&x.depois.fonte||'cotação'," · ",x.antes&&x.antes.fonte," #",x.antes&&x.antes.selId," → ",x.depois&&x.depois.fonte," #",x.depois&&x.depois.selId,x.ms!=null?' · '+(x.tipo==='medidas'?'até a publicação: ':'idade registrada do preço: ')+(x.ms/1000).toFixed(1)+' s':'',x.confirmacaoMs!=null?' · confirmação: '+(x.confirmacaoMs/1000).toFixed(1)+' s':'')))
),
negativas&&React.createElement("div",{style:{fontSize:12.5,marginBottom:10}},"Jogos: ",negativas.ligada?(negativas.linhas||0)+' linhas negativas compactadas · '+((negativas.bytes||0)/1048576).toFixed(1)+' MiB em blocos · maior leitura de bloco '+(negativas.leituraMaxMs||0)+' ms'+(negativas.emCurso?' · compactando':''):'compactação das negativas desligada',". ",negativas.ultimoErro&&React.createElement("span",{style:{color:'#b91c1c'}},"Último erro: ",negativas.ultimoErro)),
memoriaJogo&&memoriaJogo.externaMb!=null&&React.createElement("div",{style:{fontSize:12.5,marginBottom:10}},"Motor dos jogos: heap ",memoriaJogo.heapMb," MiB · memória externa ",memoriaJogo.externaMb," MiB · RSS do processo ",memoriaJogo.rssProcessoMb," MiB (compartilhado entre as threads)."),
histProps&&React.createElement("div",{style:{fontSize:12.5,marginBottom:10}},"Histórico do CLV das props: ",histProps.mudancas," mudanças · ",histProps.confirmacoes==null?'confirmações ainda sem diagnóstico':histProps.confirmacoes+' confirmações de recálculo'," · ",histProps.pendentes||0," gravações pendentes. ",histProps.ultimoErro&&React.createElement("span",{style:{color:'#b91c1c'}},"Último erro: ",histProps.ultimoErro)),
erro&&React.createElement("div",{style:{color:'#b91c1c'}},"Não foi possível atualizar os vigias: ",erro),
erroV&&React.createElement("div",{style:{color:'#b91c1c'}},"Não foi possível ler os vigias do coletor: ",erroV),
erroCob&&React.createElement("div",{style:{color:'#b91c1c'}},"Não foi possível ler o estado da cobertura de liquidação: ",erroCob),
cob&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6,color:cob.falhas?'#b91c1c':'var(--on-surface-variant)'}},"Cobertura de liquidação: ",cob.falhas," falha(s) desde a subida · ",cob.rodando?'contagem em andamento':cob.consultas.length?'última contagem disponível nas Observações de liquidação':'ainda não solicitada',".",cob.ultimaFalha&&' Última falha: '+cob.ultimaFalha.erro),
p&&p.ultimoEm&&Date.now()-Date.parse(p.ultimoEm)>60000&&React.createElement("div",{style:{color:'#b91c1c'}},"A leitura da fila está atrasada: ",new Date(p.ultimoEm).toLocaleString('pt-BR'),"."),
p&&p.erro&&React.createElement("div",{style:{color:'#b91c1c'}},"Último erro do recálculo: ",p.erro),
m&&m.ultimoErro&&React.createElement("div",{style:{color:'#b91c1c'}},"Último erro do motor de props: ",m.ultimoErro),
p&&p.estatistica&&p.estatistica.ultimoErro&&React.createElement("div",{style:{color:'#b91c1c'}},"Último erro da Estatística: ",p.estatistica.ultimoErro),
w&&w.ultimoErro&&React.createElement("div",{style:{color:'#b91c1c'}},"Último erro da worker: ",w.ultimoErro),
ret&&ret.ultimoErro&&React.createElement("div",{style:{color:'#b91c1c'}},"Último erro do retrato das props: ",ret.ultimoErro),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("tbody",null,[...linhas,...(v&&v.itens||[]).map((x)=>[x.nome,x.n])].map(([nome,n])=>React.createElement("tr",{key:nome},React.createElement("td",null,nome),React.createElement("td",{style:{color:n==null?'var(--on-surface-variant)':n>0?'#b91c1c':'#15803d'}},n==null?'sem leitura':n)))))),
v&&React.createElement("details",{style:{fontSize:12,marginTop:6}},React.createElement("summary",null,"Detalhes dos vigias do coletor · ",new Date(v.geradoEm).toLocaleTimeString('pt-BR')),(v.itens||[]).map((x)=>React.createElement("div",{key:x.id,style:{marginTop:6}},React.createElement("b",null,x.nome),x.erro&&React.createElement("div",{style:{color:'#b91c1c'}},x.erro),(x.itens||[]).map((s,i)=>React.createElement("div",{key:i},s))))),
rit&&React.createElement("div",{style:{fontSize:12,marginTop:6}},"Ritmo (últimos ",rit.janelaMin," min): ",rit.montagensPorMin," montagens/min · banco ",rit.bancoMsPorMin," ms/min (",rit.bancoPct,"% do tempo) · ",rit.linhasLidasPorMin," linhas lidas/min · leitura da partida (mediana) ",rit.leituraMsMediana==null?'—':rit.leituraMsMediana+' ms'," · pausa entre montagens: ",p&&p.pausaMs," ms"),
ret&&React.createElement("div",{style:{fontSize:12,marginTop:6}},"Subida sem refazer tudo (retrato): ",ret.pasta?(ret.restauradoDe?ret.restauradas+' partidas restauradas do retrato de '+new Date(ret.restauradoDe).toLocaleTimeString('pt-BR')+' ('+ret.idadeS+' s)'+(ret.codigoIgual===false?' · código novo: refeitas no rodízio':''):'nada restaurado'+(ret.motivo?' ('+ret.motivo+')':''))+' · '+ret.gravacoes+' gravações'+(ret.bytes?' · '+(ret.bytes/1048576).toFixed(1)+' MiB em '+ret.ms+' ms':''):'desligado'+(ret.motivo?' ('+ret.motivo+')':''),". Mudança desde a leitura guardada vem pelos carimbos, como no motor que não parou.")
);
}


function criaLeituraSaude({ler,recebe,falha,carregando,agenda=setTimeout,desagenda=clearTimeout}){
let vivo=true,emVoo=null,controlador=null,proxima=null,prazoAtivo=null,pediuAgora=false;
const le=(agora=false,leve=true)=>{
if(!vivo)return Promise.resolve();
if(emVoo){if(agora)pediuAgora=true;return emVoo;}
if(proxima!==null){desagenda(proxima);proxima=null;}
const ctrl=new AbortController();controlador=ctrl;let expirou=false,intervalo=30000;
if(!leve)carregando(true);
const prazo=agenda(()=>{if(!vivo)return;expirou=true;falha('A leitura da Saúde não respondeu no prazo; o estado atual não foi confirmado.');ctrl.abort();},leve?15000:60000);
prazoAtivo=prazo;
const minha=Promise.resolve().then(async()=>{
try{
const j=await ler(agora,leve,ctrl.signal);
if(!vivo||ctrl.signal.aborted)return;
if(!j||!Array.isArray(j.checks)||!j.invariantes)throw new Error('A resposta da Saúde veio sem as checagens e o veredito.');
recebe(j,leve);intervalo=j.calculando?8000:30000;
}catch(e){if(vivo&&!expirou)falha(e.message||String(e));}finally
{
desagenda(prazo);if(prazoAtivo===prazo)prazoAtivo=null;if(emVoo===minha)emVoo=null;if(controlador===ctrl)controlador=null;
if(vivo){if(!leve)carregando(false);if(pediuAgora){pediuAgora=false;le(true,false);}else proxima=agenda(()=>{proxima=null;le(false,true);},intervalo);}
}
});
emVoo=minha;return minha;
};
return{le,fecha(){vivo=false;pediuAgora=false;if(proxima!==null)desagenda(proxima);if(prazoAtivo!==null)desagenda(prazoAtivo);controlador?.abort();}};
}
function saudeComFalhaDeLeitura(anterior,msg){
const p=anterior||{},id='crawler_execucoes',erro='Leitura automática da Saúde sem confirmação: '+msg;
const antes=(p.checks||[]).find((c)=>c.id===id)||{id,titulo:'Execuções do crawler: publicação, progresso e concorrência',explica:'O estado atual precisa de uma leitura confirmada.'};
const checks=[{...antes,n:null,erro,itens:[],base:null},...(p.checks||[]).filter((c)=>c.id!==id)];
const inv=p.invariantes||{total:1,violadas:[],erros:[],naoMedidas:[]};
return{...p,checks,aviso:erro,crawlerExecucoes:null,invariantes:{...inv,ok:false,violadas:(inv.violadas||[]).filter((c)=>c.id!==id),erros:[...(inv.erros||[]).filter((c)=>c.id!==id),{id,regra:antes.titulo,erro}]}};
}
function ConsistenciaPainel(){
const[d,setD]=useState(null),[abertos,setAbertos]=useState({}),[carregando,setCarregando]=useState(false);
const leitura=useRef(null),load=(agora)=>leitura.current?.le(agora,false);
useEffect(()=>{
const l=criaLeituraSaude({
ler:(agora,leve,signal)=>leJson('/api/admin/er/consistencia'+(leve?'?leve=1':agora?'?agora=1':''),{credentials:'include',signal,prazoMs:0}),
recebe:(j,leve)=>setD((p)=>({...(leve&&p||{}),...j,aviso:null})),
falha:(msg)=>setD((p)=>saudeComFalhaDeLeitura(p,msg)),carregando:setCarregando
});
leitura.current=l;l.le(false,false);
return()=>{l.fecha();if(leitura.current===l)leitura.current=null;};
},[]);
const pill=(bg,cor,txt)=>React.createElement("span",{style:{background:bg,color:cor,borderRadius:999,padding:'2px 9px',fontWeight:700,fontSize:12,whiteSpace:'nowrap'}},txt);
const selo=carimboSaude.seloSaude(d);
const F=d&&d.faxina;
return React.createElement("div",{style:{marginBottom:22}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'baseline',gap:10,flexWrap:'wrap'}},
React.createElement("h3",{className:"sec-t"},"Consistência dos dados ",selo.texto),
React.createElement("button",{className:"btn-sm",disabled:carregando,onClick:()=>load(true)},carregando?'Verificando…':'Verificar agora')
),

d&&(()=>{const c=carimboSaude.carimboVerificacao(d,Date.now(),(x)=>new Date(x).toLocaleTimeString('pt-BR'));return c.texto?React.createElement("div",{style:{fontSize:12.5,fontWeight:600,marginBottom:6,color:c.atrasada?'#b91c1c':'var(--on-surface)'}},c.texto):null;})(),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Cada linha é uma regra que o dado nunca pode violar. O número tem de ficar em zero; quando não fica, os exemplos dizem onde olhar. É aqui que um erro novo aparece antes de chegar na tela de odds."),



d&&d.invariantes&&React.createElement("div",{style:{border:'1px solid var(--line-2)',borderLeft:'4px solid '+(d.invariantes.ok===null?'var(--line-2)':d.invariantes.ok?'#15803d':'#b45309'),borderRadius:8,padding:'10px 12px',marginBottom:10,background:'var(--surface,#fff)'}},
React.createElement("div",{style:{fontWeight:700,fontSize:13.5,marginBottom:2}},
d.invariantes.ok===null?'Invariantes: primeiro cálculo em andamento':
d.invariantes.ok?`✓ Sistema íntegro: as ${d.invariantes.total} invariantes estão em zero`:
`⚠ ${d.invariantes.violadas.length} de ${d.invariantes.total} invariantes violadas`
),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"Invariante é o que o dado nunca pode violar, diferente da fila do Resolver, que pode ter número sem nada estar errado."),
(d.invariantes.violadas||[]).length>0&&React.createElement("div",{style:{marginTop:6,display:'flex',flexDirection:'column',gap:3}},
d.invariantes.violadas.map((v)=>React.createElement("div",{key:v.id,style:{fontSize:12.5}},React.createElement("b",null,v.n)," · ",v.regra," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},v.id)))
),
(d.invariantes.erros||[]).length>0&&React.createElement("div",{style:{marginTop:6,fontSize:12.5,color:'#b91c1c'}},d.invariantes.erros.length," checagem(ns) falhando: ",d.invariantes.erros.map((e)=>e.id).join(', ')),
(d.invariantes.naoMedidas||[]).length>0&&React.createElement("div",{style:{marginTop:4,fontSize:12,color:'var(--on-surface-variant)'}},"ainda sem medida: ",d.invariantes.naoMedidas.join(', '))
),
F&&React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginBottom:8}},"Última faxina (limpeza automática a cada 10 min; o Verificar agora não a roda), começou ",new Date(F.em).toLocaleString('pt-BR')," · ",Math.round(F.duracaoMs/1000)," s",F.erros&&F.erros.length?React.createElement("span",{style:{color:'#b91c1c'}}," · ",F.erros.length," erro(s): ",F.erros.join(' | ')):' · sem erro',d.faxinaRodando?` · outra faxina rodando desde ${new Date(d.faxinaRodando.desde).toLocaleTimeString('pt-BR')}`:''),
d&&(d.fusoesRecentes||[]).length>0&&React.createElement("details",{style:{fontSize:12.5,marginBottom:8}},React.createElement("summary",{style:{cursor:'pointer'}},"Clubes juntados automaticamente nos últimos 7 dias (",d.fusoesRecentes.length,")"),
React.createElement("div",{style:{marginTop:4,display:'flex',flexDirection:'column',gap:2}},d.fusoesRecentes.map((x,i)=>React.createElement("div",{key:i},React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},new Date(x.em).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}))," ",x.texto))),
React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginTop:4}},"Se algum estiver errado, desfaça em Identidades, \"Clubes e jogadores juntados\" (fusões a partir de 15/09). O par desfeito não é juntado de novo pelo automático.")),
d&&d.calculando&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6}},"Recalculando por trás… a tela atualiza sozinha."),
d&&d.aviso?React.createElement("div",{style:{fontSize:13,marginBottom:6}},"⚠️ ",d.aviso,d.calculando?` · tentando de novo (${d.tentativa}ª vez)`:' · parei de tentar: clique em Verificar agora'):null,
!d?React.createElement("div",{style:{fontSize:13}},"Verificando…"):d.erro?React.createElement("div",{style:{fontSize:13}},"❌ ",d.erro):!d.checks?React.createElement("div",{style:{fontSize:13}},"Primeiro cálculo em andamento (leva alguns minutos depois de o painel reiniciar)."):
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("tbody",null,d.checks.map((c)=>React.createElement(React.Fragment,{key:c.id},
React.createElement("tr",null,
React.createElement("td",{style:{width:84}},c.erro?pill('rgba(200,40,40,.12)','#b91c1c','erro'):c.n>0?pill('rgba(180,120,20,.14)','#b45309','⚠ '+c.n):pill('rgba(20,140,80,.12)','#15803d','ok')),
React.createElement("td",null,React.createElement("b",null,c.titulo),React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},c.explica),c.erro&&React.createElement("div",{style:{fontSize:12,color:'#b91c1c'}},c.erro)),
React.createElement("td",{style:{width:120,textAlign:'right'}},(c.itens||[]).length>0&&React.createElement("button",{className:"btn-sm",onClick:()=>setAbertos((a)=>({...a,[c.id]:!a[c.id]}))},abertos[c.id]?'Esconder':'Ver exemplos'))
),
abertos[c.id]&&React.createElement("tr",null,React.createElement("td",null),React.createElement("td",{colSpan:2,style:{fontSize:12.5}},c.itens.map((x,i)=>React.createElement("div",{key:i,style:{padding:'2px 0'}},x))))
))))),
d&&d.geradoEm&&React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)',marginTop:4}},"Verificado ",new Date(d.geradoEm).toLocaleString('pt-BR'),d.daSubidaAnterior?' · resultado guardado antes do último reinício do painel; o cálculo novo substitui quando terminar':''),

d&&d.guardada&&d.guardada.falhas>0&&React.createElement("div",{style:{fontSize:11.5,color:'#b91c1c',marginTop:2}},"Guardar a Saúde no banco falhou ",d.guardada.falhas,"× (última: ",d.guardada.ultimaFalha&&d.guardada.ultimaFalha.etapa," — ",d.guardada.ultimaFalha&&d.guardada.ultimaFalha.erro,"); um reinício volta a \"sem medida\".")
);
}



function VarreduraPainel(){
const[d,setD]=useState(null),[carregando,setCarregando]=useState(false),[aberta,setAberta]=useState({});
const rodar=async()=>{setCarregando(true);try{const r=await fetch('/api/admin/er/auditoria/varredura',{credentials:'include'});const j=await r.json();setD(r.ok?j:{erro:j.error||'HTTP '+r.status});}catch(e){setD({erro:e.message});}finally{setCarregando(false);}};
const T=d&&d.totais;
return React.createElement("div",{style:{marginBottom:22}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'baseline',gap:10,flexWrap:'wrap'}},
React.createElement("h3",{className:"sec-t"},"Varredura por área e por liga ",T?T.alertas?`⚠️ ${T.alertas}`:'✓':''),
React.createElement("button",{className:"btn-sm",disabled:carregando,onClick:rodar},carregando?'Varrendo…':d?'Varrer de novo':'Varrer agora')
),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Abre toda área e toda liga com jogo nos últimos 45 dias e mostra só o que destoa: liga sem catálogo, duas ligas com o mesmo nome, liga cujos clubes são de outro país, jogo entre clubes de fora e o mesmo confronto cadastrado duas vezes. Leva alguns segundos."),
!d?null:d.erro?React.createElement("div",{style:{fontSize:13}},"❌ ",d.erro):React.createElement(React.Fragment,null,
React.createElement("div",{style:{fontSize:13,marginBottom:6}},T.areasComJogos," áreas · ",T.ligasComJogos," ligas · ",React.createElement("b",null,d.areasLimpas)," áreas limpas · ",T.areasComAlerta," com alerta · ",T.jogosDuplicados," jogo(s) repetido(s)"),
(d.jogosDuplicados||[]).length>0&&React.createElement("div",{style:{fontSize:12.5,marginBottom:8}},React.createElement("b",null,"Jogos repetidos")," (a faxina junta sozinha): ",d.jogosDuplicados.map((j,i)=>React.createElement("div",{key:i},j.texto))),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("tbody",null,d.areas.map((a)=>React.createElement(React.Fragment,{key:a.area},
React.createElement("tr",null,
React.createElement("td",{style:{width:84}},React.createElement("span",{style:{background:'rgba(180,120,20,.14)',color:'#b45309',borderRadius:999,padding:'2px 9px',fontWeight:700,fontSize:12}},"⚠ ",a.alertas.length)),
React.createElement("td",null,React.createElement("b",null,a.nome)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},a.area," · ",a.ligas," liga(s)")),
React.createElement("td",{style:{width:120,textAlign:'right'}},React.createElement("button",{className:"btn-sm",onClick:()=>setAberta((x)=>({...x,[a.area]:!x[a.area]}))},aberta[a.area]?'Esconder':'Abrir'))
),
aberta[a.area]&&React.createElement("tr",null,React.createElement("td",null),React.createElement("td",{colSpan:2,style:{fontSize:12.5}},a.alertas.map((x,i)=>React.createElement("div",{key:i,style:{padding:'2px 0'}},x))))
)))))
)
);
}

function RegistroSection({onClose}){
const[d,setD]=useState(null),[busy,setBusy]=useState(''),[msg,setMsg]=useState(''),[pp,setPp]=useState(null);
const[lg,setLg]=useState(null);
const[sim,setSim]=useState(null);
const load=async()=>{try{const r=await fetch('/api/admin/er/report',{credentials:'include'});if(r.status===401){onClose('relogin');return;}setD(await r.json());}catch(e){setD({pronto:false,motivo:e.message});}
try{const r2=await fetch('/api/admin/er/props',{credentials:'include'});if(r2.ok)setPp(await r2.json());}catch(e){}
try{const r3=await fetch('/api/admin/er/ligas',{credentials:'include'});if(r3.ok)setLg(await r3.json());}catch(e){}
try{const r4=await fetch('/api/admin/er/similaridade',{credentials:'include'});if(r4.ok)setSim(await r4.json());}catch(e){}};
useEffect(()=>{load();},[]);

const separar=async(c,pais,evs)=>{const nome=await pergunta(`Nome do clube novo para os ${evs.length} eventos de ${pais}:\n`+evs.map((e)=>'• '+e.nome).join('\n'),`${c.nome} (${pais})`);if(!nome)return;setBusy(c.id+pais);setMsg('');try{const r=await fetch('/api/admin/er/separar',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({team_id:c.id,event_ids:evs.map((e)=>e.id),nome,pais})});const j=await r.json();if(!r.ok){setMsg('❌ '+(j.error||'Erro'));}else{setMsg(`✅ ${nome} criado (#${j.novoLegacy}) — ${j.movidos} eventos movidos, escopos: ${(j.escopos||[]).join(', ')}. O relatório atualiza no próximo ciclo do crawler.`);}}catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
if(d===null)return React.createElement("div",{style:{textAlign:'center',padding:48,color:'var(--on-surface-variant)'}},"Carregando…");
if(!d.pronto)return React.createElement("div",{className:"empty",style:{padding:40}},React.createElement("div",{className:"em-ic"},React.createElement(Ic,{n:"database"})),React.createElement("div",{className:"em-t"},"Registro ainda não disponível"),React.createElement("div",null,d.motivo));
const L=d.legado||{},R=d.registro||{},A=d.amostras||{};
const fmt=(x)=>{if(!x)return'—';const t=new Date(x);return isNaN(t.getTime())?'—':t.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});};
const Card=({l,v,sub,warn})=>React.createElement("div",{style:{background:'#fff',border:'1px solid var(--line-2)',borderRadius:10,padding:'10px 18px',minWidth:120}},React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)'}},l),React.createElement("div",{style:{fontSize:20,fontWeight:700,color:warn&&Number(v)>0?'#b45309':'inherit'}},v==null?'—':v),sub&&React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},sub));
const pct=(a,b)=>b?Math.round(100*a/b)+'%':'—';
return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement(FonteJogosPainel,null),
React.createElement(ConsistenciaPainel,null),
React.createElement(VarreduraPainel,null),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginBottom:12}},React.createElement("b",null,"Isto é termômetro, não tarefa.")," O que precisa de você está na aba ",React.createElement("b",null,"Resolver"),"; aqui é só para ver se o pareamento está melhorando ou piorando. A única exceção é a tabela de conflito de país, que aparece raramente e traz o botão de conserto junto."),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:12}},"Gerado ",fmt(d.geradoEm)," · o crawler recalcula no boot e a cada 6h. Fase 1 do ADR-001: nada aqui altera pareamento ainda — é a medição do problema e a cópia do legado para o registro novo."),
(()=>{const V=d.live||{};
const auto=Number(V.decisoesAuto7d||0),corr=Number(V.correcoesHumanas7d||0);
const taxa=auto?100*corr/auto:null;
const alerta=Number(V.partidasDuplicadas||0)>0||Number(V.revisaoMaisVelhaH||0)>72;
return React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{className:"sec-t"},"Está errando? ",alerta?'⚠️':''),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Até agora este painel media ",
React.createElement("i",null,"volume")," — quantos pareamentos e por qual caminho —, nunca ",React.createElement("b",null,"erro"),". O proxy honesto de erro é a ",
React.createElement("b",null,"correção humana"),": toda vez que você move um apelido, funde, separa ou desamarra, o automático tinha errado. Se essa taxa sobe, a qualidade caiu; se cai, melhorou."

),
React.createElement("div",{style:{display:'flex',gap:12,flexWrap:'wrap'}},
React.createElement(Card,{l:"Correções humanas (7d)",v:taxa==null?'—':taxa.toFixed(3)+'%',sub:`${corr} em ${auto.toLocaleString('pt-BR')} decisões — acompanhe a TENDÊNCIA, não o número`}),
React.createElement(Card,{l:"Desamarrações automáticas (7d)",v:V.desamarrasAuto7d,warn:Number(V.desamarrasAuto7d||0)>200,sub:"o próprio sistema desfez uma amarração por id — não é correção sua"}),
React.createElement(Card,{l:"Grafias marcadas ambíguas",v:V.aliasAmbiguos,sub:"disputadas por 2 donos: não resolvem sozinhas"}),
React.createElement(Card,{l:"Mesmo jogo com 2 partidas de props",v:pp&&pp.live?pp.live.partidasDuplicadas:null,warn:true,sub:"contradição pura — tem de ser zero"}),
React.createElement(Card,{l:"Caso mais antigo na fila",v:V.revisaoMaisVelhaH==null?'—':V.revisaoMaisVelhaH+'h',warn:Number(V.revisaoMaisVelhaH||0)>72,sub:"acima de 72h a fila parou de ser trabalhada"})
)
);})(),

sim&&sim.total&&Number(sim.total.pares)>0&&React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{className:"sec-t"},"As duas medidas de semelhança, lado a lado"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:10}},"O Super Odds e o Player Props decidem \"estes dois nomes são o mesmo clube\" com contas diferentes. Trocar uma pela outra no escuro mudaria o pareamento automático de tudo de uma vez, então as duas rodam sobre o mesmo par, ",
React.createElement("b",null,"só a decisão de sempre vale"),", e o que sai diferente fica registrado aqui. É medição, não tarefa."
),
React.createElement("div",{style:{display:'flex',gap:10,flexWrap:'wrap',marginBottom:10}},
React.createElement(Card,{l:"Pares observados",v:sim.total.pares}),
React.createElement(Card,{l:"Pares em que discordam",v:sim.total.pares_discordantes,warn:true}),
React.createElement(Card,{l:"Vezes que isso aconteceu",v:sim.total.ocorrencias_discordantes,sub:`de ${sim.total.ocorrencias}`})
),
(sim.porFaixa||[]).length>0&&React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10}},
sim.porFaixa.map((f,i)=>React.createElement("span",{key:i,className:"mono-sm",style:{fontSize:11.5,padding:'3px 9px',borderRadius:99,background:'var(--surface-2,#f3f5f1)'}},"Super Odds diria ",React.createElement("b",null,f.faixa_tokenset)," · Props diria ",React.createElement("b",null,f.faixa_dice)," — ",f.n,"x"))
),
React.createElement("div",{style:{overflowX:'auto'}},React.createElement("table",{className:"tbl",style:{fontSize:12.5}},
React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Par comparado"),React.createElement("th",null,"Super Odds"),React.createElement("th",null,"Props"),React.createElement("th",null,"Decidiriam"),React.createElement("th",null,"Vezes"))),
React.createElement("tbody",null,(sim.linhas||[]).slice(0,40).map((x,i)=>React.createElement("tr",{key:i,style:x.discordam?{background:'#fff7ed'}:null},
React.createElement("td",{className:"mono-sm"},x.par),
React.createElement("td",{style:{textAlign:'right'}},Number(x.nota_tokenset).toFixed(3)),
React.createElement("td",{style:{textAlign:'right'}},Number(x.nota_dice).toFixed(3)),
React.createElement("td",null,x.discordam?React.createElement("b",null,x.faixa_tokenset," x ",x.faixa_dice):'igual'),
React.createElement("td",{style:{textAlign:'right'}},x.n)
)))
))
),

lg&&React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{className:"sec-t"},"Dicionário de ligas — aprendido sozinho"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"O apelido de um time vale ",
React.createElement("b",null,"dentro de uma liga"),". Como cada fonte escreve a liga do seu jeito (\"World / Brazil / Serie B\" x \"brasileirao-serie-b\"), os dois lados aprendiam em escopos que nunca se encontravam — e o clube era clonado. Ninguém escreve este dicionário à mão: quando um jogo fecha pelo par de times + horário, o sistema conclui que aquele rótulo ",


React.createElement("b",null,"é")," aquela competição e guarda. Rótulo disputado por duas competições fica marcado e não vale como dicionário."

),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Rótulo da fonte"),React.createElement("th",null,"É esta competição"),React.createElement("th",null,"País"),React.createElement("th",null,"Jogos"),React.createElement("th",null))),React.createElement("tbody",null,
(lg.aprendidas||[]).map((r,i)=>React.createElement("tr",{key:i},
React.createElement("td",{className:"mono-sm"},r.alias_norm),
React.createElement("td",null,r.display_name,React.createElement("div",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},r.canonical_key)),
React.createElement("td",{className:"mono-sm"},r.country||'—'),React.createElement("td",{className:"mono-sm"},r.jogos),
React.createElement("td",null,Number(r.ambiguous)?React.createElement("b",{style:{color:'#b45309'}},"disputado"):r.created_by==='human'?'✍️ você':'auto')
)),
!(lg.aprendidas||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:5,style:{color:'var(--on-surface-variant)'}},"Ainda nada aprendido — aparece assim que o primeiro jogo de cada liga fechar pelo par de times."))
))),
!!(lg.semVinculo||[]).length&&React.createElement(React.Fragment,null,
React.createElement("h4",{style:{margin:'14px 0 6px',fontSize:14}},"Ligas ainda sem vínculo (",lg.semVinculo.length,")"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Partidas dos últimos 2 dias que não acharam o jogo no registro. É daqui que sai time provisório — cada liga some desta lista assim que um jogo dela fechar."),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:8}},
lg.semVinculo.map((x,i)=>React.createElement("span",{key:i,className:"mono-sm",style:{fontSize:11.5,padding:'3px 9px',borderRadius:99,background:'var(--surface-2,#f3f5f1)'}},x.league," · ",x.n))
)
)
),

React.createElement("h3",{className:"sec-t"},"Dano do apelido global (legado em produção)"),
React.createElement("div",{style:{display:'flex',gap:12,flexWrap:'wrap',marginBottom:16}},
React.createElement(Card,{l:"Times",v:L.times}),React.createElement(Card,{l:"Apelidos",v:L.aliases,sub:`${L.aliasesHumanos||0} humanos`}),React.createElement(Card,{l:"Eventos",v:L.eventos}),
React.createElement(Card,{l:"Times com país conflitante",v:L.timesComPaisConflitante,warn:true,sub:"1 id absorvendo clubes de países diferentes"}),
React.createElement(Card,{l:"Nomes genéricos de 1 token",v:L.genericosDeUmToken,warn:true,sub:"colisão esperando acontecer"}),
React.createElement(Card,{l:"Apelidos que são o jogo inteiro",v:L.stringsDeJogo,warn:true,sub:"bug da aplicação de revisão"}),
React.createElement(Card,{l:"Times sem país inferível",v:L.timesSemPais,sub:pct(L.timesSemPais,L.times)+' do total'})
),
(d.resolucao7d||[]).length>0&&React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{className:"sec-t"},"Resolução por fonte — últimos 7 dias (fase 3: ID antes de nome)"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"\"Por ID\" = a fonte já tinha id amarrado no registro (zero string). Meta do ADR: ≥ 90% por ID nas fontes que dão id. Casa sem id na URL só resolve por nome."),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Total"),React.createElement("th",null,"Por ID"),React.createElement("th",null,"% ID"),React.createElement("th",null,"Apelido"),React.createElement("th",null,"Scoring"),React.createElement("th",null,"Revisão"),React.createElement("th",null,"Novo"),React.createElement("th",null,"Clube novo"),React.createElement("th",{title:"Jogo achado pelo lado que resolveu, com o nome do outro provado pelas grafias do adversário (issue #75)"},"Lado conhecido"),React.createElement("th",null,"Ambíguo"))),React.createElement("tbody",null,
d.resolucao7d.map((r)=>React.createElement("tr",{key:r.source},React.createElement("td",{className:"mono-sm"},r.source),React.createElement("td",null,r.total),React.createElement("td",null,r.porId),React.createElement("td",null,React.createElement("b",{style:{color:r.pctId>=90?'var(--ok,#2f6b3a)':r.pctId>=50?'#b45309':'inherit'}},r.pctId,"%")),React.createElement("td",null,r.alias),React.createElement("td",null,r.scoring),React.createElement("td",null,r.review),React.createElement("td",null,r.novo),React.createElement("td",null,r.timeNovo||0),React.createElement("td",null,r.ladoConhecido||0),React.createElement("td",null,r.ambiguo)))
))),
d.crosswalk&&React.createElement("div",{style:{display:'flex',gap:12,flexWrap:'wrap',marginTop:10}},
(d.crosswalk.eventosPorFonte||[]).map((x)=>React.createElement(Card,{key:'e'+x.source,l:`Eventos amarrados · ${x.source}`,v:x.n})),
(d.crosswalk.timesPorFonte||[]).map((x)=>React.createElement(Card,{key:'t'+x.source,l:`Times amarrados · ${x.source}`,v:x.n})),
d.crosswalk.propsMatchLigadas&&React.createElement(Card,{l:"Partidas de props ligadas ao registro (24h)",v:`${d.crosswalk.propsMatchLigadas.ligadas||0} / ${d.crosswalk.propsMatchLigadas.total||0}`})
)
),
pp&&pp.pronto&&(()=>{const J=pp.jogadores||{},P=pp.partidas||{},LV=pp.live||{};return React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{className:"sec-t"},"Jogadores dos Player Props (fase 4)"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Medido pelo COLETOR (é ele que tem o algoritmo) e gravado a cada 10 min — ",fmt(pp.geradoEm),". O jogador agora é entidade do registro, com apelido escopado nos dois elencos da partida: nome ambíguo abre revisão em vez de fundir. O time do jogador não vem de nenhuma fonte — sai da interseção das partidas em que ele aparece. ",React.createElement("b",null,"[12/09]")," A identidade do jogador passou a sobreviver à partida (antes cada jogo criava um jogador novo, e por isso a dedução de time ficava em zero); os fragmentos antigos vão sendo reunidos sozinhos."),
React.createElement("div",{style:{display:'flex',gap:12,flexWrap:'wrap',marginBottom:10}},
React.createElement(Card,{l:"Jogadores no registro",v:LV.jogadores,sub:`${LV.jogadoresUltimaHora||0} na última hora · ${LV.presencas||0} presenças`}),
React.createElement(Card,{l:"Com time deduzido",v:LV.jogadoresComTime,sub:pct(LV.jogadoresComTime,LV.jogadores)+' — por interseção de partidas'}),
React.createElement(Card,{l:"Fragmentos reunidos",v:LV.jogadoresReconstituidos,sub:"jogadores que o sistema tinha partido em vários e voltaram a ser um"}),
React.createElement(Card,{l:"Odds com jogador do registro",v:`${J.oddsComJogador||0} / ${J.oddsTotal||0}`,sub:pct(J.oddsComJogador,J.oddsTotal)}),
React.createElement(Card,{l:"Partidas de props no registro",v:`${P.comEvento||0} / ${P.total||0}`,sub:pct(P.comEvento,P.total)}),
React.createElement(Card,{l:"Revisões de jogador abertas",v:LV.revisoesJogador,warn:true,sub:"nome ambíguo: não fundiu"}),
React.createElement(Card,{l:"Times provisórios criados pelo coletor",v:LV.timesProvisorios,sub:"nasceram do props, ainda sem olho humano"})
),
(d.jogadores7d||[]).length>0&&React.createElement("div",{className:"tbl-wrap",style:{marginBottom:10}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Total"),React.createElement("th",null,"Apelido exato"),React.createElement("th",null,"Por nome/inicial"),React.createElement("th",null,"Novo"),React.createElement("th",null,"Ambíguo"),React.createElement("th",null,"Sem evento"))),React.createElement("tbody",null,
d.jogadores7d.map((r)=>React.createElement("tr",{key:r.source},React.createElement("td",{className:"mono-sm"},r.source),React.createElement("td",null,r.total),React.createElement("td",null,r.apelido),React.createElement("td",null,r.nome),React.createElement("td",null,r.novo),React.createElement("td",{style:{color:r.ambiguo?'#b45309':'inherit'}},r.ambiguo),React.createElement("td",null,r.semEvento)))
))),
(pp.homonimos||[]).length>0&&React.createElement("div",{style:{marginBottom:10}},
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:6}},"Homônimos que o agrupador antigo teria fundido (mesmo sobrenome na mesma partida) e o registro manteve separados:"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Partida (er_event)"),React.createElement("th",null,"Sobrenome"),React.createElement("th",null,"Quantos"),React.createElement("th",null,"Quem"))),React.createElement("tbody",null,
pp.homonimos.map((h,i)=>React.createElement("tr",{key:i},React.createElement("td",{className:"mono-sm"},"#",h.event_id),React.createElement("td",null,h.sobrenome),React.createElement("td",null,h.n),React.createElement("td",{style:{fontSize:12.5}},h.quem)))
)))),
(pp.ligasSemEvento||[]).length>0&&React.createElement("div",null,
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:6}},"Ligas cujas partidas ainda ficam FORA do registro (48h) — é onde falta regra de país ou nome de time:"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Liga"),React.createElement("th",null,"Partidas fora"))),React.createElement("tbody",null,
pp.ligasSemEvento.slice(0,20).map((l,i)=>React.createElement("tr",{key:i},React.createElement("td",{className:"mono-sm"},l.liga),React.createElement("td",null,l.n)))
))))
);})(),
React.createElement("h3",{className:"sec-t"},"Registro novo (er_*)"),
React.createElement("div",{style:{display:'flex',gap:12,flexWrap:'wrap',marginBottom:16}},
React.createElement(Card,{l:"Times",v:R.times,sub:`${R.timesComPais||0} com país`}),React.createElement(Card,{l:"Competições",v:R.competicoes}),React.createElement(Card,{l:"Apelidos escopados",v:R.aliases,sub:`${R.escopos||0} escopos`}),
React.createElement(Card,{l:"Marcados ambíguos",v:R.aliasesAmbiguos,sub:"nunca resolvem sozinhos"}),React.createElement(Card,{l:"Sem escopo",v:R.aliasesSemEscopo}),React.createElement(Card,{l:"Eventos",v:R.eventos}),
React.createElement(Card,{l:"IDs externos de evento",v:R.eventosExternos,sub:(R.eventosExternosPorFonte||[]).map((x)=>`${x.source} ${x.n}`).join(' · ')||'—'})
),
(A.conflitos||[]).length>0&&React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{className:"sec-t",style:{color:'#b45309'}},"Times com país conflitante (",L.timesComPaisConflitante,")"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"O mesmo id de time aparece em competições de países diferentes. Como o apelido é único por grafia, o segundo clube nunca ganhou id próprio — foi absorvido pelo primeiro."),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Time (id)"),React.createElement("th",null,"Países vistos"),React.createElement("th",null,"Exemplos de eventos"),React.createElement("th",null,"Separar"))),React.createElement("tbody",null,
A.conflitos.map((c)=>{const pp=Object.entries(c.eventosPorPais||{}).filter(([p])=>p!=='?').sort((a,b)=>a[1].length-b[1].length);return React.createElement("tr",{key:c.id},React.createElement("td",null,React.createElement("b",null,c.nome)," ",React.createElement("span",{className:"mono-sm",style:{color:'var(--on-surface-variant)'}},"#",c.id)),React.createElement("td",{className:"mono-sm"},c.paises.join(' · ')),React.createElement("td",{style:{fontSize:12.5}},c.eventos.map((e,i)=>React.createElement("div",{key:i},e))),
React.createElement("td",{style:{whiteSpace:'nowrap'}},pp.slice(0,-1).map(([pais,evs])=>React.createElement("div",{key:pais,style:{marginBottom:4}},React.createElement("button",{className:"btn-sm b-amber",disabled:!!busy,onClick:()=>separar(c,pais,evs)},"Tirar ",pais," (",evs.length,")")))));})
)))
),
(A.genericos||[]).length>0&&React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{className:"sec-t"},"Nomes genéricos de 1 token (",L.genericosDeUmToken,")"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Hoje apontam para um time só; no registro novo já entram como ambíguos e só resolvem com contexto (adversário + competição + horário)."),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Apelido"),React.createElement("th",null,"Aponta para"),React.createElement("th",null,"País"),React.createElement("th",null,"Competições"))),React.createElement("tbody",null,
A.genericos.map((g,i)=>React.createElement("tr",{key:i},React.createElement("td",{className:"mono-sm"},g.alias),React.createElement("td",null,g.time),React.createElement("td",{className:"mono-sm"},g.pais||'—'),React.createElement("td",{className:"mono-sm",style:{fontSize:12}},(g.comps||[]).join(', ')||'—')))
)))
),
(A.stringsDeJogo||[]).length>0&&React.createElement("div",{style:{marginBottom:18}},
React.createElement("h3",{className:"sec-t"},"Apelidos que são o jogo inteiro (",L.stringsDeJogo,")"),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Gravados pela aplicação de revisão antiga. Não entram no registro novo; a fase 2 corrige a origem."),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Apelido salvo"),React.createElement("th",null,"Time"),React.createElement("th",null,"Origem"))),React.createElement("tbody",null,
A.stringsDeJogo.map((g,i)=>React.createElement("tr",{key:i},React.createElement("td",null,g.raw),React.createElement("td",null,g.time),React.createElement("td",{className:"mono-sm"},g.source)))
)))
)
);
}







function CatalogoMercadosProps({catalogo,fontes,recarregar,setMsg}){
const[ed,setEd]=useState({}),[aberto,setAberto]=useState(false),[busy,setBusy]=useState(''),[abertos,setAbertos]=useState({});



const[fichas,setFichas]=useState({});
const verFicha=async(code)=>{if(fichas[code])return;setFichas((f)=>({...f,[code]:'carregando'}));
try{const r=await fetch('/api/admin/mercados/props/ficha?code='+encodeURIComponent(code),{credentials:'include'});const d=await r.json();setFichas((f)=>({...f,[code]:r.ok?d:{erro:d.error||'não deu'}}));}
catch(e){setFichas((f)=>({...f,[code]:{erro:e.message}}));}};
const TIPOS={contagem:'Contagem com linha',sim_nao:'Sim ou não',ordem:'Ordem',combinado:'Combinado'};
const FONTE={oc_uk:'OddsChecker UK',oc_br:'OddsChecker BR',casa:'Casa de Apostas',betano:'Betano',betmonitor:'Betmonitor',bb:'BetBurger'};
const NAO='__ignorar';
const nomeDe=(code)=>(catalogo.find((k)=>k.code===code)||{}).nome||code;
const bases=catalogo.filter((k)=>k.tipo==='contagem'&&!k.base);
const val=(k)=>ed[k.code]||{tipo:k.tipo||'',base:k.base||'',linha:k.linha!=null?String(k.linha).replace('.',','):''};
const post=async(url,body,chave)=>{setBusy(chave);setMsg('');
try{const r=await fetch(url,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
const d=await r.json();setMsg(r.ok?'✅ '+(d.msg||'Feito. Vale no próximo ciclo do coletor.'):'❌ '+(d.error||'Erro'));if(r.ok)recarregar();return r.ok;}
catch(e){setMsg('❌ '+e.message);return false;}finally{setBusy('');}};
const salvar=async(k)=>{const v=val(k);const ok=await post('/api/admin/mercados/props/definir',{code:k.code,tipo:v.base?'contagem':v.tipo,base:v.base||null,linha:v.base?v.linha:null},k.code);if(ok)setEd((e)=>{const n={...e};delete n[k.code];return n;});};
const doMercado=(code)=>fontes.filter((f)=>f.origem!=='pendente'&&f.origem!=='nao_trazer'&&(f.destino===code||f.multiplo&&(f.destinosLidos||[]).includes(code)));
const pendentes=fontes.filter((f)=>f.origem==='pendente');
const naoTrazer=fontes.filter((f)=>f.origem==='nao_trazer');
const cobertura=useMemo(()=>{const m={};for(const f of fontes){const c=m[f.source]||(m[f.source]={total:0,ligadas:0,pendentes:0,nao:0});c.total++;if(f.origem==='pendente')c.pendentes++;else if(f.origem==='nao_trazer')c.nao++;else c.ligadas++;}return m;},[fontes]);
const quando=(x)=>{if(!x)return'não visto em 14 dias';const d=new Date(x);return isNaN(d)?'—':'visto '+d.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});};
const origemTxt=(f)=>f.origem==='humano'?'seu vínculo':f.origem==='semente'?'dicionário inicial do cadastro':f.origem==='nao_trazer'?'marcado para não trazer':f.origem==='pendente'?'pendente: não entra em mercado nenhum':(f.multiplo?'dicionário do código (gera '+f.destinosLidos.map(nomeDe).join(', ')+')':'dicionário do código')+((f.destinosAntigos||[]).length?' · antes gerava '+f.destinosAntigos.map(nomeDe).join(', '):'');
const so725=(f)=>f.source==='casa'&&/\[725\]$/.test(f.raw);
const linha=(f,atual)=>{const ch=f.source+'|'+f.raw;return React.createElement("tr",{key:ch+'|'+atual},
React.createElement("td",{style:{paddingLeft:24,whiteSpace:'nowrap'}},FONTE[f.source]||f.source),
React.createElement("td",null,React.createElement("b",null,f.raw),f.exemplo&&React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},"ex.: ",f.exemplo),/(^|[\s(])N\+/.test(f.raw)&&React.createElement("div",{style:{fontSize:11.5,color:'#1d4ed8'}},"A linha vem no nome (N+): ligue ao mercado de contagem (o coletor lê 1+ como mais de 0,5, 2+ como mais de 1,5…) ou a um sim/não que seja o 1+ (Cartão, Marca ou assiste): aí só o 1+ entra.")),
React.createElement("td",{style:{fontSize:12,color:f.origem==='pendente'?'#b45309':'var(--on-surface-variant)'}},origemTxt(f)," · ",quando(f.ultimaVez),f.leituras?` · ${f.leituras} leituras`:''),
React.createElement("td",{colSpan:2},React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}},
!so725(f)&&React.createElement("select",{value:"",disabled:busy===ch,onChange:(e)=>{const code=e.target.value;if(code)post('/api/admin/mercados/props/vincular',{source:f.source,raw:f.raw,code},ch);}},
React.createElement("option",{value:""},f.origem==='pendente'||f.origem==='nao_trazer'?'ligar a…':'mover para…'),
catalogo.filter((k)=>k.code!==atual).map((k)=>React.createElement("option",{key:k.code,value:k.code},k.nome))
),
f.origem!=='nao_trazer'&&React.createElement("button",{className:"btn-sm",disabled:busy===ch,onClick:()=>post('/api/admin/mercados/props/vincular',{source:f.source,raw:f.raw,code:NAO},ch)},"Não trazer"),
(f.origem==='humano'||f.origem==='nao_trazer')&&React.createElement("button",{className:"btn-sm",disabled:busy===ch,title:"Apaga o seu vínculo: a grafia volta ao dicionário do código ou, se ele não a conhecer, fica pendente",onClick:()=>post('/api/admin/mercados/props/desvincular',{source:f.source,raw:f.raw},ch)},f.origem==='nao_trazer'?'Voltar a trazer':'Voltar ao automático')
))
);};
return React.createElement("div",{style:{marginBottom:16}},
React.createElement("button",{className:"btn-sm",onClick:()=>setAberto(!aberto)},aberto?'Fechar':'Ver'," cadastro de mercados (",catalogo.length,")"),
aberto&&React.createElement(React.Fragment,null,
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',margin:'8px 0'}},"Cada grafia de cada fonte entra em ",React.createElement("b",null,"um")," mercado. Decide o ",React.createElement("b",null,"seu vínculo"),"; sem vínculo, vale o ",React.createElement("b",null,"dicionário")," (grafia exata, nunca palavra parecida). Grafia que nenhum dos dois conhece fica ",React.createElement("b",null,"pendente")," e não entra em lugar nenhum até você ligar. O tipo diz como a aposta é comparada entre casas, e um mercado pode ser linha fixa de outro. Tudo vale no próximo ciclo do coletor."),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',margin:'8px 0 12px'}},
Object.entries(cobertura).map(([src,c])=>React.createElement("div",{key:src,style:{border:'1px solid var(--line-2)',borderRadius:8,padding:'6px 10px',fontSize:12.5}},React.createElement("b",null,FONTE[src]||src)," · ",c.total," grafias · ",c.ligadas," em mercado",c.pendentes?React.createElement("span",{style:{color:'#b45309',fontWeight:600}}," · ",c.pendentes," pendente(s)"):'',c.nao?` · ${c.nao} não trazida(s)`:''))
),
pendentes.length>0&&React.createElement(React.Fragment,null,React.createElement("h4",{style:{margin:'12px 0 6px',fontSize:14,color:'#b45309'}},"Pendentes nas fontes (",pendentes.length,")"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("tbody",null,pendentes.map((f)=>linha(f,null)))))),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Mercado"),React.createElement("th",null,"Tipo"),React.createElement("th",null,"É linha de"),React.createElement("th",null,"Linha"),React.createElement("th",null))),React.createElement("tbody",null,
catalogo.map((k)=>{const v=val(k);const set=(p)=>setEd((e)=>({...e,[k.code]:{...v,...p}}));const vs=doMercado(k.code);return React.createElement(React.Fragment,{key:k.code},
React.createElement("tr",null,
React.createElement("td",null,React.createElement("b",null,k.nome)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},k.code),
React.createElement("button",{className:"btn-sm",style:{marginLeft:8},onClick:()=>{const abrindo=!abertos[k.code];setAbertos((a)=>({...a,[k.code]:abrindo}));if(abrindo)verFicha(k.code);}},abertos[k.code]?'▾':'▸'," Fontes (",vs.length,")"),
!vs.length&&React.createElement("span",{title:"Nenhuma grafia de fonte entra neste mercado hoje",style:{marginLeft:8,fontSize:11,fontWeight:600,color:'#b45309',background:'#fffbeb',border:'1px solid #fde68a',borderRadius:6,padding:'1px 6px'}},"sem fonte")),
React.createElement("td",null,React.createElement("select",{value:v.base?'contagem':v.tipo,disabled:!!v.base,onChange:(e)=>set({tipo:e.target.value})},React.createElement("option",{value:""},"—"),Object.entries(TIPOS).map(([c,t])=>React.createElement("option",{key:c,value:c},t)))),
React.createElement("td",null,React.createElement("select",{value:v.base,onChange:(e)=>set({base:e.target.value})},React.createElement("option",{value:""},"não"),bases.filter((b)=>b.code!==k.code).map((b)=>React.createElement("option",{key:b.code,value:b.code},b.nome)))),
React.createElement("td",null,v.base?React.createElement("input",{value:v.linha,onChange:(e)=>set({linha:e.target.value}),placeholder:"0,5",style:{width:70}}):'—'),
React.createElement("td",null,!!ed[k.code]&&React.createElement("button",{className:"btn-sm b-green",disabled:busy===k.code,onClick:()=>salvar(k)},"Salvar"))
),
abertos[k.code]&&(vs.length?vs.map((f)=>linha(f,k.code)):React.createElement("tr",null,React.createElement("td",{colSpan:5,style:{paddingLeft:24,fontSize:12.5,color:'var(--on-surface-variant)'}},"Nenhuma grafia de fonte entra neste mercado."))),
abertos[k.code]&&React.createElement("tr",null,React.createElement("td",{colSpan:5,style:{paddingLeft:24}},(()=>{const fi=fichas[k.code];
if(!fi||fi==='carregando')return React.createElement("span",{style:{fontSize:12,color:'var(--on-surface-variant)'}},"Lendo a ficha…");
if(fi.erro)return React.createElement("span",{style:{fontSize:12,color:'#b91c1c'}},"Ficha: ",fi.erro);
const dt=(x)=>{if(!x)return'—';const d=new Date(x);return isNaN(d)?'—':d.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',year:'2-digit',hour:'2-digit',minute:'2-digit'});};
const ligada=new Set((fi.vinculos||[]).map((v)=>v.source));
return React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',padding:'4px 0 8px'}},
React.createElement("div",null,"No cadastro desde ",React.createElement("b",null,dt(fi.entidade&&fi.entidade.created_at)),(fi.historico||[]).length?' · '+fi.historico.length+' registro(s) no histórico':''),
(fi.odds||[]).length>0&&React.createElement("div",{style:{marginTop:6}},
React.createElement("b",null,"Odds já gravadas")," (por fonte):",
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',marginTop:4}},
Object.entries((fi.odds||[]).reduce((a,o)=>{const x=a[o.source]||(a[o.source]={linhas:0,ativas:0,ultima:null});x.linhas+=Number(o.linhas);x.ativas+=Number(o.ativas);if(!x.ultima||new Date(o.ultima)>new Date(x.ultima))x.ultima=o.ultima;return a;},{})).map(([src,x])=>
React.createElement("span",{key:src,style:{border:'1px solid var(--line-2)',borderRadius:6,padding:'3px 8px'}},
React.createElement("b",null,src)," · ",x.linhas," linha(s)",x.ativas?', '+x.ativas+' ativa(s)':''," · última ",dt(x.ultima),
!ligada.has(src)&&React.createElement("button",{className:"btn-sm",style:{marginLeft:6},disabled:busy==='limpa'+k.code+src,
title:"Esta fonte não alimenta mais o mercado: apaga o que ela deixou gravado, com o histórico",
onClick:async()=>{if(!(await confirma('Apagar '+x.linhas+' odd(s) de "'+src+'" do mercado "'+k.nome+'"?\n\nSó apaga o que esta fonte gravou; ela não está mais ligada a este mercado.')))return;
setBusy('limpa'+k.code+src);
const ok=await post('/api/admin/mercados/props/limpar-odds',{code:k.code,source:src},'limpa'+k.code+src);
if(ok){setFichas((f)=>({...f,[k.code]:undefined}));verFicha(k.code);}}},"Apagar")
))
),
(fi.exemplos||[]).length>0&&React.createElement("div",{style:{marginTop:6}},"Seleções gravadas: ",(fi.exemplos||[]).slice(0,6).map((e,i)=>React.createElement("span",{key:i,style:{marginRight:8}},"“",e.player,"” ",React.createElement("span",{style:{opacity:.7}},"(",e.book,", ",e.home," x ",e.away,")"))))
),
!(fi.odds||[]).length&&React.createElement("div",{style:{marginTop:4}},"Nunca gravou odd nenhuma."),
(fi.pendentes||[]).filter((p)=>!Number(p.ignorado)).length>0&&React.createElement("div",{style:{marginTop:6,color:'#b45309'}},"Grafia parecida esperando decisão: ",
(fi.pendentes||[]).filter((p)=>!Number(p.ignorado)).slice(0,4).map((p,i)=>React.createElement("span",{key:i,style:{marginRight:8}},React.createElement("b",null,p.source)," “",p.raw,"” (",p.n," odds)"))
)
);})()))
);})
))),
naoTrazer.length>0&&React.createElement(React.Fragment,null,React.createElement("h4",{style:{margin:'14px 0 6px',fontSize:14}},"Não trazer (",naoTrazer.length,")"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("tbody",null,naoTrazer.map((f)=>linha(f,NAO))))))
)
);
}




const PERIODOS_CATALOGO=[['jogo','Jogo'],['jogo_pr','Jogo c/ prorrogação'],['1t','1º tempo'],['2t','2º tempo'],['2t_pr','2º tempo c/ prorrogação'],['p1','1º período'],['p2','2º período'],['p3','3º período'],['q1','1º quarto'],['q2','2º quarto'],['q3','3º quarto'],['q4','4º quarto'],['q4_pr','4º quarto c/ prorrogação'],['set1','1º set'],['set2','2º set'],['set3','3º set'],['set4','4º set'],['set5','5º set'],['f5','5 entradas'],['e1','1ª entrada'],['e2','2ª entrada'],['e3','3ª entrada'],['e4','4ª entrada'],['e5','5ª entrada'],['e6','6ª entrada'],['e7','7ª entrada'],['e8','8ª entrada'],['e9','9ª entrada'],['mapa1','Mapa 1'],['mapa2','Mapa 2'],['mapa3','Mapa 3'],['mapa4','Mapa 4'],['mapa5','Mapa 5'],['mapa6','Mapa 6'],['mapa7','Mapa 7']];
const PERIODO_ROT=Object.fromEntries(PERIODOS_CATALOGO);
const TIPO_MERC={resultado:'Resultado',contagem:'Total (mais/menos)',handicap:'Handicap',sim_nao:'Sim/não'};
const CASAS_CORRETORA={betfair_ex:'Betfair Exchange',sharpbet:'Sharpbet',vertex:'Vertex',sharp_ag:'Sharp.ag',topodds:'TopOdds',amapola:'Amapola',punter_io:'Punter.io',paradise:'Paradisewager'};
const nomeFonte=(f)=>CASAS_CORRETORA[f]?CASAS_CORRETORA[f]:f==='casa'?'Casa de Apostas':f==='fanduel'?'FanDuel':f==='kalshi'?'Kalshi':f==='polymarket'?'Polymarket':f==='sxbet'?'SX Bet':f==='predictfun'?'predict.fun':f==='azuro'?'Bookmaker.XYZ':f==='overtime'?'Overtime':f==='fourcasters'?'4casters':f==='betdex'?'BetDEX':f==='limitless'?'Limitless':f==='hyperliquid'?'Hyperliquid':f==='betonline'?'BetOnline':f==='lowvig'?'LowVig':f==='sportsbetting'?'SportsBetting':f==='tres_et'?'3ET':f==='artline'?'Artline':f==='heritage'?'Heritage':f==='mystake'?'MyStake':f==='og'?'OG':f==='cloudbet'?'Cloudbet':f==='magicmarkets'?'MagicMarkets':f==='novig'?'Novig':f==='prophetx'?'ProphetX':f==='pinnacle'?'Pinnacle':f==='betano'?'Betano':f==='betazo'?'Betazo':String(f).startsWith('so:')?'Super Odd · '+String(f).slice(3):f;


const PERIODO_VINC=[['','o que a casa disser'],...PERIODOS_CATALOGO];
function EscolhaMercadoJogo({opcoes,inicial,disabled,rotulo,onSalvar,soMercado}){
const[v,setV]=useState({mercado:inicial&&inicial.mercado||'',periodo:inicial&&inicial.periodo!=null?inicial.periodo:'',participante:inicial&&inicial.participante||'',linha:inicial&&inicial.linha!=null?String(inicial.linha):''});
const op=(opcoes||[]).find((o)=>o.id===v.mercado);
const doTime=op&&op.escopo==='time';
const falta=!v.mercado?'escolha o mercado':doTime&&!v.participante?'diga de qual time':'';
return React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}},
React.createElement("select",{"aria-label":"mercado do cadastro",value:v.mercado,disabled:disabled,onChange:(e)=>{const m=(opcoes||[]).find((o)=>o.id===e.target.value);setV({...v,mercado:e.target.value,participante:m&&m.escopo==='time'?v.participante||'':''});}},
React.createElement("option",{value:""},"mercado do cadastro…"),
[...new Set((opcoes||[]).map((o)=>o.grupo||(o.escopo==='time'?'Do time':'Do jogo')))].map((g)=>React.createElement("optgroup",{key:g,label:g},(opcoes||[]).filter((o)=>(o.grupo||(o.escopo==='time'?'Do time':'Do jogo'))===g).map((o)=>React.createElement("option",{key:o.id,value:o.id},o.nome,o.escopo==='time'?' (do time)':''))))
),
!soMercado&&React.createElement("select",{"aria-label":"período",value:v.periodo,disabled:disabled,onChange:(e)=>setV({...v,periodo:e.target.value})},
PERIODO_VINC.map(([k,l])=>React.createElement("option",{key:k,value:k},k?l:'período: '+l))
),
doTime&&React.createElement("select",{"aria-label":"time",value:v.participante,disabled:disabled,onChange:(e)=>setV({...v,participante:e.target.value})},
React.createElement("option",{value:""},"de qual time?"),React.createElement("option",{value:"casa"},"Mandante"),React.createElement("option",{value:"fora"},"Visitante")
),
!soMercado&&React.createElement("input",{"aria-label":"linha fixa",placeholder:"linha fixa (opcional)",value:v.linha,disabled:disabled,onChange:(e)=>setV({...v,linha:e.target.value}),style:{width:140},
title:"Só quando o nome não traz a linha e ela é sempre a mesma (ex.: Empate anula = handicap 0). Em branco, a linha vem de cada seleção."}),
React.createElement("button",{className:"btn-sm b-green",disabled:disabled||!!falta,title:falta||'',onClick:()=>onSalvar({mercado:v.mercado,periodo:v.periodo||null,participante:doTime?v.participante:'',linha:v.linha.trim()===''?null:v.linha})},rotulo||'Ligar')
);
}



function AgrupadorMercados(){
const[d,setD]=useState(null),[ed,setEd]=useState({}),[busy,setBusy]=useState(''),[msg,setMsg]=useState(''),[aberto,setAberto]=useState(false);
const load=async()=>{try{const r=await fetch('/api/admin/mercados/grupos',{credentials:'include'});const j=await r.json();setD(r.ok?j:{erro:j.error||'Erro',mercados:[]});}catch(e){setD({erro:e.message,mercados:[]});}};
useEffect(()=>{load();},[]);
if(!d)return React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)'}},"Carregando…");
const ms=d.mercados||[];
const grupos=[...new Set(ms.map((m)=>m.grupo))];
const salvar=async(m)=>{const g=(ed[m.code]||'').trim();if(!g)return;setBusy(m.code);setMsg('');
try{const r=await fetch('/api/admin/mercados/grupo',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:m.code,grupo:g})});const j=await r.json();
setMsg(r.ok?'✅ '+j.msg:'❌ '+(j.error||'Erro'));if(r.ok){setEd((e)=>{const x={...e};delete x[m.code];return x;});load();}}
catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
return React.createElement("div",null,
d.erro&&React.createElement("div",{className:"err-box"},d.erro),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'center',marginBottom:6}},
grupos.map((g)=>React.createElement("span",{key:g,className:"pill"},g," · ",ms.filter((m)=>m.grupo===g).length)),
React.createElement("button",{className:"btn-sm",onClick:()=>setAberto(!aberto)},aberto?'Fechar':'Ver e trocar')
),
msg&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6}},msg),
aberto&&React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Grupo"),React.createElement("th",null,"Mercado"),React.createElement("th",null,"Escopo"),React.createElement("th",null,"Trocar grupo"))),React.createElement("tbody",null,
React.createElement("datalist",{id:"agrupadores"},grupos.map((g)=>React.createElement("option",{key:g,value:g}))),
ms.map((m)=>React.createElement("tr",{key:m.code},React.createElement("td",null,m.grupo),React.createElement("td",null,React.createElement("b",null,m.nome||m.code)," ",React.createElement("span",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},m.code)),
React.createElement("td",{style:{fontSize:12}},m.escopo==='partida'?'jogo':m.escopo==='time'?'time':'jogador'),
React.createElement("td",{style:{whiteSpace:'nowrap'}},React.createElement("input",{id:'grp-'+m.code,list:"agrupadores",placeholder:m.grupo,value:ed[m.code]||'',onChange:(e)=>setEd({...ed,[m.code]:e.target.value}),style:{width:150}})," ",React.createElement("button",{className:"btn-sm b-green",disabled:busy===m.code||!(ed[m.code]||'').trim(),onClick:()=>salvar(m)},"Salvar"))))
)))
);
}

function VinculosMercadoJogo(){
const[d,setD]=useState(null),[fonte,setFonte]=useState(''),[quem,setQuem]=useState(''),[busca,setBusca]=useState(''),[editar,setEditar]=useState(''),[msg,setMsg]=useState(''),[busy,setBusy]=useState('');
const vezLoad=useRef(0);
const load=async()=>{const n=++vezLoad.current;try{const r=await fetch('/api/admin/mercados/vinculos?fonte='+encodeURIComponent(fonte)+'&quem='+quem+'&q='+encodeURIComponent(busca),{credentials:'include'});const j=await r.json();if(n===vezLoad.current)setD(r.ok?j:{erro:j.error||'Erro',vinculos:[],semVinculo:[],mercados:[]});}catch(e){if(n===vezLoad.current)setD({erro:e.message,vinculos:[],semVinculo:[],mercados:[]});}};
useEffect(()=>{const t=setTimeout(load,250);return()=>clearTimeout(t);},[fonte,quem,busca]);
const salva=async(body,k)=>{setBusy(k);setMsg('');try{const r=await fetch('/api/admin/mercados/vinculo',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json();setMsg(r.ok?'✅ '+(j.msg||'Feito.'):'❌ '+(j.error||'Erro'));if(r.ok){setEditar('');load();}}catch(e){setMsg('❌ '+e.message);}finally{setBusy('');}};
if(d===null)return React.createElement("div",{style:{color:'var(--on-surface-variant)',fontSize:12.5}},"Carregando vínculos…");
const nomeM=(id)=>id==='__ignorar'?'Não trazer':((d.mercados||[]).find((m)=>m.id===id)||{}).nome||id;
const perRot=(p)=>p?(PERIODO_VINC.find((x)=>x[0]===p)||[])[1]||p:'o da casa';

const fontes=d.fontes||[...new Set((d.vinculos||[]).map((v)=>v.fonte).concat((d.semVinculo||[]).map((v)=>v.fonte)))].sort();
const moldeRot=(m)=>String(m).replace(/\{casa\}/g,'[mandante]').replace(/\{fora\}/g,'[visitante]');
return React.createElement("div",null,
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8,maxWidth:820}},"Cada mercado de casa aponta para um mercado do cadastro, como times e ligas. ",
React.createElement("b",null,"Regra")," = o código reconheceu o nome; ",React.createElement("b",null,"Você")," = decisão tomada aqui ou no Resolver, que manda sobre a regra. Trocar ou desfazer vale no próximo ciclo. O nome aparece sem os times: [mandante] e [visitante]."
),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',marginBottom:8}},
React.createElement("select",{"aria-label":"casa",value:fonte,onChange:(e)=>setFonte(e.target.value)},React.createElement("option",{value:""},"todas as casas"),fontes.map((f)=>React.createElement("option",{key:f,value:f},nomeFonte(f)))),
React.createElement("select",{"aria-label":"quem decidiu",value:quem,onChange:(e)=>setQuem(e.target.value)},React.createElement("option",{value:""},"regra e você"),React.createElement("option",{value:"human"},"só decisões suas"),React.createElement("option",{value:"auto"},"só da regra")),
React.createElement("input",{"aria-label":"buscar vínculo",placeholder:"buscar nome, mercado, casa ou código…",value:busca,onChange:(e)=>setBusca(e.target.value)})
),
d.total>(d.vinculos||[]).length&&React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginBottom:6}},"Mostrando ",(d.vinculos||[]).length," de ",d.total," vínculos: escolha a casa ou busque para ver o resto."),
msg&&React.createElement("div",{style:{fontSize:12.5,marginBottom:6}},msg),
d.erro&&React.createElement("div",{style:{color:'#a3402a',fontSize:12.5,marginBottom:6}},d.erro),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Nome na casa"),React.createElement("th",null,"Mercado do cadastro"),React.createElement("th",null,"Período"),React.createElement("th",null,"Time"),React.createElement("th",null,"Quem"),React.createElement("th",null,"Leituras (7 d)"),React.createElement("th",null))),React.createElement("tbody",null,
(d.vinculos||[]).map((v)=>{const k=v.fonte+'|'+v.molde;return React.createElement(React.Fragment,{key:k},React.createElement("tr",null,
React.createElement("td",{style:{fontSize:12.5}},nomeFonte(v.fonte)),
React.createElement("td",null,React.createElement("b",null,moldeRot(v.molde)),v.exemplo&&React.createElement("div",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)',wordBreak:'break-all'}},v.exemplo)),
React.createElement("td",{style:{fontSize:12.5,color:v.mercado==='__ignorar'?'#a3402a':'inherit'}},nomeM(v.mercado),v.linha!=null?' · linha '+Number(v.linha):''),
React.createElement("td",{style:{fontSize:12.5}},perRot(v.periodo)),
React.createElement("td",{style:{fontSize:12.5}},v.participante==='casa'?'Mandante':v.participante==='fora'?'Visitante':'—'),
React.createElement("td",{style:{fontSize:12.5}},v.criado_por==='human'?React.createElement("span",{title:v.por||''},"Você"):'Regra'),
React.createElement("td",{className:"mono-sm"},v.leituras||0),
React.createElement("td",{style:{whiteSpace:'nowrap'}},
React.createElement("button",{className:"btn-sm",disabled:busy===k,onClick:()=>setEditar(editar===k?'':k)},"Trocar"),' ',
v.mercado!=='__ignorar'&&React.createElement("button",{className:"btn-sm b-red",disabled:busy===k,onClick:()=>salva({fonte:v.fonte,molde:v.molde,mercado:'__ignorar'},k)},"Não trazer"),' ',
v.criado_por==='human'&&React.createElement("button",{className:"btn-sm",disabled:busy===k,title:"Tira a sua decisão: volta a valer a regra do código (sem regra, a grafia volta ao Resolver)",onClick:async()=>{if(await confirma('Desfazer a sua decisão para "'+moldeRot(v.molde)+'"?'))salva({fonte:v.fonte,molde:v.molde,voltarRegra:true},k);}},"Desfazer")
)),
editar===k&&React.createElement("tr",null,React.createElement("td",{colSpan:8},React.createElement(EscolhaMercadoJogo,{opcoes:d.mercados,inicial:v.mercado==='__ignorar'?null:v,disabled:busy===k,rotulo:"Salvar",onSalvar:(alvo)=>salva({fonte:v.fonte,molde:v.molde,...alvo},k)})))
);}),
!(d.vinculos||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:8,style:{color:'var(--on-surface-variant)'}},"Nenhum vínculo com esse filtro. Os da regra aparecem no primeiro ciclo de cada casa depois da publicação."))
))),
(d.semVinculo||[]).length>0&&React.createElement("details",{style:{marginTop:10}},React.createElement("summary",{style:{cursor:'pointer',fontSize:12.5}},"Sem vínculo (",d.semVinculo.length,") — os que o catálogo não tem (2º tempo, jogador, cartões) ficam só aqui; os demais também estão no Resolver"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Nome na casa"),React.createElement("th",null,"Por que a regra não leu"),React.createElement("th",null,"Leituras (7 d)"),React.createElement("th",null))),React.createElement("tbody",null,
d.semVinculo.map((g)=>{const k='s|'+g.fonte+'|'+g.molde;return React.createElement(React.Fragment,{key:k},React.createElement("tr",null,React.createElement("td",{style:{fontSize:12.5}},nomeFonte(g.fonte)),React.createElement("td",null,React.createElement("b",null,moldeRot(g.molde))),React.createElement("td",{style:{fontSize:12}},g.motivo),React.createElement("td",{className:"mono-sm"},g.leituras),
React.createElement("td",{style:{whiteSpace:'nowrap'}},React.createElement("button",{className:"btn-sm",disabled:busy===k,onClick:()=>setEditar(editar===k?'':k)},"Ligar"),' ',React.createElement("button",{className:"btn-sm b-red",disabled:busy===k,onClick:()=>salva({fonte:g.fonte,molde:g.molde,mercado:'__ignorar'},k)},"Não trazer"))),
editar===k&&React.createElement("tr",null,React.createElement("td",{colSpan:5},React.createElement(EscolhaMercadoJogo,{opcoes:d.mercados,disabled:busy===k,onSalvar:(alvo)=>salva({fonte:g.fonte,molde:g.molde,...alvo},k)}))));})
))))
);
}

function CatalogoUnico(){
const[d,setD]=useState(null);
const load=async()=>{try{const r=await fetch('/api/admin/mercados/canonico',{credentials:'include'});setD(await r.json());}catch(e){setD({erros:[e.message],mercados:[],frescas:[]});}};
useEffect(()=>{load();},[]);
if(d===null)return React.createElement("div",{style:{color:'var(--on-surface-variant)',padding:12}},"Carregando…");
const fr=d.frescas||[];const porMerc={};
for(const f of fr){const k=f.mercado;(porMerc[k]=porMerc[k]||[]).push(f);}
const v=d.medicao&&d.medicao.vinculos;
let totSel=0;for(const f of fr){totSel+=Number(f.selecoes);}
const jogosPin=Math.max(0,...fr.filter((f)=>f.fonte==='pinnacle'&&f.periodo==='jogo'&&f.mercado==='jogo_1x2').map((f)=>Number(f.eventos)));

const fmtIdade=(s)=>{const n=Number(s);if(!isFinite(n))return'—';return n<90?'agora':'há '+Math.round(n/60)+' min';};
return React.createElement("div",null,
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:10,maxWidth:820}},"Um cadastro só de mercados para todo o Odds Radar. Cada aposta é ",
React.createElement("b",null,"mercado + período + time (quando é do time) + linha + lado"),". Duas casas que oferecem a mesma aposta caem na mesma chave, sem comparar texto. Os mercados de jogador continuam na guia Player Props (mesmo cadastro). A ",React.createElement("b",null,"Pinnacle")," já escreve neste formato sozinha: nada para decidir aqui."
),
(d.erros||[]).length>0&&React.createElement("div",{style:{color:'#a3402a',fontSize:12.5,marginBottom:10}},d.erros.join(' · ')),
React.createElement("div",{style:{display:'flex',gap:14,flexWrap:'wrap',marginBottom:14}},
[['Mercados de jogo/time',(d.mercados||[]).length],['Seleções com preço agora',totSel],['Jogos de futebol com 1X2 da Pinnacle',jogosPin||0],
['Vínculos do Super Odds que já caem no catálogo',v?v.traduzidos+' de '+v.pinnacle:'—']].map(([l,x])=>
React.createElement("div",{key:l,style:{background:'#fff',border:'1px solid var(--line-2)',borderRadius:10,padding:'8px 16px'}},
React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},l),React.createElement("div",{style:{fontSize:18,fontWeight:700}},x)
))
),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Mercado"),React.createElement("th",null,"Código"),React.createElement("th",null,"Tipo"),React.createElement("th",null,"Esportes"),React.createElement("th",null,"Com preço agora (por período)"))),React.createElement("tbody",null,
(d.mercados||[]).map((m)=>{const fs=(porMerc[m.code]||[]).sort((a,b)=>Number(b.eventos)-Number(a.eventos));
return React.createElement("tr",{key:m.code},
React.createElement("td",null,React.createElement("b",null,m.nome||m.code),React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},m.escopo==='time'?'por time':'do jogo')),
React.createElement("td",{className:"mono-sm"},m.code),
React.createElement("td",{style:{fontSize:12.5}},TIPO_MERC[m.tipo]||m.tipo),
React.createElement("td",{style:{fontSize:12.5}},String(m.esportes||'').split(',').filter(Boolean).join(', ')),
React.createElement("td",{style:{fontSize:12.5}},fs.length?fs.map((f)=>React.createElement("div",{key:f.fonte+f.periodo},f.fonte," · ",PERIODO_ROT[f.periodo]||f.periodo,": ",React.createElement("b",null,f.eventos)," jogo(s), ",f.selecoes," seleções ",React.createElement("span",{style:{color:'var(--on-surface-variant)'}},"(",fmtIdade(f.idade_s),")"))):React.createElement("span",{style:{color:'var(--on-surface-variant)'}},"nenhuma fonte com preço nos últimos 25 min"))
);}),
!(d.mercados||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:5,style:{color:'var(--on-surface-variant)'}},"O catálogo ainda não foi semeado: ele nasce na subida do crawler de Super Odds."))
))),
(()=>{const fontes={};for(const f of fr){const k=String(f.fonte).startsWith('so:')?'Super Odds':nomeFonte(f.fonte);fontes[k]=fontes[k]||{sel:0};fontes[k].sel+=Number(f.selecoes);}
return React.createElement("div",{style:{fontSize:12.5,margin:'12px 0',color:'var(--on-surface-variant)'}},"Fontes escrevendo no catálogo agora: ",Object.entries(fontes).map(([k,x])=>React.createElement("b",{key:k,style:{marginRight:12,color:'var(--on-surface)'}},k,": ",x.sel," seleções")),!Object.keys(fontes).length&&'nenhuma');})(),
React.createElement("h4",{style:{margin:'16px 0 6px',fontSize:14}},"Casas contra a odd justa da Pinnacle (mesma aposta, preço dos últimos 25 min)"),
React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginBottom:6}},"A comparação é pela chave do catálogo: mesmo jogo do registro, mesmo mercado, período, linha e lado. A odd justa tira a margem da Pinnacle pelo mesmo método do Super Odds."),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Pinnacle"),React.createElement("th",null,"Justa"),React.createElement("th",null,"EV"))),React.createElement("tbody",null,
(d.comparacao||[]).map((c,i)=>React.createElement("tr",{key:i},React.createElement("td",{style:{fontSize:12.5}},nomeFonte(c.fonte)),React.createElement("td",{style:{fontSize:12.5}},c.jogo),React.createElement("td",{className:"mono-sm"},c.aposta,c.texto&&React.createElement("div",{style:{fontSize:11,color:'var(--on-surface-variant)',fontFamily:'inherit'}},"“",c.texto,"”"),c.suspeita&&React.createElement("div",{style:{fontSize:11,color:'#a3402a',fontFamily:'inherit'}},"provável leitura ou pareamento errado (EV acima de ",c.limite||100,"%)")),React.createElement("td",{className:"mono-sm"},c.odd.toFixed(2)),React.createElement("td",{className:"mono-sm"},c.pinnacle.toFixed(2)),React.createElement("td",{className:"mono-sm"},c.justa.toFixed(2)),React.createElement("td",{className:"mono-sm",style:{color:c.suspeita?'#a3402a':c.ev>0?'#1c6b52':'var(--on-surface-variant)',fontWeight:c.ev>0&&!c.suspeita?700:400}},c.ev>0?'+':'',c.ev,"%"))),
!(d.comparacao||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:7,style:{color:'var(--on-surface-variant)'}},"Nenhuma casa com a mesma aposta e preço fresco da Pinnacle agora."))
))),
d.sombra&&React.createElement("div",{style:{fontSize:12.5,marginTop:12}},
React.createElement("b",null,"Odd justa do Super Odds lida pelo catálogo (sombra, desde ",new Date(d.sombra.desde).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}),"):"),' ',
d.sombra.iguais," iguais à atual (até 1%), ",d.sombra.diverge," diferentes, ",d.sombra.semCatalogo," sem as pernas no catálogo, ",d.sombra.semSelecao," de mercados que o catálogo ainda não lê (vínculos manuais); ",d.sombra.gravadas," Super Odds gravadas no catálogo.",d.sombra.erros?React.createElement("span",{style:{color:'#a3402a'}}," ",d.sombra.erros," erro(s): ",d.sombra.ultimoErro):null,
(d.sombra.exemplos||[]).length>0&&React.createElement("details",null,React.createElement("summary",{style:{cursor:'pointer'}},"Diferentes (",d.sombra.exemplos.length,")"),React.createElement("ul",null,d.sombra.exemplos.map((x,i)=>React.createElement("li",{key:i,className:"mono-sm"},x.selecao,": atual ",x.justaAtual," · catálogo ",x.justaCatalogo," (",x.mercado,")"))))
),
d.grafias&&React.createElement("div",{style:{fontSize:12.5,marginTop:12}},
React.createElement("b",null,"Traduções das casas (7 dias):"),' ',(d.grafias.resumo||[]).map((g,i)=>React.createElement("span",{key:i,style:{marginRight:10}},nomeFonte(g.fonte)," · ",g.status,": ",g.n)),!(d.grafias.resumo||[]).length&&'nenhuma leitura ainda',
(d.grafias.pendentes||[]).length>0&&React.createElement("details",null,React.createElement("summary",{style:{cursor:'pointer'}},"Mercados de casa ainda sem tradução (",d.grafias.pendentes.length,")"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Mercado da casa"),React.createElement("th",null,"Situação"),React.createElement("th",null,"Leituras"))),React.createElement("tbody",null,
d.grafias.pendentes.map((g,i)=>React.createElement("tr",{key:i},React.createElement("td",null,nomeFonte(g.fonte)),React.createElement("td",null,React.createElement("b",null,g.raw),React.createElement("div",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)',wordBreak:'break-all'}},g.exemplo)),React.createElement("td",{style:{fontSize:12}},g.status==='rejeitado'?'lido, mas recusado: ':'',g.motivo),React.createElement("td",{className:"mono-sm"},g.n)))
))))
),
React.createElement("h4",{style:{margin:'18px 0 6px',fontSize:14}},"Agrupador dos mercados do cadastro"),
React.createElement(AgrupadorMercados,null),
React.createElement("h4",{style:{margin:'18px 0 6px',fontSize:14}},"Vínculos dos mercados de jogo"),
React.createElement(VinculosMercadoJogo,null),
d.pinnacle&&d.pinnacle.etapas&&React.createElement("div",{style:{fontSize:12,marginTop:10,color:'var(--on-surface-variant)'}},"Último ciclo da Pinnacle: ",d.pinnacle.durSec!=null?d.pinnacle.durSec+' s':'em andamento'," · ",Object.entries(d.pinnacle.etapas).map(([k,s])=>k+' '+s+'s').join(' · ')),
v&&v.semTraducao&&v.semTraducao.length>0&&React.createElement("details",{style:{marginTop:14}},
React.createElement("summary",{style:{cursor:'pointer',fontSize:13}},"Vínculos do Super Odds em mercados da Pinnacle que o catálogo ainda não tem (",v.pinnacle-v.traduzidos,")"),
React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',margin:'6px 0'}},"Specials como “Ambas marcam” e “Placar correto”. Continuam valendo no cálculo de EV como hoje. Entram no catálogo no próximo passo."),
React.createElement("ul",{style:{fontSize:12.5,columns:2}},v.semTraducao.map((x)=>React.createElement("li",{key:x},x)))
),
React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)',marginTop:10}},"Medição dos vínculos: ",d.medicao?new Date(d.medicao.em).toLocaleString('pt-BR'):'ainda não rodou'," (a cada 30 min) · ",React.createElement("button",{className:"btn-sm",onClick:load},"Atualizar"))
);
}

function MercadosSection({onClose}){


const[msg,setMsg]=useState('');
const[subM,setSubM]=useRota('sm','catalogo');
const[props,setProps]=useState(null);
const loadProps=async()=>{try{const r=await fetch('/api/admin/mercados/props',{credentials:'include'});setProps(await r.json());}catch(e){setProps({linhas:[],erro:e.message});}};
useEffect(()=>{if(subM==='props')loadProps();},[subM]);
const ignoraProps=async(l,ignorar)=>{setMsg('');
try{const r=await fetch('/api/admin/mercados/props/ignorar',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
body:JSON.stringify({source:l.source,raw:l.raw,ignorar})});const d=await r.json();
setMsg(r.ok?ignorar?'Mercado marcado como ignorado — sai do Resolver.':'Mercado de volta para o Resolver.':'❌ '+(d.error||'Erro'));
if(r.ok)loadProps();}catch(e){setMsg('❌ '+e.message);}};
return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Um catálogo só para todas as fontes — Pinnacle, casas, bolsas e Super Odds. O que uma fonte escreve e o dicionário ainda não lê vira cartão no ",
React.createElement("b",null,"Resolver"),", onde você liga a grafia a um mercado nosso."
),
React.createElement("div",{className:"seg",style:{marginBottom:14,display:'inline-flex'}},[['catalogo','Catálogo único'],['props','Player Props']].map(([v,l])=>React.createElement("button",{key:v,className:"segb"+(subM===v?' on':''),onClick:()=>setSubM(v)},l))),

subM==='catalogo'&&React.createElement(CatalogoUnico,null),
subM==='props'&&(()=>{
if(props===null)return React.createElement("div",{style:{color:'var(--on-surface-variant)',padding:12}},"Carregando…");
const ls=props.linhas||[];const t=props.total||{};
const pend=ls.filter((l)=>!Number(l.ignorado)),ign=ls.filter((l)=>Number(l.ignorado));
const fmtD=(x)=>{if(!x)return'—';const d=new Date(x);return isNaN(d)?'—':d.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});};
const linha=(l,i)=>React.createElement("tr",{key:l.source+'|'+l.raw+i},
React.createElement("td",{className:"mono-sm"},l.source),
React.createElement("td",null,React.createElement("b",null,l.raw),l.exemplo&&React.createElement("div",{className:"mono-sm",style:{fontSize:11,color:'var(--on-surface-variant)'}},"ex.: ",l.exemplo),/(^|[\s(])N\+/.test(l.raw)&&React.createElement("div",{style:{fontSize:11.5,color:'#1d4ed8'}},"A linha vem no nome (N+): ligue ao mercado de contagem (o coletor lê 1+ como mais de 0,5, 2+ como mais de 1,5…) ou a um sim/não que seja o 1+ (Cartão, Marca ou assiste): aí só o 1+ entra.")),
React.createElement("td",{className:"mono-sm"},l.n),
React.createElement("td",{className:"mono-sm"},fmtD(l.last_seen)),
React.createElement("td",null,Number(l.ignorado)?
React.createElement("button",{className:"btn-sm",onClick:()=>ignoraProps(l,false)},"Voltar pro Resolver"):
React.createElement("button",{className:"btn-sm",onClick:()=>ignoraProps(l,true)},"Não interessa"))
);
return React.createElement("div",null,
React.createElement("div",{style:{display:'flex',gap:14,flexWrap:'wrap',marginBottom:12}},
[['Moldes sem tradução',t.linhas],['Odds descartadas (30d)',t.odds],['Marcados como não interessa',t.ignorados]].map(([lb,v])=>
React.createElement("div",{key:lb,style:{background:'#fff',border:'1px solid var(--line-2)',borderRadius:10,padding:'8px 16px'}},
React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},lb),React.createElement("div",{style:{fontSize:18,fontWeight:700}},v==null?'—':v)
))
),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:8}},"Cada linha é uma aposta que chega das fontes e ainda ",
React.createElement("b",null,"não está ligada")," a um mercado nosso, então é jogada fora. Ligar é decisão sua, na guia Resolver: escolha o nosso mercado e vale no próximo ciclo, sem mexer no código. Marque “não interessa” no que for ruído."
),
React.createElement(CatalogoMercadosProps,{catalogo:props.catalogo||[],fontes:props.fontes||[],recarregar:loadProps,setMsg:setMsg}),
React.createElement("h4",{style:{margin:'6px 0',fontSize:14}},"Esperando decisão (",pend.length,")"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Molde"),React.createElement("th",null,"Odds"),React.createElement("th",null,"Visto por último"),React.createElement("th",null))),React.createElement("tbody",null,
pend.map(linha),
!pend.length&&React.createElement("tr",null,React.createElement("td",{colSpan:5,style:{color:'var(--on-surface-variant)'}},"Nada pendente — toda aposta que chegou nos últimos 30 dias tem tradução."))
))),
!!ign.length&&React.createElement(React.Fragment,null,
React.createElement("h4",{style:{margin:'18px 0 6px',fontSize:14}},"Não interessa (",ign.length,")"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Molde"),React.createElement("th",null,"Odds"),React.createElement("th",null,"Visto por último"),React.createElement("th",null))),React.createElement("tbody",null,ign.map(linha))))
)
);
})()
);
}

function SolicitacoesTab({onClose}){
const[lista,setLista]=useState(null),[msg,setMsg]=useState('');
const load=async()=>{try{const r=await fetch('/api/admin/solicitacoes',{credentials:'include'});if(r.status===401){onClose('relogin');return;}setLista(await r.json());}catch(e){setLista([]);}};
useEffect(()=>{load();},[]);
const decidir=async(id,acao)=>{setMsg('');try{await fetch(`/api/admin/solicitacoes/${id}/${acao}`,{method:'POST',credentials:'include'});setMsg(acao==='aprovar'?'✅ Cadastro aprovado':'Cadastro rejeitado');load();}catch(e){setMsg('❌ Erro: '+e.message);}};
if(lista===null)return React.createElement("div",{style:{textAlign:'center',padding:48,color:'var(--on-surface-variant)'}},"Carregando…");
return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg),
lista.length===0?React.createElement("div",{className:"empty",style:{padding:40}},React.createElement("div",{className:"em-ic"},React.createElement(Ic,{n:"how_to_reg"})),React.createElement("div",{className:"em-t"},"Nenhuma solicitação pendente"),React.createElement("div",null,"Novos cadastros aparecem aqui para aprovação.")):
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Nome"),React.createElement("th",null,"E-mail"),React.createElement("th",null,"Quando"),React.createElement("th",null,"Ações"))),
React.createElement("tbody",null,lista.map((u)=>React.createElement("tr",{key:u.id},
React.createElement("td",{style:{fontWeight:600}},u.nome),
React.createElement("td",{className:"mono-sm"},u.email),
React.createElement("td",{style:{color:'var(--on-surface-variant)'}},timeAgo(u.criado_em)),
React.createElement("td",null,React.createElement("div",{style:{display:'flex',gap:6}},
React.createElement("button",{className:"btn-sm b-green",onClick:()=>decidir(u.id,'aprovar')},"Aprovar"),
React.createElement("button",{className:"btn-sm b-red",onClick:()=>decidir(u.id,'rejeitar')},"Rejeitar")
))
)))))
);
}






function situacaoConta(u){
if(u.status==='pendente_aprovacao')return{k:'pendente',t:'Aguardando aprovação',c:'#8A5A00',bg:'#FFF4D6',ic:'hourglass_top'};
if(u.status==='rejeitado')return{k:'rejeitado',t:'Cadastro rejeitado',c:'#A32D2D',bg:'#FDECEC',ic:'block'};
if(Number(u.ativo)===0)return{k:'inativo',t:'Inativo (sem acesso)',c:'#4A5563',bg:'#ECEFF3',ic:'person_off'};
if(u.prazo_vencido)return{k:'inativo',t:'Prazo vencido (sem acesso)',c:'#4A5563',bg:'#ECEFF3',ic:'event_busy'};
if(u.status==='ativo')return{k:'ativo',t:'Ativo',c:'#0F6E56',bg:'#E4F6EF',ic:'check_circle'};
return{k:'inativo',t:'Desativado',c:'#4A5563',bg:'#ECEFF3',ic:'person_off'};
}
const nomesTelas=(ids)=>ABAS_PERFIL.filter(([id])=>(ids||[]).includes(id)).map(([,lbl])=>lbl);

const diaDoPrazo=(d)=>{const p=fusoSP.partesSP(d);return p?`${String(p.dia).padStart(2,'0')}/${String(p.mes).padStart(2,'0')}/${p.ano}`:'—';};
const diasAtePrazo=(d)=>d?Math.ceil((new Date(d).getTime()-Date.now())/86400000):null;

const ativaAprovada=(u)=>u.status==='ativo'&&Number(u.ativo)!==0&&!u.prazo_vencido;
const FILTROS_AVISO={parada:(u)=>!!u.parada_dias,sem2fa:(u)=>ativaAprovada(u)&&!u.totp_ativo,prazo:(u)=>ativaAprovada(u)&&u.acesso_ate&&diasAtePrazo(u.acesso_ate)<=7,provisoria:(u)=>ativaAprovada(u)&&u.trocar_senha};
function quandoFoi(d){
if(!d)return'nunca';const s=Math.floor((Date.now()-new Date(d).getTime())/1000);if(isNaN(s))return'—';
if(s<120)return'agora há pouco';if(s<3600)return`há ${Math.floor(s/60)} min`;
if(s<86400){const h=Math.floor(s/3600);return`há ${h} hora${h>1?'s':''}`;}
const dd=Math.floor(s/86400);return`há ${dd} dia${dd>1?'s':''}`;
}
function UsuariosTab({onClose,usuario}){
const euMaster=!!(usuario&&usuario.master),euId=usuario&&usuario.id;
const[lista,setLista]=useState(null),[erroLista,setErroLista]=useState(''),[msg,setMsg]=useState('');
const[busca,setBusca]=useState(''),[fSit,setFSit]=useState('todos'),[fPapel,setFPapel]=useState('todos');
const[modalPerfis,setModalPerfis]=useState(null),[editando,setEditando]=useState(null),[senhaNova,setSenhaNova]=useState(null),[historico,setHistorico]=useState(null),[aberto,setAberto]=useState(null);
const[sessoesDe,setSessoesDe]=useState(null),[histGeral,setHistGeral]=useState(false);
const load=()=>leJson('/api/admin/usuarios').then((d)=>{setLista(Array.isArray(d)?d:[]);setErroLista('');}).
catch((e)=>{if(e.status===401){onClose('relogin');return;}setErroLista('A lista de usuários não carregou: '+e.message);setLista((l)=>l||[]);});
useEffect(()=>{load();},[]);
const grava=async(url,method,corpo)=>{
const r=await fetch(url,{method,credentials:'include',...(corpo?{headers:{'Content-Type':'application/json'},body:JSON.stringify(corpo)}:{})});
if(r.status===401){onClose('relogin');return null;}
const d=await r.json().catch(()=>({}));
if(!r.ok)throw new Error(d.error||'erro '+r.status);
return d;
};
const faz=async(fn)=>{setMsg('');try{const d=await fn();if(d){setMsg('✅ '+(d.mensagem||'Feito.'));load();}}catch(e){setMsg('❌ Não deu certo: '+e.message);}};
const base=(u)=>`/api/admin/usuarios/${u.id}`;
const novaSenha=async(u)=>{
if(!(await confirma(`Gerar uma senha nova para ${u.nome}?\n\nA senha de agora deixa de valer e ${u.nome} sai de todos os aparelhos. A senha nova aparece UMA vez, para você copiar e mandar para a pessoa.`,{sim:'Gerar senha nova'})))return;
setMsg('');try{const d=await grava(base(u)+'/nova-senha','POST');if(d){setSenhaNova({nome:u.nome,email:u.email,senha:d.senha,novo:false});load();}}catch(e){setMsg('❌ Não deu certo: '+e.message);}};
const mudarAtivo=async(u,ativo)=>{
if(!(await confirma(ativo?`Reativar ${u.nome}?\n\nA pessoa volta a entrar no painel com a mesma senha e as mesmas telas de antes.`:
`Inativar ${u.nome}?\n\nA pessoa perde o acesso agora (sai de todos os aparelhos) e não consegue mais entrar. Nada é apagado: dá para reativar quando quiser.`,{sim:ativo?'Reativar':'Inativar'})))return;
faz(()=>grava(base(u)+'/ativo','PUT',{ativo}));};
const encerrar=async(u)=>{if(!(await confirma(`Encerrar as sessões abertas de ${u.nome}?\n\nA pessoa sai de todos os aparelhos e precisa entrar de novo (a senha continua a mesma).`,{sim:'Encerrar sessões'})))return;faz(()=>grava(base(u)+'/encerrar-sessoes','POST'));};
const resetar2fa=async(u)=>{if(!(await confirma(`Resetar o 2FA de ${u.nome}?\n\nNo próximo login a pessoa configura o app autenticador de novo (use quando ela trocar ou perder o celular).`,{sim:'Resetar 2FA'})))return;faz(()=>grava(base(u)+'/resetar-2fa','POST'));};

const mudarMaster=async(u,master)=>{
if(!(await confirma(master?`Tornar ${u.nome} admin master? Vê e altera as telas exclusivas (Filtro de EV, Odd justa por segmento, Histórico de EV) e pode dar ou tirar o master de outros.`:`Tirar o admin master de ${u.nome}? Continua admin.`)))return;
faz(()=>grava(base(u)+'/master','PUT',{master}));};
const excluir=async(u)=>{if(!(await confirma(`Excluir ${u.nome} DE VEZ?\n\nIsto apaga a conta e não tem volta. Se a ideia é só tirar o acesso, use "Inativar". Se a pessoa voltar, vai precisar de uma conta nova.`,{sim:'Excluir de vez'})))return;faz(()=>grava(base(u),'DELETE'));};
const decidir=async(u,acao)=>{
if(acao==='rejeitar'&&!(await confirma(`Rejeitar o cadastro de ${u.nome}?`,{sim:'Rejeitar'})))return;
faz(async()=>{const d=await grava(`/api/admin/solicitacoes/${u.id}/${acao}`,'POST');return d&&{mensagem:acao==='aprovar'?`Cadastro de ${u.nome} aprovado.`:`Cadastro de ${u.nome} rejeitado.`};});};
if(lista===null)return React.createElement("div",{style:{textAlign:'center',padding:48,color:'var(--on-surface-variant)'}},"Carregando…");
const q=busca.trim().toLowerCase();
const sit=(u)=>situacaoConta(u).k;
const qtd=(k)=>lista.filter((u)=>sit(u)===k).length;
const passa=(u)=>fSit==='todos'||(FILTROS_AVISO[fSit]?FILTROS_AVISO[fSit](u):sit(u)===fSit);
const visiveis=lista.filter((u)=>passa(u)&&(
fPapel==='todos'||(fPapel==='master'?!!Number(u.master):u.papel===fPapel))&&(
!q||String(u.nome||'').toLowerCase().includes(q)||String(u.email||'').toLowerCase().includes(q)));
const filtrosSit=[['todos','Todos',lista.length],['ativo','Ativos',qtd('ativo')],['inativo','Inativos',qtd('inativo')],['pendente','Aguardando aprovação',qtd('pendente')],['rejeitado','Rejeitados',qtd('rejeitado')]].
filter(([k,,n])=>['todos','ativo','inativo'].includes(k)||n>0);
const icBtn={fontSize:15,verticalAlign:'-3px',marginRight:3};

const nomesDe=(l)=>l.slice(0,4).map((u)=>u.nome).join(', ')+(l.length>4?` e mais ${l.length-4}`:'');
const avisos=[
['parada','schedule',lista.filter(FILTROS_AVISO.parada),(l)=>`${l.length===1?'1 conta ativa não entra':l.length+' contas ativas não entram'} no painel há mais de 30 dias (${nomesDe(l)}). Se a pessoa não usa mais, inative.`],
['sem2fa','phonelink_lock',lista.filter(FILTROS_AVISO.sem2fa),(l)=>`${l.length===1?'1 conta ativa ainda não configurou':l.length+' contas ativas ainda não configuraram'} o 2FA, o código do celular (${nomesDe(l)}). O painel pede isso no próximo login; se a pessoa nunca entrou, mande o endereço e a senha de novo.`],
['prazo','event',lista.filter(FILTROS_AVISO.prazo),(l)=>`${l.length===1?'1 conta perde':l.length+' contas perdem'} o acesso nos próximos 7 dias pelo prazo de acesso (${nomesDe(l)}). Para estender, edite e mude a data.`],
['provisoria','password',lista.filter(FILTROS_AVISO.provisoria),(l)=>`${l.length===1?'1 conta ainda está':l.length+' contas ainda estão'} com a senha provisória gerada aqui (${nomesDe(l)}): a pessoa troca no primeiro acesso.`]].
filter(([,,l])=>l.length);
return React.createElement("div",null,
React.createElement("div",{style:{display:'flex',gap:10,alignItems:'center',flexWrap:'wrap',marginBottom:12}},
React.createElement("input",{className:"inp",style:{flex:'1 1 240px',width:'auto'},placeholder:"Buscar por nome ou e-mail…",value:busca,onChange:(e)=>setBusca(e.target.value),"aria-label":"Buscar usuário"}),
React.createElement("div",{className:"sel-wrap",style:{flex:'0 0 180px'}},React.createElement("select",{className:"sel",value:fPapel,onChange:(e)=>setFPapel(e.target.value),"aria-label":"Filtrar por papel"},React.createElement("option",{value:"todos"},"Todos os papéis"),React.createElement("option",{value:"admin"},"Admins"),React.createElement("option",{value:"master"},"Admins master"),React.createElement("option",{value:"tipster"},"Tipsters")),React.createElement(Ic,{n:"arrow_drop_down"})),
React.createElement("button",{className:"btn-sm",style:{padding:'9px 14px',fontSize:13.5},onClick:()=>setHistGeral(true)},React.createElement(Ic,{n:"history",style:icBtn}),"Histórico geral"),
React.createElement("button",{className:"btn-sm b-green",style:{padding:'9px 16px',fontSize:13.5},onClick:()=>setEditando('novo')},React.createElement(Ic,{n:"person_add",style:icBtn}),"Criar usuário")
),
avisos.length>0&&React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:6,marginBottom:12}},avisos.map(([k,ic,l,txt])=>
React.createElement("div",{key:k,style:{display:'flex',gap:10,alignItems:'center',padding:'9px 12px',background:'#FFF8E6',border:'1px solid #F3D9A9',borderRadius:10,fontSize:13,color:'#6B4A00'}},
React.createElement(Ic,{n:ic,style:{fontSize:19}}),React.createElement("span",{style:{flex:1}},txt(l)),
React.createElement("button",{className:"btn-sm",onClick:()=>setFSit(fSit===k?'todos':k)},fSit===k?'Mostrar todos':'Ver quem')
))),
React.createElement("div",{className:"seg",style:{display:'inline-flex',marginBottom:12}},filtrosSit.map(([k,l,n])=>React.createElement("button",{key:k,className:'segb'+(fSit===k?' on':''),onClick:()=>setFSit(k)},l," (",n,")")),
FILTROS_AVISO[fSit]&&React.createElement("button",{className:"segb on",onClick:()=>setFSit('todos')},{parada:'Paradas',sem2fa:'Sem 2FA',prazo:'Prazo vencendo',provisoria:'Senha provisória'}[fSit]," (",visiveis.length,") ✕")),
erroLista&&React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erroLista," ",React.createElement("button",{className:"btn-sm",onClick:load},"Tentar de novo")),
msg&&React.createElement("div",{className:"toast",role:"status"},msg),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Usuário"),React.createElement("th",null,"Papel"),React.createElement("th",null,"Telas que vê"),React.createElement("th",null,"Situação"),React.createElement("th",null,"2FA"),React.createElement("th",null,"Último acesso"),React.createElement("th",null,"Ações"))),
React.createElement("tbody",null,visiveis.map((u)=>{
const s=situacaoConta(u),eu=u.id===euId,master=!!Number(u.master),podeMexer=!master||euMaster,inativo=Number(u.ativo)===0||!!u.prazo_vencido,mais=aberto===u.id;
return React.createElement(React.Fragment,{key:u.id},
React.createElement("tr",null,
React.createElement("td",{style:inativo?{opacity:.6}:undefined},React.createElement("div",{style:{fontWeight:600}},u.nome,eu&&React.createElement("span",{className:"pill",style:{marginLeft:6}},"você")),React.createElement("div",{className:"mono-sm",style:{color:'var(--on-surface-variant)'}},u.email)),
React.createElement("td",null,u.papel==='admin'?React.createElement("span",{style:{color:'var(--tertiary-dim)',fontWeight:600}},master?'Admin master':'Admin'):'Tipster'),
React.createElement("td",{style:{maxWidth:240,fontSize:12.5}},u.papel==='admin'?React.createElement("span",{style:{color:'var(--on-surface-variant)'}},"Todas (admin)"):React.createElement(React.Fragment,null,
React.createElement("div",null,nomesTelas(u.abas).join(' · ')||'—'),
React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},(u.perfis||[]).length?'Perfis: '+u.perfis.map((p)=>p.nome+(p.ativo?'':' (perfil inativo)')).join(', '):'Sem perfil: vê o padrão'))),
React.createElement("td",null,React.createElement("span",{style:{display:'inline-flex',alignItems:'center',gap:4,padding:'3px 9px',borderRadius:999,background:s.bg,color:s.c,fontWeight:700,fontSize:12,whiteSpace:'nowrap'}},React.createElement(Ic,{n:s.ic,style:{fontSize:15}}),s.t),
u.acesso_ate&&!u.prazo_vencido&&Number(u.ativo)!==0&&React.createElement("div",{style:{fontSize:11.5,marginTop:3,color:diasAtePrazo(u.acesso_ate)<=7?'#8A5A00':'var(--on-surface-variant)',fontWeight:diasAtePrazo(u.acesso_ate)<=7?700:400}},"Acesso até ",diaDoPrazo(u.acesso_ate),diasAtePrazo(u.acesso_ate)<=7?` (faltam ${diasAtePrazo(u.acesso_ate)} dia${diasAtePrazo(u.acesso_ate)===1?'':'s'})`:''),
u.trocar_senha&&ativaAprovada(u)&&React.createElement("div",{style:{fontSize:11.5,marginTop:3,color:'var(--on-surface-variant)'}},"Senha provisória (ainda não trocou)")),
React.createElement("td",{style:{fontSize:12.5}},u.totp_ativo?React.createElement("span",{style:{color:'#0F6E56'}},"✓ Ligado"):React.createElement("span",{style:{color:ativaAprovada(u)?'#8A5A00':'var(--on-surface-variant)',fontWeight:ativaAprovada(u)?600:400},title:"A pessoa configura o app autenticador no próximo login"},"⚠ Falta configurar")),
React.createElement("td",{style:{whiteSpace:'nowrap',fontSize:12.5},title:u.ultimo_acesso?fusoSP.fmtSP(u.ultimo_acesso)+' (São Paulo)'+(u.acesso_estimado?' — estimado pelo último login':''):''},u.acesso_estimado?'≈ ':'',quandoFoi(u.ultimo_acesso),
u.parada_dias&&React.createElement("div",{style:{fontSize:11.5,color:'#8A5A00',fontWeight:700}},"Parada há ",u.parada_dias," dias"),
u.sessoes>0&&React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},u.sessoes," ",u.sessoes===1?'sessão aberta':'sessões abertas')),
React.createElement("td",null,React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},
s.k==='pendente'?React.createElement(React.Fragment,null,React.createElement("button",{className:"btn-sm b-green",onClick:()=>decidir(u,'aprovar')},"Aprovar"),React.createElement("button",{className:"btn-sm b-red",onClick:()=>decidir(u,'rejeitar')},"Rejeitar")):null,
podeMexer?React.createElement("button",{className:"btn-sm",onClick:()=>setEditando(u)},React.createElement(Ic,{n:"edit",style:icBtn}),"Editar"):null,
podeMexer&&!eu?React.createElement("button",{className:"btn-sm",onClick:()=>novaSenha(u)},React.createElement(Ic,{n:"key",style:icBtn}),"Nova senha"):null,
podeMexer&&!eu&&s.k==='ativo'&&(u.papel!=='admin'||euMaster)?React.createElement("button",{className:"btn-sm b-amber",onClick:()=>mudarAtivo(u,false)},React.createElement(Ic,{n:"person_off",style:icBtn}),"Inativar"):null,
podeMexer&&inativo?React.createElement("button",{className:"btn-sm b-green",onClick:()=>mudarAtivo(u,true)},React.createElement(Ic,{n:"person_check",style:icBtn}),"Reativar"):null,
React.createElement("button",{className:"btn-sm","aria-expanded":mais,onClick:()=>setAberto(mais?null:u.id)},mais?'Menos ▴':'Mais ▾')
))
),
mais&&React.createElement("tr",null,React.createElement("td",{colSpan:7,style:{background:'var(--paper-2)'}},React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}},
React.createElement("span",{style:{fontSize:12,color:'var(--on-surface-variant)',marginRight:6}},u.criado_em?`Conta criada ${quandoFoi(u.criado_em)}${u.criado_por_nome?' por '+u.criado_por_nome:''}.`:''),
React.createElement("button",{className:"btn-sm",onClick:()=>setHistorico(u)},React.createElement(Ic,{n:"history",style:icBtn}),"Histórico da conta"),
u.papel!=='admin'&&podeMexer?React.createElement("button",{className:"btn-sm",onClick:()=>setModalPerfis(u)},React.createElement(Ic,{n:"filter_alt",style:icBtn}),"Perfis e ajustes de filtro"):null,
u.sessoes>0?React.createElement("button",{className:"btn-sm",onClick:()=>setSessoesDe(u)},React.createElement(Ic,{n:"devices",style:icBtn}),"Sessões abertas (",u.sessoes,")"):null,
u.totp_ativo&&podeMexer?React.createElement("button",{className:"btn-sm b-amber",onClick:()=>resetar2fa(u)},"Resetar 2FA"):null,
u.papel==='admin'&&!master&&euMaster&&s.k==='ativo'?React.createElement("button",{className:"btn-sm",onClick:()=>mudarMaster(u,true)},"Tornar admin master"):null,
master&&euMaster&&!eu?React.createElement("button",{className:"btn-sm b-amber",onClick:()=>mudarMaster(u,false)},"Tirar master"):null,
u.papel!=='admin'&&(inativo||s.k==='rejeitado')?React.createElement("button",{className:"btn-sm b-red",onClick:()=>excluir(u)},"Excluir de vez"):null,
!podeMexer?React.createElement("span",{style:{fontSize:12,color:'var(--on-surface-variant)'}},"Só um admin master mexe nesta conta."):null
)))
);}),
!visiveis.length&&React.createElement("tr",null,React.createElement("td",{colSpan:7,style:{textAlign:'center',padding:28,color:'var(--on-surface-variant)'}},lista.length?'Nenhum usuário com essa busca ou filtro.':'Nenhum usuário cadastrado.'))
))),
React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)'}},"Inativar tira o acesso sem apagar nada (dá para reativar depois). \"Excluir de vez\" fica em \"Mais\" e só aparece para tipster já inativo ou com cadastro rejeitado."),
editando&&React.createElement(UsuarioModal,{alvo:editando==='novo'?null:editando,euMaster:euMaster,euId:euId,onClose:()=>setEditando(null),onRelogin:()=>onClose('relogin'),
onSalvo:(d,dados)=>{setEditando(null);if(d.senha)setSenhaNova({nome:dados.nome,email:dados.email,senha:d.senha,novo:true});setMsg('✅ '+(d.mensagem||'Salvo.'));load();}}),
senhaNova&&React.createElement(SenhaGeradaModal,{info:senhaNova,onClose:()=>setSenhaNova(null)}),
historico&&React.createElement(HistoricoContaModal,{alvo:historico,onClose:()=>setHistorico(null),onRelogin:()=>onClose('relogin')}),
sessoesDe&&React.createElement(SessoesModal,{alvo:sessoesDe,eu:sessoesDe.id===euId,podeMexer:!Number(sessoesDe.master)||euMaster,onClose:()=>{setSessoesDe(null);load();},onRelogin:()=>onClose('relogin'),grava:grava,encerrarTodas:()=>{setSessoesDe(null);encerrar(sessoesDe);}}),
histGeral&&React.createElement(HistoricoGeralModal,{admins:lista.filter((u)=>u.papel==='admin'),onClose:()=>setHistGeral(false),onRelogin:()=>onClose('relogin')}),
modalPerfis&&React.createElement(AtribuirPerfisModal,{tipster:modalPerfis,onClose:()=>setModalPerfis(null),onSaved:()=>{setMsg('✅ Perfis atualizados');load();},onRelogin:()=>onClose('relogin')})
);
}



function UsuarioModal({alvo,euMaster,euId,onClose,onSalvo,onRelogin}){
const novo=!alvo;
const[nome,setNome]=useState(alvo?alvo.nome:''),[email,setEmail]=useState(alvo?alvo.email:''),[papel,setPapel]=useState(alvo?alvo.papel:'tipster');
const[sel,setSel]=useState(()=>new Set(alvo?(alvo.perfis||[]).map((p)=>p.id):[]));

const prazoInicial=alvo&&alvo.acesso_ate?fusoSP.diaSP(alvo.acesso_ate)||'':'';
const[prazo,setPrazo]=useState(prazoInicial);
const[perfis,setPerfis]=useState(null),[erro,setErro]=useState(''),[salvando,setSalvando]=useState(false);
useEffect(()=>{leJson('/api/admin/perfis').then((d)=>setPerfis(Array.isArray(d)?d:[])).catch((e)=>{if(e.status===401){onRelogin();return;}setPerfis([]);setErro('Os perfis não carregaram: '+e.message);});},[]);

const travaPapel=novo?'':String(alvo.id)===String(euId)?'Você não pode mudar o seu próprio papel.':Number(alvo.master)?'O admin master não muda de papel.':
alvo.papel==='admin'&&!euMaster?'Só o admin master pode tirar outro admin.':alvo.papel!=='admin'&&(alvo.status!=='ativo'||Number(alvo.ativo)===0)?'Para virar admin, a conta precisa estar aprovada e ativa.':'';
const toggle=(id)=>setSel((p)=>{const n=new Set(p);n.has(id)?n.delete(id):n.add(id);return n;});
const telas=papel==='admin'?ABAS_PERFIL.map((a)=>a[0]):(()=>{
const ativos=(perfis||[]).filter((p)=>sel.has(p.id)&&Number(p.ativo));
if(!ativos.length)return ABAS_PADRAO;
const s=new Set();ativos.forEach((p)=>(p.abas||ABAS_PADRAO).forEach((a)=>s.add(a)));return ABAS_PERFIL.map((a)=>a[0]).filter((a)=>s.has(a));
})();
const salvar=async()=>{
if(!nome.trim()){setErro('Preencha o nome.');return;}
if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())){setErro('Confira o e-mail: ele parece incompleto.');return;}
setSalvando(true);setErro('');
try{
let acesso_ate;
if(prazo!==prazoInicial){
if(!prazo)acesso_ate=null;else
{const[a,m,d]=prazo.split('-').map(Number);const t=fusoSP.instanteSP(a,m,d,23,59);if(!t){setErro('Confira a data do prazo de acesso.');setSalvando(false);return;}acesso_ate=t.toISOString();}
}
const corpo={nome:nome.trim(),email:email.trim(),perfil_ids:[...sel],...(novo||!travaPapel?{papel}:{}),...(acesso_ate!==undefined?{acesso_ate}:{})};
const r=await fetch(novo?'/api/admin/usuarios':`/api/admin/usuarios/${alvo.id}`,{method:novo?'POST':'PUT',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(corpo)});
if(r.status===401){onRelogin();return;}
const d=await r.json().catch(()=>({}));
if(!r.ok)throw new Error(d.error||'erro '+r.status);
onSalvo(d,{nome:corpo.nome,email:corpo.email.toLowerCase()});
}catch(e){setErro('Não salvou: '+e.message);setSalvando(false);}
};
const rot={fontSize:12,fontWeight:700,color:'var(--teal-deep)',textTransform:'uppercase',letterSpacing:.4,margin:'14px 0 6px',display:'block'};
const opPapel=(v,titulo,txt)=>{const on=papel===v,trava=!!travaPapel&&!on;return(
React.createElement("div",{key:v,onClick:()=>!travaPapel&&setPapel(v),style:{flex:'1 1 200px',padding:'10px 12px',borderRadius:10,border:'1.5px solid '+(on?'var(--teal-deep)':'var(--line-2)'),background:on?'var(--paper-2)':'#fff',cursor:travaPapel?'not-allowed':'pointer',opacity:trava?.5:1}},
React.createElement("div",{style:{fontWeight:700,color:'var(--navy-900)'}},on?'● ':'○ ',titulo),React.createElement("div",{style:{fontSize:12,color:'var(--mut)'}},txt)
));};
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&!salvando&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:580},role:"dialog","aria-modal":"true"},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}},
React.createElement("h2",null,React.createElement(Ic,{n:novo?'person_add':'edit'}),novo?'Criar usuário':'Editar '+alvo.nome),
React.createElement("button",{className:"x-btn",onClick:onClose,"aria-label":"Fechar"},React.createElement(Ic,{n:"close"}))
),
erro&&React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro),
React.createElement("label",{style:rot},"Nome"),
React.createElement("input",{className:"inp",value:nome,onChange:(e)=>setNome(e.target.value),placeholder:"Nome e sobrenome",autoFocus:true}),
React.createElement("label",{style:rot},"E-mail (é o que a pessoa usa para entrar)"),
React.createElement("input",{className:"inp",type:"email",value:email,onChange:(e)=>setEmail(e.target.value),placeholder:"nome@exemplo.com"}),
React.createElement("label",{style:rot},"Papel"),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap'}},
opPapel('tipster','Tipster','Vê só as telas dos perfis marcados abaixo.'),
opPapel('admin','Admin','Vê todas as telas e administra o painel (usuários, fontes, pareamentos).')
),
travaPapel&&React.createElement("div",{style:{fontSize:12,color:'var(--mut)',marginTop:6}},travaPapel),
papel==='tipster'&&React.createElement(React.Fragment,null,
React.createElement("label",{style:rot},"Perfis (definem as telas e os filtros)"),
perfis===null?React.createElement("div",{style:{color:'var(--mut)',fontSize:12.5}},"Carregando perfis…"):
!perfis.length?React.createElement("div",{style:{color:'var(--mut)',fontSize:12.5}},"Nenhum perfil criado ainda. Sem perfil, a pessoa vê o padrão (Super Odds e Player Props). Crie perfis em \"Perfis\"."):
React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:6,maxHeight:220,overflowY:'auto'}},perfis.map((p)=>{const on=sel.has(p.id);return(
React.createElement("label",{key:p.id,style:{display:'flex',gap:9,alignItems:'flex-start',padding:'8px 10px',border:'1px solid '+(on?'var(--teal-deep)':'var(--line-2)'),borderRadius:9,cursor:'pointer',background:on?'var(--paper-2)':'#fff'}},
React.createElement("input",{type:"checkbox",checked:on,onChange:()=>toggle(p.id),style:{marginTop:3}}),
React.createElement("span",null,React.createElement("b",null,p.nome),!Number(p.ativo)&&React.createElement("span",{style:{fontSize:11,color:'var(--mut)'}}," (perfil inativo: não libera nada)"),
React.createElement("span",{style:{display:'block',fontSize:11.5,color:'var(--mut)'}},"Telas: ",nomesTelas(p.abas||ABAS_PADRAO).join(' · '),p.descricao?' — '+p.descricao:''))
));}))
),
React.createElement("label",{style:rot},"Prazo de acesso (opcional)"),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}},
React.createElement("input",{className:"inp",type:"date",style:{width:180},value:prazo,min:fusoSP.diaSP(new Date()),onChange:(e)=>setPrazo(e.target.value),"aria-label":"Prazo de acesso"}),
prazo?React.createElement("button",{className:"btn-sm",onClick:()=>setPrazo('')},"Sem prazo"):null,
React.createElement("span",{style:{fontSize:12,color:'var(--mut)',flex:'1 1 200px'}},prazo?`A pessoa entra até ${prazo.split('-').reverse().join('/')} às 23:59 (São Paulo). Depois disso perde o acesso sozinha, sem apagar nada.`:'Sem prazo: o acesso vale até alguém inativar. Use para tipster temporário.')
),
React.createElement("div",{style:{marginTop:14,padding:'10px 12px',borderRadius:10,background:'#E4F6EF',border:'1px solid #A9E1CC',fontSize:13}},
React.createElement("b",null,"Telas que ",nome.trim()||'a pessoa'," vai ver:")," ",nomesTelas(telas).join(' · '),papel==='admin'?' e todo o Admin Menu':'',
papel==='tipster'&&!(perfis||[]).some((p)=>sel.has(p.id)&&Number(p.ativo))&&React.createElement("div",{style:{fontSize:11.5,color:'#0F6E56'}},"Sem perfil ativo marcado: vale o padrão.")
),
novo&&React.createElement("div",{style:{marginTop:10,fontSize:12.5,color:'var(--mut)'}},"A senha é gerada pelo painel ao criar. Ela aparece uma vez só, para você copiar e mandar para a pessoa. É provisória: no primeiro acesso o painel pede para configurar o app autenticador (2FA) no celular e para a pessoa escolher a senha dela."),
React.createElement("div",{style:{display:'flex',justifyContent:'flex-end',gap:8,marginTop:16}},
React.createElement("button",{className:"btn-sm",onClick:onClose,disabled:salvando},"Cancelar"),
React.createElement("button",{className:"btn-sm b-green",onClick:salvar,disabled:salvando},salvando?'Salvando…':novo?'Criar e gerar senha':'Salvar')
)
)
);
}


function SenhaGeradaModal({info,onClose}){
const[copiado,setCopiado]=useState('');
const link=location.origin+'/login';
const mensagem=`Olá, ${info.nome}! ${info.novo?'Seu acesso ao painel Odds Radar está pronto.':'Sua senha do painel Odds Radar foi trocada.'}\n\nEndereço: ${link}\nE-mail: ${info.email}\nSenha: ${info.senha}\n\n`+(
info.novo?'No primeiro acesso o painel pede para configurar um app autenticador (Google Authenticator ou parecido) no celular. ':'')+'Esta senha é provisória: ao entrar, o painel pede para você escolher a sua.';
const copia=async(txt,qual)=>{try{await navigator.clipboard.writeText(txt);setCopiado(qual);}catch(e){setCopiado('erro');}};
return React.createElement("div",{className:"overlay"},
React.createElement("div",{className:"modal",style:{maxWidth:520},role:"dialog","aria-modal":"true"},
React.createElement("h2",null,React.createElement(Ic,{n:"key"}),info.novo?'Conta criada':'Senha nova gerada'),
React.createElement("div",{style:{fontSize:13.5,margin:'6px 0 10px'}},"Senha de ",React.createElement("b",null,info.nome)," (",info.email,"):"),
React.createElement("div",{style:{fontFamily:'var(--f-data, monospace)',fontSize:22,fontWeight:700,letterSpacing:1,padding:'14px 16px',background:'var(--paper-2)',border:'1px dashed var(--line-2)',borderRadius:10,textAlign:'center',userSelect:'all',wordBreak:'break-all'}},info.senha),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',margin:'12px 0'}},
React.createElement("button",{className:"btn-sm b-green",onClick:()=>copia(info.senha,'senha')},React.createElement(Ic,{n:"content_copy",style:{fontSize:15,verticalAlign:'-3px',marginRight:3}}),"Copiar senha"),
React.createElement("button",{className:"btn-sm",onClick:()=>copia(mensagem,'mensagem')},"Copiar mensagem pronta para mandar")
),
copiado&&React.createElement("div",{className:"toast",role:"status"},copiado==='erro'?'Não consegui copiar sozinho: selecione a senha com o mouse e copie (Ctrl+C).':copiado==='senha'?'✅ Senha copiada.':'✅ Mensagem copiada: é só colar no WhatsApp ou no e-mail da pessoa.'),
React.createElement("div",{style:{background:'#FFF4D6',border:'1px solid #F3D9A9',borderRadius:10,padding:'10px 12px',fontSize:12.5,color:'#6B4A00'}},React.createElement("b",null,"Atenção:")," esta senha aparece só agora. Depois de fechar, ninguém consegue vê-la de novo (nem você). Se perder, gere outra."),
React.createElement("div",{style:{display:'flex',justifyContent:'flex-end',marginTop:14}},React.createElement("button",{className:"btn-sm b-green",onClick:onClose},"Já copiei, fechar"))
)
);
}


const ACOES_CONTA={criar:'Criou a conta',editar:'Editou os dados',nova_senha:'Gerou senha nova',inativar:'Inativou (tirou o acesso)',reativar:'Reativou a conta',encerrar_sessoes:'Encerrou as sessões',resetar_2fa:'Resetou o 2FA',papel:'Mudou o papel',master:'Mudou o admin master',perfis:'Mudou os perfis',aprovar:'Aprovou o cadastro',rejeitar:'Rejeitou o cadastro',excluir:'Excluiu a conta',ilegivel:'Registro ilegível',
derrubar_sessao:'Derrubou uma sessão',prazo_vencido:'Perdeu o acesso pelo prazo',trocou_senha:'Trocou a senha provisória'};
const CAMPOS_CONTA={nome:'nome',email:'e-mail',papel:'papel',master:'admin master',acesso_ate:'prazo de acesso'};

const valorConta=(k,v)=>v==null||v===''?k==='acesso_ate'?'sem prazo':'—':k==='acesso_ate'?diaDoPrazo(v):String(v);
const detalheConta=(it)=>[...Object.entries(it.mudancas||{}).map(([k,v])=>k==='perfil_ids'?`perfis: ${(v.de||[]).length} → ${(v.para||[]).length}`:`${CAMPOS_CONTA[k]||k}: ${valorConta(k,v.de)} → ${valorConta(k,v.para)}`),
...(it.acao==='derrubar_sessao'?[`${aparelho(it.aparelho)}${it.ip?' · IP '+it.ip:''}`]:[]),
...(it.acao==='prazo_vencido'&&it.acesso_ate?[`prazo: ${diaDoPrazo(it.acesso_ate)}`]:[])].join(' · ');
function HistoricoContaModal({alvo,onClose,onRelogin}){
const[itens,setItens]=useState(null),[erro,setErro]=useState('');
useEffect(()=>{leJson(`/api/admin/usuarios/${alvo.id}/historico`).then((d)=>setItens(d&&d.itens||[])).catch((e)=>{if(e.status===401){onRelogin();return;}setItens([]);setErro('O histórico não carregou: '+e.message);});},[]);
const detalhe=detalheConta;
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:620},role:"dialog","aria-modal":"true"},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}},
React.createElement("h2",null,React.createElement(Ic,{n:"history"}),"Histórico de ",alvo.nome),
React.createElement("button",{className:"x-btn",onClick:onClose,"aria-label":"Fechar"},React.createElement(Ic,{n:"close"}))
),
erro&&React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro),
itens===null?React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--mut)'}},"Carregando…"):
!itens.length?React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--mut)'}},"Nenhuma mudança registrada ainda (o registro começou em 31/10/2026)."):
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Quando (São Paulo)"),React.createElement("th",null,"O que foi feito"),React.createElement("th",null,"Por quem"))),React.createElement("tbody",null,
itens.map((it)=>React.createElement("tr",{key:it.id},React.createElement("td",{style:{whiteSpace:'nowrap'}},fusoSP.fmtSP(it.quando)),
React.createElement("td",null,ACOES_CONTA[it.acao]||it.acao,detalhe(it)&&React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)'}},detalhe(it))),
React.createElement("td",null,it.porNome||(it.por!=null?'#'+it.por:'—'))))
)))
)
);
}



function SessoesModal({alvo,eu,podeMexer,onClose,onRelogin,grava,encerrarTodas}){
const[lista,setLista]=useState(null),[erro,setErro]=useState(''),[msg,setMsg]=useState('');
const load=()=>leJson(`/api/admin/usuarios/${alvo.id}/sessoes`).then((d)=>{setLista(d&&d.sessoes||[]);setErro('');}).
catch((e)=>{if(e.status===401){onRelogin();return;}setLista((l)=>l||[]);setErro('As sessões não carregaram: '+e.message);});
useEffect(()=>{load();},[]);
const derrubar=async(s)=>{
if(!(await confirma(`Derrubar a sessão de ${alvo.nome} em ${aparelho(s.user_agent)}?\n\nSó esse aparelho sai; os outros continuam. A senha não muda.`,{sim:'Derrubar'})))return;
setMsg('');try{const d=await grava(`/api/admin/usuarios/${alvo.id}/sessoes/${s.chave}`,'DELETE');if(d){setMsg('✅ '+(d.mensagem||'Feito.'));load();}}catch(e){setMsg('❌ Não deu certo: '+e.message);}};
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:760},role:"dialog","aria-modal":"true"},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}},
React.createElement("h2",null,React.createElement(Ic,{n:"devices"}),"Sessões abertas de ",alvo.nome),
React.createElement("button",{className:"x-btn",onClick:onClose,"aria-label":"Fechar"},React.createElement(Ic,{n:"close"}))
),
React.createElement("div",{style:{fontSize:12.5,color:'var(--mut)',marginBottom:10}},"Cada linha é um aparelho (navegador) em que a pessoa está logada. Cada login vale 30 dias."),
erro&&React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro),
msg&&React.createElement("div",{className:"toast",role:"status"},msg),
lista===null?React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--mut)'}},"Carregando…"):
!lista.length?React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--mut)'}},"Nenhuma sessão aberta: a pessoa não está logada em nenhum aparelho."):
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Aparelho"),React.createElement("th",null,"Entrou (São Paulo)"),React.createElement("th",null,"Último uso"),React.createElement("th",null,"Vale até"),React.createElement("th",null))),React.createElement("tbody",null,
lista.map((s)=>React.createElement("tr",{key:s.chave},
React.createElement("td",null,React.createElement("b",null,aparelho(s.user_agent)),s.minha&&React.createElement("span",{className:"pill",style:{marginLeft:6}},"você, agora"),React.createElement("div",{className:"mono-sm",style:{color:'var(--on-surface-variant)'}},"IP ",s.ip||'—')),
React.createElement("td",{style:{whiteSpace:'nowrap'}},s.inicio_estimado?'≈ ':'',fusoSP.fmtSP(s.inicio)),
React.createElement("td",{style:{whiteSpace:'nowrap'}},s.visto_em?quandoFoi(s.visto_em):'—'),
React.createElement("td",{style:{whiteSpace:'nowrap'}},fusoSP.fmtSP(s.expira_em)),
React.createElement("td",null,podeMexer&&!s.minha?React.createElement("button",{className:"btn-sm b-red",onClick:()=>derrubar(s)},"Derrubar"):null)
))
))),
lista&&lista.some((s)=>s.inicio_estimado)&&React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)'}},"≈ sessão aberta antes desta versão do painel: a hora de entrada é estimada pela validade de 30 dias, e o último uso aparece depois do próximo acesso."),
React.createElement("div",{style:{display:'flex',justifyContent:'flex-end',gap:8,marginTop:12}},
podeMexer&&!eu&&lista&&lista.length>1?React.createElement("button",{className:"btn-sm b-amber",onClick:encerrarTodas},"Derrubar todas"):null,
React.createElement("button",{className:"btn-sm",onClick:onClose},"Fechar")
)
)
);
}


function HistoricoGeralModal({admins,onClose,onRelogin}){
const[por,setPor]=useState(''),[acao,setAcao]=useState(''),[conta,setConta]=useState('');
const[itens,setItens]=useState(null),[erro,setErro]=useState('');
useEffect(()=>{let vivo=true;setItens(null);
const qs=new URLSearchParams({...(por?{por}:{}),...(acao?{acao}:{}),limite:'500'}).toString();
leJson('/api/admin/usuarios-historico?'+qs).then((d)=>{if(vivo){setItens(d&&d.itens||[]);setErro('');}}).
catch((e)=>{if(!vivo)return;if(e.status===401){onRelogin();return;}setItens([]);setErro('O histórico não carregou: '+e.message);});
return()=>{vivo=false;};},[por,acao]);
const q=conta.trim().toLowerCase();
const vis=(itens||[]).filter((it)=>!q||String(it.alvoNome||'').toLowerCase().includes(q));
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:900},role:"dialog","aria-modal":"true"},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}},
React.createElement("h2",null,React.createElement(Ic,{n:"history"}),"Histórico geral das contas"),
React.createElement("button",{className:"x-btn",onClick:onClose,"aria-label":"Fechar"},React.createElement(Ic,{n:"close"}))
),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10}},
React.createElement("div",{className:"sel-wrap",style:{flex:'0 0 220px'}},React.createElement("select",{className:"sel",value:por,onChange:(e)=>setPor(e.target.value),"aria-label":"Feito por"},
React.createElement("option",{value:""},"Feito por: todos"),admins.map((a)=>React.createElement("option",{key:a.id,value:a.id},"Feito por: ",a.nome)),React.createElement("option",{value:"auto"},"Feito pelo painel (automático)")),React.createElement(Ic,{n:"arrow_drop_down"})),
React.createElement("div",{className:"sel-wrap",style:{flex:'0 0 220px'}},React.createElement("select",{className:"sel",value:acao,onChange:(e)=>setAcao(e.target.value),"aria-label":"Ação"},
React.createElement("option",{value:""},"Todas as ações"),Object.entries(ACOES_CONTA).filter(([k])=>k!=='ilegivel').map(([k,l])=>React.createElement("option",{key:k,value:k},l))),React.createElement(Ic,{n:"arrow_drop_down"})),
React.createElement("input",{className:"inp",style:{flex:'1 1 180px',width:'auto'},placeholder:"Conta (nome)…",value:conta,onChange:(e)=>setConta(e.target.value),"aria-label":"Filtrar pela conta"})
),
erro&&React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro),
itens===null?React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--mut)'}},"Carregando…"):
!vis.length?React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--mut)'}},"Nada registrado com esse filtro (o registro começou em 31/10/2026)."):
React.createElement("div",{className:"tbl-wrap",style:{maxHeight:'60vh',overflowY:'auto'}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Quando (São Paulo)"),React.createElement("th",null,"Conta"),React.createElement("th",null,"O que foi feito"),React.createElement("th",null,"Por quem"))),React.createElement("tbody",null,
vis.map((it)=>React.createElement("tr",{key:it.id},React.createElement("td",{style:{whiteSpace:'nowrap'}},fusoSP.fmtSP(it.quando)),
React.createElement("td",null,it.alvoNome||(it.alvo!=null?'#'+it.alvo:'—')),
React.createElement("td",null,ACOES_CONTA[it.acao]||it.acao,detalheConta(it)&&React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)'}},detalheConta(it))),
React.createElement("td",null,it.porNome||(it.por!=null?'#'+it.por:'—'))))
))),
React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)',marginTop:6}},"Mostra os 500 registros mais recentes que batem com o filtro.")
)
);
}



function TrocaSenhaObrigatoria({usuario}){
const[atual,setAtual]=useState(''),[nova,setNova]=useState(''),[nova2,setNova2]=useState(''),[erro,setErro]=useState(''),[busy,setBusy]=useState(false);
const trocar=async(e)=>{e.preventDefault();setErro('');
if(nova.length<8){setErro('A senha nova precisa de pelo menos 8 caracteres.');return;}
if(nova!==nova2){setErro('As duas senhas novas não estão iguais.');return;}
if(nova===atual){setErro('A senha nova precisa ser diferente da provisória.');return;}
setBusy(true);
try{
const r=await fetch('/api/auth/trocar-senha',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({senhaAtual:atual,novaSenha:nova})});
const d=await r.json().catch(()=>({}));
if(r.status===401){location.href='/login';return;}
if(!r.ok){setErro(d.error||'erro '+r.status);setBusy(false);return;}
location.reload();
}catch(e2){setErro(e2.message);setBusy(false);}
};
const sair=()=>fetch('/api/auth/logout',{method:'POST',credentials:'include'}).finally(()=>{location.href='/login';});
const rot={fontSize:12,fontWeight:700,color:'var(--teal-deep)',textTransform:'uppercase',letterSpacing:.4,margin:'12px 0 5px',display:'block'};
return React.createElement("div",{style:{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',padding:16,background:'var(--paper-2)'}},
React.createElement("form",{className:"modal",style:{maxWidth:430},onSubmit:trocar},
React.createElement("h2",null,React.createElement(Ic,{n:"password"}),"Escolha a sua senha"),
React.createElement("div",{style:{fontSize:13.5,color:'var(--ink-2)',margin:'6px 0 4px'}},"Olá, ",usuario.nome,"! Você entrou com uma ",React.createElement("b",null,"senha provisória"),", criada pelo administrador. Antes de continuar, escolha uma senha só sua, com pelo menos 8 caracteres."),
erro&&React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro),
React.createElement("label",{style:rot},"Senha provisória (a que você recebeu)"),
React.createElement("input",{className:"inp",type:"password",autoComplete:"current-password",value:atual,onChange:(e)=>setAtual(e.target.value),autoFocus:true}),
React.createElement("label",{style:rot},"Senha nova"),
React.createElement("input",{className:"inp",type:"password",autoComplete:"new-password",value:nova,onChange:(e)=>setNova(e.target.value)}),
React.createElement("label",{style:rot},"Repita a senha nova"),
React.createElement("input",{className:"inp",type:"password",autoComplete:"new-password",value:nova2,onChange:(e)=>setNova2(e.target.value)}),
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',gap:8,marginTop:16}},
React.createElement("button",{type:"button",className:"btn-sm",onClick:sair},"Sair"),
React.createElement("button",{type:"submit",className:"btn-sm b-green",disabled:busy},busy?'Salvando…':'Salvar e entrar')
)
)
);
}

function AtribuirPerfisModal({tipster,onClose,onSaved,onRelogin}){
const[data,setData]=useState(null),[erro,setErro]=useState(''),[sel,setSel]=useState(new Set()),[salvando,setSalvando]=useState(false);
const[ajustes,setAjustes]=useState([]);

const[opCasas,setOpCasas]=useState([]),[opLabels,setOpLabels]=useState([]),[opEsportes,setOpEsportes]=useState([]);
const[boostsPorCasa,setBoostsPorCasa]=useState({});

const[novoTipo,setNovoTipo]=useState('incluir'),[novaDim,setNovaDim]=useState('casa'),[novoValor,setNovoValor]=useState('');
const[novosBoosts,setNovosBoosts]=useState([]);
useEffect(()=>{(async()=>{
try{
const[rp,ra]=await Promise.all([
fetch(`/api/admin/usuarios/${tipster.id}/perfis`,{credentials:'include'}),
fetch(`/api/admin/usuarios/${tipster.id}/ajustes`,{credentials:'include'})]
);
if(rp.status===401||ra.status===401){onRelogin();return;}
if(!rp.ok){setErro((await rp.json().catch(()=>({}))).error||'Erro');return;}
const d=await rp.json();setData(d);setSel(new Set(d.perfis.filter((p)=>p.atribuido).map((p)=>p.id)));
if(ra.ok){const da=await ra.json();setAjustes((da.ajustes||[]).map((a)=>({tipo:a.tipo,dimensao:a.dimensao,valor:a.valor,boosts:a.boosts||null})));}
}catch(e){setErro(e.message);}
})();

const falhou=(o)=>(e)=>setErro(o+' não carregaram: '+e.message);
leJson('/api/casas').then((cs)=>setOpCasas((cs||[]).map((c)=>c.name).sort((a,b)=>a.localeCompare(b,'pt-BR')))).catch(falhou('As casas'));
leJson('/api/labels').then((ls)=>setOpLabels((ls||[]).sort((a,b)=>(a||'').localeCompare(b||'','pt-BR')))).catch(falhou('As etiquetas'));
leJson('/api/stats').then((s)=>{
setOpEsportes((s.bySport||[]).map((x)=>x.sport).filter(Boolean).sort((a,b)=>a.localeCompare(b,'pt-BR',{sensitivity:'base'})));

const map={};(s.labelsByCasa||[]).forEach(({casa,boost_label})=>{if(!map[casa])map[casa]=[];map[casa].push(boost_label);});
setBoostsPorCasa(map);
}).catch(falhou('Os esportes e boosts'));
},[]);
const toggle=(id)=>setSel((prev)=>{const n=new Set(prev);n.has(id)?n.delete(id):n.add(id);return n;});
const opcoesDim=novaDim==='casa'?opCasas:novaDim==='label'?opLabels:novaDim==='esporte'?opEsportes:[];

const boostsDaCasaForm=novaDim==='casa'&&novoValor?boostsPorCasa[novoValor]||[]:[];
const toggleNovoBoost=(b)=>setNovosBoosts((prev)=>prev.includes(b)?prev.filter((x)=>x!==b):[...prev,b]);
const addAjuste=()=>{
const v=novoValor.trim();if(!v)return;

if(ajustes.some((a)=>a.tipo===novoTipo&&a.dimensao===novaDim&&a.valor.toLowerCase()===v.toLowerCase()))return;

const boosts=novaDim==='casa'&&novosBoosts.length?[...novosBoosts]:null;
setAjustes((prev)=>[...prev,{tipo:novoTipo,dimensao:novaDim,valor:v,boosts}]);
setNovoValor('');setNovosBoosts([]);
};
const remAjuste=(i)=>setAjustes((prev)=>prev.filter((_,idx)=>idx!==i));
const salvar=async()=>{setSalvando(true);setErro('');
try{
const reqs=[
fetch(`/api/admin/usuarios/${tipster.id}/perfis`,{method:'PUT',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({perfil_ids:[...sel]})}),
fetch(`/api/admin/usuarios/${tipster.id}/ajustes`,{method:'PUT',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({ajustes})})];

const rs=await Promise.all(reqs);
if(!rs[0].ok)throw new Error((await rs[0].json().catch(()=>({}))).error||'Erro ao salvar perfis');
if(!rs[1].ok)throw new Error((await rs[1].json().catch(()=>({}))).error||'Erro ao salvar ajustes');
onSaved();onClose();
}catch(e){setErro(e.message);setSalvando(false);}
};
const rotDim={casa:'Casa',label:'Boost',esporte:'Esporte',torneio:'Torneio'};
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:520}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}},
React.createElement("h2",null,React.createElement(Ic,{n:"filter_alt"}),"Perfis do tipster"),
React.createElement("button",{className:"x-btn",onClick:onClose},React.createElement(Ic,{n:"close"}))
),
React.createElement("div",{style:{fontSize:13,color:'var(--mut)',marginBottom:14}},tipster.nome," recebe a ",React.createElement("b",null,"soma")," dos perfis, com os ajustes por cima."),
erro&&React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro),
!data?React.createElement("div",{style:{textAlign:'center',padding:36,color:'var(--mut)'}},"Carregando…"):
React.createElement("div",{style:{maxHeight:'62vh',overflowY:'auto'}},
React.createElement("div",{style:{fontSize:11.5,fontWeight:700,color:'var(--teal-deep)',textTransform:'uppercase',letterSpacing:.4,marginBottom:9}},"Perfis atribuídos"),
data.perfis.length===0?
React.createElement("div",{style:{textAlign:'center',padding:24,color:'var(--mut)',fontSize:12.5}},"Nenhum perfil criado ainda. Crie na aba \"Perfis\"."):
React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:8}},
data.perfis.map((p)=>{const on=sel.has(p.id);return(
React.createElement("div",{key:p.id,onClick:()=>toggle(p.id),style:{display:'flex',alignItems:'center',gap:11,padding:'11px 13px',border:'1.5px solid '+(on?'var(--teal-deep)':'var(--line-2)'),borderRadius:11,cursor:'pointer',background:on?'var(--paper-2)':'#fff'}},
React.createElement("span",{style:{width:19,height:19,borderRadius:5,border:'1.5px solid var(--line-2)',display:'grid',placeItems:'center',flexShrink:0,background:on?'var(--teal-deep)':'#fff'}},on&&React.createElement(Ic,{n:"check"})),
React.createElement("span",{style:{flex:1}},
React.createElement("span",{style:{fontWeight:600,color:'var(--navy-900)'}},p.nome,!p.ativo&&React.createElement("span",{style:{fontSize:11,color:'var(--mut)',marginLeft:6}},"(inativo)")),
p.descricao&&React.createElement("span",{style:{display:'block',fontSize:11.5,color:'var(--mut)'}},p.descricao)
)
));
})
),

React.createElement("div",{style:{borderTop:'1px solid var(--line)',marginTop:18,paddingTop:16}},
React.createElement("div",{style:{fontSize:11.5,fontWeight:700,color:'var(--teal-deep)',textTransform:'uppercase',letterSpacing:.4,marginBottom:2}},"Ajustes individuais"),
React.createElement("div",{style:{fontSize:12,color:'var(--mut)',marginBottom:11}},"Forçados por cima dos perfis, só pra este tipster."),
ajustes.length>0&&React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:7,marginBottom:11}},
ajustes.map((a,i)=>{const inc=a.tipo==='incluir';const temBoosts=a.dimensao==='casa'&&a.boosts&&a.boosts.length;return(
React.createElement("div",{key:i,style:{display:'flex',alignItems:'center',gap:9,padding:'8px 11px',background:inc?'#E4F6EF':'#FDECEC',border:'1px solid '+(inc?'#A9E1CC':'#F0C4C4'),borderRadius:9,fontSize:12.5}},
React.createElement("span",{style:{background:inc?'#0F6E56':'#A32D2D',color:'#fff',fontSize:10.5,fontWeight:700,padding:'2px 8px',borderRadius:6,flexShrink:0}},inc?'SEMPRE':'NUNCA'),
React.createElement("span",{style:{color:'var(--navy-900)'}},rotDim[a.dimensao],": ",React.createElement("b",null,a.valor),temBoosts?React.createElement("span",{style:{color:'var(--mut)'}}," → só: ",a.boosts.join(', ')):''),
React.createElement("span",{onClick:()=>remAjuste(i),style:{marginLeft:'auto',color:'#A32D2D',cursor:'pointer',display:'flex'}},React.createElement(Ic,{n:"close"}))
));
})
),
React.createElement("div",{style:{background:'var(--paper-2)',border:'1px solid var(--line-2)',borderRadius:10,padding:11}},
React.createElement("div",{style:{display:'flex',gap:7,marginBottom:8}},
React.createElement("div",{className:"sel-wrap",style:{flex:'0 0 108px'}},React.createElement("select",{className:"sel",value:novoTipo,onChange:(e)=>setNovoTipo(e.target.value)},React.createElement("option",{value:"incluir"},"Sempre"),React.createElement("option",{value:"excluir"},"Nunca")),React.createElement(Ic,{n:"arrow_drop_down"})),
React.createElement("div",{className:"sel-wrap",style:{flex:'0 0 108px'}},React.createElement("select",{className:"sel",value:novaDim,onChange:(e)=>{setNovaDim(e.target.value);setNovoValor('');setNovosBoosts([]);}},React.createElement("option",{value:"casa"},"Casa"),React.createElement("option",{value:"label"},"Boost"),React.createElement("option",{value:"esporte"},"Esporte"),React.createElement("option",{value:"torneio"},"Torneio")),React.createElement(Ic,{n:"arrow_drop_down"}))
),
React.createElement("div",{style:{display:'flex',gap:7}},
novaDim==='torneio'?
React.createElement("input",{className:"inp",style:{flex:1},placeholder:"Nome do torneio",value:novoValor,onChange:(e)=>setNovoValor(e.target.value),onKeyDown:(e)=>e.key==='Enter'&&addAjuste()}):
React.createElement("div",{className:"sel-wrap",style:{flex:1}},React.createElement("select",{className:"sel",value:novoValor,onChange:(e)=>{setNovoValor(e.target.value);setNovosBoosts([]);}},React.createElement("option",{value:""},"Escolher ",rotDim[novaDim].toLowerCase(),"…"),opcoesDim.map((o)=>React.createElement("option",{key:o,value:o},o))),React.createElement(Ic,{n:"arrow_drop_down"})),
React.createElement("button",{className:"btn-sm b-green",style:{flexShrink:0,padding:'0 14px'},onClick:addAjuste},"Adicionar")
),
novaDim==='casa'&&novoValor&&boostsDaCasaForm.length>0&&React.createElement("div",{style:{marginTop:9,paddingTop:9,borderTop:'1px dashed var(--line-2)'}},
React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)',marginBottom:6}},"Boosts da ",novoValor," (deixe vazio = todos):"),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:6}},
boostsDaCasaForm.map((b)=>{const on=novosBoosts.includes(b);return(
React.createElement("span",{key:b,onClick:()=>toggleNovoBoost(b),style:{display:'inline-flex',alignItems:'center',gap:5,padding:'5px 10px',border:'1.5px solid '+(on?'var(--teal-deep)':'var(--line-2)'),background:on?'var(--paper-2)':'#fff',borderRadius:7,fontSize:12,cursor:'pointer',color:on?'var(--navy-900)':'var(--mut)',fontWeight:on?600:400}},on&&React.createElement(Ic,{n:"check"}),b));
})
)
)
)
)





),
data&&React.createElement("button",{onClick:salvar,disabled:salvando,style:{opacity:salvando?.6:1,marginTop:16}},salvando?'Salvando…':'Salvar')
)
);
}

function MeusFiltrosTab({onClose}){



const[data,setData]=useState(null);
const[ft,setFt]=useState(null),[ftVinc,setFtVinc]=useState(false);
const[carregando,setCarregando]=useState(true),[msg,setMsg]=useState('');
const[q,setQ]=useState(''),[flt,setFlt]=useState('all');
const[labelModal,setLabelModal]=useState(null);
const[espModal,setEspModal]=useState(null);
const[espGlobalModal,setEspGlobalModal]=useState(false);
const headers={'Content-Type':'application/json'};
const TIPOS=[['new','Nova Odd',true],['increased','Aumento',true],['decreased','Diminuição',true],['readded','Reabertura',false],['removed','Odd Removida',false]];



const CAMPO_PCT={new:'minNewPercent',increased:'minIncreasedPercent',decreased:'minDecreasedPercent'};
const ROTULO_PCT={new:'boost mín',increased:'mín',decreased:'mín'};

const carregar=async()=>{
try{
const[r1,r2]=await Promise.all([
fetch('/api/tipster/meus-filtros',{credentials:'include'}),
fetch('/api/tipster/meus-filtros-tipo',{credentials:'include'})]
);
if(r1.status===401){onClose('relogin');return;}
setData(await r1.json());
const dt=await r2.json();setFtVinc(!!dt.vinculado);setFt(dt.filtros||null);
}catch(e){setMsg('❌ '+e.message);}finally{setCarregando(false);}
};
useEffect(()=>{carregar();},[]);

const salvar=async(novasEscolhas)=>{
try{
const r=await fetch('/api/tipster/meus-filtros',{method:'PUT',credentials:'include',headers,body:JSON.stringify(novasEscolhas)});
if(!r.ok)throw new Error((await r.json().catch(()=>({}))).error||'Erro');
const d=await r.json();
setData((prev)=>({...prev,escolhas:d.escolhas}));
setMsg('✅ Salvo');setTimeout(()=>setMsg(''),1500);
}catch(e){setMsg('❌ '+e.message);}
};
const salvarTipos=async(novos)=>{
try{
const r=await fetch('/api/tipster/meus-filtros-tipo',{method:'PUT',credentials:'include',headers,body:JSON.stringify({filtros:novos})});
if(!r.ok)throw new Error((await r.json().catch(()=>({}))).error||'Erro');
const d=await r.json();setFt(d.filtros);setMsg('✅ Salvo');setTimeout(()=>setMsg(''),1500);
}catch(e){setMsg('❌ '+e.message);}
};

if(carregando)return React.createElement("div",{style:{textAlign:'center',padding:48,color:'var(--on-surface-variant)'}},"Carregando…");
if(!data)return React.createElement("div",{style:{textAlign:'center',padding:40,color:'var(--on-surface-variant)'}},"Não consegui carregar seus filtros.");
if(!data.temPerfil)return React.createElement("div",{className:"glass panel",style:{textAlign:'center',padding:40}},
React.createElement("div",{style:{fontSize:15,fontWeight:600,color:'var(--navy-900)',marginBottom:8}},"Você ainda não tem um perfil"),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',lineHeight:1.5}},"Assim que um administrador atribuir um perfil pra você, aqui você poderá escolher o que quer receber dentro dele.")
);

const esc=data.escolhas;
const casas=(data.casas||[]).slice().sort((a,b)=>a.localeCompare(b,'pt-BR',{sensitivity:'base'}));


const bloquearCasa=(casa)=>salvar({...esc,casasBloqueadas:esc.casasBloqueadas.includes(casa)?esc.casasBloqueadas:[...esc.casasBloqueadas,casa]});
const liberarCasa=(casa)=>salvar({...esc,casasBloqueadas:esc.casasBloqueadas.filter((c)=>c!==casa)});
const liberarTudo=(casa)=>{
const lb={...esc.labelsBloqueadosPorCasa},eb={...esc.esportesBloqueadosPorCasa};delete lb[casa];delete eb[casa];
salvar({...esc,labelsBloqueadosPorCasa:lb,esportesBloqueadosPorCasa:eb,casasBloqueadas:esc.casasBloqueadas.filter((c)=>c!==casa)});
};
const salvarLabels=(casa,marcados)=>{
const todos=data.labelsPorCasa[casa]||[];
const bloq=todos.filter((l)=>!marcados.includes(l));
const lb={...esc.labelsBloqueadosPorCasa};
if(bloq.length)lb[casa]=bloq;else delete lb[casa];
salvar({...esc,labelsBloqueadosPorCasa:lb});
};
const salvarEsportes=(casa,marcados)=>{
const todos=data.esportesPorCasa[casa]||[];
const bloq=todos.filter((e)=>!marcados.includes(e));
const eb={...esc.esportesBloqueadosPorCasa};
if(bloq.length)eb[casa]=bloq;else delete eb[casa];
salvar({...esc,esportesBloqueadosPorCasa:eb});
};
const salvarEsportesGlobal=(marcados)=>{
const todos=data.esportesGlobais||[];
const bloq=todos.filter((e)=>!marcados.includes(e));
salvar({...esc,esportesBloqueados:bloq});
};

const toggleTipo=(k)=>salvarTipos({...ft,[k]:!ft[k]});
const setMin=(k,v)=>salvarTipos({...ft,[k]:Math.max(0,Number(v)||0)});

const linhas=casas.filter((c)=>{
if(q&&!c.toLowerCase().includes(q.toLowerCase()))return false;
const temFiltro=(esc.labelsBloqueadosPorCasa[c]||[]).length>0||(esc.esportesBloqueadosPorCasa[c]||[]).length>0;
if(flt==='blocked')return esc.casasBloqueadas.includes(c);
if(flt==='filtered')return temFiltro&&!esc.casasBloqueadas.includes(c);
return true;
});

return React.createElement(React.Fragment,null,
msg&&React.createElement("div",{className:"toast"},msg),

React.createElement("div",{className:"glass panel",style:{marginBottom:14,padding:'14px 16px'}},
React.createElement("div",{style:{fontSize:13,color:'var(--navy-700)',lineHeight:1.5}},"Escolha o que você quer receber. São as casas que seu perfil libera.",

React.createElement("b",null," Tudo vem liberado por padrão")," — bloqueie ou filtre só o que não quiser."
)
),


ftVinc&&ft&&React.createElement("div",{className:"glass panel",style:{marginBottom:14}},
React.createElement("div",{className:"panel-head",style:{cursor:'default'}},React.createElement("div",{className:"t"},React.createElement("h2",null,"Tipos de evento"))),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:10,padding:'6px 2px'}},
TIPOS.map(([k,label,temPct])=>
React.createElement("div",{key:k,style:{display:'flex',alignItems:'center',gap:8,border:'1px solid var(--line-2)',borderRadius:10,padding:'8px 12px',background:ft[k]?'var(--paper-2)':'transparent'}},
React.createElement("button",{onClick:()=>toggleTipo(k),style:{width:38,height:22,borderRadius:12,border:'none',cursor:'pointer',background:ft[k]?'var(--teal-deep)':'var(--line-2)',position:'relative',flexShrink:0}},
React.createElement("span",{style:{position:'absolute',top:2,left:ft[k]?18:2,width:18,height:18,borderRadius:'50%',background:'#fff',transition:'left .15s'}})
),
React.createElement("span",{style:{fontSize:13,fontWeight:600,color:ft[k]?'var(--navy-900)':'var(--on-surface-variant)'}},label),
temPct&&ft[k]&&React.createElement("span",{style:{display:'flex',alignItems:'center',gap:4}},
React.createElement("span",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},ROTULO_PCT[k]||'mín'),
React.createElement("input",{type:"number",min:"0",step:"0.5",value:ft[CAMPO_PCT[k]]??0,
onChange:(e)=>setMin(CAMPO_PCT[k],e.target.value),
style:{width:56,height:30,padding:'0 6px',border:'1px solid var(--line-2)',borderRadius:7,fontSize:12.5,background:'#fff'}}),
React.createElement("span",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},"%")
)
))
)
),


React.createElement("div",{className:"glass panel",style:{marginBottom:14,padding:'14px 16px',display:'flex',alignItems:'center',justifyContent:'space-between',gap:12,flexWrap:'wrap'}},
React.createElement("div",null,
React.createElement("div",{style:{fontWeight:700,fontSize:14,color:'var(--navy-900)'}},"Esportes (geral)"),
React.createElement("div",{style:{fontSize:12,color:'var(--on-surface-variant)',marginTop:2}},
esc.esportesBloqueados.length?`${esc.esportesBloqueados.length} esporte(s) bloqueado(s) em todas as casas`:'Recebendo todos os esportes'
)
),
React.createElement("button",{className:"btn-sm b-amber",onClick:()=>setEspGlobalModal(true)},"Filtrar esportes")
),


React.createElement("div",{className:"adm-filters"},
React.createElement("input",{className:"adm-inp",placeholder:"Buscar casa…",value:q,onChange:(e)=>setQ(e.target.value)}),
React.createElement("div",{className:"seg"},[['all','Todas'],['filtered','Filtradas'],['blocked','Bloqueadas']].map(([v,l])=>React.createElement("button",{key:v,className:"segb"+(flt===v?' on':''),onClick:()=>setFlt(v)},l)))
),


React.createElement("h3",{className:"sec-t",style:{color:'var(--primary)'}},"Casas (",linhas.length,")"),
React.createElement("div",{className:"tbl-wrap"},
React.createElement("table",null,
React.createElement("thead",null,React.createElement("tr",{style:{cursor:'default'}},React.createElement("th",{style:{cursor:'default'}},"Casa"),React.createElement("th",{style:{cursor:'default'}},"Status"),React.createElement("th",{style:{cursor:'default'}},"Labels"),React.createElement("th",{style:{cursor:'default'}},"Ações"))),
React.createElement("tbody",null,
linhas.map((casa)=>{
const todosLabels=(data.labelsPorCasa[casa]||[]).slice().sort((a,b)=>(a||'').localeCompare(b||'','pt-BR'));
const todosEsp=(data.esportesPorCasa[casa]||[]).slice().sort((a,b)=>(a||'').localeCompare(b||'','pt-BR'));
const labelsBloq=esc.labelsBloqueadosPorCasa[casa]||[];
const espBloq=esc.esportesBloqueadosPorCasa[casa]||[];
const casaBloqueada=esc.casasBloqueadas.includes(casa);
const temFiltro=labelsBloq.length>0||espBloq.length>0;
return React.createElement("tr",{key:casa},
React.createElement("td",{style:{fontWeight:600,whiteSpace:'nowrap'}},React.createElement("span",{className:"sdot",style:{background:casaBloqueada?'var(--down)':'var(--primary)'}}),casa),
React.createElement("td",{style:{whiteSpace:'nowrap'}},
casaBloqueada?React.createElement("span",{style:{color:'var(--error,#E24B4A)',fontWeight:600}},"🔒 Bloqueada"):
temFiltro?React.createElement("span",{style:{color:'#B8860B',fontWeight:600}},"⚠️ Filtrada"):
React.createElement("span",{style:{color:'var(--primary)',fontWeight:600}},"✅ Recebendo")
),
React.createElement("td",null,todosLabels.length>0?todosLabels.map((l)=>React.createElement("span",{key:l,className:"pill",style:labelsBloq.includes(l)?{textDecoration:'line-through',opacity:.55}:null},l)):React.createElement("span",{style:{color:'var(--on-surface-variant)',opacity:.5}},"—")),
React.createElement("td",{style:{whiteSpace:'nowrap'}},React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},
casaBloqueada?
React.createElement("button",{className:"btn-sm b-green",onClick:()=>liberarCasa(casa)},"Liberar"):
React.createElement(React.Fragment,null,
temFiltro&&React.createElement("button",{className:"btn-sm b-green",onClick:()=>liberarTudo(casa)},"Liberar tudo"),
React.createElement("button",{className:"btn-sm b-red",onClick:()=>bloquearCasa(casa)},"Bloquear"),
todosLabels.length>0&&React.createElement("button",{className:"btn-sm b-amber",onClick:()=>setLabelModal({casa,todos:todosLabels,marcados:todosLabels.filter((l)=>!labelsBloq.includes(l))})},"Labels"),
todosEsp.length>0&&React.createElement("button",{className:"btn-sm b-amber",onClick:()=>setEspModal({casa,todos:todosEsp,marcados:todosEsp.filter((e)=>!espBloq.includes(e))})},"Esportes")
)
))
);
})
)
)
),
linhas.length===0&&React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--on-surface-variant)'}},"Nenhuma casa pra esse filtro."),

labelModal&&React.createElement(FiltroModal,{titulo:`Labels — ${labelModal.casa}`,todos:labelModal.todos,marcados:labelModal.marcados,
onSave:(m)=>salvarLabels(labelModal.casa,m),onClose:()=>setLabelModal(null)}),
espModal&&React.createElement(FiltroModal,{titulo:`Esportes — ${espModal.casa}`,todos:espModal.todos,marcados:espModal.marcados,
onSave:(m)=>salvarEsportes(espModal.casa,m),onClose:()=>setEspModal(null)}),
espGlobalModal&&React.createElement(FiltroModal,{titulo:"Esportes (todas as casas)",todos:data.esportesGlobais||[],marcados:(data.esportesGlobais||[]).filter((e)=>!esc.esportesBloqueados.includes(e)),
onSave:(m)=>salvarEsportesGlobal(m),onClose:()=>setEspGlobalModal(false)})
);
}


function FiltroModal({titulo,todos,marcados,onSave,onClose}){
const[sel,setSel]=useState(new Set(marcados));
const toggle=(v)=>setSel((prev)=>{const n=new Set(prev);n.has(v)?n.delete(v):n.add(v);return n;});
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:460}},
React.createElement("h3",{style:{fontFamily:'var(--f-display)',fontSize:17,fontWeight:700,color:'var(--navy-900)',marginBottom:4}},titulo),
React.createElement("div",{style:{fontSize:12.5,color:'var(--on-surface-variant)',marginBottom:14}},"Marque o que quer receber. Desmarcado = não recebe."),
React.createElement("div",{style:{display:'flex',gap:8,marginBottom:12}},
React.createElement("button",{className:"btn-sm b-green",onClick:()=>setSel(new Set(todos))},"Marcar todos"),
React.createElement("button",{className:"btn-sm b-red",onClick:()=>setSel(new Set())},"Desmarcar todos")
),
React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:2,maxHeight:340,overflowY:'auto',marginBottom:16}},
todos.map((v)=>{const on=sel.has(v);return(
React.createElement("div",{key:v,onClick:()=>toggle(v),style:{display:'flex',alignItems:'center',gap:10,padding:'9px 11px',borderRadius:8,cursor:'pointer',background:on?'var(--paper-2)':'transparent',border:'1px solid '+(on?'var(--line-2)':'transparent')}},
React.createElement("span",{style:{width:20,height:20,borderRadius:5,border:'2px solid '+(on?'var(--teal-deep)':'var(--line-2)'),background:on?'var(--teal-deep)':'transparent',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}},
on&&React.createElement("span",{style:{color:'#fff',fontSize:13,fontWeight:700}},"✓")
),
React.createElement("span",{style:{fontSize:13,color:'var(--navy-900)'}},v)
));
})
),
React.createElement("div",{style:{display:'flex',gap:9}},
React.createElement("button",{className:"btn-sm b-green",style:{flex:1,padding:10},onClick:()=>{onSave([...sel]);onClose();}},"Salvar"),
React.createElement("button",{className:"btn-sm b-red",style:{flex:1,padding:10},onClick:onClose},"Cancelar")
)
)
);
}



function MinhaContaTab({usuario,onClose}){
const[atual,setAtual]=useState(''),[nova,setNova]=useState(''),[nova2,setNova2]=useState('');
const[msg,setMsg]=useState(null),[busy,setBusy]=useState(false);

const[vinc,setVinc]=useState({id_telegram:usuario?.id_telegram||null,telegram_username:usuario?.telegram_username||null});
const[codigo,setCodigo]=useState(null),[codBusy,setCodBusy]=useState(false),[copiado,setCopiado]=useState(false),[vincMsg,setVincMsg]=useState(null);
const trocar=async()=>{
setMsg(null);
if(nova!==nova2){setMsg({t:'err',m:'As senhas novas não coincidem.'});return;}
if(nova.length<8){setMsg({t:'err',m:'A nova senha precisa de ao menos 8 caracteres.'});return;}
setBusy(true);
try{
const r=await fetch('/api/auth/trocar-senha',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({senhaAtual:atual,novaSenha:nova})});
const d=await r.json();
if(!r.ok){setMsg({t:'err',m:d.error||'Não foi possível trocar a senha.'});setBusy(false);return;}
setMsg({t:'ok',m:'Senha alterada com sucesso.'});setAtual('');setNova('');setNova2('');setBusy(false);
}catch(e){setMsg({t:'err',m:'Erro de conexão.'});setBusy(false);}
};
const gerarCodigo=async()=>{setCodBusy(true);setVincMsg(null);
try{const r=await fetch('/api/auth/vinculo/codigo',{method:'POST',credentials:'include'});
const d=await r.json();
if(!r.ok){setVincMsg({t:'err',m:d.error||'Erro ao gerar código'});setCodBusy(false);return;}
setCodigo(d);setCodBusy(false);
}catch(e){setVincMsg({t:'err',m:'Erro de conexão'});setCodBusy(false);}
};
const copiar=()=>{if(codigo)navigator.clipboard.writeText(codigo.codigo).then(()=>{setCopiado(true);setTimeout(()=>setCopiado(false),1500);});};
const desvincular=async()=>{if(!(await confirma('Desvincular seu Telegram? Você deixará de receber os alertas até vincular de novo.')))return;
try{const r=await fetch('/api/auth/vinculo/remover',{method:'POST',credentials:'include'});
if(!r.ok){setVincMsg({t:'err',m:'Erro ao desvincular'});return;}
setVinc({id_telegram:null,telegram_username:null});setCodigo(null);setVincMsg({t:'ok',m:'Telegram desvinculado.'});
}catch(e){setVincMsg({t:'err',m:'Erro de conexão'});}
};
const vinculado=!!vinc.id_telegram;
return React.createElement("div",{style:{maxWidth:440}},
usuario&&React.createElement("div",{style:{marginBottom:18,padding:'12px 14px',background:'var(--surface-container-high)',borderRadius:12}},
React.createElement("div",{style:{fontWeight:600,fontSize:15}},usuario.nome),
React.createElement("div",{style:{fontSize:13,color:'var(--on-surface-variant)',marginTop:2}},usuario.email," · ",usuario.papel==='admin'?'Admin':'Tipster')
),

React.createElement("h3",{className:"sec-t"},"Telegram"),
vincMsg&&React.createElement("div",{className:"toast",style:{background:vincMsg.t==='ok'?'rgba(82,255,172,.12)':'rgba(255,90,90,.12)',color:vincMsg.t==='ok'?'var(--primary)':'var(--error)'}},vincMsg.m),
vinculado?
React.createElement("div",{style:{padding:'13px 15px',background:'#E4F6EF',border:'1px solid #A9E1CC',borderRadius:12,marginTop:8}},
React.createElement("div",{style:{display:'flex',alignItems:'center',gap:8,marginBottom:4}},
React.createElement(Ic,{n:"check_circle"}),React.createElement("span",{style:{fontWeight:600,color:'#0F6E56'}},"Telegram vinculado")
),
React.createElement("div",{style:{fontSize:13,color:'var(--ink-2)'}},vinc.telegram_username?'@'+vinc.telegram_username:'ID '+vinc.id_telegram," — você recebe os alertas conforme seus perfis."),
React.createElement("button",{className:"btn-sm b-red",style:{marginTop:11},onClick:desvincular},"Desvincular")
):
React.createElement("div",{style:{marginTop:8}},
React.createElement("div",{style:{fontSize:13,color:'var(--mut)',marginBottom:11}},"Vincule sua conta ao Telegram pra receber os alertas do bot conforme seus perfis."),
!codigo?
React.createElement("button",{className:"btn-sm b-green",style:{height:38,padding:'0 20px'},onClick:gerarCodigo,disabled:codBusy},codBusy?'Gerando…':'Gerar código de vínculo'):
React.createElement("div",{style:{padding:'15px 16px',background:'var(--paper-2)',border:'1px solid var(--line-2)',borderRadius:12}},
React.createElement("div",{style:{fontSize:12.5,color:'var(--mut)',marginBottom:9}},"Envie este código pro bot ",React.createElement("b",null,"@oddsradarbot")," no Telegram (é só colar e enviar):"),
React.createElement("div",{style:{display:'flex',alignItems:'center',gap:10,marginBottom:10}},
React.createElement("span",{style:{fontFamily:'var(--f-mono)',fontSize:26,fontWeight:800,letterSpacing:4,color:'var(--navy-900)',background:'#fff',border:'1.5px dashed var(--teal-deep)',borderRadius:10,padding:'8px 16px'}},codigo.codigo),
React.createElement("button",{className:"btn-sm",style:{padding:'8px 12px'},onClick:copiar},copiado?React.createElement(Ic,{n:"check"}):React.createElement(Ic,{n:"content_copy"}))
),
React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)'}},"Válido por ",codigo.validade_min," minutos. Depois de enviar ao bot, atualize esta página."),
React.createElement("button",{className:"btn-sm",style:{marginTop:11},onClick:gerarCodigo,disabled:codBusy},codBusy?'Gerando…':'Gerar outro')
)
),

React.createElement("h3",{className:"sec-t",style:{marginTop:26}},"Trocar senha"),
msg&&React.createElement("div",{className:"toast",style:{background:msg.t==='ok'?'rgba(82,255,172,.12)':'rgba(255,90,90,.12)',color:msg.t==='ok'?'var(--primary)':'var(--error)'}},msg.m),
React.createElement("div",{className:"fg",style:{marginTop:10}},React.createElement("label",null,"Senha atual"),React.createElement("input",{className:"inp",type:"password",value:atual,onChange:(e)=>setAtual(e.target.value),autoComplete:"current-password"})),
React.createElement("div",{className:"fg",style:{marginTop:12}},React.createElement("label",null,"Nova senha"),React.createElement("input",{className:"inp",type:"password",placeholder:"Mínimo 8 caracteres",value:nova,onChange:(e)=>setNova(e.target.value),autoComplete:"new-password"})),
React.createElement("div",{className:"fg",style:{marginTop:12}},React.createElement("label",null,"Confirmar nova senha"),React.createElement("input",{className:"inp",type:"password",value:nova2,onChange:(e)=>setNova2(e.target.value),onKeyDown:(e)=>e.key==='Enter'&&trocar(),autoComplete:"new-password"})),
React.createElement("button",{className:"btn-sm b-green",style:{marginTop:16,height:38,padding:'0 20px'},onClick:trocar,disabled:busy},busy?'Salvando…':'Salvar nova senha')
);
}

function BotUsersTab({onClose}){
const[data,setData]=useState(null),[erro,setErro]=useState('');
const[q,setQ]=useState(''),[flt,setFlt]=useState('todos'),[copiado,setCopiado]=useState(null);
useEffect(()=>{(async()=>{
try{const r=await fetch('/api/admin/bot-users',{credentials:'include'});
if(r.status===401){onClose('relogin');return;}
if(!r.ok){const d=await r.json().catch(()=>({}));setErro(d.error||'Erro ao carregar');return;}
setData(await r.json());
}catch(e){setErro(e.message);}
})();},[]);
const copiar=(id)=>{navigator.clipboard.writeText(String(id)).then(()=>{setCopiado(id);setTimeout(()=>setCopiado(null),1500);});};

if(erro)return React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro);
if(!data)return React.createElement("div",{style:{textAlign:'center',padding:48,color:'var(--on-surface-variant)'}},"Consultando o Telegram… ",React.createElement("div",{style:{fontSize:12,marginTop:6,opacity:.7}},"(verificando o acesso de cada usuário nos canais)"));

const us=data.usuarios||[];
const comAcesso=us.filter((u)=>u.acesso).length;
const semAcesso=us.filter((u)=>u.acesso===false).length;
const fmtData=(d)=>{if(!d)return'—';const dt=new Date(d);return dt.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'});};
const match=(u)=>{
const busca=!q||[u.name,u.username,String(u.id_telegram)].some((v)=>(v||'').toLowerCase().includes(q.toLowerCase()));
const passaFlt=flt==='todos'?true:flt==='acesso'?u.acesso===true:u.acesso===false;
return busca&&passaFlt;
};
const shown=us.filter(match);

return React.createElement("div",null,
data.semToken&&React.createElement("div",{className:"toast",style:{color:'#ffd479'}},"⚠️ TELEGRAM_BOT_TOKEN não configurado — mostrando a lista, mas sem o status de acesso. Configure o token no EasyPanel pra ver quem tem acesso ativo."),
data.aviso&&React.createElement("div",{className:"toast",style:{color:'#ffd479'}},"⚠️ ",data.aviso),
React.createElement("div",{style:{display:'flex',gap:10,flexWrap:'wrap',marginBottom:14}},
React.createElement("div",{style:{flex:1,minWidth:130,background:'var(--paper-2)',border:'1px solid var(--line)',borderRadius:12,padding:'12px 16px'}},
React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)',fontWeight:600,textTransform:'uppercase',letterSpacing:.4}},"No bot"),
React.createElement("div",{style:{fontFamily:'var(--f-display)',fontSize:26,fontWeight:800,color:'var(--navy-900)'}},us.length)
),
React.createElement("div",{style:{flex:1,minWidth:130,background:'#E4F6EF',border:'1px solid #A9E1CC',borderRadius:12,padding:'12px 16px'}},
React.createElement("div",{style:{fontSize:11.5,color:'#0F6E56',fontWeight:600,textTransform:'uppercase',letterSpacing:.4}},"Com acesso"),
React.createElement("div",{style:{fontFamily:'var(--f-display)',fontSize:26,fontWeight:800,color:'#0F6E56'}},data.semToken?'—':comAcesso)
),
React.createElement("div",{style:{flex:1,minWidth:130,background:'#FDECEC',border:'1px solid #F0C4C4',borderRadius:12,padding:'12px 16px'}},
React.createElement("div",{style:{fontSize:11.5,color:'#A32D2D',fontWeight:600,textTransform:'uppercase',letterSpacing:.4}},"Sem acesso"),
React.createElement("div",{style:{fontFamily:'var(--f-display)',fontSize:26,fontWeight:800,color:'#A32D2D'}},data.semToken?'—':semAcesso)
)
),

React.createElement("div",{className:"adm-filters"},
React.createElement("input",{className:"adm-inp",placeholder:"Buscar por nome, @username ou Telegram ID…",value:q,onChange:(e)=>setQ(e.target.value)}),
React.createElement("div",{className:"seg"},[['todos','Todos'],['acesso','Com acesso'],['sem','Sem acesso']].map(([v,l])=>React.createElement("button",{key:v,className:"segb"+(flt===v?' on':''),onClick:()=>setFlt(v)},l)))
),

React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},
React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Usuário"),React.createElement("th",null,"Telegram ID"),React.createElement("th",null,"Plano ativo"),React.createElement("th",null,"Acesso"),React.createElement("th",null,"Desde"))),
React.createElement("tbody",null,shown.map((u)=>React.createElement("tr",{key:u.id_telegram},
React.createElement("td",null,React.createElement("div",{style:{fontWeight:600,color:'var(--navy-900)'}},u.name||'—'),React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)'}},u.username?'@'+u.username:'sem @username')),
React.createElement("td",null,React.createElement("div",{style:{display:'flex',alignItems:'center',gap:6}},React.createElement("span",{className:"mono-sm"},u.id_telegram),React.createElement("button",{className:"btn-sm",style:{padding:'3px 7px',background:'var(--paper-2)',border:'1px solid var(--line-2)',color:'var(--ink-2)'},onClick:()=>copiar(u.id_telegram),title:"Copiar Telegram ID"},copiado===u.id_telegram?React.createElement(Ic,{n:"check"}):React.createElement(Ic,{n:"content_copy"})))),
React.createElement("td",null,u.planosAtivos&&u.planosAtivos.length>0?u.planosAtivos.map((p)=>React.createElement("span",{key:p.id,className:"pill"},p.nome)):React.createElement("span",{style:{color:'var(--mut)',opacity:.6}},"—")),
React.createElement("td",null,data.semToken||u.acesso==null?React.createElement("span",{style:{color:'var(--mut)'}},data.semToken?'—':'não conferido'):u.acesso?React.createElement("span",{style:{display:'inline-flex',alignItems:'center',gap:4,color:'#0F6E56',fontWeight:700,fontSize:12}},React.createElement(Ic,{n:"check_circle"}),"Ativo"):React.createElement("span",{style:{display:'inline-flex',alignItems:'center',gap:4,color:'#A32D2D',fontWeight:700,fontSize:12}},React.createElement(Ic,{n:"cancel"}),"Sem acesso")),
React.createElement("td",{className:"mono-sm"},fmtData(u.criadoEm))
))))
),
shown.length===0&&React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--on-surface-variant)'}},"Nenhum usuário pra esse filtro.")
);
}



const ABAS_PERFIL=[['dashboard','Super Odds','analytics'],['props','Player Props','sports_soccer'],['ev','EV+','trending_up'],['odds','Odds Screen','table_chart']];
const ABAS_PADRAO=['dashboard','props'];
function PerfilModal({perfil,casas,labels,esportes,boostsPorCasa,onSave,onClose}){
const ed=perfil&&perfil.id;
const[abas,setAbas]=useState(perfil&&perfil.abas||ABAS_PADRAO);
const toggleAba=(id)=>setAbas((v)=>v.includes(id)?v.filter((x)=>x!==id):[...v,id]);
const r=perfil&&perfil.regras||{};
const[nome,setNome]=useState(perfil?.nome||'');
const[descricao,setDescricao]=useState(perfil?.descricao||'');
const[selCasas,setSelCasas]=useState(r.casas||[]);
const[selLabels,setSelLabels]=useState(r.labels||[]);
const[selEsportes,setSelEsportes]=useState(r.esportes||[]);
const[torneios,setTorneios]=useState((r.torneios||[]).join(', '));
const[pctMin,setPctMin]=useState(r.pct_min??'');
const[oddMin,setOddMin]=useState(r.odd_min??'');
const[oddMax,setOddMax]=useState(r.odd_max??'');
const[aoVivo,setAoVivo]=useState(r.ao_vivo||'todas');

const[boostPorCasa,setBoostPorCasa]=useState(r.boost_por_casa||{});
const[buscaCasa,setBuscaCasa]=useState('');
const[casaAberta,setCasaAberta]=useState(null);
const[salvando,setSalvando]=useState(false),[erro,setErro]=useState('');
const salvar=async()=>{
if(!nome.trim()){setErro('Dê um nome ao perfil');return;}
if(!abas.length){setErro('Marque ao menos uma tela que o perfil vê');return;}
setSalvando(true);setErro('');


const bpc={};Object.entries(boostPorCasa).forEach(([c,ls])=>{
if(!ls||!ls.length)return;
if(!selCasas.includes(c))return;
bpc[c]=ls;
});
const regras={casas:selCasas,labels:selLabels,esportes:selEsportes,
torneios:torneios.split(',').map((t)=>t.trim()).filter(Boolean),
pct_min:pctMin,odd_min:oddMin,odd_max:oddMax,ao_vivo:aoVivo,boost_por_casa:bpc};
try{await onSave({nome:nome.trim(),descricao:descricao.trim(),regras,abas});onClose();}
catch(e){setErro(e.message||'Erro ao salvar');setSalvando(false);}
};







const casasDoBoost=(selCasas||[]).filter((c)=>(boostsPorCasa[c]||[]).length>0);
const casasFiltradas=casasDoBoost.
filter((c)=>c.toLowerCase().includes(buscaCasa.toLowerCase())).

sort((a,b)=>{const ra=(boostPorCasa[a]||[]).length>0?0:1,rb=(boostPorCasa[b]||[]).length>0?0:1;return ra-rb||a.localeCompare(b,'pt-BR');});
const nRestritas=Object.entries(boostPorCasa).filter(([c,ls])=>ls&&ls.length&&selCasas.includes(c)).length;
const toggleBoostCasa=(casa,label)=>{
setBoostPorCasa((prev)=>{
const atual=prev[casa]||[];
const novo=atual.includes(label)?atual.filter((l)=>l!==label):[...atual,label];
return{...prev,[casa]:novo};
});
};
const limparCasa=(casa)=>setBoostPorCasa((prev)=>{const n={...prev};delete n[casa];return n;});
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:640}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}},
React.createElement("h2",null,React.createElement(Ic,{n:"filter_alt"}),ed?'Editar perfil':'Novo perfil'),
React.createElement("button",{className:"x-btn",onClick:onClose},React.createElement(Ic,{n:"close"}))
),
erro&&React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro),
React.createElement("div",{style:{display:'grid',gap:14}},
React.createElement("div",{className:"fg"},React.createElement("label",null,"Nome do perfil"),React.createElement("input",{className:"inp",placeholder:"Ex: Águas Profundas",value:nome,onChange:(e)=>setNome(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Descrição (opcional)"),React.createElement("input",{className:"inp",placeholder:"Ex: odds altas de futebol",value:descricao,onChange:(e)=>setDescricao(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Telas que o perfil vê"),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:8}},
ABAS_PERFIL.map(([id,lbl,ic])=>{const on=abas.includes(id);return(
React.createElement("button",{type:"button",key:id,role:"checkbox","aria-checked":on,onClick:()=>toggleAba(id),
style:{display:'flex',alignItems:'center',gap:8,padding:'7px 12px',borderRadius:9,cursor:'pointer',fontSize:13,
border:'1.5px solid '+(on?'var(--teal-deep)':'var(--line-2)'),background:on?'color-mix(in srgb,var(--teal) 10%,#fff)':'#fff',color:'var(--ink)'}},
React.createElement("span",{style:{width:17,height:17,borderRadius:5,border:'1.5px solid var(--line-2)',display:'grid',placeItems:'center',flexShrink:0,background:on?'var(--teal-deep)':'#fff'}},on&&React.createElement(Ic,{n:"check"})),
React.createElement(Ic,{n:ic}),lbl
));})
),
React.createElement("div",{style:{fontSize:12,color:'var(--mut)',marginTop:6}},"Meus filtros e Minha conta aparecem para todo tipster. As telas do Admin Menu são só de admin. Quem tem vários perfis vê a soma das telas.")
),
React.createElement("div",{style:{borderTop:'1px solid var(--line)',paddingTop:12,fontSize:12.5,color:'var(--mut)'}},"Filtros das Super Odds. Deixe um campo vazio pra ",React.createElement("b",null,"não")," filtrar por ele."),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Casas"),React.createElement(MultiSelect,{items:casas,selected:selCasas,onChange:setSelCasas})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Tipos de Boost"),React.createElement(MultiSelect,{items:labels,selected:selLabels,onChange:setSelLabels})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Esportes"),React.createElement(MultiSelect,{items:esportes,selected:selEsportes,onChange:setSelEsportes})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Torneios (separados por vírgula)"),React.createElement("input",{className:"inp",placeholder:"Ex: Brasileirão, Champions League",value:torneios,onChange:(e)=>setTorneios(e.target.value)})),
React.createElement("div",{style:{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12}},
React.createElement("div",{className:"fg"},React.createElement("label",null,"Aumento mín (%)"),React.createElement("input",{className:"inp data",type:"number",inputMode:"numeric",placeholder:"—",value:pctMin,onChange:(e)=>setPctMin(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Odd mín"),React.createElement("input",{className:"inp data",type:"number",step:"0.01",inputMode:"decimal",placeholder:"—",value:oddMin,onChange:(e)=>setOddMin(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Odd máx"),React.createElement("input",{className:"inp data",type:"number",step:"0.01",inputMode:"decimal",placeholder:"—",value:oddMax,onChange:(e)=>setOddMax(e.target.value)}))
),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Ao vivo"),React.createElement("div",{className:"sel-wrap"},React.createElement("select",{className:"sel",value:aoVivo,onChange:(e)=>setAoVivo(e.target.value)},React.createElement("option",{value:"todas"},"Todos"),React.createElement("option",{value:"sim"},"Só ao vivo"),React.createElement("option",{value:"nao"},"Só pré-jogo")),React.createElement(Ic,{n:"arrow_drop_down"}))),

React.createElement("div",{style:{borderTop:'1px solid var(--line)',paddingTop:14}},
React.createElement("div",{style:{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:4}},
React.createElement("label",{style:{margin:0,fontSize:13,color:'var(--navy-700)',fontWeight:700}},"Boost por casa (opcional)"),
nRestritas>0&&React.createElement("span",{className:"pill",style:{margin:0}},nRestritas," casa(s) restrita(s)")
),
React.createElement("div",{style:{fontSize:12,color:'var(--mut)',marginBottom:10}},"Toda casa manda ",React.createElement("b",null,"todos")," os boosts por padrão. Clique numa casa pra escolher só alguns."),
selCasas.length===0?
React.createElement("div",{style:{padding:'16px 14px',textAlign:'center',color:'var(--mut)',fontSize:12.5,background:'var(--paper-2)',border:'1px dashed var(--line-2)',borderRadius:10}},"Selecione casas em ",React.createElement("b",null,"\"Casas\"")," acima pra restringir os boosts delas aqui."):
React.createElement(React.Fragment,null,
React.createElement("div",{style:{position:'relative',marginBottom:8}},
React.createElement("input",{className:"inp",style:{paddingLeft:36},placeholder:`Buscar casa (${casasDoBoost.length})`,value:buscaCasa,onChange:(e)=>setBuscaCasa(e.target.value)}),
React.createElement("span",{style:{position:'absolute',left:11,top:'50%',transform:'translateY(-50%)',color:'var(--mut)',fontSize:0}},React.createElement(Ic,{n:"search"}))
),
React.createElement("div",{style:{maxHeight:230,overflowY:'auto',border:'1px solid var(--line-2)',borderRadius:10}},
casasFiltradas.length===0?React.createElement("div",{style:{padding:16,textAlign:'center',color:'var(--mut)',fontSize:12.5}},"Nenhuma casa encontrada."):
casasFiltradas.map((casa)=>{
const sel=boostPorCasa[casa]||[];
const restrita=sel.length>0;
const aberta=casaAberta===casa;
const boosts=boostsPorCasa[casa]||[];
return React.createElement("div",{key:casa,style:{borderBottom:'1px solid var(--line)',background:restrita?'#E4F6EF':'transparent',borderLeft:restrita?'3px solid var(--teal-deep)':'3px solid transparent'}},
React.createElement("div",{style:{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'9px 12px',cursor:'pointer'},onClick:()=>setCasaAberta(aberta?null:casa)},
React.createElement("span",{style:{display:'flex',alignItems:'center',gap:7}},
restrita&&React.createElement(Ic,{n:"check_circle"}),
React.createElement("span",{style:{fontWeight:restrita?700:600,color:'var(--navy-900)',fontSize:13}},casa)
),
React.createElement("span",{style:{display:'flex',alignItems:'center',gap:6}},
React.createElement("span",{style:{fontSize:12,color:restrita?'var(--teal-deep)':'var(--mut)',fontWeight:restrita?600:400}},
restrita?`só: ${sel.join(', ')}`:'todos os boosts'
),
React.createElement(Ic,{n:aberta?'expand_less':'expand_more'})
)
),
aberta&&React.createElement("div",{style:{padding:'4px 12px 12px',background:'#fff'}},
boosts.map((b)=>{
const on=sel.includes(b);
return React.createElement("div",{key:b,onClick:()=>toggleBoostCasa(casa,b),style:{display:'flex',alignItems:'center',gap:9,padding:'6px 4px',cursor:'pointer',fontSize:12.5}},
React.createElement("span",{style:{width:17,height:17,borderRadius:5,border:'1.5px solid var(--line-2)',display:'grid',placeItems:'center',flexShrink:0,background:on?'var(--teal-deep)':'#fff'}},on&&React.createElement(Ic,{n:"check"})),
React.createElement("span",null,b)
);
}),
restrita&&React.createElement("div",{onClick:()=>limparCasa(casa),style:{fontSize:11.5,color:'var(--mut)',cursor:'pointer',marginTop:6,textDecoration:'underline'}},"voltar pra todos os boosts")
)
);
})
)
)
)
),
React.createElement("button",{onClick:salvar,disabled:salvando,style:{opacity:salvando?.6:1}},salvando?'Salvando…':ed?'Salvar alterações':'Criar perfil')
)
);
}

function PerfisTab({onClose}){
const[perfis,setPerfis]=useState(null),[erro,setErro]=useState(''),[msg,setMsg]=useState('');
const[casas,setCasas]=useState([]),[labels,setLabels]=useState([]),[esportes,setEsportes]=useState([]);
const[boostsPorCasa,setBoostsPorCasa]=useState({});
const[modal,setModal]=useState(null);
const headers={'Content-Type':'application/json'};
const carregar=async()=>{
try{
const r=await fetch('/api/admin/perfis',{credentials:'include'});
if(r.status===401){onClose('relogin');return;}
if(!r.ok){setErro((await r.json().catch(()=>({}))).error||'Erro');return;}
setPerfis(await r.json());
}catch(e){setErro(e.message);}
};
useEffect(()=>{carregar();


const falhou=(o)=>(e)=>setMsg('❌ '+o+' não carregaram: '+e.message);
leJson('/api/casas').then((cs)=>setCasas((cs||[]).map((c)=>c.name).sort((a,b)=>a.localeCompare(b,'pt-BR')))).catch(falhou('As casas'));
leJson('/api/labels').then((ls)=>setLabels((ls||[]).sort((a,b)=>(a||'').localeCompare(b||'','pt-BR')))).catch(falhou('As etiquetas'));
leJson('/api/stats').then((s)=>{
setEsportes((s.bySport||[]).map((x)=>x.sport).filter(Boolean).sort((a,b)=>a.localeCompare(b,'pt-BR',{sensitivity:'base'})));

const map={};(s.labelsByCasa||[]).forEach(({casa,boost_label})=>{if(!map[casa])map[casa]=[];map[casa].push(boost_label);});
setBoostsPorCasa(map);
}).catch(falhou('Os esportes e boosts'));
},[]);
const criar=async(dados)=>{const r=await fetch('/api/admin/perfis',{method:'POST',credentials:'include',headers,body:JSON.stringify(dados)});if(!r.ok)throw new Error((await r.json().catch(()=>({}))).error||'Erro ao criar');setMsg('✅ Perfil criado');carregar();};
const editar=async(id,dados)=>{const r=await fetch('/api/admin/perfis/'+id,{method:'PUT',credentials:'include',headers,body:JSON.stringify(dados)});if(!r.ok)throw new Error((await r.json().catch(()=>({}))).error||'Erro ao salvar');setMsg('✅ Perfil atualizado');carregar();};
const excluir=async(p)=>{if(!(await confirma(`Excluir o perfil "${p.nome}"?`+(p.qtd_tipsters>0?`\n\n${p.qtd_tipsters} tipster(s) usam esse perfil — eles deixarão de recebê-lo.`:''))))return;const r=await fetch('/api/admin/perfis/'+p.id,{method:'DELETE',credentials:'include'});if(!r.ok){setMsg('❌ '+((await r.json().catch(()=>({}))).error||'Erro'));return;}setMsg('✅ Perfil excluído');carregar();};


const resumo=(r)=>{
const p=[];
if(r.casas?.length)p.push(`${r.casas.length} casa(s)`);
if(r.labels?.length)p.push(`${r.labels.length} label(s)`);
if(r.esportes?.length)p.push(r.esportes.join('/'));
if(r.torneios?.length)p.push(`${r.torneios.length} torneio(s)`);
if(r.pct_min!=null)p.push(`≥${r.pct_min}%`);
if(r.odd_min!=null||r.odd_max!=null)p.push(`odd ${r.odd_min??'0'}–${r.odd_max??'∞'}`);
if(r.ao_vivo==='sim')p.push('só ao vivo');
if(r.ao_vivo==='nao')p.push('só pré-jogo');
if(r.boost_por_casa&&Object.keys(r.boost_por_casa).length)p.push(`${Object.keys(r.boost_por_casa).length} casa(s) c/ boost restrito`);
return p.length?p.join(' · '):'sem filtros (recebe tudo)';
};

if(erro)return React.createElement("div",{className:"toast",style:{color:'var(--error)'}},"❌ ",erro);
if(!perfis)return React.createElement("div",{style:{textAlign:'center',padding:48,color:'var(--on-surface-variant)'}},"Carregando perfis…");

return React.createElement("div",null,
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}},
React.createElement("div",{style:{fontSize:13,color:'var(--mut)'}},"Perfis são conjuntos de filtros que você atribui aos tipsters. Um tipster pode somar vários."),
React.createElement("button",{className:"btn-sm b-green",style:{display:'flex',alignItems:'center',gap:5,whiteSpace:'nowrap'},onClick:()=>setModal({novo:true})},React.createElement(Ic,{n:"add"}),"Novo perfil")
),
perfis.length===0?
React.createElement("div",{style:{textAlign:'center',padding:50,color:'var(--mut)'}},
React.createElement("div",{style:{fontSize:0,marginBottom:12}},React.createElement(Ic,{n:"filter_alt"})),
React.createElement("div",{style:{fontFamily:'var(--f-display)',fontSize:16,fontWeight:700,color:'var(--navy-700)',marginBottom:5}},"Nenhum perfil ainda"),
React.createElement("div",null,"Crie o primeiro (ex.: \"Águas Profundas\") pra começar.")
):
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},
React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Perfil"),React.createElement("th",null,"Telas"),React.createElement("th",null,"Filtros"),React.createElement("th",null,"Tipsters"),React.createElement("th",null,"Ações"))),
React.createElement("tbody",null,perfis.map((p)=>React.createElement("tr",{key:p.id},
React.createElement("td",null,React.createElement("div",{style:{fontWeight:600,color:'var(--navy-900)'}},p.nome,!p.ativo&&React.createElement("span",{style:{fontSize:11,color:'var(--mut)',marginLeft:6}},"(inativo)")),p.descricao&&React.createElement("div",{style:{fontSize:11.5,color:'var(--mut)'}},p.descricao)),
React.createElement("td",{style:{fontSize:12,color:'var(--ink-2)',maxWidth:220}},ABAS_PERFIL.filter(([id])=>(p.abas||ABAS_PADRAO).includes(id)).map(([,lbl])=>lbl).join(' · ')),
React.createElement("td",{style:{fontSize:12,color:'var(--ink-2)',maxWidth:280}},resumo(p.regras)),
React.createElement("td",null,React.createElement("span",{className:"pill"},p.qtd_tipsters)),
React.createElement("td",null,React.createElement("div",{style:{display:'flex',gap:6}},
React.createElement("button",{className:"btn-sm b-amber",onClick:()=>setModal({perfil:p})},"Editar"),
React.createElement("button",{className:"btn-sm b-red",onClick:()=>excluir(p)},"Excluir")
))
))))
),
modal&&React.createElement(PerfilModal,{perfil:modal.perfil,casas:casas,labels:labels,esportes:esportes,boostsPorCasa:boostsPorCasa,
onSave:(dados)=>modal.perfil?editar(modal.perfil.id,dados):criar(dados),onClose:()=>setModal(null)})
);
}





const EV_TIPOS=[['jogo','Mercados de jogo'],['prop','Props'],['superodd','Super Odds']];



function evContaPorTipo(linhas,passa){const n={},vistos={};for(const[k]of EV_TIPOS){n[k]=0;vistos[k]=new Set();}for(const l of linhas){if(n[l.tipo]==null||!passa(l))continue;const g=l.grupo||l.chave;if(g!=null){if(vistos[l.tipo].has(g))continue;vistos[l.tipo].add(g);}n[l.tipo]++;}return n;}
function evRotuloTipo(nome,marcado,n){return(marcado?'✓ ':'')+nome+(n!=null?' · '+n:'');}
function fmtFalta(ms){const m=Math.round((ms-Date.now())/60000);if(m<0)return'começou';if(m<60)return m+' min';const h=Math.floor(m/60);if(h<24)return h+'h'+String(m%60).padStart(2,'0');return Math.floor(h/24)+'d '+h%24+'h';}
function fmtIdade(s){if(s==null)return'—';if(s<60)return Math.max(0,Math.round(s))+' s';const m=Math.round(s/60);return m<60?m+' min':Math.round(m/60)+' h';}


function idadeViva(l,agora,conf,desvio){const c=l.confirmadoCanal&&conf?conf[l.fonte]:null;const t=c||l.lidoEm||l.ts;return t?Math.max(0,(agora+(desvio||0)-t)/1000):l.idade_s;}
function kellyQ(odd,justa){if(!(odd>1&&justa>1&&odd>justa))return null;return(odd/justa-1)/(odd-1)/4*100;}


function evTitulo5050(justa,justaPag,d,formato,casa){const p=justa>1?1/justa:null;const pc=(x)=>(100*x).toFixed(2).replace('.',',')+'%';
return'Justa da seleção (P6j): '+fmtOddF(justa,formato)+(p?' = chance '+pc(p):'')+'. Na '+(casa||'Polymarket')+' o W.O. antes do início ou o cancelamento paga 0,50 (a Pinnacle anula)'+(d!=null?'; d = '+pc(d)+' das partidas deste jogo':'')+'. Chance que vale para ela: (1 − d)·p + 0,5·d'+(p&&d!=null?' = '+pc((1-d)*p+0.5*d):'')+' → justa desta casa '+fmtOddF(justaPag,formato)+'. EV = odd ÷ '+fmtOddF(justaPag,formato)+' − 1.';}



const EV_FILTRO_PADRAO={tipos:['jogo','prop','superodd'],evMin:1,evMax:null,liqMin:null,oddMin:1.3,oddMax:10,horas:72,soBR:false,boasVindas:false,liqBloqueadas:false,casasFora:[],mercadosFora:[],ligasFora:[],esportesFora:[],porPagina:50};
const EV_ESPORTES={football:['Futebol','sports_soccer'],soccer:['Futebol','sports_soccer'],basketball:['Basquete','sports_basketball'],tennis:['Tênis','sports_tennis'],volleyball:['Vôlei','sports_volleyball'],baseball:['Beisebol','sports_baseball'],ice_hockey:['Hóquei no gelo','sports_hockey'],hockey:['Hóquei','sports_hockey'],american_football:['Futebol americano','sports_football'],nfl:['Futebol americano','sports_football'],mma:['MMA','sports_mma'],boxing:['Boxe','sports_mma'],handball:['Handebol','sports_handball'],esports:['eSports','sports_esports'],darts:['Dardos','adjust'],cricket:['Críquete','sports_cricket'],snooker:['Sinuca','sports']};
const evEsporte=(s)=>EV_ESPORTES[String(s||'').toLowerCase()]||[s?String(s):'Outros','sports'];
const evNorm=(t)=>String(t||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase();
function evGrupoMercado(l){if(l.tipo==='prop')return'p:'+(l.mercadoNome||l.mercado);return'j:'+osGrupo(String(l.mercado||''));}
function evRotuloGrupo(k){if(k.startsWith('p:'))return k.slice(2);const g=(OS_GRUPOS.find(([x])=>x===k.slice(2))||[])[1];return g||k.slice(2);}
const evJogoChave=(l)=>l.evento?'e'+l.evento:'t'+l.jogo;

const evGk=(l)=>l.grupo||l.chave;


function oddDec(n){const r=Math.round(n*1000)/1000;return Math.round(r*1000)%10===0?r.toFixed(2):r.toFixed(3);}
function fmtOddF(o,f){const n=Number(o);if(!(n>1))return'—';if(f==='americana')return n>=2?'+'+Math.round((n-1)*100):'-'+Math.round(100/(n-1));if(f==='prob')return(100/n).toFixed(1).replace('.',',')+'%';return oddDec(n);}
const fmtQuando=(ms)=>new Date(ms).toLocaleString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).replace(',','');
function EvLogo({info,nome}){if(info&&info.logo)return React.createElement("img",{className:"ev-logo",src:info.logo,alt:"",loading:"lazy",onError:(e)=>{e.currentTarget.style.display='none';}});return React.createElement("span",{className:"ev-logo ev-logo-txt","aria-hidden":"true"},String(nome||'?').slice(0,1).toUpperCase());}





function evMotivoFora(c,f,casasInfo){
if(!f)return null;
if((f.casasFora||[]).includes(c.casa))return'casa oculta no filtro';
if(f.soBR&&!(casasInfo[c.casa]||{}).br)return'filtro só casas BR';
if(f.liqMin!=null&&c.tamanho!=null&&c.tamanho<f.liqMin)return'liquidez '+fmtUsd(c.tamanho)+' < mínimo '+fmtUsd(f.liqMin);
if(c.odd<f.oddMin||c.odd>f.oddMax)return'odd fora da faixa do filtro';
if(c.ev!=null&&c.ev>0&&c.ev<f.evMin)return'EV abaixo do mínimo do filtro';
return null;
}




function EvContaP6j({referencia:ref,casas,formato,linha}){





const r=ref.p6j,pc=(x)=>(100*x).toFixed(1).replace('.',',')+'%',pc2=(x)=>(100*x).toFixed(2).replace('.',',')+'%';
const livros=r&&Array.isArray(r.livros)?r.livros:null;
const fecha=r&&r.p>0&&r.p<1&&r.pPin>0&&r.pPin<1&&livros&&Math.abs(1/r.p-ref.justa)<0.0025;
const soma=fecha?livros.reduce((a,x)=>a+(Number(x.r)||0),0):0;
const deste=(x)=>{const m=x.m2!=null?x.m2:x.m;return r.conta?1-m:m;};
const pags=(casas||[]).filter((c)=>!c.referencia&&c.justa>1&&(c.pagamento||Math.abs(c.justa-ref.justa)>=0.0005));

const pagam=(casas||[]).filter((c)=>!c.referencia&&(c.pagamento||c.sem5050));
const lista=(xs)=>xs.map((c)=>c.casa).join(', ').replace(/, ([^,]*)$/,' e $1');
const nomesPag=lista(pagam.length?pagam:pags);
const daLinha=linha?(casas||[]).find((c)=>c.fonte===linha.fonte):null;
const jL=linha?linha.justaPagamento>1?linha.justaPagamento:linha.justa:null;
const pagL=linha&&linha.justaPagamento>1?daLinha&&daLinha.pagamento||pags[0]&&pags[0].pagamento||{}:null;
const dL=pagL?pagL.d!=null?pagL.d:linha.p6j&&linha.p6j.d:null;
const kL=linha&&jL?kellyQ(linha.odd,jL):null;
const semL=linha&&!pagL?linha.sem5050||daLinha&&daLinha.sem5050||null:null;
const fmtEv=(v)=>v==null?'—':(v>0?'+':'')+Number(v).toFixed(1).replace('.',',')+'%';
return React.createElement("div",{style:{marginTop:8}},
fecha&&React.createElement("table",{className:"ev-det-tab"},React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Parte da justa"),React.createElement("th",null,"Chance"),React.createElement("th",null,"Justa"),React.createElement("th",null,"Peso"))),React.createElement("tbody",null,
React.createElement("tr",null,React.createElement("td",null,"Pinnacle sem margem"),React.createElement("td",{className:"ev-num"},pc(r.pPin)),React.createElement("td",{className:"ev-num"},fmtOddF(1/r.pPin,formato)),React.createElement("td",{className:"ev-num"},pc(1/(1+soma)))),
livros.map((x,i)=>React.createElement("tr",{key:i},React.createElement("td",null,EV_NOME_BOLSA[x.b]||x.b,x.m2!=null?' (meio corrigido pelo 50/50)':' (meio do livro)',x.calc?' · calculada de '+x.calc:''),React.createElement("td",{className:"ev-num"},pc(deste(x))),React.createElement("td",{className:"ev-num"},deste(x)>0?fmtOddF(1/deste(x),formato):'—'),React.createElement("td",{className:"ev-num"},pc((Number(x.r)||0)/(1+soma))))),
React.createElement("tr",null,React.createElement("td",null,"Justa P6j antes do 50/50 ",React.createElement("span",{className:"ev-sub"},"(a das casas que não pagam 0,50)")),React.createElement("td",{className:"ev-num"},pc(r.p)),React.createElement("td",{className:"ev-num"},fmtOddF(ref.justa,formato)),React.createElement("td",{className:"ev-num"},"100%")),
pagL&&React.createElement("tr",null,React.createElement("td",null,"Conta do 50/50: (1 − d)·p + 0,5·d",dL!=null?', d = '+pc2(dL):''," — ",React.createElement("b",null,"aplicado")," (sobe a justa)"),React.createElement("td",{className:"ev-num"},pc(1/jL)),React.createElement("td",{className:"ev-num"},fmtOddF(jL,formato)),React.createElement("td",null)),
semL&&React.createElement("tr",null,React.createElement("td",null,"Conta do 50/50: (1 − d)·p + 0,5·d",semL.d!=null?', d = '+pc2(semL.d):''," — ",React.createElement("b",null,"não aplicado"),": deixaria a justa menor"),React.createElement("td",{className:"ev-num"},pc(1/semL.justa)),React.createElement("td",{className:"ev-num"},fmtOddF(semL.justa,formato)),React.createElement("td",null))
)),
linha&&jL>1&&React.createElement("div",{className:"esta",style:{marginTop:6,padding:'6px 8px',borderRadius:6,background:'color-mix(in srgb,var(--teal) 10%,transparent)',fontSize:13}},
React.createElement("b",null,"Justa desta aposta (",linha.casa,pagL?', com o 50/50':semL?', P6j — 50/50 não aplicado: deixaria a justa menor':'',"): ",fmtOddF(jL,formato)," → EV ",fmtEv(linha.ev)," → ¼ Kelly ",kL!=null&&kL>0?kL.toFixed(2).replace('.',',')+'%':'—'),
React.createElement("div",{className:"ev-sub"},fmtOddF(linha.odd,formato)," ÷ ",fmtOddF(jL,formato)," − 1 = ",fmtEv(linha.ev),". É a mesma justa da lista e da tabela das casas.")
),
React.createElement("div",{className:"ev-sub",style:{marginTop:4}},"Justa P6j da seleção: ",React.createElement("b",null,fmtOddF(ref.justa,formato)),ref.justaPin>1&&Math.abs(ref.justaPin-ref.justa)>=0.0005?' (a Pinnacle sem margem, '+fmtOddF(ref.justaPin,formato)+', puxada pelas bolsas)':''," — é a do EV das casas que anulam a aposta no cancelamento",pags.length?'':', e de todas nesta seleção',".",
pagam.length>0&&React.createElement(React.Fragment,null," As casas que pagam 0,50 no W.O. antes do início ou no cancelamento (",nomesPag,") usam a maior entre a P6j e a justa com o 50/50 (o 50/50 só vale quando deixa a justa mais conservadora)",pags.length?React.createElement(React.Fragment,null,": aqui ",React.createElement("b",null,fmtOddF(pags[0].justa,formato)),", com o 50/50"):React.createElement(React.Fragment,null,": aqui o 50/50 daria ",fmtOddF((pagam[0].sem5050||{}).justa,formato),", menor, e não vale — fica a P6j"),".")
)
);
}
const EV_NOME_BOLSA={polymarket:'Polymarket',kalshi:'Kalshi',sxbet:'SX Bet',fourcasters:'4casters'};
function EvDetalhe({l,casas,formato,onOcultar,onNav,filtro}){
const[d,setD]=useState(null),[erro,setErro]=useState(null);
useEffect(()=>{let vivo=true;setErro(null);
fetch('/api/ev/detalhe?g='+encodeURIComponent(l.grupo||''),{credentials:'include'}).then(async(r)=>{const x=await r.json().catch(()=>({}));if(!vivo)return;if(!r.ok)throw new Error(x.error||'HTTP '+r.status);setD(x);}).catch((e)=>{if(vivo)setErro(e.message);});
return()=>{vivo=false;};},[l.grupo,l.odd,l.justa]);
const ref=d&&d.referencia;

const irOddsScreen=()=>{try{localStorage.setItem('os.sel',JSON.stringify(l.evento));}catch(e){}if(window.Rota)window.Rota.set({ev:l.evento});if(onNav)onNav('odds');};
return React.createElement("div",{className:"ev-det"},
React.createElement("div",{className:"ev-det-col"},
React.createElement("div",{className:"ev-det-tit"},l.selecao," ",React.createElement("span",{className:"ev-sub"},"· ",l.mercadoNome)),
erro&&React.createElement("div",{className:"ev-sub"},"Não carregou as outras casas: ",erro),
!d&&!erro&&React.createElement("div",{className:"ev-sub"},"Carregando as outras casas…"),
d&&React.createElement("table",{className:"ev-det-tab"},React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Odd"),React.createElement("th",{title:"A justa que entra no EV desta casa: EV = odd ÷ justa − 1"},"Justa"),React.createElement("th",null,"EV"),React.createElement("th",null,"Preço"),React.createElement("th",null),React.createElement("th",{title:"¼ Kelly: fração da banca pelo critério de Kelly dividido por 4, contra a justa desta casa"},"¼ Kelly"))),React.createElement("tbody",null,
d.casas.map((c0)=>{const esta=c0.fonte===l.fonte;const c=esta&&Number(c0.odd)===Number(l.odd)&&l.justa>1?{...c0,justa:l.justaPagamento>1?l.justaPagamento:l.justa,ev:l.ev,pagamento:l.justaPagamento>1?c0.pagamento:undefined,sem5050:l.sem5050||undefined}:c0;const melhor=d.melhor!=null&&c.odd===d.melhor;const fora=!c.referencia&&c.ev>0?evMotivoFora(c,filtro,casas):null;return React.createElement("tr",{key:c.fonte,className:(esta?'esta ':'')+(melhor?'melhor':''),style:fora?{opacity:.6}:undefined,title:fora?'Fora da lista pelo seu filtro: '+fora:undefined},
React.createElement("td",null,React.createElement("span",{className:"ev-casa"},React.createElement(EvLogo,{info:{logo:c.logo||(casas[c.casa]||{}).logo},nome:c.casa}),c.casa),c.liq&&React.createElement(ObsAlerta,{liq:c.liq,casas:[c.casa],molde:c.moldeCasa}),
c.periodoCasa&&React.createElement("div",{className:"ev-sub"},c.periodoCasa==='jogo_pr'?'Inclui prorrogação':'90 minutos'),
c.referencia&&React.createElement("span",{className:"ev-tag"},"referência"),c.tipoOdd==='maker'&&React.createElement("span",{className:"ev-tag",title:'Odd de quem oferece (ordem parada na Limitless, sem taxa): a casa só paga se alguém tomar a ordem. Postar a '+String(c.maker&&c.maker.preco).replace('.',',')+' (um tick melhor que o livro; SIM: ask '+String(c.maker&&c.maker.ask).replace('.',',')+' · bid '+String(c.maker&&c.maker.bid).replace('.',',')+')'},"ordem parada: pode não preencher"),c.superOdd&&React.createElement("span",{className:"ev-tag"},c.rotulo||'Super Odd'),c.calculada&&React.createElement("span",{className:"ev-tag",title:"Esta casa não tem a linha: a odd sai exata das duas linhas vizinhas dela (comprando as duas nas proporções certas). É a mesma que o filtro 'outras casas acima da justa' usa."},"calculada de ",c.calculada),c.suspeito&&React.createElement("span",{className:"ev-tag ev-tag-aviso",title:"O preço desta casa num mercado principal não parece ser do mesmo jogo da Pinnacle: fica fora do EV"},"pareamento suspeito"),esta&&React.createElement("span",{className:"ev-tag"},"esta linha"),fora&&React.createElement("span",{className:"ev-tag ev-tag-aviso"},"fora do filtro: ",fora)),
React.createElement("td",{className:"ev-num"},React.createElement("b",null,fmtOddF(c.odd,formato)),c.tamanho!=null&&React.createElement("div",{className:"ev-sub"},"até ",fmtUsd(c.tamanho)),c.tamanhoRedes!=null&&React.createElement("div",{className:"ev-sub",title:"Overtime: a soma das 3 redes (o robô divide a aposta entre elas)"},"3 redes: ",fmtUsd(c.tamanhoRedes))),

React.createElement("td",{className:"ev-num"},c.referencia?'—':fmtOddF(c.justa!=null?c.justa:ref&&ref.justa,formato),c.pagamento&&React.createElement("div",{className:"ev-sub",title:evTitulo5050(ref&&ref.justa,c.justa,c.pagamento.d,formato,c.casa)},"com o 50/50"),c.sem5050&&React.createElement("div",{className:"ev-sub",title:'O 50/50 daria '+fmtOddF(c.sem5050.justa,formato)+', menor que a P6j: não vale (só deixa a justa mais conservadora)'},"50/50 não aplicado")),
React.createElement("td",{className:"ev-num",style:{color:c.ev>0?'var(--up)':c.ev<0?'var(--ink-2)':undefined}},c.ev==null?'—':(c.ev>0?'+':'')+c.ev.toFixed(1)+'%'),
React.createElement("td",{className:"ev-sub"},fmtIdade(c.idade_s)),
React.createElement("td",null,c.url&&React.createElement("a",{className:"ev-ir",href:c.url,target:"_blank",rel:"noopener",title:'Abrir '+c.casa},React.createElement(Ic,{n:"open_in_new"}))),

React.createElement("td",{className:"ev-num"},(()=>{const k=!c.referencia&&ref&&ref.justa?kellyQ(c.odd,c.justa!=null?c.justa:ref.justa):null;return k!=null&&k>0?k.toFixed(2).replace('.',',')+'%':'—';})())
);})
),React.createElement("tfoot",null,React.createElement("tr",null,React.createElement("td",null,"Média",d.casas.some((c)=>c.referencia)?' (sem a referência)':''),React.createElement("td",{className:"ev-num"},fmtOddF(d.media,formato)),React.createElement("td",{colSpan:5,className:"ev-sub"},d.casas.length," casa(s) com esta seleção"))))
),
React.createElement("div",{className:"ev-det-col"},
React.createElement("div",{className:"ev-det-tit"},"De onde vem a justa"),
ref&&ref.justaOrigem&&React.createElement(EqOrigem,{o:ref.justaOrigem,longo:true}),
ref&&ref.tipo==='pinnacle'&&React.createElement(React.Fragment,null,
React.createElement("div",{className:"ev-sub"},ref.metodo,ref.margem!=null?' · margem da Pinnacle '+String(ref.margem).replace('.',',')+'%':''),

ref.pernas&&ref.pernas.length>0?React.createElement("table",{className:"ev-det-tab"},React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Seleção"),React.createElement("th",null,"Pinnacle"),React.createElement("th",{title:"A Pinnacle sem a margem. Com a P6j, a justa que vale é a de baixo (Pinnacle puxada pelas bolsas)"},"Sem margem"))),React.createElement("tbody",null,
ref.pernas.map((p,i)=>React.createElement("tr",{key:i,className:p.esta?'esta':''},React.createElement("td",null,p.rotulo),React.createElement("td",{className:"ev-num"},fmtOddF(p.odd,formato)),React.createElement("td",{className:"ev-num"},fmtOddF(p.justa,formato))))
)):React.createElement("div",{className:"ev-sub"},"A Pinnacle não tem o mercado completo agora."),
ref.justa>1&&React.createElement(EvContaP6j,{referencia:ref,casas:d.casas,formato:formato,linha:l})
),
ref&&ref.tipo==='props'&&React.createElement(React.Fragment,null,
React.createElement("div",{className:"ev-sub"},ref.comparacao?'Props: vale a maior entre o modelo atual e a P6j.':'Props: vale a maior das justas disponíveis.'," Escolhida: ",ref.escolhida,"."),
React.createElement(VotoVelho,{em:ref.justaVotoEm,longo:true}),
React.createElement("table",{className:"ev-det-tab"},React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Método"),React.createElement("th",null,"Justa"),React.createElement("th",null,"Grupos de casas"))),React.createElement("tbody",null,
ref.justas.map((j)=>React.createElement("tr",{key:j.nome,className:j.nome===ref.escolhida?'esta':''},React.createElement("td",null,j.nome),React.createElement("td",{className:"ev-num"},fmtOddF(j.odd,formato)),React.createElement("td",{className:"ev-num"},j.grupos??'—')))
)),
ref.p6j&&React.createElement("div",{style:{marginTop:8}},
React.createElement("div",{className:"ev-sub"},"P6j: Pinnacle + ",(ref.p6j.livros||[]).length," bolsa(s) utilizada(s). Bolsa de um lado só: Polymarket pelo spread típico do mercado (semente + vivo, 14 dias); Kalshi pela média de 15 min; mínimo de 100 jogadores; mercado sem 100 usa o esporte inteiro, e sem 100 no esporte a bolsa fica de fora."),
React.createElement("table",{className:"ev-det-tab"},React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Justa da fonte"),React.createElement("th",null,"Peso"),React.createElement("th",null,"Livro"))),React.createElement("tbody",null,
React.createElement("tr",null,React.createElement("td",null,"Pinnacle"),React.createElement("td",{className:"ev-num"},fmtOddF(1/ref.p6j.pPin,formato)),React.createElement("td",{className:"ev-num"},(100/(1+(ref.p6j.livros||[]).reduce((a,x)=>a+x.r,0))).toFixed(1),"%"),React.createElement("td",null,"Par real sem margem")),
(ref.p6j.livros||[]).map((x)=>React.createElement("tr",{key:x.b},React.createElement("td",null,x.b),React.createElement("td",{className:"ev-num"},fmtOddF(1/x.m,formato)),React.createElement("td",{className:"ev-num"},(100*x.r/(1+ref.p6j.livros.reduce((a,y)=>a+y.r,0))).toFixed(1),"%"),React.createElement("td",null,x.estimativa?x.estimativa.metodo==='spread_tipico_mercado'?React.createElement(React.Fragment,null,React.createElement("b",null,"Estimada")," · degrau ",x.estimativa.degrau||'mercado',": spread típico ",x.estimativa.degrau==='esporte'?'do esporte':'do mercado'," ",x.estimativa.grupo,x.estimativa.mercado?' (o mercado '+x.estimativa.mercado.grupo+' tem '+x.estimativa.mercado.jogadores+' jogadores)':'',": ",x.estimativa.jogadores," jogadores (",x.estimativa.origem,x.estimativa.origem==='semente+vivo'?': '+x.estimativa.jogadoresSemente+' + '+x.estimativa.jogadoresVivo:'',"); spread ",(100*x.estimativa.media).toFixed(2)," pp; p10–p90 ",(100*x.estimativa.p10).toFixed(2),"–",(100*x.estimativa.p90).toFixed(2)," pp"):React.createElement(React.Fragment,null,React.createElement("b",null,"Estimada"),x.estimativa.degrau?' · degrau '+x.estimativa.degrau:'',": ",x.estimativa.jogadores," jogadores / ",x.estimativa.jogos," jogos; spread médio ",(100*x.estimativa.media).toFixed(2)," pp; p10–p90 ",(100*x.estimativa.p10).toFixed(2),"–",(100*x.estimativa.p90).toFixed(2)," pp (",x.estimativa.recorte,", 15 min)"):'Dois lados reais'))),
Object.entries(ref.p6j.sem||{}).map(([b,m])=>React.createElement("tr",{key:b},React.createElement("td",null,b),React.createElement("td",{colSpan:3,className:"ev-sub"},"Não utilizada: ",m,(()=>{const f=(ref.p6j.fora||{})[b];return f?` — ${f.degrau==='esporte'?'nem o esporte chega ao mínimo: ':''}grupo ${f.grupo}: ${f.jogadores} de ${f.minimo} jogadores${f.origem?' ('+f.origem+')':''}${f.mercado?`; mercado ${f.mercado.grupo}: ${f.mercado.jogadores}`:''}`:'';})())))
))
)
),
l.texto&&React.createElement("div",{className:"ev-sub",style:{marginTop:8}},"Texto da Super Odd: “",l.texto,"”",l.original?' · odd sem o boost: '+fmtOddF(l.original,formato):'',l.boasVindas?' · só para conta nova':''),
React.createElement("div",{className:"ev-sub",style:{marginTop:8}},fmtQuando(l.kickoff)," · ¼ Kelly = fração da banca pelo critério de Kelly dividido por 4"),
React.createElement("div",{className:"ev-det-acoes"},
l.url&&React.createElement("a",{className:"btn-sm b-green",href:l.url,target:"_blank",rel:"noopener"},"Abrir na ",l.casa),
l.evento&&onNav&&React.createElement("button",{className:"btn-sm",onClick:irOddsScreen},"Ver o jogo no Odds Screen"),
React.createElement("button",{className:"btn-sm",onClick:(e)=>onOcultar(e,l)},"Ocultar…")
)
)
);
}



function AlertaTaxa(){
const[it,setIt]=useState([]);const[aberto,setAberto]=useState(false);

useEffect(()=>{let vivo=true;const le=()=>leJson('/api/ev/alertas').then((j)=>{if(vivo&&j)setIt(j.taxa||[]);}).catch((e)=>{if(vivo)setIt([`não consegui ler os alertas de taxa: ${e.message}`]);});
le();const i=setInterval(le,30000);return()=>{vivo=false;clearInterval(i);};},[]);
if(!it.length)return null;
return React.createElement("div",{role:"alert",style:{background:'#FDECEA',border:'2px solid #B3261E',color:'#7A1712',borderRadius:10,padding:'10px 14px',margin:'0 0 12px',fontSize:13.5}},
React.createElement("div",{style:{display:'flex',gap:10,alignItems:'center'}},React.createElement("b",{style:{flex:1}},"⚠ Taxa das casas: ",it.length," alerta",it.length>1?'s':''," — veja cada um abaixo (só sai do EV a linha do item que diz “fora do EV”; as outras seguem com a marca “taxa não conferida”)"),
React.createElement("button",{className:"btn-sm",onClick:()=>setAberto(!aberto)},aberto?'Fechar':'Ver')),
aberto&&React.createElement("ul",{style:{margin:'8px 0 0 18px',padding:0}},it.map((t,i)=>React.createElement("li",{key:i},t)))
);
}
function EvTab({onNav:onNavTela,pode}){
const onNav=pode&&!pode('odds')?null:onNavTela;
const[linhas,setLinhas]=useState(()=>new Map());
const[casasInfo,setCasasInfo]=useState({});
const[conectado,setConectado]=useState(false);
const[recuperadoEm,setRecuperadoEm]=useState(null);
const[em,setEm]=useState(null);
const[suspeitos,setSuspeitos]=useState([]);
const[frescor,setFrescor]=useState(null);

const[filtrosCat,setFiltrosCat]=useState({mercadosJogo:[],mercadosProps:[],esportes:[]});
const[novas,setNovas]=useState(()=>new Set());

const padrao=useMemo(()=>{const lerV=(k,p)=>{try{const v=localStorage.getItem('ev.'+k);return v==null?p:JSON.parse(v);}catch(e){return p;}};
return{...EV_FILTRO_PADRAO,tipos:lerV('tipos',EV_FILTRO_PADRAO.tipos),evMin:lerV('evMin',1),oddMin:lerV('oddMin',1.3),oddMax:lerV('oddMax',10),horas:lerV('horas',72),soBR:lerV('soBR',false),boasVindas:lerV('boasVindas',false),casasFora:lerV('casasFora',[])};},[]);
const[filtrosSalvos,setFiltrosSalvos]=usePrefServidor('ev.filtros',padrao);
const[presets,setPresets]=usePrefServidor('ev.presets',[]);
const[ocultasSalvas,setOcultas]=usePrefServidor('ev.ocultas',[]);
const[formato,setFormato]=usePrefServidor('ev.formato','decimal');
const f={...EV_FILTRO_PADRAO,...(filtrosSalvos||{})};
const setF=(patch)=>setFiltrosSalvos({...f,...patch});
const[busca,setBusca]=useState('');
const[painel,setPainel]=useState(false);
const[buscaPainel,setBuscaPainel]=useState('');
const[nomePreset,setNomePreset]=useState(null);
const[aberta,setAberta]=useState(null);
const[menu,setMenu]=useState(null);
const[pagina,setPagina]=useState(0);
const[agora,setAgora]=useState(Date.now());
useEffect(()=>{const i=setInterval(()=>setAgora(Date.now()),5000);return()=>clearInterval(i);},[]);
const[confirmados,setConfirmados]=useState({});const[desvio,setDesvio]=useState(0);
const atrasos=useAtrasosFontes();
useEffect(()=>{
let es=null,parado=false,espera=null;
const liga=()=>{
es=new EventSource('/api/ev/stream',{withCredentials:true});
es.addEventListener('open',()=>setConectado(true));
es.addEventListener('error',()=>{setConectado(false);es.close();if(!parado)espera=setTimeout(liga,5000);});
es.addEventListener('snapshot',(e)=>{const d=JSON.parse(e.data);setLinhas(new Map((d.linhas||[]).map((l)=>[l.chave,l])));setEm(d.em);setRecuperadoEm(d.recuperadoEm||null);if(d.confirmados)setConfirmados(d.confirmados);if(d.srv)setDesvio(d.srv-Date.now());setSuspeitos(d.suspeitos||[]);if(d.frescor)setFrescor(d.frescor);if(d.casas)setCasasInfo(d.casas);if(d.filtros)setFiltrosCat(d.filtros);});
es.addEventListener('reinicio',()=>setConectado(false));


es.addEventListener('diff',(e)=>{pend.push(JSON.parse(e.data));agenda();});
};
const pend=[];let timer=null;
const aplica=()=>{timer=null;if(!pend.length)return;if(document.hidden)return;
const ds=pend.splice(0);const ult=ds[ds.length-1];
setLinhas((prev)=>{const m=new Map(prev);for(const d of ds){for(const k of d.del||[])m.delete(k);for(const l of d.add||[])m.set(l.chave,l);for(const l of d.upd||[])m.set(l.chave,l);}return m;});


const agoraSrv=Date.now()+(ult.srv?ult.srv-Date.now():0);
const ks=ds.flatMap((d)=>(d.add||[]).filter((l)=>{const p=d.primeiras&&d.primeiras[l.chave];return!(p>0)||agoraSrv-p<20000;}).map((l)=>l.chave));
if(ks.length){setNovas((v)=>new Set([...v,...ks]));setTimeout(()=>setNovas((v)=>{const n=new Set(v);for(const k of ks)n.delete(k);return n;}),6000);}
const ultCom=(campo)=>{for(let i=ds.length-1;i>=0;i--)if(ds[i][campo])return ds[i][campo];return null;};
setEm(ult.em);const c=ultCom('confirmados');if(c)setConfirmados(c);if(ult.srv)setDesvio(ult.srv-Date.now());setSuspeitos(ult.suspeitos||[]);
const fr=ultCom('frescor');if(fr)setFrescor(fr);const ca=ultCom('casas');if(ca)setCasasInfo(ca);const fi=ultCom('filtros');if(fi)setFiltrosCat(fi);
for(let i=ds.length-1;i>=0;i--)if(Object.prototype.hasOwnProperty.call(ds[i],'recuperadoEm')){setRecuperadoEm(ds[i].recuperadoEm||null);break;}};
const agenda=()=>{if(!timer&&!document.hidden)timer=setTimeout(aplica,700);};
const visivel=()=>{if(!document.hidden&&pend.length)aplica();};
document.addEventListener('visibilitychange',visivel);
liga();
return()=>{parado=true;if(espera)clearTimeout(espera);if(timer)clearTimeout(timer);document.removeEventListener('visibilitychange',visivel);if(es)es.close();};
},[]);
useEffect(()=>{if(!menu)return;const fecha=()=>setMenu(null);window.addEventListener('click',fecha);return()=>window.removeEventListener('click',fecha);},[menu]);



const agoraFiltro=Math.floor(agora/60000)*60000;
const ocultas=useMemo(()=>(ocultasSalvas||[]).filter((o)=>o&&o.ate>agoraFiltro),[ocultasSalvas,agoraFiltro]);
const ocultaSet=useMemo(()=>new Set(ocultas.map((o)=>o.k)),[ocultas]);
const ocultar=(l,quanto,jogoInteiro)=>{
const ate=quanto==='jogo'?Math.max(l.kickoff,Date.now()+3600e3):Date.now()+quanto*3600e3;


const k=jogoInteiro?'jogo:'+evJogoChave(l):'sel:'+(l.grupo||l.chave);
const r=jogoInteiro?l.jogo:l.selecao+' · '+l.mercadoNome+' · '+l.jogo;
setOcultas([...ocultas.filter((o)=>o.k!==k),{k,ate,r:String(r).slice(0,80)}].slice(-100));
setMenu(null);if(aberta===evGk(l))setAberta(null);
};
const abreMenu=(e,l)=>{e.stopPropagation();const b=e.currentTarget.getBoundingClientRect();setMenu({l,x:Math.min(b.left,window.innerWidth-260),y:b.bottom+4});};

const todas=useMemo(()=>[...linhas.values()],[linhas]);
const q=evNorm(busca.trim());
const fora={casas:new Set(f.casasFora),mercados:new Set(f.mercadosFora),ligas:new Set(f.ligasFora),esportes:new Set(f.esportesFora)};
const chaveFiltro=JSON.stringify(f)+'|'+q;



const passaFaixa=(l)=>l.ev>=f.evMin&&(f.evMax==null||l.ev<=f.evMax)&&l.odd>=f.oddMin&&l.odd<=f.oddMax&&
l.kickoff-agoraFiltro<=f.horas*3600e3&&(!f.soBR||(casasInfo[l.casa]||{}).br||l.br)&&(f.boasVindas||!l.boasVindas)&&(

f.liqBloqueadas||!(l.liq&&l.liq.classe==='bloqueia'))&&
!ocultaSet.has(l.chave)&&!ocultaSet.has('sel:'+(l.grupo||l.chave))&&!ocultaSet.has('jogo:'+evJogoChave(l))&&(

f.liqMin==null||l.tamanho==null||l.tamanho>=f.liqMin)&&(
!q||evNorm(l.jogo+' '+l.liga+' '+l.mercadoNome+' '+l.selecao+' '+l.casa).includes(q));
const base=useMemo(()=>todas.filter((l)=>f.tipos.includes(l.tipo)&&passaFaixa(l)),[todas,chaveFiltro,agoraFiltro,ocultaSet,casasInfo]);
const passaListas=(l)=>!fora.casas.has(l.casa)&&!fora.mercados.has(evGrupoMercado(l))&&!fora.esportes.has(evEsporte(l.esporte)[0])&&!fora.ligas.has(l.liga||'(sem liga)');
const porTipo=useMemo(()=>evContaPorTipo(todas,(l)=>passaFaixa(l)&&passaListas(l)),[todas,chaveFiltro,agoraFiltro,ocultaSet,casasInfo]);
const vis=useMemo(()=>base.filter(passaListas).sort((a,b)=>b.ev-a.ev),[base,chaveFiltro]);



const agrupadas=useMemo(()=>{const m=new Map();for(const l of vis){const k=l.grupo||l.chave;const g=m.get(k);if(!g)m.set(k,{...l,outras:[]});else g.outras.push(l);}
const melhorTodas=new Map();for(const l of todas){const k=l.grupo||l.chave;const b=melhorTodas.get(k);if(!b||l.odd>b.odd)melhorTodas.set(k,l);}
for(const g of m.values()){const b=melhorTodas.get(g.grupo||g.chave);if(b&&b.odd>g.odd&&b.casa!==g.casa)g.foraMelhor={casa:b.casa,odd:b.odd,ev:b.ev,motivo:evMotivoFora(b,f,casasInfo)||'fora dos filtros da lista'};}
return[...m.values()];},[vis,todas]);
useEffect(()=>{setPagina(0);},[chaveFiltro]);
const porPag=Number(f.porPagina)||50;
const nPag=Math.max(1,Math.ceil(agrupadas.length/porPag));
const pag=Math.min(pagina,nPag-1);
const livre=agrupadas.slice(pag*porPag,pag*porPag+porPag);




const congelar=aberta!=null||!!menu;
const congRef=useRef(null);
const porGrupo=useMemo(()=>new Map(agrupadas.map((g)=>[evGk(g),g])),[agrupadas]);
if(!congelar)congRef.current=null;else
if(!congRef.current)congRef.current={ordem:livre.map(evGk),ultimo:new Map(livre.map((g)=>[evGk(g),g]))};
let daPagina=livre,esperando=0;
if(congRef.current){const c=congRef.current;
daPagina=c.ordem.map((k)=>{const g=porGrupo.get(k);if(g){c.ultimo.set(k,g);return g;}const u=c.ultimo.get(k);
if(!u||ocultaSet.has('sel:'+k)||ocultaSet.has(u.chave)||ocultaSet.has('jogo:'+evJogoChave(u)))return null;return{...u,saiu:true};}).filter(Boolean);
const tem=new Set(c.ordem);esperando=livre.filter((g)=>!tem.has(evGk(g))).length+c.ordem.filter((k)=>!porGrupo.has(k)).length;}

useEffect(()=>{setAberta(null);},[pagina,chaveFiltro]);


const facetas=useMemo(()=>{
const casas=new Map(),mercados=new Map(),ligas=new Map();
for(const l of base){
casas.set(l.casa,(casas.get(l.casa)||0)+1);
const g=evGrupoMercado(l);mercados.set(g,(mercados.get(g)||0)+1);
const esp=evEsporte(l.esporte)[0],lg=l.liga||'(sem liga)';
if(!ligas.has(esp))ligas.set(esp,new Map());const m=ligas.get(esp);m.set(lg,(m.get(lg)||0)+1);
}
return{casas,mercados,ligas};
},[base]);
const todasCasas=useMemo(()=>[...new Set([...todas.map((l)=>l.casa),...Object.keys(casasInfo||{})])].sort((a,b)=>a.localeCompare(b,'pt-BR')),[todas,casasInfo]);
const qp=evNorm(buscaPainel.trim());
const casaTipo=(c)=>{const i=casasInfo[c]||{};return i.tipo==='bolsa'?'Bolsas de previsão':i.br?'Casas brasileiras':'Casas internacionais';};

const alterna=(campo,valor)=>{const s=new Set(f[campo]);s.has(valor)?s.delete(valor):s.add(valor);setF({[campo]:[...s]});};
const poeTodos=(campo,valores,ligado)=>{const s=new Set(f[campo]);for(const v of valores)ligado?s.delete(v):s.add(v);setF({[campo]:[...s]});};

const semMeta=(x)=>{const{_preset,...r}=x||{};return r;};
const presetAtivo=presets.find((p)=>p.nome===f._preset)||null;
const alterado=presetAtivo&&JSON.stringify(semMeta(presetAtivo.filtros))!==JSON.stringify(semMeta(f));
const salvaPreset=(nome)=>{const n=String(nome||'').trim().slice(0,40);if(!n)return;setPresets([...presets.filter((p)=>p.nome!==n),{nome:n,filtros:semMeta(f)}].slice(-20));setF({_preset:n});setNomePreset(null);};
const usaPreset=(nome)=>{if(!nome){setFiltrosSalvos({...EV_FILTRO_PADRAO});return;}const p=presets.find((x)=>x.nome===nome);if(p)setFiltrosSalvos({...EV_FILTRO_PADRAO,...p.filtros,_preset:p.nome});};
const apagaPreset=async(nome)=>{if(!(await confirma(`Apagar o filtro salvo "${nome}"?`)))return;setPresets(presets.filter((p)=>p.nome!==nome));if(f._preset===nome)setF({_preset:null});};

const nFora=f.casasFora.length+f.mercadosFora.length+f.ligasFora.length+f.esportesFora.length;
const corEv=(ev)=>ev>=10?'#0f5d46':ev>=5?'#1c6b52':ev>=2?'#2f7d63':'#4b7a68';
const chip=(on,label,fn,key)=>React.createElement("button",{key:key||label,className:"segb"+(on?' on':''),onClick:fn},label);
const itemLista=(campo,valor,rotulo,n,extra)=>{const on=!f[campo].includes(valor);return React.createElement("label",{key:valor,className:'ev-item'+(on?'':' off')},
React.createElement("input",{type:"checkbox",checked:on,onChange:()=>alterna(campo,valor)}),extra,React.createElement("span",{className:"ev-item-nome"},rotulo),React.createElement("span",{className:"ev-item-n"},n||0));};
const secaoCasas=()=>{const grupos=new Map();for(const c of todasCasas){if(qp&&!evNorm(c).includes(qp))continue;const g=casaTipo(c);if(!grupos.has(g))grupos.set(g,[]);grupos.get(g).push(c);}
return['Casas brasileiras','Casas internacionais','Bolsas de previsão'].filter((g)=>grupos.has(g)).map((g)=>React.createElement("div",{key:g,className:"ev-sub-sec"},
React.createElement("div",{className:"ev-sub-tit"},g,React.createElement("span",null,React.createElement("button",{onClick:()=>poeTodos('casasFora',grupos.get(g),true)},"todas"),React.createElement("button",{onClick:()=>poeTodos('casasFora',grupos.get(g),false)},"nenhuma"))),
React.createElement("div",{className:"ev-lista"},grupos.get(g).map((c)=>itemLista('casasFora',c,c,facetas.casas.get(c),React.createElement(EvLogo,{info:casasInfo[c],nome:c}))))));};
const secaoMercados=()=>{const ks=[...new Set([...facetas.mercados.keys(),...f.mercadosFora,...(filtrosCat.mercadosJogo||[]).map((m)=>'j:'+osGrupo(String(m))),...(filtrosCat.mercadosProps||[]).map((m)=>'p:'+m)])].filter((k)=>!qp||evNorm(evRotuloGrupo(k)).includes(qp));
const jogo=ks.filter((k)=>k.startsWith('j:')).sort((a,b)=>OS_GRUPOS.findIndex(([x])=>x===a.slice(2))-OS_GRUPOS.findIndex(([x])=>x===b.slice(2)));
const props=ks.filter((k)=>k.startsWith('p:')).sort((a,b)=>a.localeCompare(b,'pt-BR'));
return[['Mercados de jogo e Super Odds',jogo],['Jogador (props)',props]].filter(([,xs])=>xs.length).map(([t,xs])=>React.createElement("div",{key:t,className:"ev-sub-sec"},
React.createElement("div",{className:"ev-sub-tit"},t,React.createElement("span",null,React.createElement("button",{onClick:()=>poeTodos('mercadosFora',xs,true)},"todos"),React.createElement("button",{onClick:()=>poeTodos('mercadosFora',xs,false)},"nenhum"))),
React.createElement("div",{className:"ev-lista"},xs.map((k)=>itemLista('mercadosFora',k,evRotuloGrupo(k),facetas.mercados.get(k))))));};

const secaoLigas=()=>{const m=new Map(facetas.ligas);for(const e of filtrosCat.esportes||[]){const nm=evEsporte(e)[0];if(!m.has(nm))m.set(nm,new Map());}return[...m.entries()].sort((a,b)=>a[0].localeCompare(b[0],'pt-BR')).map(([esp,ligas])=>{
const lista=[...ligas.entries()].filter(([lg])=>!qp||evNorm(lg).includes(qp)||evNorm(esp).includes(qp)).sort((a,b)=>b[1]-a[1]);
if(!lista.length&&(ligas.size||qp))return null;const espOn=!f.esportesFora.includes(esp);const ic=Object.values(EV_ESPORTES).find((x)=>x[0]===esp);
return React.createElement("div",{key:esp,className:"ev-sub-sec"},
React.createElement("div",{className:"ev-sub-tit"},React.createElement("label",{className:"ev-item",style:{padding:0}},React.createElement("input",{type:"checkbox",checked:espOn,onChange:()=>alterna('esportesFora',esp)}),React.createElement(Ic,{n:ic?ic[1]:'sports'})," ",esp),
React.createElement("span",null,React.createElement("button",{onClick:()=>poeTodos('ligasFora',lista.map((x)=>x[0]),true)},"todas"),React.createElement("button",{onClick:()=>poeTodos('ligasFora',lista.map((x)=>x[0]),false)},"nenhuma"))),
espOn&&React.createElement("div",{className:"ev-lista"},lista.map(([lg,n])=>itemLista('ligasFora',lg,lg,n))));});};

return React.createElement("div",{className:"ev-tela"},
React.createElement(AlertaTaxa,null),
React.createElement("style",null,`
      .ev-barra{display:flex;flex-wrap:wrap;gap:10px 14px;align-items:center;margin-bottom:10px}
      .ev-barra label{font-size:12px;color:var(--on-surface-variant);display:flex;gap:6px;align-items:center}
      .ev-barra input[type=number]{width:64px}
      .ev-vivo{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--on-surface-variant)}
      .ev-vivo i{width:8px;height:8px;border-radius:50%;background:#a3402a;display:inline-block}
      .ev-vivo.on i{background:#1c9b6d;box-shadow:0 0 0 3px color-mix(in srgb,#1c9b6d 25%,transparent)}
      .ev-presets{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
      .ev-presets select{max-width:200px}
      .ev-alterado{font-size:11px;color:var(--amber-deep)}
      .ev-tab td{vertical-align:top}
      .ev-tab tr.ev-linha{cursor:pointer}
      .ev-tab tr.ev-linha:hover td{background:color-mix(in srgb,var(--teal) 6%,transparent)}
      .ev-tab tr.ev-linha.aberta td{background:color-mix(in srgb,var(--teal) 10%,transparent)}
      .ev-tab tr.nova td{animation:evNova 6s ease-out}
      @keyframes evNova{0%{background:color-mix(in srgb,#1c9b6d 22%,transparent)}100%{background:transparent}}
      @media (prefers-reduced-motion:reduce){.ev-tab tr.nova td{animation:none}}
      .ev-pill{display:inline-block;min-width:56px;text-align:center;padding:3px 8px;border-radius:999px;color:#fff;font-weight:700;font-variant-numeric:tabular-nums;font-size:13px}
      .ev-sub{font-size:11.5px;color:var(--on-surface-variant)}
      .ev-num{font-variant-numeric:tabular-nums;font-family:var(--mono,ui-monospace,monospace);font-size:13px}
      .ev-tag{font-size:10.5px;padding:1px 6px;border-radius:4px;background:color-mix(in srgb,var(--on-surface-variant) 14%,transparent);margin-left:6px;white-space:nowrap}
      .ev-tag-aviso{background:color-mix(in srgb,var(--amber) 25%,transparent);color:var(--amber-deep)}
      .ev-jogo{display:flex;gap:8px;align-items:flex-start}
      .ev-jogo .ms-icon{font-size:18px;color:var(--teal-deep);margin-top:1px}
      .ev-quando{font-size:11.5px;color:var(--navy-700);font-weight:600;white-space:nowrap}
      .ev-casa{display:inline-flex;align-items:center;gap:6px;white-space:nowrap}
      .ev-logo{width:18px;height:18px;border-radius:4px;object-fit:contain;flex-shrink:0;background:#fff;border:1px solid var(--line)}
      .ev-logo-txt{display:inline-grid;place-items:center;font-size:10px;font-weight:700;color:var(--navy-700);background:var(--paper-2)}
      .ev-ir{display:inline-grid;place-items:center;color:var(--teal-deep);text-decoration:none}
      .ev-ir .ms-icon{font-size:17px}
      .ev-acao{border:1px solid var(--line-2);background:var(--card);border-radius:7px;padding:2px 5px;cursor:pointer;color:var(--ink-2)}
      .ev-acao .ms-icon{font-size:17px}
      .ev-menu{position:fixed;z-index:60;background:var(--card);border:1px solid var(--line-2);border-radius:10px;box-shadow:0 12px 30px -10px rgba(0,40,75,.35);padding:6px;min-width:240px}
      .ev-menu div.t{font-size:11px;color:var(--mut);padding:6px 8px 2px;text-transform:uppercase;letter-spacing:.06em}
      .ev-menu button{display:block;width:100%;text-align:left;border:none;background:none;padding:7px 8px;border-radius:6px;cursor:pointer;font-size:13px;color:var(--ink)}
      .ev-menu button:hover{background:var(--paper-2)}
      .ev-det{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:18px;padding:10px 4px 6px}
      @media (max-width:900px){.ev-det{grid-template-columns:1fr}}
      .ev-det-col{min-width:0}
      .ev-det-tit{font-weight:700;color:var(--navy-900);margin-bottom:6px;font-size:13px}
      .ev-det-tab{border-collapse:collapse;width:100%;font-size:12.5px;background:var(--card);border:1px solid var(--line);border-radius:8px}
      .ev-det-tab th{font-size:10.5px;text-transform:uppercase;letter-spacing:.05em;color:var(--mut);text-align:left;padding:5px 8px;border-bottom:1px solid var(--line)}
      .ev-det-tab td{padding:5px 8px;border-bottom:1px solid color-mix(in srgb,var(--line) 70%,transparent)}
      .ev-det-tab tr.melhor td{background:color-mix(in srgb,var(--up) 12%,transparent)}
      .ev-det-tab tr.esta td:first-child{box-shadow:inset 3px 0 0 var(--teal-deep)}
      .ev-det-tab tfoot td{font-weight:600;border-bottom:none}
      .ev-det-acoes{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
      .ev-det-acoes a{text-decoration:none}
      .ev-paginas{display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-top:10px;font-size:12.5px;color:var(--ink-2)}
      .ev-paginas .btns{display:flex;gap:4px;flex-wrap:wrap}
      .ev-paginas button{min-width:32px}
      .ev-paginas button.on{background:var(--navy-700);color:#fff}
      .ev-fundo{position:fixed;inset:0;background:rgba(0,40,75,.25);z-index:70}
      .ev-painel{position:fixed;top:0;right:0;bottom:0;width:min(440px,100vw);background:var(--card);z-index:71;box-shadow:-20px 0 50px -20px rgba(0,40,75,.4);display:flex;flex-direction:column}
      .ev-painel-cab{padding:14px 16px;border-bottom:1px solid var(--line);display:flex;gap:10px;align-items:center}
      .ev-painel-cab h3{margin:0;font-size:16px;flex:1;color:var(--navy-900)}
      .ev-painel-corpo{overflow:auto;padding:4px 16px 24px;flex:1}
      .ev-sec{border-bottom:1px solid var(--line);padding:12px 0}
      .ev-sec>h4{margin:0 0 8px;font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:var(--mut)}
      .ev-sec .linha{display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:12.5px;margin-bottom:6px}
      .ev-sec input[type=number]{width:70px}
      .ev-sub-sec{margin-bottom:10px}
      .ev-sub-tit{display:flex;justify-content:space-between;align-items:center;font-size:12.5px;font-weight:600;color:var(--navy-700);margin:6px 0 4px}
      .ev-sub-tit button{border:none;background:none;color:var(--teal-deep);cursor:pointer;font-size:11.5px;padding:0 0 0 8px}
      .ev-lista{display:flex;flex-direction:column}
      .ev-item{display:flex;align-items:center;gap:8px;font-size:12.5px;padding:3px 2px;cursor:pointer}
      .ev-item.off .ev-item-nome{color:var(--mut);text-decoration:line-through}
      .ev-item-nome{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .ev-item-n{font-variant-numeric:tabular-nums;color:var(--mut);font-size:11.5px}
      .ev-oculta{display:flex;gap:8px;align-items:center;font-size:12px;padding:4px 0}
      .ev-oculta span{flex:1;min-width:0}
    `),
React.createElement("div",{className:"ev-barra"},
React.createElement("span",{className:"ev-vivo"+(conectado?' on':'')},React.createElement("i",null),recuperadoEm?'recuperado de '+new Date(recuperadoEm).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}):conectado?'ao vivo':'reconectando… lista mantida',em?' · atualizado '+new Date(em).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit',second:'2-digit'}):''),
React.createElement("div",{className:"seg",style:{display:'inline-flex'},title:"Marque um ou mais tipos: a lista junta os marcados, do maior EV para o menor"},EV_TIPOS.map(([k,l])=>chip(f.tipos.includes(k),evRotuloTipo(l,f.tipos.includes(k),porTipo[k]),()=>setF({tipos:f.tipos.includes(k)?f.tipos.filter((x)=>x!==k):[...f.tipos,k]}),k))),
React.createElement("label",null,"EV mín. % ",React.createElement("input",{id:"ev-min",type:"number",step:"0.5",value:f.evMin,onChange:(e)=>setF({evMin:Number(e.target.value)||0})})),
React.createElement("label",{title:"Valor disponível na melhor oferta (bolsas: Kalshi, Polymarket, SX, predict.fun). Casa que não informa o valor continua aparecendo."},"Liq. mín. US$ ",React.createElement("input",{id:"ev-liq",type:"number",step:"10",min:"0",placeholder:"—",value:f.liqMin??'',onChange:(e)=>setF({liqMin:e.target.value===''?null:Math.max(0,Number(e.target.value)||0)})})),
React.createElement("label",null,"Começa em até ",React.createElement("select",{id:"ev-horas",value:f.horas,onChange:(e)=>setF({horas:Number(e.target.value)})},[3,6,12,24,48,72].map((h)=>React.createElement("option",{key:h,value:h},h," h")))),
React.createElement("input",{id:"ev-busca",placeholder:"Buscar jogo, liga, jogador, mercado, casa…",value:busca,onChange:(e)=>setBusca(e.target.value),style:{minWidth:240}}),
React.createElement("button",{className:"btn-sm",onClick:()=>setPainel(true),style:{display:'inline-flex',alignItems:'center',gap:5}},React.createElement(Ic,{n:"tune"}),"Filtros",nFora||ocultas.length?` (${nFora} fora${ocultas.length?' · '+ocultas.length+' ocultada(s)':''})`:''),
React.createElement("div",{className:"ev-presets"},
React.createElement("select",{id:"ev-preset",value:f._preset||'',onChange:(e)=>usaPreset(e.target.value),title:"Filtros salvos"},
React.createElement("option",{value:""},"Filtro padrão"),presets.map((p)=>React.createElement("option",{key:p.nome,value:p.nome},p.nome))
),
alterado&&React.createElement("span",{className:"ev-alterado"},"alterado"),
nomePreset==null?
React.createElement("button",{className:"btn-sm",onClick:()=>setNomePreset(presetAtivo?presetAtivo.nome:'')},presetAtivo&&alterado?'Salvar':'Salvar como…'):
React.createElement(React.Fragment,null,React.createElement("input",{id:"ev-preset-nome",autoFocus:true,placeholder:"Nome do filtro",value:nomePreset,onChange:(e)=>setNomePreset(e.target.value),onKeyDown:(e)=>{if(e.key==='Enter')salvaPreset(nomePreset);if(e.key==='Escape')setNomePreset(null);},style:{width:150}}),
React.createElement("button",{className:"btn-sm b-green",onClick:()=>salvaPreset(nomePreset)},"Salvar"),React.createElement("button",{className:"btn-sm",onClick:()=>setNomePreset(null)},"Cancelar")),
presetAtivo&&nomePreset==null&&React.createElement("button",{className:"btn-sm",onClick:()=>apagaPreset(presetAtivo.nome),title:"Apagar este filtro salvo"},React.createElement(Ic,{n:"delete"}))
)
),
React.createElement("div",{className:"ev-sub",style:{marginBottom:8}},agrupadas.length," aposta(s) com os filtros",agrupadas.length!==vis.length?` (${vis.length} casa×aposta)`:''," · ",todas.length," no ar",frescor&&frescor.casa+frescor.pinnacle>0?React.createElement("span",{title:'Fora do ar por preço velho: '+Object.entries(frescor.porCasa||{}).sort((a,b)=>b[1].casa+b[1].pinnacle-(a[1].casa+a[1].pinnacle)).slice(0,12).map(([c,v])=>c+' '+(v.casa+v.pinnacle)).join(', ')+'. Limites: casa '+Math.round(frescor.limites.jogo/60)+' min (Super Odd '+Math.round(frescor.limites.superodd/60)+', props '+Math.round(frescor.limites.prop/60)+'), Pinnacle '+Math.round(frescor.limites.pinnacle/60)+' min até 6 h do jogo, '+Math.round(frescor.limites.pinnacle24h/60)+' até 24 h e '+Math.round(frescor.limites.pinnacleLonge/60)+' depois.'}," · ",frescor.casa+frescor.pinnacle," fora por preço velho (",frescor.casa," da casa, ",frescor.pinnacle," da Pinnacle)"):null,". Mercados de jogo e Super Odds: odd justa da Pinnacle sem a margem. Props: a maior entre Legado, Comparativa e Semi-sharp. Clique numa linha para ver a aposta em todas as casas."),

aberta!=null&&React.createElement("div",{className:"ev-sub",style:{position:'fixed',left:'50%',bottom:16,transform:'translateX(-50%)',zIndex:50,maxWidth:'calc(100vw - 32px)',padding:'8px 12px',borderRadius:10,background:'var(--surface, #fff)',boxShadow:'0 4px 18px rgba(0,0,0,.18)',border:'1px solid color-mix(in srgb,var(--teal) 35%,transparent)',display:'flex',gap:10,alignItems:'center'}},
React.createElement(Ic,{n:"push_pin"}),React.createElement("span",null,"Lista parada enquanto você vê o detalhe: os números seguem atualizando, as linhas não mudam de lugar.",esperando>0?` ${esperando} mudança(s) esperando.`:''),
aberta!=null&&React.createElement("button",{className:"btn-sm",onClick:()=>{setAberta(null);setMenu(null);}},"Fechar e atualizar")),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",{className:"ev-tab"},React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"EV"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Odd"),React.createElement("th",null,"Justa"),React.createElement("th",null,"Preço"),React.createElement("th",null,"¼ Kelly"),React.createElement("th",null))),React.createElement("tbody",null,
daPagina.map((l)=>{const k=kellyQ(l.odd,l.justaPagamento||l.justa);const gk=evGk(l);const ab=aberta===gk;const esp=evEsporte(l.esporte);return React.createElement(React.Fragment,{key:gk},
React.createElement("tr",{className:'ev-linha'+(novas.has(l.chave)&&!congelar?' nova':'')+(ab?' aberta':''),style:l.saiu||l.aguardando?{opacity:.5}:undefined,title:l.saiu?'Saiu da lista (EV, preço ou filtro) — fica aqui até você fechar o detalhe':l.aguardando?EV_AGUARDANDO_TXT:undefined,onClick:()=>setAberta(ab?null:gk)},
React.createElement("td",null,React.createElement("span",{className:"ev-pill",style:{background:corEv(l.ev)}},"+",l.ev.toFixed(1),"%")),
React.createElement("td",null,React.createElement("div",{className:"ev-jogo"},React.createElement(Ic,{n:esp[1],title:esp[0]}),React.createElement("div",null,React.createElement("b",null,l.jogo),React.createElement("div",{className:"ev-sub"},l.liga||esp[0]),React.createElement("div",{className:"ev-quando"},fmtQuando(l.kickoff)," · ",fmtFalta(l.kickoff))))),
React.createElement("td",null,l.selecao,l.saiu&&React.createElement("span",{className:"ev-tag",style:{marginLeft:6}},"saiu da lista"),l.aguardando&&React.createElement("span",{className:"ev-tag",style:{marginLeft:6,color:'var(--on-surface-variant)'},title:EV_AGUARDANDO_TXT},"aguardando confirmação da casa"),React.createElement("div",{className:"ev-sub"},l.mercadoNome,l.tipo==='superodd'&&React.createElement("span",{className:"ev-tag"},l.rotulo||'Super Odd'),l.tipo==='prop'&&React.createElement("span",{className:"ev-tag"},"Prop"))),
React.createElement("td",null,React.createElement("span",{className:"ev-casa"},React.createElement(EvLogo,{info:casasInfo[l.casa],nome:l.casa}),l.casa,l.tipoOdd==='maker'&&React.createElement("span",{title:'Odd de quem oferece (ordem parada na Limitless, sem taxa): a casa só paga se alguém tomar a ordem. Postar a '+String(l.maker&&l.maker.preco).replace('.',',')+' (um tick melhor que o livro; SIM: ask '+String(l.maker&&l.maker.ask).replace('.',',')+' · bid '+String(l.maker&&l.maker.bid).replace('.',',')+')',style:{fontSize:10.5,fontWeight:600,color:'#0b5394',background:'#E6F0FA',border:'1px solid #B7D0EA',borderRadius:6,padding:'0 5px',marginLeft:4}},"ordem parada: pode não preencher"),l.taxaNaoLida&&React.createElement("span",{title:'Linha traduzida pelo vínculo do Resolver com o preço cru da casa: a taxa/comissão dela ainda não é aplicada nesse mercado. O EV '+String(l.ev).replace('.',',')+'% é BRUTO (sem a taxa) — fora do robô e dos tips até a casa ganhar a fórmula (aí o selo some sozinho)',style:{fontSize:10.5,fontWeight:700,color:'#8a6110',background:'#FFF4D6',border:'1px solid #F3D9A9',borderRadius:6,padding:'0 5px',marginLeft:4}},"taxa não lida · EV bruto, fora do robô"),l.mandoNaoConfirmado&&React.createElement("span",{title:"O coletor decidiu o mando (quem é o time da casa) deste jogo nesta casa só pelo preço, uma vez: falta a 2ª conferência ou os nomes baterem com o cadastro. Até lá, a linha fica fora do robô e dos tips — uma inversão dos times daria EV falso",style:{fontSize:10.5,fontWeight:700,color:'#8a6110',background:'#FFF4D6',border:'1px solid #F3D9A9',borderRadius:6,padding:'0 5px',marginLeft:4}},"mando não confirmado · fora do robô"),l.corretora&&React.createElement("span",{title:l.corretora.origem==='sem desconto lido'?'Aposta pela corretora '+l.corretora.nome+': desconto dela ainda não lido — vale a odd da casa com a taxa da casa ('+String(l.odd).replace('.',',')+'); preço publicado na casa '+String(l.corretora.oddCheia).replace('.',','):'Odd final na corretora '+l.corretora.nome+': '+String(l.odd).replace('.',',')+' = preço publicado na casa '+String(l.corretora.oddCheia).replace('.',',')+(l.corretora.pct?' com '+String(l.corretora.pct).replace('.',',')+'% no lucro':' sem desconto')+' ('+l.corretora.origem+'). A taxa da casa não entra: o desconto da corretora já é o custo',style:l.corretora.origem==='regras lidas há mais de 1 h'||l.corretora.origem==='sem desconto lido'?{fontSize:10.5,fontWeight:700,color:'#8a6110',background:'#FFF4D6',border:'1px solid #F3D9A9',borderRadius:6,padding:'0 5px',marginLeft:4}:{fontSize:10.5,fontWeight:700,color:'#0b5394',background:'#E6F0FA',border:'1px solid #B7D0EA',borderRadius:6,padding:'0 5px',marginLeft:4}},"via ",l.corretora.nome,l.corretora.pct?' '+String(l.corretora.pct).replace('.',',')+'%':'',l.corretora.origem==='regras lidas há mais de 1 h'?' · regras velhas, fora do robô':l.corretora.origem==='sem desconto lido'?' · desconto não lido, fora do robô':''),l.taxaNaoConferida&&React.createElement("span",{title:"Taxa da documentação, ainda não lida nem medida (sem conta nesta casa) — decisão do Matheus, 04/11",style:{fontSize:10.5,fontWeight:700,color:'#8a6110',background:'#FFF4D6',border:'1px solid #F3D9A9',borderRadius:6,padding:'0 5px',marginLeft:4}},"taxa não conferida"),React.createElement(SeloAtraso,{a:atrasoDasFontes(atrasos,[l.fonte])}),l.url&&React.createElement("a",{className:"ev-ir",href:l.url,target:"_blank",rel:"noopener",onClick:(e)=>e.stopPropagation(),title:'Abrir na '+l.casa},React.createElement(Ic,{n:"open_in_new"}))),React.createElement(ObsAlerta,{liq:l.liq,casas:[l.casa,String(l.fonte||'').replace(/^so:/,'')],mercado:l.mercado,esporte:l.esporte,lado:l.lado}),
l.periodoCasa&&React.createElement("div",{className:"ev-sub"},l.periodoCasa==='jogo_pr'?'Inclui prorrogação':'90 minutos'),
l.outras&&l.outras.length>0&&React.createElement("div",{className:"ev-sub",title:"A mesma aposta com EV em outras casas (clique na linha para ver todas)"},"+ ",l.outras.map((o)=>`${o.casa} ${fmtOddF(o.odd,formato)} (+${o.ev.toFixed(1)}%)`).join(' · ')),
l.regraEv&&React.createElement("div",{className:"ev-sub",style:{color:'var(--up)'},title:"Passou numa regra do Filtro de EV"},"✓ ",l.regraEv),
l.avisosSeg&&l.avisosSeg.length>0&&React.createElement("div",{className:"ev-sub",style:{color:'#a35a00'},title:'Classe da casa (Peixe Admin): '+(l.cls&&l.cls.classe||'?')+(l.cls&&l.cls.produto?' · produto '+l.cls.produto:'')+'\n'+l.avisosSeg.map((a)=>a.seg+': '+a.texto).join('\n')+'\nPor enquanto só aviso: o robô continua podendo apostar até o cadastro ser completado.'},"⚠ ",l.avisosSeg.map((a)=>a.seg).join(' · ')," — ",l.avisosSeg[0].texto),
l.foraMelhor&&React.createElement("div",{className:"ev-sub",style:{color:'#a35a00'},title:"Paga mais nesta seleção, mas o seu filtro tirou da lista"},"↑ ",l.foraMelhor.casa," ",fmtOddF(l.foraMelhor.odd,formato)," (",l.foraMelhor.ev>0?'+':'',Number(l.foraMelhor.ev).toFixed(1),"%) fora do filtro: ",l.foraMelhor.motivo)),
React.createElement("td",{className:"ev-num"},React.createElement("b",null,fmtOddF(l.odd,formato)),l.tamanho!=null&&React.createElement("div",{className:"ev-sub",title:l.tamanhoRedes!=null?'Overtime: o maior valor que um bilhete leva numa rede (Optimism, Arbitrum ou Base)':'Bolsa: valor disponível a esta odd agora (taxa já descontada da odd)'},"até ",fmtUsd(l.tamanho)),l.tamanhoRedes!=null&&React.createElement("div",{className:"ev-sub",title:"Overtime: a soma das 3 redes (o robô divide a aposta entre elas)"},"3 redes: ",fmtUsd(l.tamanhoRedes))),
React.createElement("td",{className:"ev-num"},fmtOddF(l.justaPagamento||l.justa,formato),React.createElement(EqOrigem,{o:l.justaOrigem}),React.createElement(VotoVelho,{em:l.justaVotoEm,agora:agora}),l.justaPagamento>1&&React.createElement("div",{className:"ev-sub",title:evTitulo5050(l.justa,l.justaPagamento,l.p6j&&l.p6j.d,formato,l.casa)},"com o 50/50 · P6j ",fmtOddF(l.justa,formato)),l.sem5050&&React.createElement("div",{className:"ev-sub",title:'Esta casa paga 0,50 no cancelamento, mas a justa com o 50/50 ('+fmtOddF(l.sem5050.justa,formato)+') seria menor que a P6j: o 50/50 só vale quando deixa a justa mais conservadora (Matheus, 03/11).'},"50/50 não aplicado"),

(()=>{if(!l.justaMetodo)return React.createElement("div",{className:"ev-sub"},l.justaFonte);
const lsG=[l,...(l.outras||[])],nomeDe=(b)=>EV_NOME_BOLSA[b]||(lsG.find((x)=>x.fonte===b)||{}).casa||b,classeDe=(b)=>{const x=lsG.find((y)=>y.fonte===b);return x&&x.cls?x.cls.classe:null;};
const pin=l.p6j&&l.p6j.pPin>0?(1/l.p6j.pPin).toFixed(3).replace('.',','):null;
return React.createElement("div",{className:"ev-sub",title:l.p6j?P6jRotulo.titulo(l.justaMetodo,l.p6j,lsG.map((x)=>x.fonte),nomeDe,pin,classeDe):undefined},l.p6j?P6jRotulo.rotulo(l.justaMetodo,l.p6j,nomeDe):l.justaMetodo==='p6j_esports'?'P6j e-sports':'P6j');})(),l.pinIdade_s>180&&React.createElement("div",{className:"ev-sub",style:{color:'#a35a00',fontWeight:600},title:"A Pinnacle que fez esta justa não atualiza há mais de 3 minutos"},"⚠ Pinnacle há ",fmtIdade(l.pinIdade_s))),
React.createElement("td",{className:"ev-sub",title:l.confirmadoCanal?'Confirmado pelo canal ao vivo (WebSocket) da casa: preço igual ao gravado':'Desde a última leitura gravada da casa'},fmtIdade(idadeViva(l,agora,confirmados,desvio)),l.confirmadoCanal&&React.createElement("span",{style:{color:'var(--up)',marginLeft:3}},"●")),
React.createElement("td",{className:"ev-num"},k?k.toFixed(2).replace('.',',')+'%':'—'),
React.createElement("td",null,React.createElement("button",{className:"ev-acao",title:"Ocultar esta aposta ou o jogo","aria-label":"Ocultar",onClick:(e)=>abreMenu(e,l)},React.createElement(Ic,{n:"visibility_off"})))
),
ab&&React.createElement("tr",null,React.createElement("td",{colSpan:9,style:{background:'color-mix(in srgb,var(--teal) 5%,transparent)'}},React.createElement(EvDetalhe,{l:l,casas:casasInfo,formato:formato,onOcultar:abreMenu,onNav:onNav,filtro:f})))
);}),
!vis.length&&React.createElement("tr",null,React.createElement("td",{colSpan:9,className:"ev-sub"},linhas.size?'Nenhuma oportunidade com esses filtros.':'Carregando as oportunidades…'))
))),
vis.length>0&&React.createElement("div",{className:"ev-paginas"},
React.createElement("span",null,pag*porPag+1,"–",Math.min(vis.length,(pag+1)*porPag)," de ",vis.length),
React.createElement("div",{className:"btns"},
React.createElement("button",{className:"btn-sm",disabled:pag===0,onClick:()=>setPagina(pag-1)},"Anterior"),
Array.from({length:nPag},(_,i)=>i).filter((i)=>i===0||i===nPag-1||Math.abs(i-pag)<=2).map((i,x,arr)=>React.createElement(React.Fragment,{key:i},x>0&&i-arr[x-1]>1&&React.createElement("span",null,"…"),React.createElement("button",{className:'btn-sm'+(i===pag?' on':''),onClick:()=>setPagina(i)},i+1))),
React.createElement("button",{className:"btn-sm",disabled:pag>=nPag-1,onClick:()=>setPagina(pag+1)},"Próxima")
),
React.createElement("label",{className:"ev-sub"},"Por página ",React.createElement("select",{id:"ev-porpagina",value:porPag,onChange:(e)=>setF({porPagina:Number(e.target.value)})},[25,50,100].map((n)=>React.createElement("option",{key:n,value:n},n))))
),
menu&&React.createElement("div",{className:"ev-menu",style:{left:menu.x,top:menu.y},onClick:(e)=>e.stopPropagation()},
React.createElement("div",{className:"t"},"Ocultar esta aposta"),
React.createElement("button",{onClick:()=>ocultar(menu.l,1)},"Por 1 hora"),
React.createElement("button",{onClick:()=>ocultar(menu.l,24)},"Por 24 horas"),
React.createElement("button",{onClick:()=>ocultar(menu.l,'jogo')},"Até o jogo começar"),
React.createElement("div",{className:"t"},"Ocultar o jogo inteiro"),
React.createElement("button",{onClick:()=>ocultar(menu.l,'jogo',true)},menu.l.jogo," — até começar")
),
painel&&React.createElement(React.Fragment,null,React.createElement("div",{className:"ev-fundo",onClick:()=>setPainel(false)}),
React.createElement("aside",{className:"ev-painel",role:"dialog","aria-label":"Filtros do EV+"},
React.createElement("div",{className:"ev-painel-cab"},React.createElement("h3",null,"Filtros"),React.createElement("button",{className:"btn-sm",onClick:()=>setFiltrosSalvos({...EV_FILTRO_PADRAO,_preset:null})},"Limpar tudo"),React.createElement("button",{className:"btn-sm",onClick:()=>setPainel(false),"aria-label":"Fechar"},React.createElement(Ic,{n:"close"}))),
React.createElement("div",{style:{padding:'10px 16px 0'}},React.createElement("input",{id:"ev-busca-painel",placeholder:"Procurar casa, mercado ou liga nos filtros…",value:buscaPainel,onChange:(e)=>setBuscaPainel(e.target.value),style:{width:'100%'}})),
React.createElement("div",{className:"ev-painel-corpo"},
React.createElement("div",{className:"ev-sec"},React.createElement("h4",null,"Tipo de aposta"),React.createElement("div",{className:"seg",style:{display:'inline-flex'}},EV_TIPOS.map(([k,l])=>chip(f.tipos.includes(k),l,()=>setF({tipos:f.tipos.includes(k)?f.tipos.filter((x)=>x!==k):[...f.tipos,k]}),'p'+k)))),
React.createElement("div",{className:"ev-sec"},React.createElement("h4",null,"Faixas"),
React.createElement("div",{className:"linha"},"EV % de ",React.createElement("input",{id:"ev-p-evmin",type:"number",step:"0.5",value:f.evMin,onChange:(e)=>setF({evMin:Number(e.target.value)||0})})," até ",React.createElement("input",{id:"ev-p-evmax",type:"number",step:"1",placeholder:"sem teto",value:f.evMax??'',onChange:(e)=>setF({evMax:e.target.value===''?null:Number(e.target.value)})})),
React.createElement("div",{className:"linha"},"Odd de ",React.createElement("input",{id:"ev-p-oddmin",type:"number",step:"0.1",value:f.oddMin,onChange:(e)=>setF({oddMin:Number(e.target.value)||1})})," até ",React.createElement("input",{id:"ev-p-oddmax",type:"number",step:"0.5",value:f.oddMax,onChange:(e)=>setF({oddMax:Number(e.target.value)||100})})),
React.createElement("div",{className:"linha"},"Começa em até ",React.createElement("select",{id:"ev-p-horas",value:f.horas,onChange:(e)=>setF({horas:Number(e.target.value)})},[3,6,12,24,48,72].map((h)=>React.createElement("option",{key:h,value:h},h," h"))))
),
React.createElement("div",{className:"ev-sec"},React.createElement("h4",null,"Opções"),
React.createElement("label",{className:"ev-item"},React.createElement("input",{id:"ev-p-br",type:"checkbox",checked:!!f.soBR,onChange:(e)=>setF({soBR:e.target.checked})})," Só casas brasileiras (regulamentadas)"),
React.createElement("label",{className:"ev-item",title:"Boost só para conta nova (Welcome Boost): o preço é real, mas não vale para quem já tem conta"},React.createElement("input",{id:"ev-p-bv",type:"checkbox",checked:!!f.boasVindas,onChange:(e)=>setF({boasVindas:e.target.checked})})," Mostrar Super Odds de boas-vindas"),
React.createElement("label",{className:"ev-item",title:"Lado em que a regra de liquidação da casa piora a aposta de um jeito que não dá para medir (ex.: reserva que entra vale, vermelho conta 1 cartão no Mais)"},React.createElement("input",{id:"ev-p-bloq",type:"checkbox",checked:!!f.liqBloqueadas,onChange:(e)=>setF({liqBloqueadas:e.target.checked})})," Mostrar apostas bloqueadas pela regra de liquidação"),
React.createElement("div",{className:"linha",style:{marginTop:6}},"Formato da odd ",React.createElement("div",{className:"seg",style:{display:'inline-flex'}},[['decimal','Decimal'],['americana','Americana'],['prob','Probabilidade']].map(([k,l])=>chip(formato===k,l,()=>setFormato(k),'f'+k))))
),
React.createElement("div",{className:"ev-sec"},React.createElement("h4",null,"Casas"),secaoCasas()),
React.createElement("div",{className:"ev-sec"},React.createElement("h4",null,"Mercados"),secaoMercados()),
React.createElement("div",{className:"ev-sec"},React.createElement("h4",null,"Esportes e ligas"),secaoLigas()),
React.createElement("div",{className:"ev-sec"},React.createElement("h4",null,"Ocultadas (",ocultas.length,")"),
!ocultas.length&&React.createElement("div",{className:"ev-sub"},"Nada oculto. Use o botão ",React.createElement(Ic,{n:"visibility_off"})," numa linha para esconder a aposta ou o jogo por um tempo."),
ocultas.map((o)=>React.createElement("div",{key:o.k,className:"ev-oculta"},React.createElement("span",null,o.k.startsWith('jogo:')?React.createElement("b",null,"Jogo: "):null,o.r,React.createElement("div",{className:"ev-sub"},"até ",fmtQuando(o.ate))),React.createElement("button",{className:"btn-sm",onClick:()=>setOcultas(ocultas.filter((x)=>x.k!==o.k))},"Mostrar")))
)
)
)),


em==null&&React.createElement("div",{className:"ev-sub",style:{marginTop:14,fontSize:12}},"Pareamentos suspeitos fora do EV: carregando…"),
em!=null&&suspeitos.length===0&&React.createElement("div",{className:"ev-sub",style:{marginTop:14,fontSize:12}},"Pareamentos suspeitos fora do EV: nenhum agora. A conferência compara cada casa com a Pinnacle nos mercados principais; o jogo aparece aqui quando um lado difere mais de 12 pontos."),
suspeitos.length>0&&React.createElement("details",{style:{marginTop:14}},React.createElement("summary",{style:{cursor:'pointer',fontSize:13}},"Pareamentos suspeitos fora do EV (",suspeitos.length,")"),
React.createElement("div",{className:"ev-sub",style:{margin:'6px 0'}},"O preço da casa num mercado principal não parece ser do mesmo jogo da Pinnacle (um lado com probabilidade diferente em mais de 12 pontos). As linhas dessa casa nesse jogo ficam fora do EV até a causa ser resolvida."),


React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Jogo (mandante x visitante)"),React.createElement("th",null,"Começa"),React.createElement("th",null,"Mercado"),React.createElement("th",null,"Diferença"),React.createElement("th",null,"Casa × Pinnacle"),React.createElement("th",null,"O que a casa mandou"))),React.createElement("tbody",null,
suspeitos.map((x,i)=>React.createElement("tr",{key:i},React.createElement("td",null,x.fonte),React.createElement("td",null,React.createElement("a",{href:'#p=odds&ev='+x.evento,target:"_blank",rel:"noopener",title:"Abrir na Odds Screen: todas as casas e a Pinnacle deste jogo"},x.jogo||'#'+x.evento),React.createElement("div",{className:"ev-sub"},"#",x.evento)),React.createElement("td",{className:"mono-sm"},x.kickoff?fusoSP.fmtSP(new Date(x.kickoff)):'—'),React.createElement("td",{className:"mono-sm"},x.mercado," · ",PERIODO_ROT[x.periodo]||x.periodo||'—'," ",x.lado," ",x.linha),React.createElement("td",{className:"ev-num"},x.diferenca," pts"),React.createElement("td",{className:"ev-num"},x.casa," × ",x.pinnacle,x.justa?` (justa ${x.justa})`:'',x.somaCasa>0&&React.createElement("div",{className:"ev-sub",title:"Soma das probabilidades dos lados no livro da casa. Perto de 100–110% é livro normal; muito acima é livro raso (bolsa sem oferta perto do preço justo), não outro jogo."},"livro da casa: ",String(x.somaCasa).replace('.',','),"%")),React.createElement("td",{className:"mono-sm",style:{fontSize:11,wordBreak:'break-all',whiteSpace:'pre-wrap'}},x.motivo&&React.createElement("b",{style:{color:'#b3261e',display:'block'}},x.motivo," · com os times trocados a diferença cai para ",x.trocado," pts"),x.bruto||!x.motivo&&React.createElement("span",{className:"ev-sub"},"a casa não guardou texto cru nesta linha"),x.eventoFonte&&React.createElement("div",{className:"ev-sub"},"evento na casa: ",x.eventoFonte))))
))))
);
}




const OS_GRUPOS=[['todos','Tudo'],['resultado','Resultado'],['gols','Gols'],['handicap','Handicap'],['ambas','Ambas marcam'],['escanteios','Escanteios'],['cartoes','Cartões'],['outros','Outros'],['props','Props']];
function osGrupo(m){if(/escanteios/.test(m))return'escanteios';if(/cartoes/.test(m))return'cartoes';if(/handicap/.test(m))return'handicap';if(/ambas/.test(m))return'ambas';if(/^jogo_(1x2|vencedor|dupla_chance)$/.test(m))return'resultado';if(/gols_total$/.test(m))return'gols';return'outros';}
function osOdd(o){return o==null?'—':oddDec(Number(o));}


const osJustaDe=(l,key)=>l&&l.justasCasa&&l.justasCasa[key]>1?l.justasCasa[key]:l&&l.justa;
function OsJustaCasas({l}){if(!l||!l.justasCasa)return null;return React.createElement("div",{className:"os-sub",title:'Na Polymarket e na predict.fun o W.O. antes do início ou o cancelamento paga 0,50 (a Pinnacle anula): a chance que vale para elas é (1 − d)·p + 0,5·d'+(l.pagamento&&l.pagamento.d!=null?' (d = '+(100*l.pagamento.d).toFixed(2).replace('.',',')+'%)':'')+', a mesma conta do EV+. O EV de cada uma é odd ÷ esta justa − 1.'},(()=>{const nm={polymarket:'Polymarket',predictfun:'predict.fun'};const por=new Map();for(const[k,v]of Object.entries(l.justasCasa)){const t=osOdd(v);por.set(t,[...(por.get(t)||[]),nm[k]||k]);}return[...por].map(([t,ns])=>ns.join(' e ')+' '+t+' (50/50)').join(' · ');})());}


const fmtUsd=(v)=>{const n=Number(v);if(!isFinite(n))return'—';return'US$ '+(n>=1000?(n/1000).toFixed(n>=10000?0:1).replace('.',',')+' mil':n<10?n.toFixed(2).replace('.',','):Math.round(n));};





function osLer(k,p){try{const v=localStorage.getItem('os.'+k);return v==null?p:JSON.parse(v);}catch(e){return p;}}
function osGrava(k,v){try{localStorage.setItem('os.'+k,JSON.stringify(v));}catch(e){}}



const osNomeCasa=(n)=>String(n||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s*·\s*via .*$/,'').trim();
function osOrdenaCasas(lista,nomeDe,favs,modo,melhores){const fav=(c)=>favs&&favs.has(osNomeCasa(nomeDe(c)))?0:1;const mel=(c)=>melhores?melhores.get(c.key)||0:0;
return lista.slice().sort((a,b)=>fav(a)-fav(b)||(modo==='melhor'?mel(b)-mel(a):0)||String(nomeDe(a)).localeCompare(String(nomeDe(b)),'pt-BR',{sensitivity:'base'})||String(a.key).localeCompare(String(b.key)));}

function OsFaixa({children}){const ref=useRef(null);const[pontas,setPontas]=useState([false,false]);

const mede=()=>{const el=ref.current;if(!el)return;const a=el.scrollLeft>2,b=el.scrollLeft+el.clientWidth<el.scrollWidth-2;setPontas((p)=>p[0]===a&&p[1]===b?p:[a,b]);};



const marcado=useRef(null);
useEffect(()=>{const el=ref.current;if(!el)return;const on=el.querySelector('.os-chip.on');const nome=on?on.textContent.replace((on.querySelector('.n')||{}).textContent||'',''):null;
if(on&&nome!==marcado.current){marcado.current=nome;const l=on.offsetLeft-el.offsetLeft;if(l<el.scrollLeft||l+on.offsetWidth>el.scrollLeft+el.clientWidth)el.scrollLeft=Math.max(0,l-40);}mede();});

useEffect(()=>{const el=ref.current;window.addEventListener('resize',mede);
const roda=(ev)=>{if(!el||Math.abs(ev.deltaY)<=Math.abs(ev.deltaX))return;const max=el.scrollWidth-el.clientWidth;if(max<=0)return;
if(ev.deltaY<0&&el.scrollLeft<=0||ev.deltaY>0&&el.scrollLeft>=max-1)return;ev.preventDefault();el.scrollLeft+=ev.deltaY;};
if(el)el.addEventListener('wheel',roda,{passive:false});
return()=>{window.removeEventListener('resize',mede);if(el)el.removeEventListener('wheel',roda);};},[]);
const anda=(dx)=>{const el=ref.current;if(el)el.scrollBy({left:dx*Math.max(200,el.clientWidth*.7),behavior:'smooth'});};
return React.createElement("div",{className:"os-faixa"},pontas[0]&&React.createElement("button",{type:"button",className:"os-seta","aria-label":"Rolar para a esquerda",onClick:()=>anda(-1)},"‹"),React.createElement("div",{className:"os-faixa-in",ref:ref,onScroll:mede},children),pontas[1]&&React.createElement("button",{type:"button",className:"os-seta dir","aria-label":"Rolar para a direita",onClick:()=>anda(1)},"›"));}

const osLinhaTxt=(v)=>String(Number(v)).replace('.',',');
const OS_HORAS=[[6,'Próximas 6 h'],[24,'24 h'],[48,'48 h'],[72,'3 dias'],[168,'7 dias']];
const OS_PRINCIPAIS=['jogo_vencedor','jogo_1x2','jogo_gols_handicap','jogo_gols_total','jogo_ambas_marcam','jogo_dupla_chance','time_gols_total'];
const osPct=(v)=>(v>0?'+':'')+v.toFixed(1).replace('.',',')+'%';
const osHora=(t)=>new Date(t).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
const osDia=(t)=>new Date(t).toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'2-digit'});





const osNCasas=(ls)=>new Set(ls.flatMap((l)=>Object.keys(l.odds||{}))).size;
const osEquilibrio=(m)=>{const p=m.lados.map((l)=>l.odds.pinnacle&&l.odds.pinnacle.odd).filter(Boolean);return p.length>1?Math.max(...p)-Math.min(...p):99;};
const OS_PARTE_ORDEM=['jogo','jogo_pr','1t','2t'];
function OsJogoDetalhe({evento,onVoltar,favs,ordemCasas}){
const[det,setDet]=useState(null);
const[carregando,setCarregando]=useState(false);
const[cat,setCat]=useState(null);
const[mkSel,setMkSel]=useState(null);
const[perSel,setPerSel]=useState(null);
const[alt,setAlt]=useState(false);
const[mkProp,setMkProp]=useState(null);
const[altP,setAltP]=useState(false);
const[nJog,setNJog]=useState(60);
const[buscaJog,setBuscaJog]=useState('');
const carregaJogo=async(ev,quieto)=>{if(!ev)return;if(!quieto)setCarregando(true);try{const r=await fetch('/api/odds-screen/jogo/'+ev,{credentials:'include'});const d=await r.json();if(!r.ok)throw new Error(d.error||'erro');setDet(d);}catch(e){if(!quieto)setDet({erro:e.message});}finally{setCarregando(false);}};
useEffect(()=>{setDet(null);setCat(null);setMkSel(null);setPerSel(null);setMkProp(null);setAlt(false);setAltP(false);if(evento){carregaJogo(evento);const i=setInterval(()=>carregaJogo(evento,true),30000);return()=>clearInterval(i);}},[evento]);

const mercadosOk=useMemo(()=>(det&&det.mercados||[]).filter((m)=>m.lados.some((l)=>Object.keys(l.odds||{}).length)),[det]);
const propsMk=useMemo(()=>(det&&det.props&&det.props.markets||[]).filter((m)=>m.rows.some((r)=>Object.keys(r.cells||{}).length)),[det]);
const codigos=useMemo(()=>{const mp=new Map();for(const m of mercadosOk){const g=mp.get(m.mercado)||{mercado:m.mercado,nome:m.grupo||m.mercado,cat:osGrupo(m.mercado),partes:new Map()};g.partes.set(m.periodo,m.parte||m.periodo);mp.set(m.mercado,g);}
const pos=(c)=>{const i=OS_PRINCIPAIS.indexOf(c);return i<0?100:i;};return[...mp.values()].sort((a,b)=>pos(a.mercado)-pos(b.mercado));},[mercadosOk]);
const cats=OS_GRUPOS.filter(([k])=>k!=='todos'&&(k==='props'?propsMk.length>0:codigos.some((c)=>c.cat===k)));
const catAt=cats.some(([k])=>k===cat)?cat:(cats[0]||[])[0]||null;
const doCat=codigos.filter((c)=>c.cat===catAt);
const mkAt=doCat.find((c)=>c.mercado===mkSel)||doCat[0]||null;
const partes=mkAt?[...mkAt.partes].sort((a,b)=>{const i=(x)=>{const p=OS_PARTE_ORDEM.indexOf(x[0]);return p<0?50:p;};return i(a)-i(b);}):[];
const perAt=partes.some(([p])=>p===perSel)?perSel:(partes[0]||[])[0]||null;

const blocos=useMemo(()=>{if(!mkAt||catAt==='props')return[];const pp=new Map();for(const m of mercadosOk)if(m.mercado===mkAt.mercado&&m.periodo===perAt){const l=pp.get(m.participante||'')||[];l.push(m);pp.set(m.participante||'',l);}
return[...pp].map(([part,ls])=>{const ord=ls.slice().sort((a,b)=>osNCasas(b.lados)-osNCasas(a.lados)||osEquilibrio(a)-osEquilibrio(b)||(a.linha||0)-(b.linha||0));const principal=ord[0];
return{part,principal,todas:ls.slice().sort((a,b)=>(a.linha||0)-(b.linha||0)),nAlt:ls.length-1};});},[mercadosOk,mkAt&&mkAt.mercado,perAt,catAt]);
const nAlt=blocos.reduce((s,b)=>s+b.nAlt,0);
const mostrar=blocos.flatMap((b)=>alt?b.todas.map((m)=>({m,principal:m===b.principal})):[{m:b.principal,principal:true}]);
const colunas=det&&det.colunas?det.colunas:[];

const melhoresJ=new Map();for(const{m}of mostrar)for(const l of m.lados)if(l.melhor)melhoresJ.set(l.melhor.fonte,(melhoresJ.get(l.melhor.fonte)||0)+1);
const cols=osOrdenaCasas(colunas.filter((c)=>mostrar.some(({m})=>m.lados.some((l)=>l.odds[c.key]))),(c)=>c.nome,favs,ordemCasas,melhoresJ);

const pm=catAt==='props'?propsMk.find((m)=>m.market===mkProp)||propsMk[0]||null:null;
const NOME_JUSTA={legacy:'Legado',comparative:'Comparativa',semiSharp:'Semi-sharp',pinnacle:'Pinnacle',novig:'Novig',prophetx:'ProphetX'};
const tiposJ=det&&det.props&&det.props.fairOdds&&det.props.fairOdds.tipos||['legacy','comparative','semiSharp'];
const colunasJ=tiposJ.length>1?tiposJ:[];
const justaProp=(r)=>{const f=r.fair||{};const xs=tiposJ.map((k)=>[k,NOME_JUSTA[k]||k]).map(([k,n])=>({n,o:f[k]&&Number(f[k].odd)>1?Number(f[k].odd):null}));const m=xs.filter((x)=>x.o).reduce((a,b)=>!a||b.o>a.o?b:a,null);return{xs,maior:m};};
const qj=buscaJog.trim().toLowerCase();
const jogadores=useMemo(()=>{if(!pm)return[];const pj=new Map();for(const r of pm.rows){if(!Object.keys(r.cells||{}).length)continue;const g=pj.get(r.playerKey)||{key:r.playerKey,player:r.player,linhas:new Map()};const lk=r.line==null?'':String(r.line);const ln=g.linhas.get(lk)||{line:r.line,rows:[]};ln.rows.push(r);g.linhas.set(lk,ln);pj.set(r.playerKey,g);}
const ordS={over:0,yes:0,under:1,no:2};
return[...pj.values()].map((g)=>{const ls=[...g.linhas.values()].map((l)=>({...l,rows:l.rows.sort((a,b)=>(ordS[a.side]??9)-(ordS[b.side]??9)),n:new Set(l.rows.flatMap((r)=>Object.keys(r.cells))).size}));
const principal=ls.slice().sort((a,b)=>b.n-a.n||Math.abs(((a.rows[0]||{}).best||{}).odds-2)-Math.abs(((b.rows[0]||{}).best||{}).odds-2))[0];
return{...g,principal,todas:ls.sort((a,b)=>(a.line??-1)-(b.line??-1)),nAlt:ls.length-1,n:principal?principal.n:0};}).sort((a,b)=>b.n-a.n||String(a.player).localeCompare(String(b.player),'pt-BR'));},[pm]);
const jogF=jogadores.filter((g)=>!qj||String(g.player).toLowerCase().includes(qj));
const nAltP=jogF.reduce((s,g)=>s+g.nAlt,0);
const linhasP=jogF.slice(0,nJog).flatMap((g)=>(altP?g.todas:[g.principal]).map((l)=>({g,l,principal:l===g.principal})));
const melhoresP=new Map();for(const{l}of linhasP)for(const r of l.rows)if(r.best&&r.best.col)melhoresP.set(r.best.col,(melhoresP.get(r.best.col)||0)+1);
const booksPm=pm&&det.props?osOrdenaCasas(det.props.books.filter((b)=>linhasP.some(({l})=>l.rows.some((r)=>r.cells[b.key]))),(b)=>b.book,favs,ordemCasas,melhoresP):[];
const abre=(u)=>{if(u)window.open(u,'_blank','noopener');};
const ladoP=(r)=>r.side==='over'?'Mais de '+osLinhaTxt(r.line):r.side==='under'?'Menos de '+osLinhaTxt(r.line):r.side==='yes'?'Sim':'Não';
return React.createElement("div",{className:"os-det"},
React.createElement("style",null,`.os-det .os-tab tr.alt-ini td{border-top:1px solid var(--line-2,#d8dde3)}.os-det .os-tab tr.principal td.os-sel{font-weight:600}.os-det .os-tab td.lin{color:var(--ink-2);font-size:12px}.os-det .os-barra{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:8px 0}.os-det .os-rot{min-width:74px}`),
React.createElement("button",{className:"btn-sm",onClick:onVoltar,style:{marginBottom:10}},"← Voltar para a grade"),
carregando&&!det&&React.createElement("div",{className:"os-vazio"},"Carregando o jogo…"),
det&&det.erro&&React.createElement("div",{className:"os-vazio"},"Não carregou o jogo: ",det.erro),
det&&det.jogo&&React.createElement(React.Fragment,null,
React.createElement("h2",null,det.jogo.casa," x ",det.jogo.fora),
React.createElement("div",{className:"os-sub"},det.jogo.liga||'',det.jogo.liga?' · ':'',new Date(det.jogo.kickoff).toLocaleString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})," · ",fmtFalta(det.jogo.kickoff),det.jogo.kickoffCadastro&&React.createElement("span",{title:"Hora confirmada pela Pinnacle. O cadastro do jogo guarda outra hora (a primeira que a Pinnacle publicou); ela não é trocada sozinha.",style:{color:'var(--amber-deep)'}}," · pela Pinnacle; no cadastro: ",new Date(det.jogo.kickoffCadastro).toLocaleString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}))),
!cats.length&&React.createElement("div",{className:"os-vazio"},"Nenhuma casa com odd fresca neste jogo agora."),
cats.length>0&&React.createElement("div",{className:"os-barra"},React.createElement("span",{className:"os-rot"},"Categoria"),cats.map(([k,l])=>React.createElement("button",{key:k,className:'os-chip'+(catAt===k?' on':''),onClick:()=>{setCat(k);setMkSel(null);setPerSel(null);setAlt(false);}},l))),
catAt&&catAt!=='props'&&React.createElement(React.Fragment,null,
React.createElement("div",{className:"os-barra"},React.createElement("span",{className:"os-rot"},"Mercado"),doCat.map((c)=>React.createElement("button",{key:c.mercado,className:'os-chip'+(mkAt&&mkAt.mercado===c.mercado?' on':''),onClick:()=>{setMkSel(c.mercado);setPerSel(null);setAlt(false);}},c.nome))),
partes.length>1&&React.createElement("div",{className:"os-barra"},React.createElement("span",{className:"os-rot"},"Parte"),partes.map(([p,n])=>React.createElement("button",{key:p,className:'os-chip'+(perAt===p?' on':''),onClick:()=>{setPerSel(p);setAlt(false);}},n))),
mostrar.length>0&&React.createElement("div",{className:"tbl-wrap"},React.createElement("table",{className:"os-tab"},React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",{className:"os-sel"},"Seleção"),React.createElement("th",null,"Justa"),React.createElement("th",null,"Melhor"),cols.map((c)=>React.createElement("th",{key:c.key,className:c.sharp?'os-sharp':''},c.nome,c.taxaNaoConferida&&React.createElement("span",{title:"Taxa da documentação, ainda não lida nem medida — decisão do Matheus, 04/11",style:{display:'block',fontSize:9.5,fontWeight:700,color:'#8a6110',background:'#FFF4D6',border:'1px solid #F3D9A9',borderRadius:5,padding:'0 4px',marginTop:2}},"taxa não conferida"),React.createElement(ObsAlerta,{casas:[c.nome,String(c.key||'')],mercado:mkAt.mercado,esporte:det.jogo.esporte,periodo:perAt}))))),React.createElement("tbody",null,
mostrar.map(({m,principal},bi)=>m.lados.map((l,i)=>React.createElement("tr",{key:m.titulo+'|'+l.lado,className:(i===0&&bi>0?'alt-ini ':'')+(alt&&principal?'principal':'')},
React.createElement("td",{className:"os-sel"},l.rotulo,alt&&principal&&i===0&&React.createElement("span",{className:"os-sub"}," · principal")),
React.createElement("td",{className:"os-justa"},osOdd(l.justa),React.createElement(OsJustaCasas,{l:l}),React.createElement(EqOrigem,{o:l.justaOrigem,cls:"os-sub"}),l.justaCalculada&&React.createElement("div",{className:"os-sub",title:"A Pinnacle não tem esta linha: a justa sai exata das duas linhas vizinhas dela (meias), como no EV+."},"calculada de ",l.justaCalculada)),
React.createElement("td",null,l.melhor?React.createElement("span",null,React.createElement("b",null,osOdd(l.melhor.odd)),l.ev!=null&&React.createElement("div",{className:l.ev>0?'os-ev':'os-sub'},osPct(l.ev))):'—'),
cols.map((c)=>{const o=l.odds[c.key];if(!o)return React.createElement("td",{key:c.key},"—");const best=l.melhor&&l.melhor.fonte===c.key;const jc=osJustaDe(l,c.key);const valor=jc&&o.odd>jc;const velhaPin=c.key==='pinnacle'&&o.idade_s>180;return React.createElement("td",{key:c.key,className:'os-od'+(best?' os-best':'')+(valor?' os-valor':''),style:velhaPin?{background:'#fff4e0',color:'#7a4d00'}:undefined,title:(velhaPin?'⚠ Pinnacle sem atualizar há mais de 3 min · ':'')+(o.tamanho!=null?'disponível a esta odd: '+fmtUsd(o.tamanho)+' (taxa já descontada) · ':'')+'visto há '+fmtIdade(o.idade_s)+(o.url?' · clique para abrir a casa':'')+(jc!==l.justa&&jc?' · justa desta casa (50/50) '+osOdd(jc)+': EV '+osPct((o.odd/jc-1)*100):''),onClick:()=>abre(o.url)},osOdd(o.odd),o.tipoOdd==='maker'&&React.createElement("div",{className:"os-tam",title:'Odd de quem oferece (ordem parada na Limitless, sem taxa): a casa só paga se alguém tomar a ordem. Postar a '+String(o.maker&&o.maker.preco).replace('.',',')+' (um tick melhor que o livro; SIM: ask '+String(o.maker&&o.maker.ask).replace('.',',')+' · bid '+String(o.maker&&o.maker.bid).replace('.',',')+')'},"ordem parada"),o.tamanho!=null&&React.createElement("div",{className:"os-tam"},fmtUsd(o.tamanho)),jc!==l.justa&&jc&&React.createElement("div",{className:"os-tam"},"justa ",osOdd(jc)));})
)))))),
nAlt>0&&React.createElement("button",{className:"btn-sm",style:{marginTop:8},onClick:()=>setAlt((v)=>!v)},alt?'Só a linha principal':'Linhas alternativas ('+nAlt+')')
),
catAt==='props'&&React.createElement(React.Fragment,null,
React.createElement("div",{className:"os-barra"},React.createElement("span",{className:"os-rot"},"Mercado"),propsMk.map((m)=>React.createElement("button",{key:m.market,className:'os-chip'+(pm&&pm.market===m.market?' on':''),onClick:()=>{setMkProp(m.market);setAltP(false);setNJog(60);}},m.label))),
React.createElement("div",{className:"os-barra"},React.createElement("input",{id:"os-buscajog",type:"text",placeholder:"Buscar jogador…",value:buscaJog,onChange:(e)=>{setBuscaJog(e.target.value);setNJog(60);},style:{flex:'0 1 240px'}}),
nAltP>0&&React.createElement("button",{className:"btn-sm",onClick:()=>setAltP((v)=>!v)},altP?'Só a linha principal':'Linhas alternativas ('+nAltP+')'),
React.createElement("span",{className:"os-sub"},jogF.length," jogador(es) · justa = ",tiposJ.length>1?'a maior entre '+tiposJ.map((k)=>NOME_JUSTA[k]||k).join(', '):(NOME_JUSTA[tiposJ[0]]||tiposJ[0])+' sem a margem')),
pm&&linhasP.length>0&&React.createElement("div",{className:"tbl-wrap"},React.createElement("table",{className:"os-tab"},React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",{className:"os-sel"},"Jogador"),React.createElement("th",null,"Linha"),colunasJ.map((k)=>React.createElement("th",{key:k,title:'Justa pela '+(NOME_JUSTA[k]||k)},NOME_JUSTA[k]||k,React.createElement("div",{className:"os-tam"},"justa"))),React.createElement("th",{title:tiposJ.length>1?'A maior das justas ao lado':'Sem a margem, na mesma linha do mesmo jogador'},"Justa"),React.createElement("th",{title:"A maior odd entre as casas (verde quando passa da justa)"},"Melhor"),booksPm.map((b)=>React.createElement("th",{key:b.key},b.book,React.createElement(ObsAlerta,{casas:[b.book,String(b.source||''),String(b.key||'').split('|')[0]],mercado:pm.market,esporte:det.jogo.esporte}))))),React.createElement("tbody",null,
linhasP.map(({g,l,principal},bi)=>l.rows.map((r,i)=>{const jp=justaProp(r);return React.createElement("tr",{key:r.key,className:(i===0&&bi>0?'alt-ini ':'')+(altP&&principal?'principal':'')},
React.createElement("td",{className:"os-sel"},i===0?g.player:'',altP&&principal&&i===0&&React.createElement("span",{className:"os-sub"}," · principal")),React.createElement("td",{className:"lin"},ladoP(r)),
colunasJ.length>0&&jp.xs.map((x)=>React.createElement("td",{key:x.n,className:"os-justa"},osOdd(x.o))),React.createElement("td",{className:"os-justa",style:{color:'inherit'}},osOdd(jp.maior&&jp.maior.o)),
(()=>{let m=null;for(const b of booksPm){const c=r.cells[b.key];if(c&&(!m||c.odds>m.odd))m={odd:c.odds,casa:b.book,u:c.url||c.link};}if(!m)return React.createElement("td",null,"—");const ev=jp.maior?(m.odd/jp.maior.o-1)*100:null;
return React.createElement("td",{className:'os-od'+(ev!=null&&ev>0?' os-best':''),style:{cursor:m.u?'pointer':undefined},title:m.casa+(ev!=null?' · EV '+osPct(ev):''),onClick:()=>abre(m.u)},React.createElement("b",null,osOdd(m.odd)),React.createElement("div",{className:"os-tam"},m.casa,ev!=null?' · '+osPct(ev):''));})(),
booksPm.map((b)=>{const c=r.cells[b.key];if(!c)return React.createElement("td",{key:b.key},"—");const best=r.best&&r.best.col===b.key;const valor=jp.maior&&c.odds>jp.maior.o;const u=c.url||c.link;return React.createElement("td",{key:b.key,className:'os-od'+(best?' os-best':'')+(valor?' os-valor':''),title:b.book+(c.tamanho!=null?' · disponível a esta odd: '+fmtUsd(c.tamanho)+' (taxa já descontada)':'')+(u?' · clique para abrir a casa':''),onClick:()=>abre(u)},osOdd(c.odds),c.molde&&React.createElement(ObsAlerta,{casas:[b.book,String(b.source||''),String(b.key||'').split('|')[0]],mercado:pm.market,esporte:det.jogo.esporte,lado:window.LiqEfeito?window.LiqEfeito.ladoDeProp(r.side):undefined,molde:c.molde}),c.tamanho!=null&&React.createElement("div",{className:"os-tam"},fmtUsd(c.tamanho)));})
);}))))),
jogF.length>nJog&&React.createElement("button",{className:"btn-sm",style:{marginTop:8},onClick:()=>setNJog((n)=>n+60)},"Mostrar mais jogadores (",jogF.length-nJog,")")
)
)
);
}


const OS_CSS=`
      .os-tela2{display:grid;gap:10px;grid-template-columns:minmax(0,1fr);min-width:0}
      /* [11/11] minmax(0,1fr): sem isto a faixa rolável dos botões alargava o grid até a largura de todos eles e a tela passava da janela */
      .os-filtros{display:grid;gap:6px;padding:8px 12px;border:1px solid var(--line-2,#d8dde3);border-radius:12px;background:var(--card,#fff)}
      /* [11/11] os filtros NÃO grudam no topo: grudados, cobriam o cabeçalho da tabela (a linha com os nomes das casas) ao rolar a página */
      .os-linha{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
      .os-rot{font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--ink-2);margin-right:4px;min-width:62px}
      .os-chip{display:inline-flex;align-items:center;gap:5px;padding:5px 10px;border-radius:999px;border:1px solid var(--line-2,#d8dde3);background:none;cursor:pointer;font-size:12.5px;font-weight:600;color:var(--ink-2);font-family:var(--f-body)}
      .os-chip .n{font-weight:500;opacity:.7;font-variant-numeric:tabular-nums}
      .os-chip.on{background:var(--navy-900,#0d2a45);border-color:var(--navy-900,#0d2a45);color:#fff}
      .os-chip:focus-visible{outline:2px solid var(--teal,#1c9b6d);outline-offset:2px}
      .os-chip .material-symbols-outlined{font-size:16px}
      .os-casas{position:relative}
      .os-pop{position:absolute;right:0;top:calc(100% + 6px);z-index:20;background:var(--card,#fff);border:1px solid var(--line-2,#d8dde3);border-radius:10px;box-shadow:0 8px 24px rgba(0,40,75,.14);padding:10px;width:280px;max-height:60vh;overflow:auto;display:grid;gap:4px}
      .os-pop label{display:flex;gap:6px;align-items:center;font-size:13px}
      /* [11/11] a tabela rola por dentro com quase a altura da janela: o cabeçalho (casas) gruda no topo dela e a coluna do jogo à esquerda */
      .os-grade-wrap{overflow:auto;max-height:calc(100vh - 32px);border:1px solid var(--line-2,#d8dde3);border-radius:12px;background:var(--card,#fff);scroll-margin-top:8px}
      .os-grade{border-collapse:separate;border-spacing:0;font-size:13px;min-width:100%}
      .os-grade th{position:sticky;top:0;z-index:3;background:var(--card,#fff);font-size:11px;font-weight:600;color:var(--ink-2);padding:6px 8px;border-bottom:1px solid var(--line-2,#d8dde3);white-space:nowrap;text-align:center}
      .os-grade th .logo{height:16px;max-width:64px;object-fit:contain;display:block;margin:0 auto 2px}
      .os-grade td{padding:5px 8px;text-align:center;border-bottom:1px solid color-mix(in srgb,var(--line-2,#d8dde3) 60%,transparent);font-variant-numeric:tabular-nums;white-space:nowrap}
      .os-grade .fx{position:sticky;background:var(--card,#fff);z-index:2;text-align:left}
      .os-grade th.fx{z-index:4}
      /* [11/11] largura FIXA das colunas grudadas: com mín. 200 e máx. 240, o jogo crescia e a coluna seguinte (presa em 200 px) cobria parte dele */
      .os-grade .fx{box-sizing:border-box}
      .os-grade .c-jogo{left:0;width:220px;min-width:220px;max-width:220px;white-space:normal;cursor:pointer}
      .os-grade .c-sel{left:220px;width:150px;min-width:150px;max-width:150px;white-space:normal}
      .os-grade .c-justa{left:370px;width:64px;min-width:64px;max-width:64px;text-align:center;color:var(--ink-2);font-weight:600}
      .os-grade .c-melhor{left:434px;width:104px;min-width:104px;max-width:104px;text-align:center;box-shadow:inset -1px 0 0 var(--line-2,#d8dde3)}
      .os-grade th .fav{color:#c98a00;font-size:11px;margin-right:2px}
      .os-pop .fav-bt{border:none;background:none;cursor:pointer;font-size:15px;line-height:1;padding:0 2px;color:#b9c0c8}
      .os-pop .fav-bt.on{color:#c98a00}
      .os-faixa-l{flex-wrap:nowrap;min-width:0}
      .os-faixa-l>.os-chip{flex:0 0 auto;white-space:nowrap}
      .os-filtros{grid-template-columns:minmax(0,1fr);min-width:0}
      .os-faixa{position:relative;flex:1 1 auto;min-width:0;display:flex;align-items:center}
      .os-faixa-in{display:flex;gap:6px;overflow-x:auto;scrollbar-width:thin;padding:2px 0;min-width:0;flex:1 1 auto}
      .os-faixa-in .os-chip{flex:0 0 auto;white-space:nowrap}
      .os-seta{position:absolute;top:50%;transform:translateY(-50%);left:-2px;z-index:2;width:26px;height:26px;border-radius:50%;border:1px solid var(--line-2,#d8dde3);background:var(--card,#fff);box-shadow:0 2px 6px rgba(0,40,75,.18);cursor:pointer;font-size:16px;line-height:1;color:var(--ink-2)}
      .os-seta.dir{left:auto;right:-2px}
      @media (max-width:900px){.os-grade .fx{position:static}}
      .os-grade tr.dia td{background:color-mix(in srgb,var(--ink-2) 6%,var(--card,#fff));font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--ink-2);text-align:left;font-weight:600}
      .os-grade td.c-jogo:hover .tm{text-decoration:underline}
      .os-grade .tm{font-weight:600;line-height:1.25}
      .os-grade .lg{font-size:11px;color:var(--ink-2)}
      .os-grade .hr{font-size:11.5px;color:var(--ink-2);font-variant-numeric:tabular-nums}
      .os-grade .bloco-fim td{border-bottom:1px solid var(--line-2,#d8dde3)}
      .os-grade td.od{cursor:pointer}
      .os-grade td.od:hover{outline:1px solid var(--teal,#1c9b6d);outline-offset:-1px}
      .os-grade td.best{background:color-mix(in srgb,#1c6b52 18%,transparent);font-weight:700}
      .os-grade td.valor{box-shadow:inset 0 -2px 0 #1c9b6d}
      .os-grade .mel-odd{font-weight:700;font-size:14px}
      .os-grade .mel-casa{font-size:10.5px;color:var(--ink-2);max-width:96px;overflow:hidden;text-overflow:ellipsis}
      .os-grade .ev-pos{color:#1c6b52;font-weight:700;font-size:11px}
      .os-grade .ev-neg{color:var(--ink-2);font-size:11px}
      .os-grade select{font-size:12px;padding:1px 4px;max-width:120px}
      .os-vazio{padding:24px;color:var(--ink-2);font-size:13px}
      .os-det h2{margin:0 0 2px;font-size:20px}
      .os-sub{font-size:12px;color:var(--ink-2)}
      .os-chips{display:flex;flex-wrap:wrap;gap:6px;margin:12px 0}
      .os-mk{margin-bottom:14px}
      .os-mk h3{font-size:13px;margin:0 0 6px;font-weight:600}
      .os-tab{border-collapse:collapse;font-size:13px;width:auto}
      .os-det{min-width:0}
      .os-det .tbl-wrap{max-width:100%;overflow-x:auto}
      .os-tab th{font-size:11px;font-weight:600;color:var(--ink-2);text-align:center;padding:4px 8px;white-space:nowrap;border-bottom:1px solid var(--line-2,#d8dde3)}
      .os-tab th.os-sel,.os-tab td.os-sel{text-align:left;position:sticky;left:0;background:var(--card,#fff);z-index:1;min-width:170px;max-width:280px;white-space:normal}
      .os-tab td{padding:5px 8px;text-align:center;border-bottom:1px solid color-mix(in srgb,var(--line-2,#d8dde3) 60%,transparent);font-variant-numeric:tabular-nums;white-space:nowrap}
      .os-tab td.os-od{cursor:pointer;border-radius:4px}
      .os-tab .os-tam{font-size:10px;font-weight:400;color:var(--ink-2);line-height:1.1}
      .os-tab td.os-od:hover{outline:1px solid #1c6b52}
      .os-tab td.os-best{background:color-mix(in srgb,#1c6b52 20%,transparent);font-weight:700}
      .os-tab td.os-valor{box-shadow:inset 0 -2px 0 #1c9b6d}
      .os-tab td.os-justa{color:var(--ink-2);font-weight:600}
      .os-tab th.os-sharp{color:#1c6b52}
      .os-ev{font-size:11px;font-weight:700;color:#1c6b52}
      .os-carga{height:3px;border-radius:2px;background:linear-gradient(90deg,transparent,var(--teal,#1c9b6d),transparent);background-size:200% 100%;animation:osCarga 1s linear infinite}
      @keyframes osCarga{from{background-position:200% 0}to{background-position:-200% 0}}
      @media (prefers-reduced-motion:reduce){.os-carga{animation:none}}
      .os-grade-wrap.velha{opacity:.55;transition:opacity .15s}
`;

const osCacheGrade=new Map();


let __atrasoFontes={em:0,d:null};
function useAtrasosFontes(){const[d,setD]=useState(__atrasoFontes.d);useEffect(()=>{let vivo=true;const le=()=>leJson('/api/fontes/atraso').then((j)=>{if(j&&vivo){__atrasoFontes={em:Date.now(),d:j};setD(j);}}).catch((e)=>console.error('[atraso das fontes] leitura:',e.message));if(!__atrasoFontes.d||Date.now()-__atrasoFontes.em>60000)le();else setD(__atrasoFontes.d);const t=setInterval(le,60000);return()=>{vivo=false;clearInterval(t);};},[]);return d;}
function atrasoDasFontes(at,fontes){if(!at||!at.fontes)return null;let m=null;for(const f of fontes||[]){const x=at.fontes[String(f||'').replace(/^so:/,'')];if(x&&x.p50S>(at.limiteS||60)&&(!m||x.p50S>m.p50S))m=x;}return m;}
function SeloAtraso({a}){if(!a)return null;const min=Math.max(1,Math.round(a.p50S/60));return React.createElement("span",{title:'O preço desta casa chega com ~'+min+' min de atraso: medido mensagem a mensagem (p50 '+a.p50S+' s'+(a.via?', pela rota '+a.via:'')+'). A idade na tela é a da chegada; o preço é de ~'+min+' min antes',style:{fontSize:10.5,fontWeight:700,color:'#8a6110',background:'#FFF4D6',border:'1px solid #F3D9A9',borderRadius:6,padding:'0 5px',marginLeft:4,whiteSpace:'nowrap'}},"preço com ~",min," min de atraso");}
function OddsScreenTab(){
const[horas,setHoras]=useState(()=>osLer('horas',24));
const[esporte,setEsporte]=useState(()=>osLer('esporte',''));
const[liga,setLiga]=useState(()=>osLer('liga',''));
const[mk,setMk]=useState(()=>osLer('mk',{tipo:'jogo',mercado:'',periodo:'jogo'}));
const[ocultas,setOcultas]=useState(()=>new Set(osLer('ocultas',[])));
const[soBR,setSoBR]=useState(()=>osLer('soBR',false));
const[soValor,setSoValor]=useState(false);
const[ordem,setOrdem]=useState(()=>osLer('ordem','hora'));
const[busca,setBusca]=useState('');
const[painelCasas,setPainelCasas]=useState(false);
const atrasos=useAtrasosFontes();
const[linhaSel,setLinhaSel]=useState({});
const[linhaG,setLinhaG]=useState('');
const[favs,setFavs]=useState(()=>new Set(osLer('favs',[])));
const[ordemCasas,setOrdemCasas]=useState(()=>osLer('ordemCasas','alfa'));
const[d,setD]=useState(null),[erro,setErro]=useState(null),[carregando,setCarregando]=useState(false);

const[selRota,setSelRota]=useRota('ev','');
const sel=Number(selRota)||null;
useEffect(()=>{osGrava('horas',horas);osGrava('esporte',esporte);osGrava('liga',liga);osGrava('mk',mk);osGrava('ocultas',[...ocultas]);osGrava('soBR',soBR);osGrava('ordem',ordem);osGrava('favs',[...favs]);osGrava('ordemCasas',ordemCasas);},[horas,esporte,liga,mk,ocultas,soBR,ordem,favs,ordemCasas]);
const pedido=useRef(null);
const versaoGrade=useRef({qs:null,l:null,ate:0,x:null});
const[limite,setLimite]=useState(120);
const carrega=async(quieto)=>{const qs=new URLSearchParams({horas,tipo:mk.tipo,...(esporte?{esporte}:{}),...(liga?{liga}:{}),...(mk.mercado?{mercado:mk.mercado}:{}),...(mk.tipo==='jogo'&&mk.periodo!=null?{periodo:mk.periodo}:{})}).toString();
const c=osCacheGrade.get(qs);if(c&&!quieto){setD(c.x);setErro(null);if(Date.now()-c.em<20000)return;}


if(quieto&&pedido.current&&!pedido.current.feito)return;
if(pedido.current)pedido.current.abort();const ac=new AbortController();pedido.current=ac;
if(!quieto)setCarregando(true);


const b=versaoGrade.current;
const vq=quieto&&b.qs===qs&&b.l&&b.x?'&l='+encodeURIComponent(b.l)+'&desde='+b.ate:'';
try{const r=await fetch('/api/odds-screen/grade?'+qs+vq,{credentials:'include',signal:ac.signal});let x=await r.json();if(!r.ok)throw new Error(x.error||'erro');
if(x.mesma)return;
if(x.delta){
const base=b.x,m=new Map((base.jogos||[]).map((g)=>[g.evento+'|'+(g.participante??''),g]));
for(const k of x.del||[])m.delete(k);
for(const g of x.linhas||[])m.set(g.evento+'|'+(g.participante??''),g);
const jogos=[...m.values()].sort((a,c)=>a.jogo.kickoff-c.jogo.kickoff||a.evento-c.evento||String(a.jogador??a.participante).localeCompare(String(c.jogador??c.participante),'pt-BR'));
const meta={};for(const k of['esportes','ligas','mercados','escolhido','casas','cortado'])if(k in x)meta[k]=x[k];
x={...base,...meta,jogos,tempos:x.tempos||base.tempos,l:x.l,ate:x.ate};
}
versaoGrade.current={qs,l:x.l||null,ate:x.ate||0,x};
osCacheGrade.set(qs,{x,em:Date.now()});if(osCacheGrade.size>40)osCacheGrade.delete(osCacheGrade.keys().next().value);
if(pedido.current===ac){setD(x);setErro(null);}}
catch(e){if(e.name!=='AbortError'&&pedido.current===ac)setErro(e.message);}finally{ac.feito=true;if(pedido.current===ac)setCarregando(false);}};
useEffect(()=>{if(sel)return;setLimite(120);carrega();const i=setInterval(()=>{if(!document.hidden)carrega(true);},5000);return()=>{clearInterval(i);if(pedido.current)pedido.current.abort();};},[horas,esporte,liga,mk.tipo,mk.mercado,mk.periodo,sel]);
if(sel)return React.createElement("div",{className:"os-tela"},React.createElement("style",null,OS_CSS),React.createElement(OsJogoDetalhe,{evento:sel,onVoltar:()=>setSelRota(''),favs:favs,ordemCasas:ordemCasas}));
const esc=d&&d.escolhido;
const casas=(d&&d.casas||[]).filter((c)=>!ocultas.has(c.key)&&(!soBR||c.br||c.sharp));
const q=busca.trim().toLowerCase();
const mkJogo=(d&&d.mercados||[]).filter((m)=>m.tipo==='jogo'),mkProps=(d&&d.mercados||[]).filter((m)=>m.tipo==='props');

const porMercado=new Map();for(const m of mkJogo){const g=porMercado.get(m.mercado)||{mercado:m.mercado,nome:m.nome,jogos:0,periodos:[]};g.periodos.push(m);g.jogos=Math.max(g.jogos,m.jogos);porMercado.set(m.mercado,g);}
const gruposMk=[...porMercado.values()];


const todosMk=[...OS_PRINCIPAIS.map((c)=>porMercado.get(c)).filter(Boolean),...gruposMk.filter((g)=>!OS_PRINCIPAIS.includes(g.mercado)).sort((a,b)=>b.jogos-a.jogos)];

const ativo=(tipo,mercado)=>mk.mercado?mk.tipo===tipo&&mk.mercado===mercado:esc&&esc.tipo===tipo&&esc.mercado===mercado;
const partePedida=(p)=>mk.mercado&&mk.periodo!=null?mk.periodo===p.periodo:esc&&esc.periodo===p.periodo;
const escMk=esc&&esc.tipo==='jogo'?porMercado.get(esc.mercado):null;
const escolhe=(tipo,mercado,periodo)=>{setMk({tipo,mercado,periodo:periodo??'jogo'});setLinhaSel({});setLinhaG('');};



const propsOrd=mkProps.slice().sort((a,b)=>b.jogos-a.jogos);
const mkPeriodoPadrao=(g)=>(g.periodos.find((p)=>p.periodo==='jogo')||g.periodos.find((p)=>p.periodo==='jogo_pr')||g.periodos[0]).periodo;

const linhasG=esc&&esc.tipo==='props'?(()=>{const c=new Map();for(const e of d.jogos||[])for(const l of e.linhas)if(l.linha!=null)c.set(l.linha,(c.get(l.linha)||0)+1);return[...c].sort((a,b)=>a[0]-b[0]);})():[];
const linhaGOk=linhaG!==''&&linhasG.some(([v])=>String(v)===String(linhaG))?linhaG:'';
let semALinha=0;

const entradas=(d&&d.jogos||[]).map((e)=>{const k=e.evento+'|'+e.participante;let idx;
if(linhaGOk!==''){idx=e.linhas.findIndex((l)=>String(l.linha)===String(linhaGOk));if(idx<0){semALinha++;return null;}}else idx=Math.min(linhaSel[k]??(e.principal||0),e.linhas.length-1);
const lin=e.linhas[idx];
const lados=lin.lados.map((l)=>{let melhor=null;for(const c of casas){const o=l.odds[c.key];if(o&&(!melhor||o.odd>melhor.odd))melhor={key:c.key,odd:o.odd,url:o.url};}const jm=melhor?osJustaDe(l,melhor.key):null;const ev=jm&&melhor?(melhor.odd/jm-1)*100:null;return{...l,melhor,ev};});
const evMax=Math.max(-999,...lados.map((l)=>l.ev??-999));return{e,k,idx,lin,lados,evMax};}).
filter(Boolean).filter((x)=>x.lados.some((l)=>l.melhor)&&(!q||(x.e.jogo.casa+' '+x.e.jogo.fora+' '+(x.e.jogo.liga||'')+' '+(x.e.jogador||'')).toLowerCase().includes(q))&&(!soValor||x.evMax>0));
if(ordem==='ev')entradas.sort((a,b)=>b.evMax-a.evMax);

const melhores=new Map();for(const x of entradas)for(const l of x.lados)if(l.melhor)melhores.set(l.melhor.key,(melhores.get(l.melhor.key)||0)+1);
const casasOrd=osOrdenaCasas(casas,(c)=>c.nome,favs,ordemCasas,melhores);
const trocaFav=(nome)=>{const n=osNomeCasa(nome);const s2=new Set(favs);if(s2.has(n))s2.delete(n);else s2.add(n);setFavs(s2);};
const abre=(u)=>{if(u)window.open(u,'_blank','noopener');};
const nColsFixas=4;
const linhaTxt=(l,e)=>{if(l.linha==null)return'';const v=Number(l.linha);if(esc&&/_handicap$/.test(esc.mercado))return e.jogo.casa+' '+(v>0?'+':'')+String(v).replace('.',',');return esc&&esc.tipo==='props'?osLinhaTxt(v):String(v).replace('.',',');};
let diaAnt=null;
return React.createElement("div",{className:"os-tela2"},
React.createElement(AlertaTaxa,null),
React.createElement("style",null,OS_CSS),
React.createElement("div",{className:"os-filtros"},
React.createElement("div",{className:"os-linha os-faixa-l"},React.createElement("span",{className:"os-rot"},"Esporte"),
React.createElement(OsFaixa,null,React.createElement("button",{className:'os-chip'+(!esporte?' on':''),onClick:()=>{setEsporte('');setLiga('');escolhe(mk.tipo,'',null);}},"Todos"),
(d&&d.esportes||[]).map((x)=>{const[n,ic]=evEsporte(x.esporte);return React.createElement("button",{key:x.esporte,className:'os-chip'+(esporte===x.esporte?' on':''),onClick:()=>{setEsporte(x.esporte);setLiga('');escolhe(mk.tipo,'',null);}},React.createElement(Ic,{n:ic}),n,React.createElement("span",{className:"n"},x.jogos));}))
),
React.createElement("div",{className:"os-linha"},React.createElement("span",{className:"os-rot"},"Liga"),
React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"os-liga",className:"sel",value:liga,onChange:(e)=>{setLiga(e.target.value);setLinhaSel({});}},
React.createElement("option",{value:""},"Todas as ligas"),(d&&d.ligas||[]).map((l)=>React.createElement("option",{key:l.liga,value:l.liga},l.liga," (",l.jogos,")")))),
React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"os-horas",className:"sel",value:horas,onChange:(e)=>setHoras(Number(e.target.value))},OS_HORAS.map(([h,t])=>React.createElement("option",{key:h,value:h},t)))),
React.createElement("input",{id:"os-busca",type:"text",placeholder:mk.tipo==='props'?'Buscar jogador, time ou liga…':'Buscar time ou liga…',value:busca,onChange:(e)=>setBusca(e.target.value),style:{flex:'1 1 180px',minWidth:160}}),
React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"os-ordem",className:"sel",value:ordem,onChange:(e)=>setOrdem(e.target.value)},React.createElement("option",{value:"hora"},"Por horário"),React.createElement("option",{value:"ev"},"Maior EV primeiro"))),
React.createElement("label",{style:{display:'flex',gap:4,alignItems:'center',fontSize:12.5}},React.createElement("input",{id:"os-valor",type:"checkbox",checked:soValor,onChange:(e)=>setSoValor(e.target.checked)})," Só com valor"),
React.createElement("div",{className:"os-casas"},React.createElement("button",{className:"os-chip",onClick:()=>setPainelCasas((v)=>!v),"aria-expanded":painelCasas},React.createElement(Ic,{n:"storefront"}),"Casas ",d?casas.length+'/'+(d.casas||[]).length:''),
painelCasas&&d&&React.createElement("div",{className:"os-pop"},
React.createElement("label",null,React.createElement("input",{id:"os-sobr",type:"checkbox",checked:soBR,onChange:(e)=>setSoBR(e.target.checked)})," Só casas BR (e a Pinnacle)"),
React.createElement("label",{style:{gap:6}},"Ordem das colunas ",React.createElement("select",{id:"os-ordemcasas",className:"sel",value:ordemCasas,onChange:(e)=>setOrdemCasas(e.target.value),style:{fontSize:12.5,padding:'2px 6px'}},React.createElement("option",{value:"alfa"},"Alfabética"),React.createElement("option",{value:"melhor"},"Pela melhor odd"))),
React.createElement("div",{className:"os-sub"},"★ fixa a casa nas primeiras colunas (vale na grade, no jogo e nas props)."),
React.createElement("div",{style:{display:'flex',gap:6,margin:'4px 0'}},React.createElement("button",{className:"btn-sm",onClick:()=>setOcultas(new Set())},"Mostrar todas"),React.createElement("button",{className:"btn-sm",onClick:()=>setOcultas(new Set((d.casas||[]).filter((c)=>!c.sharp).map((c)=>c.key)))},"Esconder todas")),
osOrdenaCasas(d.casas||[],(c)=>c.nome,favs,'alfa',null).map((c)=>React.createElement("label",{key:c.key},React.createElement("button",{type:"button",className:'fav-bt'+(favs.has(osNomeCasa(c.nome))?' on':''),title:favs.has(osNomeCasa(c.nome))?'Tirar das favoritas':'Fixar nas primeiras colunas',"aria-label":'Favorita: '+c.nome,onClick:(ev)=>{ev.preventDefault();trocaFav(c.nome);}},"★"),React.createElement("input",{type:"checkbox",checked:!ocultas.has(c.key),onChange:(e)=>{const s=new Set(ocultas);if(e.target.checked)s.delete(c.key);else s.add(c.key);setOcultas(s);}}),c.nome,c.br&&React.createElement("span",{className:"os-sub"}," · BR")))
)
)
),
React.createElement("div",{className:"os-linha os-faixa-l"},React.createElement("span",{className:"os-rot"},"Mercado"),
mkProps.length>0&&React.createElement("button",{className:'os-chip'+((mk.mercado?mk.tipo==='props':esc&&esc.tipo==='props')?' on':''),onClick:()=>escolhe('props',(propsOrd[0]||{}).mercado||'',null)},React.createElement(Ic,{n:"person"}),"Props de jogador",React.createElement("span",{className:"n"},Math.max(...mkProps.map((m)=>m.jogos)))),
React.createElement(OsFaixa,null,todosMk.map((g)=>React.createElement("button",{key:g.mercado,className:'os-chip'+(ativo('jogo',g.mercado)?' on':''),onClick:()=>escolhe('jogo',g.mercado,mkPeriodoPadrao(g))},g.nome,React.createElement("span",{className:"n"},g.jogos))))
),
esc&&esc.tipo==='jogo'&&escMk&&escMk.periodos.length>1&&React.createElement("div",{className:"os-linha"},React.createElement("span",{className:"os-rot"},"Parte"),
escMk.periodos.map((p)=>React.createElement("button",{key:p.periodo,className:'os-chip'+(partePedida(p)?' on':''),onClick:()=>escolhe('jogo',p.mercado,p.periodo)},p.parte||'Jogo inteiro',React.createElement("span",{className:"n"},p.jogos)))),
esc&&esc.tipo==='props'&&React.createElement("div",{className:"os-linha os-faixa-l"},React.createElement("span",{className:"os-rot"},"Estatística"),
React.createElement(OsFaixa,null,propsOrd.map((p)=>React.createElement("button",{key:p.mercado,className:'os-chip'+(ativo('props',p.mercado)?' on':''),onClick:()=>escolhe('props',p.mercado,null)},p.nome,React.createElement("span",{className:"n"},p.jogos))))),
esc&&esc.tipo==='props'&&linhasG.length>0&&React.createElement("div",{className:"os-linha"},React.createElement("span",{className:"os-rot"},"Linha"),
React.createElement("button",{className:'os-chip'+(linhaGOk===''?' on':''),onClick:()=>setLinhaG(''),title:"A linha mais equilibrada de cada jogador, a mais perto de 50/50 pela justa (troca na própria linha)"},"Principal de cada um"),
linhasG.map(([v,n])=>React.createElement("button",{key:v,className:'os-chip'+(String(linhaGOk)===String(v)?' on':''),onClick:()=>setLinhaG(String(v)),title:'Mais/menos de '+String(v).replace('.',',')+' para todos os jogadores'},osLinhaTxt(v),React.createElement("span",{className:"n"},n))),
linhaGOk!==''&&semALinha>0&&React.createElement("span",{className:"os-sub"},semALinha," jogador(es) sem esta linha ficam de fora"))
),
carregando&&d?React.createElement("div",{className:"os-carga",role:"progressbar","aria-label":"Carregando o mercado"}):React.createElement("div",{style:{height:3}}),
erro&&React.createElement("div",{className:"os-vazio"},"Não carregou: ",erro),
!d&&!erro&&React.createElement("div",{className:"os-vazio"},"Carregando…"),
d&&!entradas.length&&React.createElement("div",{className:"os-vazio"},carregando?'Carregando…':'Nenhum jogo com esses filtros.'),
d&&entradas.length>0&&React.createElement("div",{className:'os-grade-wrap'+(carregando?' velha':'')},React.createElement("table",{className:"os-grade"},React.createElement("thead",null,React.createElement("tr",null,
React.createElement("th",{className:"fx c-jogo"},esc&&esc.tipo==='props'?'Jogador · jogo':'Jogo'),React.createElement("th",{className:"fx c-sel"},esc?esc.nome+(esc.parte?' · '+esc.parte:''):'Seleção'),React.createElement("th",{className:"fx c-justa",title:esc&&esc.tipo==='props'?'A justa do motor do EV (a mesma da tela EV+)':'A justa da seleção, a mesma do EV+ (P6j: a Pinnacle sem margem puxada pelas bolsas). Na Polymarket em e-sports vale a justa com o 50/50, mostrada embaixo e na célula dela'},"Justa"),React.createElement("th",{className:"fx c-melhor"},"Melhor"),
casasOrd.map((c)=>React.createElement("th",{key:c.key,title:c.nome+(c.fontes&&c.fontes.length?' · fontes: '+c.fontes.join(', '):'')+(c.taxaNaoConferida?' — taxa da documentação, ainda não lida nem medida':'')},c.logo&&React.createElement("img",{className:"logo",src:c.logo,alt:"",loading:"lazy"}),favs.has(osNomeCasa(c.nome))&&React.createElement("span",{className:"fav",title:"Favorita"},"★"),c.nome,c.taxaNaoConferida&&React.createElement("div",{style:{fontSize:9.5,fontWeight:700,color:'#8a6110'}},"taxa não conferida"),esc&&React.createElement(ObsAlerta,{casas:[c.nome,...(c.fontes||[]),String(c.key||'').split('|')[0],String(c.key||'').split('|')[1]||''],mercado:esc.mercado,esporte:esporte||(d.jogos||[])[0]&&(d.jogos||[])[0].jogo.esporte,periodo:esc.tipo==='jogo'?esc.periodo:undefined}),React.createElement(SeloAtraso,{a:atrasoDasFontes(atrasos,c.fontes)})))
)),React.createElement("tbody",null,
entradas.slice(0,limite).map((x)=>{const{e,k,idx,lin,lados}=x;const dia=ordem==='hora'?osDia(e.jogo.kickoff):null;const novoDia=dia&&dia!==diaAnt;diaAnt=dia||diaAnt;
return React.createElement(React.Fragment,{key:k},
novoDia&&React.createElement("tr",{className:"dia"},React.createElement("td",{colSpan:nColsFixas+casasOrd.length},dia)),
lados.map((l,i)=>React.createElement("tr",{key:l.lado,className:i===lados.length-1?'bloco-fim':''},
i===0&&React.createElement("td",{className:"fx c-jogo",rowSpan:lados.length,onClick:()=>setSelRota(String(e.evento)),title:"Abrir o jogo inteiro (todos os mercados e as props)"},
e.jogador&&React.createElement("div",{className:"tm"},e.jogador),
React.createElement("div",{className:e.jogador?'lg':'tm'},e.jogo.casa,React.createElement("br",null),e.jogo.fora),
React.createElement("div",{className:"hr"},osHora(e.jogo.kickoff)," · ",fmtFalta(e.jogo.kickoff),e.jogo.liga?' · ':'',React.createElement("span",{className:"lg"},e.jogo.liga||''))),
React.createElement("td",{className:"fx c-sel"},i===0&&e.linhas.length>1?React.createElement("select",{"aria-label":"Linha",value:idx,onChange:(ev)=>setLinhaSel({...linhaSel,[k]:Number(ev.target.value)})},e.linhas.map((ln,j)=>React.createElement("option",{key:j,value:j},linhaTxt(ln,e)||ln.titulo))):null,
React.createElement("div",null,l.rotulo)),
React.createElement("td",{className:"fx c-justa"},osOdd(l.justa),React.createElement(OsJustaCasas,{l:l}),React.createElement(EqOrigem,{o:l.justaOrigem,cls:"os-sub"}),l.justaCalculada&&React.createElement("div",{className:"os-sub",title:"A Pinnacle não tem esta linha: a justa sai exata das duas linhas vizinhas dela (meias), como no EV+."},"calculada de ",l.justaCalculada)),
React.createElement("td",{className:"fx c-melhor"},l.melhor?React.createElement("div",{style:{cursor:'pointer'},onClick:()=>abre(l.melhor.url),title:"Abrir a casa"},React.createElement("div",{className:"mel-odd"},osOdd(l.melhor.odd)),React.createElement("div",{className:"mel-casa"},(casas.find((c)=>c.key===l.melhor.key)||{}).nome),l.ev!=null&&React.createElement("div",{className:l.ev>0?'ev-pos':'ev-neg'},osPct(l.ev))):'—'),
casasOrd.map((c)=>{const o=l.odds[c.key];if(!o)return React.createElement("td",{key:c.key},"—");const best=l.melhor&&l.melhor.key===c.key;const jc=osJustaDe(l,c.key);const valor=jc&&o.odd>jc;
return React.createElement("td",{key:c.key,className:'od'+(best?' best':'')+(valor?' valor':''),onClick:()=>abre(o.url),title:c.nome+(o.tamanho!=null?' · disponível: '+fmtUsd(o.tamanho):'')+(o.idade_s!=null?' · visto há '+fmtIdade(o.idade_s):'')+(o.url?' · clique para abrir a casa':'')+(jc!==l.justa&&jc?' · justa desta casa (50/50) '+osOdd(jc)+': EV '+osPct((o.odd/jc-1)*100):'')},osOdd(o.odd),o.tipoOdd==='maker'&&React.createElement("div",{className:"os-tam",title:'Odd de quem oferece (ordem parada na Limitless, sem taxa): a casa só paga se alguém tomar a ordem. Postar a '+String(o.maker&&o.maker.preco).replace('.',',')+' (um tick melhor que o livro; SIM: ask '+String(o.maker&&o.maker.ask).replace('.',',')+' · bid '+String(o.maker&&o.maker.bid).replace('.',',')+')'},"ordem parada"),o.tamanho!=null&&React.createElement("div",{className:"os-tam"},fmtUsd(o.tamanho)),jc!==l.justa&&jc&&React.createElement("div",{className:"os-tam"},"justa ",osOdd(jc)));})
))
);})
))),
entradas.length>limite&&React.createElement("button",{className:"btn-sm",onClick:()=>setLimite((n)=>n+120)},"Mostrar mais ",Math.min(120,entradas.length-limite)," (de ",entradas.length,")"),
d&&d.cortado&&React.createElement("div",{className:"os-sub"},"Mostrando 1.500 de ",d.cortado," linhas — filtre por esporte ou liga para ver o resto.")
);
}





function AvisoPinnacle({rota='/api/pinnacle/saude'}){
const[s,setS]=useState(null);
useEffect(()=>{let vivo=true;const le=()=>fetch(rota,{credentials:'include'}).then((r)=>r.ok?r.json():null).then((d)=>{if(vivo)setS(d);}).catch(()=>{});
le();const i=setInterval(le,30000);return()=>{vivo=false;clearInterval(i);};},[]);
if(!s||!s.alerta)return null;
const erro=s.nivel==='erro';
return React.createElement("div",{role:"status",style:{display:'flex',gap:8,alignItems:'center',padding:'8px 12px',margin:'0 0 10px',borderRadius:8,fontSize:13,
background:erro?'#fdecea':'#fff4e0',color:erro?'#8c1d18':'#7a4d00',border:'1px solid '+(erro?'#f2b8b5':'#f3d19c')}},
React.createElement(Ic,{n:erro?'error':'schedule'}),React.createElement("span",null,s.alerta));
}



function AvisoPainelEsperando(){
const[n,setN]=useState(0);
useEffect(()=>{const f=(e)=>setN(e.detail&&e.detail.n||0);window.addEventListener('painel-esperando',f);return()=>window.removeEventListener('painel-esperando',f);},[]);
if(!n)return null;
return React.createElement("div",{role:"status",style:{display:'flex',gap:8,alignItems:'center',padding:'8px 12px',margin:'0 0 10px',borderRadius:8,fontSize:13,
background:'#fff4e0',color:'#7a4d00',border:'1px solid #f3d19c'}},
React.createElement(Ic,{n:"sync"}),React.createElement("span",null,"O painel não está respondendo (reiniciando ou sobrecarregado). ",n===1?'1 leitura esperando':n+' leituras esperando'," para tentar de novo sozinha",n===1?'':'s',"; o que está vazio na tela ainda não chegou."));
}





function EvFiltroTab(){
const[d,setD]=useState(null),[erro,setErro]=useState(null),[msg,setMsg]=useState(''),[ed,setEd]=useState(null),[busy,setBusy]=useState(false);
const load=()=>fetch('/api/master/ev-regras',{credentials:'include'}).then(async(r)=>{const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'HTTP '+r.status);setD(x);setErro(null);}).catch((e)=>setErro(e.message));
useEffect(()=>{load();const i=setInterval(load,20000);return()=>clearInterval(i);},[]);
if(erro)return React.createElement("div",{className:"empty",style:{padding:32}},"Não carregou: ",erro);
if(!d)return React.createElement("div",{style:{padding:32,color:'var(--on-surface-variant)'}},"Carregando…");
const nomeFonte=(f)=>((d.fontes||[]).find((x)=>x.fonte===f)||{}).nome||f;
const lst=(v)=>String(v||'').split(',').map((x)=>x.trim()).filter(Boolean);
const TIPOS=[['jogo','Mercados de jogo'],['superodd','Super Odds'],['prop','Props de jogador']];
const recorte=(r)=>[lst(r.classes).length?'classe '+lst(r.classes).join(', '):'',lst(r.produtos).length?'produto '+lst(r.produtos).join(', '):'',lst(r.casas).map(nomeFonte).join(', '),lst(r.esportes).map((e)=>evEsporte(e)[0]).join(', '),lst(r.mercados).join(', '),lst(r.tipos).map((t)=>(TIPOS.find((x)=>x[0]===t)||[t,t])[1]).join(', ')].filter(Boolean).join(' · ')||'—';

const SETAS=[['sobe','↑'],['igual','='],['desce','↓'],['qualquer','qualquer']];
const pv=(c,campo)=>{const v=ed&&ed.params&&ed.params[campo];return v!=null?v:c.padrao;};
const setP=(campo,v)=>setEd({...ed,params:{...(ed.params||{}),[campo]:v}});
const produtosChips=(d.classes||[]).filter((c)=>c.por==='fonte'&&!String(c.chave).startsWith('so:')&&(c.classe==='BOLSA'||c.classe==='AMM'||c.origem==='reserva'));
const pt=(x)=>x==null?'—':(x>0?'+':x<0?'−':'')+Math.abs(x*100).toFixed(1).replace('.',',')+' pt';
const SETA={sobe:'↑',igual:'=',desce:'↓'};

const TX=d.taxasFontes&&d.taxasFontes.fontes||{};
const DE_TAXA={mercado:'de cada mercado',serie:'da série',conta:'da conta',codigo:'fórmula do leitor',odd_fixa:'odd fixa'};
const pctTx=(v)=>v==null?'—':String(Math.round(v*100000)/1000).replace('.',',')+'%';
const haTx=(ms)=>{if(!ms)return'nada lido desde a subida';const s=Math.max(0,Math.round((Date.now()-ms)/1000));return'lida há '+(s<120?s+' s':s<7200?Math.round(s/60)+' min':Math.round(s/3600)+' h');};
const textoTaxa=(t)=>`${pctTx(t.taxa)} · ${DE_TAXA[t.de]||t.de} · ${haTx(t.lidaEm)}`;
const nomeRegra=(id)=>((d.regras||[]).find((r)=>r.id===id)||{}).nome||'#'+id;
const salvar=async()=>{setBusy(true);setMsg('');try{const r=await fetch('/api/master/ev-regras'+(ed.id?'/'+ed.id:''),{method:ed.id?'PUT':'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(ed)});const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'HTTP '+r.status);setMsg('✅ '+(x.msg||'Salvo'));setEd(null);load();}catch(e){setMsg('❌ '+e.message);}finally{setBusy(false);}};
const alterna=async(r)=>{setMsg('');const x=await fetch('/api/master/ev-regras/'+r.id,{method:'PUT',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({...r,ativa:!r.ativa})}).then((x)=>x.json()).catch((e)=>({error:e.message}));setMsg(x.error?'❌ '+x.error:!r.ativa?'✅ Regra ligada':'Regra desligada');load();};
const exclui=async(r)=>{if(!(await confirma(`Excluir a regra "${r.nome}"?`)))return;await fetch('/api/master/ev-regras/'+r.id,{method:'DELETE',credentials:'include'});setMsg('Regra excluída');load();};
const marca=(campo,v)=>{const a=lst(ed[campo]);setEd({...ed,[campo]:(a.includes(v)?a.filter((x)=>x!==v):[...a,v]).join(',')});};
const chip=(campo,v,rot)=>React.createElement("button",{key:v,type:"button",className:'pill'+(lst(ed[campo]).includes(v)?' on':''),style:{cursor:'pointer',border:'1px solid var(--line-2)',background:lst(ed[campo]).includes(v)?'color-mix(in srgb,var(--teal) 18%,transparent)':'transparent'},onClick:()=>marca(campo,v)},rot);
const cond=ed&&d.condicoes[ed.condicao];
return React.createElement("div",{style:{display:'grid',gap:16}},
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement("div",{className:"ev-sub",style:{fontSize:13,maxWidth:820}},"Cada regra pega um ",React.createElement("b",null,"recorte")," (casas, esportes, mercados, tipos) e uma ",React.createElement("b",null,"condição"),". ",React.createElement("b",null,"Ocultar")," tira o EV quando a condição vale; ",React.createElement("b",null,"Só exibir se")," mantém só os EVs em que ela vale. Vale para todos os usuários, na próxima volta do EV+ (até 20 s)."),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center'}},React.createElement("button",{className:"btn-sm b-green",onClick:()=>setEd({nome:'',ativa:true,casas:'',esportes:'',mercados:'',tipos:'',classes:'',produtos:'',params:{},condicao:'sempre',acao:'ocultar'})},"Nova regra"),React.createElement("span",{className:"ev-sub"},d.movimentosAcompanhados," preços acompanhados · histórico de 15 min: ",d.curto?`${d.curto.chaves} seleções, ${d.curto.pontos} pontos, ~${d.curto.kb} KB`:'—',d.curto&&d.curto.banco?` · no banco ${d.curto.banco.linhas??'?'} linhas${d.curto.banco.carregado?` (carregou ${d.curto.banco.pontosCarregados} pontos na subida)`:''}`:'',d.curto&&d.curto.banco&&(d.curto.banco.erroCarga||d.curto.banco.erroGravacao)?React.createElement("b",{style:{color:'#b3261e'}}," · ERRO: ",d.curto.banco.erroCarga||d.curto.banco.erroGravacao):null," · última volta ",d.ultimoTick?new Date(d.ultimoTick).toLocaleTimeString('pt-BR'):'—')),
d.classesStatus&&d.classesStatus.aviso&&React.createElement("div",{className:"toast",style:{background:'color-mix(in srgb,#a35a00 14%,transparent)'}},"⚠ ",d.classesStatus.aviso),
ed&&React.createElement("div",{className:"card",style:{padding:16,border:'1px solid var(--line-2)',borderRadius:12,display:'grid',gap:12}},
React.createElement("label",{style:{display:'grid',gap:4}},"Nome",React.createElement("input",{id:"evr-nome",value:ed.nome,onChange:(e)=>setEd({...ed,nome:e.target.value}),placeholder:"Ex.: Kalshi em eSports só com a Pinnacle mexendo por último"})),
React.createElement("div",{style:{display:'grid',gap:6}},React.createElement("b",{style:{fontSize:13}},"Classe de casa")," ",React.createElement("span",{className:"ev-sub"},"pelo produto no Peixe Admin (só ele, desde 12/11) — o recorte certo para regra de bolsa (SEG-1)"),React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},(d.classesDeCasa||[]).map((c)=>chip('classes',c,(d.rotuloClasse||{})[c]||c)))),
React.createElement("div",{style:{display:'grid',gap:6}},React.createElement("b",{style:{fontSize:13}},"Produto")," ",React.createElement("span",{className:"ev-sub"},"só para regra de um produto específico (ex.: Kalshi)"),React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},produtosChips.map((c)=>chip('produtos',c.chave,`${c.nome} (${c.produto||c.chave})`)))),
React.createElement("div",{style:{display:'grid',gap:6}},React.createElement("b",{style:{fontSize:13}},"Casas")," ",React.createElement("span",{className:"ev-sub"},"pelo nome — evite em regra de bolsa"),React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},(d.fontes||[]).map((f)=>chip('casas',f.fonte,f.nome)))),
React.createElement("div",{style:{display:'grid',gap:6}},React.createElement("b",{style:{fontSize:13}},"Esportes"),React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},(d.esportes||[]).map((e)=>chip('esportes',e,evEsporte(e)[0])))),
React.createElement("div",{style:{display:'grid',gap:6}},React.createElement("b",{style:{fontSize:13}},"Tipos"),React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},TIPOS.map(([v,r])=>chip('tipos',v,r)))),
React.createElement("label",{style:{display:'grid',gap:4}},"Mercados (códigos separados por vírgula; vazio = todos)",React.createElement("input",{id:"evr-mercados",value:ed.mercados,onChange:(e)=>setEd({...ed,mercados:e.target.value}),placeholder:"Ex.: jogo_vencedor, jogo_gols_total"})),
React.createElement("label",{style:{display:'grid',gap:4}},"Condição",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"evr-cond",className:"sel",value:ed.condicao,onChange:(e)=>setEd({...ed,condicao:e.target.value,params:{}})},Object.entries(d.condicoes).map(([k,c])=>React.createElement("option",{key:k,value:k},c.nome))),React.createElement(Ic,{n:"arrow_drop_down"})),cond&&React.createElement("span",{className:"ev-sub"},cond.descricao)),
cond&&cond.params&&cond.params.length>0&&React.createElement("div",{style:{display:'flex',gap:16,flexWrap:'wrap',alignItems:'end'}},cond.params.map((c)=>{const v=pv(c,c.campo);
if(c.tipo==='mov')return React.createElement("div",{key:c.campo,style:{display:'grid',gap:4}},React.createElement("b",{style:{fontSize:13}},c.rotulo),React.createElement("div",{style:{display:'flex',gap:6,alignItems:'center'}},
React.createElement("label",{style:{display:'flex',gap:4,alignItems:'center'}},React.createElement("input",{id:'evr-'+c.campo+'-nao',type:"checkbox",checked:!!(v&&v.nao),onChange:(e)=>setP(c.campo,{...(v||{}),nao:e.target.checked})}),"NÃO"),
SETAS.map(([k,r])=>React.createElement("button",{key:k,type:"button",className:'pill'+(v&&v.valor===k?' on':''),style:{cursor:'pointer',border:'1px solid var(--line-2)',background:v&&v.valor===k?'color-mix(in srgb,var(--teal) 18%,transparent)':'transparent'},onClick:()=>setP(c.campo,{...(v||{}),valor:k})},r))));

if(c.tipo==='lista'){const a=Array.isArray(v)?v:lst(v),ops=c.deFontes?(d.fontes||[]).filter((f)=>!String(f.fonte).startsWith('so:')).map((f)=>[f.fonte,f.nome]):(c.opcoes||[]).map((k)=>[k,(d.rotuloClasse||{})[k]||k]);
return React.createElement("div",{key:c.campo,style:{display:'grid',gap:4,flex:'1 1 100%'}},React.createElement("b",{style:{fontSize:13}},c.rotulo),React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},ops.map(([k,r])=>{const on=a.includes(k);return React.createElement("button",{key:k,type:"button",className:'pill'+(on?' on':''),style:{cursor:'pointer',border:'1px solid var(--line-2)',background:on?'color-mix(in srgb,var(--teal) 18%,transparent)':'transparent'},onClick:()=>setP(c.campo,on?a.filter((x)=>x!==k):[...a,k])},r);})));}
if(c.tipo==='texto')return React.createElement("label",{key:c.campo,style:{display:'grid',gap:4,flex:'1 1 320px'}},c.rotulo,React.createElement("input",{id:'evr-'+c.campo,type:"text",value:v==null?'':v,onChange:(e)=>setP(c.campo,e.target.value),style:{width:'100%'}}));
if(c.tipo==='opcao')return React.createElement("label",{key:c.campo,style:{display:'grid',gap:4}},c.rotulo,React.createElement("div",{className:"sel-wrap"},React.createElement("select",{className:"sel",value:v,onChange:(e)=>setP(c.campo,e.target.value)},c.opcoes.map(([k,r])=>React.createElement("option",{key:k,value:k},r))),React.createElement(Ic,{n:"arrow_drop_down"})));
return React.createElement("label",{key:c.campo,style:{display:'grid',gap:4}},c.rotulo,React.createElement("input",{id:'evr-'+c.campo,type:"number",value:v,min:c.min,max:c.max,step:c.inteiro?1:undefined,onChange:(e)=>setP(c.campo,e.target.value),style:{width:140}}));})),
React.createElement("label",{style:{display:'grid',gap:4}},"Ação",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"evr-acao",className:"sel",value:ed.acao,onChange:(e)=>setEd({...ed,acao:e.target.value})},Object.entries(d.acoes).map(([k,a])=>React.createElement("option",{key:k,value:k},a))),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("label",{style:{display:'flex',gap:8,alignItems:'center'}},React.createElement("input",{id:"evr-ativa",type:"checkbox",checked:!!ed.ativa,onChange:(e)=>setEd({...ed,ativa:e.target.checked})})," Ligada"),
React.createElement("div",{style:{display:'flex',gap:8}},React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:salvar},busy?'Salvando…':'Salvar regra'),React.createElement("button",{className:"btn-sm",onClick:()=>setEd(null)},"Cancelar"))
),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Regra"),React.createElement("th",null,"Recorte"),React.createElement("th",null,"Condição"),React.createElement("th",null,"Ação"),React.createElement("th",null,"Tirando agora"),React.createElement("th",{title:`Seleções distintas que a regra tirou nos últimos ${d.janelaContagemMin||15} min (desde a subida do painel): como 1ª regra (a do motivo) / como qualquer regra que tiraria`},"Últimos ",d.janelaContagemMin||15," min"),React.createElement("th",null))),React.createElement("tbody",null,
(d.regras||[]).map((r)=>React.createElement("tr",{key:r.id,style:r.ativa?undefined:{opacity:.55}},
React.createElement("td",{style:{fontWeight:600}},r.nome,React.createElement("div",{className:"ev-sub"},r.por?'por '+r.por:'')),
React.createElement("td",null,recorte(r)),
React.createElement("td",null,r.condicaoTexto||(d.condicoes[r.condicao]||{}).nome||r.condicao),
React.createElement("td",null,d.acoes[r.acao]||r.acao),
React.createElement("td",{className:"ev-num"},r.ativa?r.barradasAgora:'desligada'),
React.createElement("td",{className:"ev-num"},r.ultimos15?`${r.ultimos15.primeira} / ${r.ultimos15.qualquer}`:'—'),
React.createElement("td",null,React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},React.createElement("button",{className:"btn-sm",onClick:()=>alterna(r)},r.ativa?'Desligar':'Ligar'),React.createElement("button",{className:"btn-sm",onClick:()=>setEd({...r})},"Editar"),React.createElement("button",{className:"btn-sm b-red",onClick:()=>exclui(r)},"Excluir")))
)),
!(d.regras||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:7,className:"ev-sub"},"Nenhuma regra."))
))),
React.createElement("div",null,React.createElement("b",null,"Fora da tela agora")," ",React.createElement("span",{className:"ev-sub"},"(",(d.barradas||[]).length,") — o que as regras tiraram nesta volta, com o motivo")),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Odd"),React.createElement("th",null,"Justa"),React.createElement("th",null,"EV"),React.createElement("th",null,"Regra · motivo"),React.createElement("th",{title:"Auditoria: classe usada, Δ em 15 min (Pinnacle / casa), tempo até o início, limite da Pinnacle e custo aplicado"},"Auditoria"))),React.createElement("tbody",null,
(d.barradas||[]).map((b,i)=>{const a=b.aud||{};return React.createElement("tr",{key:i},React.createElement("td",null,b.jogo),React.createElement("td",null,b.selecao,React.createElement("div",{className:"ev-sub"},b.mercado)),React.createElement("td",null,b.casa),React.createElement("td",{className:"ev-num"},Number(b.odd).toFixed(2)),React.createElement("td",{className:"ev-num"},Number(b.justa).toFixed(2)),React.createElement("td",{className:"ev-num"},"+",Number(b.ev).toFixed(1),"%"),React.createElement("td",null,b.regraNome||nomeRegra(b.regra),React.createElement("div",{className:"ev-sub"},b.motivo),b.regras&&b.regras!==b.regraNome&&React.createElement("div",{className:"ev-sub",title:"As regras se somam (SEG-5): todas estas tirariam"},"também: ",b.regras.split(' | ').filter((x)=>x!==b.regraNome).join(' · '))),
React.createElement("td",{className:"ev-sub"},a.classe||'—',a.produto?' · '+a.produto:'',a.origem==='reserva'?' (reserva)':'',React.createElement("br",null),"Pin ",pt(a.dPin),a.clPin?' '+SETA[a.clPin]:''," · casa ",pt(a.dBolsa),a.clBolsa?' '+SETA[a.clBolsa]:'',a.metodo&&a.metodo!=='meio'?' ('+a.metodo+')':'',React.createElement("br",null),a.faltaMin!=null?`faltam ${a.faltaMin} min`:'',a.limitePin!=null?` · limite US$ ${Number(a.limitePin).toLocaleString('pt-BR')}`:' · sem limite',a.custoPt!=null?` · taxa ${String(a.custoPt).replace('.',',')} pt`:''));}),
!(d.barradas||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:8,className:"ev-sub"},"Nenhum EV fora da tela agora."))
))),
React.createElement("div",null,React.createElement("b",null,"Classe de cada casa")," ",React.createElement("span",{className:"ev-sub"},"— do produto no Peixe Admin; sem produto, OUTRO (não há reserva no código desde 12/11: a casa é achada pelo nome, pela chave ou pelo nome do produto; com o Admin fora na subida vale o último cadastro guardado). Avisos SEG por enquanto só avisam (o robô continua podendo apostar).",d.classesStatus&&d.classesStatus.okEm?` Admin lido às ${new Date(d.classesStatus.okEm).toLocaleTimeString('pt-BR')}.`:'')),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Fonte"),React.createElement("th",null,"Classe"),React.createElement("th",null,"Produto"),React.createElement("th",null,"De onde"),React.createElement("th",{title:"A taxa que o coletor aplicou na odd, lida no ato (o custo não é mais cadastrado no Peixe Admin)"},"Taxa (coletor)"),React.createElement("th",null,"Avisos"))),React.createElement("tbody",null,
(d.classes||[]).filter((c)=>c.por==='fonte').map((c)=>React.createElement("tr",{key:c.chave},React.createElement("td",null,c.nome),React.createElement("td",{className:"ev-sub"},c.chave),React.createElement("td",null,React.createElement("b",null,c.classe)),React.createElement("td",null,c.produto||'—'),React.createElement("td",null,c.origem==='admin'?'Peixe Admin':c.origem==='reserva'?'classe de reserva':'sem cadastro'),React.createElement("td",{className:"ev-sub",title:TX[c.chave]?TX[c.chave].modelo+'\n'+TX[c.chave].fonteOficial:''},TX[c.chave]?textoTaxa(TX[c.chave]):'—'),React.createElement("td",{className:"ev-sub",style:{color:c.avisos&&c.avisos.length?'#a35a00':undefined}},(c.avisos||[]).map((a)=>a.seg+': '+a.texto).join(' · ')||'—')))
))),
React.createElement("div",null,React.createElement("b",null,"Taxa de cada casa")," ",React.createElement("span",{className:"ev-sub"},"— lida no ato pelo coletor, por linha quando a casa informa (o custo não é mais cadastrado no Peixe Admin; a odd do EV+ já vem com esta taxa descontada). ",d.taxasFontes&&d.taxasFontes.em?`Publicada às ${new Date(d.taxasFontes.em).toLocaleTimeString('pt-BR')}.`:'O coletor ainda não publicou (chega no próximo reinício dele); até lá a conta usa a fórmula do leitor, o mesmo número.',d.taxasFontes&&d.taxasFontes.erro?' Erro ao ler: '+d.taxasFontes.erro:'')),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte"),React.createElement("th",null,"Taxa"),React.createElement("th",null,"De onde"),React.createElement("th",null,"Leitura"),React.createElement("th",null,"Modelo"),React.createElement("th",null,"Valores vistos (15 min)"),React.createElement("th",null,"Fonte oficial"))),React.createElement("tbody",null,
Object.entries(TX).sort((a,b)=>a[0].localeCompare(b[0])).map(([f,t])=>React.createElement("tr",{key:f},React.createElement("td",null,nomeFonte(f),React.createElement("div",{className:"ev-sub"},f)),React.createElement("td",{className:"ev-num"},pctTx(t.taxa)),React.createElement("td",null,DE_TAXA[t.de]||t.de),React.createElement("td",{className:"ev-sub"},haTx(t.lidaEm),t.erro?React.createElement("div",{style:{color:'#a35a00'}},t.erro):null),React.createElement("td",{className:"ev-sub"},t.modelo,t.detalhe?React.createElement("div",null,t.detalhe):null),React.createElement("td",{className:"ev-sub"},Object.entries(t.valores||{}).map(([k,n])=>k+': '+n).join(' · ')||'—'),React.createElement("td",{className:"ev-sub"},t.fonteOficial))),
!Object.keys(TX).length&&React.createElement("tr",null,React.createElement("td",{colSpan:7,className:"ev-sub"},"Sem taxa publicada pelo coletor."))
)))
);
}



function EvHistoricoTab(){
const[d,setD]=useState(null),[erro,setErro]=useState(null),[f,setF]=useState({dias:7,casa:'',tipo:'',minEv:'',q:''});
const load=()=>{const qs=new URLSearchParams(Object.entries(f).filter(([,v])=>v!==''&&v!=null)).toString();
fetch('/api/master/ev-historico?'+qs,{credentials:'include'}).then(async(r)=>{const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'HTTP '+r.status);setD(x);setErro(null);}).catch((e)=>setErro(e.message));};
useEffect(()=>{load();const i=setInterval(load,60000);return()=>clearInterval(i);},[f.dias,f.casa,f.tipo,f.minEv,f.q]);
if(erro)return React.createElement("div",{className:"empty",style:{padding:32}},"Não carregou: ",erro);
if(!d)return React.createElement("div",{style:{padding:32,color:'var(--on-surface-variant)'}},"Carregando…");
const TIPOS={jogo:'Mercados de jogo',superodd:'Super Odds',prop:'Props de jogador'};
const pct=(x)=>x==null?'—':Number(x).toFixed(2).replace('.',',')+'%';
const dur=(s)=>s==null?'—':s<60?Math.round(s)+' s':s<3600?Math.round(s/60)+' min':(s/3600).toFixed(1).replace('.',',')+' h';
const hora=(t)=>t?new Date(t*1000).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'—';
const b=d.bancaAgora||{},r=d.resumo||{};
const serie=d.serie||[];
const W=640,Hh=120,P=28;
const maxK=Math.max(1,...serie.map((s)=>s.kelly||0));
const t0=serie.length?serie[0].em:0,t1=serie.length?serie[serie.length-1].em:1;
const x=(t)=>P+(t1>t0?(t-t0)/(t1-t0):0)*(W-P-8),y=(k)=>Hh-18-k/maxK*(Hh-30);
const caminho=serie.map((s,i)=>(i?'L':'M')+x(s.em).toFixed(1)+' '+y(s.kelly).toFixed(1)).join(' ');
const tile=(rot,val,sub)=>React.createElement("div",{style:{padding:'12px 14px',border:'1px solid var(--line-2)',borderRadius:10,minWidth:150,flex:'1 1 150px'}},React.createElement("div",{className:"ev-sub",style:{textTransform:'uppercase',letterSpacing:'.04em',fontSize:11}},rot),React.createElement("div",{style:{fontFamily:'var(--f-data)',fontSize:22,fontWeight:700,fontVariantNumeric:'tabular-nums'}},val),sub&&React.createElement("div",{className:"ev-sub"},sub));
const campo=(k,v)=>setF({...f,[k]:v});
return React.createElement("div",{style:{display:'grid',gap:16}},
React.createElement("div",{className:"ev-sub",style:{fontSize:13,maxWidth:820}},"Cada EV que esteve na tela EV+ vira uma ",React.createElement("b",null,"aparição"),": preço e EV na entrada, no pico e na saída, e quanto tempo ficou. EV que some e volta em até 10 min é a mesma aparição. Guardado por ",d.motor&&d.motor.retencaoDias||30," dias.",d.disco&&React.createElement(React.Fragment,null," Ocupa ",React.createElement("b",null,d.disco.mb!=null?String(d.disco.mb).replace('.',','):'—'," MB")," (",(d.disco.linhas||0).toLocaleString('pt-BR')," linhas); limpeza a cada 6 h",d.motor&&d.motor.limpezaEm?` (última ${new Date(d.motor.limpezaEm).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})})`:'',".")),
d.motor&&d.motor.erro&&React.createElement("div",{className:"toast"},"❌ ",d.motor.erro),
React.createElement("div",{style:{display:'flex',gap:10,flexWrap:'wrap'}},
tile('Banca no ar agora',pct(b.kellyTotal),`¼ Kelly somado · ${b.selecoes||0} seleções (melhor casa de cada)`),
Object.entries(b.porTipo||{}).map(([t,v])=>React.createElement(React.Fragment,{key:t},tile(TIPOS[t]||t,pct(v),'¼ Kelly no ar'))),
tile(`Aparições (${d.dias} d)`,(r.aparicoes||0).toLocaleString('pt-BR'),`${(r.selecoes||0).toLocaleString('pt-BR')} seleções · ${r.abertas||0} no ar`),
tile('EV no pico (média)',r.ev_max_medio!=null?'+'+Number(r.ev_max_medio).toFixed(1).replace('.',',')+'%':'—',`máx. +${Number(r.ev_max||0).toFixed(1).replace('.',',')}% · fica ${dur(r.duracao_media_s)} em média`)
),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'end'}},
React.createElement("label",{style:{display:'grid',gap:4}},"Período",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"evh-dias",className:"sel",value:f.dias,onChange:(e)=>campo('dias',Number(e.target.value))},[1,7,30,90].map((n)=>React.createElement("option",{key:n,value:n},n===1?'Últimas 24 h':`Últimos ${n} dias`))),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("label",{style:{display:'grid',gap:4}},"Casa",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"evh-casa",className:"sel",value:f.casa,onChange:(e)=>campo('casa',e.target.value)},React.createElement("option",{value:""},"Todas"),(d.casas||[]).map((c)=>React.createElement("option",{key:c,value:c},c))),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("label",{style:{display:'grid',gap:4}},"Tipo",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"evh-tipo",className:"sel",value:f.tipo,onChange:(e)=>campo('tipo',e.target.value)},React.createElement("option",{value:""},"Todos"),Object.entries(TIPOS).map(([k,v])=>React.createElement("option",{key:k,value:k},v))),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("label",{style:{display:'grid',gap:4}},"EV mínimo no pico (%)",React.createElement("input",{id:"evh-minev",type:"number",min:"0",step:"0.5",value:f.minEv,onChange:(e)=>campo('minEv',e.target.value),style:{width:110}})),
React.createElement("label",{style:{display:'grid',gap:4}},"Jogo ou seleção",React.createElement("input",{id:"evh-q",value:f.q,onChange:(e)=>campo('q',e.target.value),placeholder:"Ex.: Flamengo"}))
),
React.createElement("div",null,React.createElement("b",null,"Banca no ar ao longo do tempo")," ",React.createElement("span",{className:"ev-sub"},"(¼ Kelly somado, foto a cada 5 min)")),
serie.length>1?React.createElement("div",{style:{overflowX:'auto'}},React.createElement("svg",{viewBox:`0 0 ${W} ${Hh}`,style:{width:'100%',maxWidth:W,height:'auto'},role:"img","aria-label":"Banca no ar ao longo do tempo"},
[0,.5,1].map((q)=>React.createElement("g",{key:q},React.createElement("line",{x1:P,x2:W-8,y1:y(maxK*q),y2:y(maxK*q),stroke:"var(--line-2)",strokeDasharray:"3 3"}),React.createElement("text",{x:P-4,y:y(maxK*q)+4,textAnchor:"end",fontSize:"10",fill:"var(--on-surface-variant)"},Math.round(maxK*q),"%"))),
React.createElement("path",{d:caminho,fill:"none",stroke:"var(--teal)",strokeWidth:"1.8"}),
React.createElement("circle",{cx:x(serie[serie.length-1].em),cy:y(serie[serie.length-1].kelly),r:"3",fill:"var(--teal)"}),
React.createElement("text",{x:P,y:Hh-3,fontSize:"10",fill:"var(--on-surface-variant)"},hora(t0)),React.createElement("text",{x:W-8,y:Hh-3,textAnchor:"end",fontSize:"10",fill:"var(--on-surface-variant)"},hora(t1))
)):React.createElement("div",{className:"ev-sub"},"A primeira foto sai até 5 min depois da subida do painel."),
React.createElement("div",null,React.createElement("b",null,"Por casa")," ",React.createElement("span",{className:"ev-sub"},"— \"relâmpago\" = ficou menos de 1 min na tela (difícil de apostar a tempo)")),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Casa"),React.createElement("th",null,"Aparições"),React.createElement("th",null,"EV no pico (média)"),React.createElement("th",null,"Tempo médio na tela"),React.createElement("th",null,"Relâmpago"),React.createElement("th",null,"No ar"))),React.createElement("tbody",null,
(d.porCasa||[]).map((c)=>React.createElement("tr",{key:c.casa||'?'},React.createElement("td",{style:{fontWeight:600}},c.casa||'—'),React.createElement("td",{className:"ev-num"},c.n.toLocaleString('pt-BR')),React.createElement("td",{className:"ev-num"},"+",Number(c.evMaxMedio||0).toFixed(1).replace('.',','),"%"),React.createElement("td",{className:"ev-num"},dur(c.duracaoMediaS)),React.createElement("td",{className:"ev-num"},c.n?Math.round(100*c.relampago/c.n):0,"%"),React.createElement("td",{className:"ev-num"},c.abertas||0))),
!(d.porCasa||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:6,className:"ev-sub"},"Nenhuma aparição no período."))
))),
React.createElement("div",null,React.createElement("b",null,"Aparições")," ",React.createElement("span",{className:"ev-sub"},"(as 300 mais recentes do filtro)")),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Entrou"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Entrada"),React.createElement("th",null,"Pico"),React.createElement("th",null,"Saída"),React.createElement("th",null,"¼ Kelly (pico)"),React.createElement("th",null,"Na tela"))),React.createElement("tbody",null,
(d.lista||[]).map((l)=>React.createElement("tr",{key:l.ap},
React.createElement("td",{className:"ev-num"},hora(l.inicio)),
React.createElement("td",null,l.jogo,React.createElement("div",{className:"ev-sub"},l.liga||'',l.kickoff?' · '+hora(l.kickoff):'')),
React.createElement("td",null,l.selecao,React.createElement("div",{className:"ev-sub"},l.mercado,l.justa_fonte?' · justa '+l.justa_fonte:'')),
React.createElement("td",null,l.casa,React.createElement("div",{className:"ev-sub"},TIPOS[l.tipo]||l.tipo)),
React.createElement("td",{className:"ev-num"},Number(l.odd_ini).toFixed(2),React.createElement("div",{className:"ev-sub"},"+",Number(l.ev_ini).toFixed(1),"%")),
React.createElement("td",{className:"ev-num"},Number(l.odd_max).toFixed(2),React.createElement("div",{className:"ev-sub"},"+",Number(l.ev_max).toFixed(1),"% · justa ",Number(l.justa_max).toFixed(2))),
React.createElement("td",{className:"ev-num"},l.fim?React.createElement(React.Fragment,null,Number(l.odd_fim).toFixed(2),React.createElement("div",{className:"ev-sub"},Number(l.ev_fim)>=0?'+':'',Number(l.ev_fim).toFixed(1),"%")):React.createElement("span",{className:"pill",style:{color:'var(--up)'}},"no ar")),
React.createElement("td",{className:"ev-num"},pct(l.kelly_max)),
React.createElement("td",{className:"ev-num"},dur(l.duracao_s))
)),
!(d.lista||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:9,className:"ev-sub"},"Nenhuma aparição no filtro."))
)))
);
}



function P6jCard(){
const[d,setD]=useState(null),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false),[json,setJson]=useState(''),[verJson,setVerJson]=useState(false);
const load=()=>leJson('/api/master/justa-p6j').then((x)=>{setD(x);setJson((j)=>j||JSON.stringify(x.parametros,null,2));}).catch((e)=>setMsg('❌ P6j não carregou: '+e.message));
useEffect(()=>{load();const i=setInterval(load,30000);return()=>clearInterval(i);},[]);
if(!d)return React.createElement("div",{className:"ev-sub"},msg||'carregando a P6j…');
const acao=async(qual)=>{const txt=qual==='ligar'?`Ligar a P6j? Isso desliga ${d.seLigarDesliga.length} regra(s) do Filtro de EV no mesmo momento e muda o EV+ e o que o robô vê.`:'Desligar a P6j? A justa volta a ser a Pinnacle sem margem (e-sports: a regra A) e as regras que a P6j desligou voltam.';
if(!(await confirma(txt)))return;setBusy(true);setMsg('');try{const x=await leJson('/api/master/justa-p6j/'+qual,{method:'POST'});setMsg('✅ '+x.msg);load();}catch(e){setMsg('❌ '+e.message);}setBusy(false);};
const gravaJson=async()=>{let p;try{p=JSON.parse(json);}catch(e){setMsg('❌ JSON ilegível: '+e.message);return;}
if(!(await confirma('Gravar os parâmetros novos da P6j? Valem na próxima volta do EV+ (os de antes ficam no er_report).')))return;
setBusy(true);setMsg('');try{const x=await leJson('/api/master/justa-p6j/parametros',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({parametros:p})});setMsg('✅ '+x.msg);setJson(JSON.stringify(x.parametros,null,2));load();}catch(e){setMsg('❌ '+e.message);}setBusy(false);};
const v=d.volta,NB={polymarket:'Polymarket',kalshi:'Kalshi',sxbet:'SX',fourcasters:'4casters'};
const MOT={sem_leitura:'sem leitura recente',um_lado_so:'um lado só',sem_os_lados:'sem os lados',preco_ilegivel:'preço ilegível'};
return React.createElement("div",{className:"card",style:{padding:16,border:'1px solid var(--line-2)',borderRadius:12,display:'grid',gap:10}},
React.createElement("div",{style:{display:'flex',gap:10,alignItems:'center',flexWrap:'wrap'}},React.createElement("b",{style:{fontSize:15}},"Justa P6j — Pinnacle + bolsas"),
React.createElement("span",{id:"p6j-estado",className:"pill",style:{border:'1px solid var(--line-2)',background:d.ligada?'color-mix(in srgb,var(--teal) 18%,transparent)':'transparent'}},d.ligada?'LIGADA':'DESLIGADA'),
React.createElement("span",{className:"ev-sub"},d.versao,d.em?` · desde ${new Date(d.em).toLocaleString('pt-BR')} por ${d.por||'?'}`:' · ligada por padrão')),
React.createElement("div",{className:"ev-sub",style:{fontSize:13,maxWidth:860}},"A justa dos mercados de jogo e das Super Odds parte da Pinnacle sem margem e é puxada para o meio do livro de Polymarket, Kalshi, SX e 4casters no mesmo mercado e linha. O peso de cada bolsa depende dela, do esporte, dos minutos até o jogo, do spread e da idade do livro. Nos e-sports só a Polymarket entra, com o meio corrigido pelo 50/50. Ligada, ela desliga as 16 regras da seção 12.1, a TEN-3 e a TEN-2 (ficam ",d.regrasQueFicam.join(', ')," e as de props) e liga a trava pré-jogo × ao vivo."),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',alignItems:'center'}},
d.ligada?React.createElement("button",{id:"p6j-desligar",className:"btn-sm",disabled:busy,onClick:()=>acao('desligar')},"Desligar a P6j"):React.createElement("button",{id:"p6j-ligar",className:"btn-sm b-green",disabled:busy,onClick:()=>acao('ligar')},"Ligar a P6j"),
msg&&React.createElement("span",null,msg)),
(d.erroParametros||d.erroChave||d.config&&d.config.erro)&&React.createElement("div",{className:"toast"},"❌ ",[d.erroParametros,d.erroChave,d.config&&d.config.erro].filter(Boolean).join(' · ')),
v?React.createElement("div",{style:{display:'grid',gap:4,fontSize:13}},
React.createElement("div",null,"Última volta inteira (",new Date(v.em).toLocaleTimeString('pt-BR'),"): ",React.createElement("b",null,(v.selecoes||0).toLocaleString('pt-BR'))," seleções, ",React.createElement("b",null,(v.comLivro||0).toLocaleString('pt-BR'))," com pelo menos um livro de bolsa, ",(v.movidas||0).toLocaleString('pt-BR')," com a justa diferente da Pinnacle (maior diferença ",String(v.maiorMudancaPt||0).replace('.',',')," pt)."),
React.createElement("div",null,"Livros na conta: ",Object.entries(v.livros||{}).map(([b,n])=>`${NB[b]||b} ${n.toLocaleString('pt-BR')}`).join(' · ')||'nenhum',v.livrosCalculados?` (${v.livrosCalculados.toLocaleString('pt-BR')} calculados das linhas vizinhas)`:''),
React.createElement("div",null,"Descartados pelas travas: spread ",v.descartes.spread," · meio ",v.descartes.meio," · longe da Pinnacle ",v.descartes.distancia,v.foraDaFaixa?` · ${v.foraDaFaixa} com a Pinnacle fora de 2–98% (justa = Pinnacle)`:''),
React.createElement("div",null,"Fora por outro motivo: ",Object.entries(v.sem||{}).map(([b,m])=>`${NB[b]||b}: `+Object.entries(m).map(([k,n])=>`${MOT[k]||k} ${n}`).join(', ')).join(' · ')||'nenhum',v.idadeDesconhecida?` · ${v.idadeDesconhecida} livro(s) sem a hora da última mudança (idade 0)`:'',v.listagensRepetidas?` · ${v.listagensRepetidas} com duas listagens da mesma bolsa (ficou a de maior liquidez)`:''),
Object.keys(v.jogosEsports||{}).length>0&&React.createElement("div",null,"E-sports por jogo: ",Object.entries(v.jogosEsports).map(([g,n])=>`${g} ${n}`).join(' · '))
):React.createElement("div",{className:"ev-sub"},"A primeira volta inteira do EV+ com a P6j ainda não terminou."),
React.createElement("details",null,React.createElement("summary",{style:{cursor:'pointer'}},"Regras do Filtro de EV da seção 12 (",d.regras.filter((r)=>r.saiComP6j).length,")"),
React.createElement("table",{className:"ev-det-tab"},React.createElement("tbody",null,d.regras.filter((r)=>r.saiComP6j).map((r)=>React.createElement("tr",{key:r.id},React.createElement("td",null,"#",r.id),React.createElement("td",null,r.nome),React.createElement("td",null,r.ativa?'ligada':'desligada'),React.createElement("td",{className:"ev-sub"},r.por||''))))),
(d.naoAchadas||[]).length>0&&React.createElement("div",{className:"ev-sub"},"Sem regra com este código no Filtro de EV: ",d.naoAchadas.join(', '))
),
React.createElement("details",{open:verJson,onToggle:(e)=>setVerJson(e.target.open)},React.createElement("summary",{style:{cursor:'pointer'}},"Parâmetros (JSON do SPEC 5.3 + e-sports 6.1)"),
React.createElement("textarea",{id:"p6j-json",value:json,onChange:(e)=>setJson(e.target.value),spellCheck:false,style:{width:'100%',minHeight:260,fontFamily:'var(--f-data)',fontSize:12}}),
React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap'}},React.createElement("button",{id:"p6j-gravar",className:"btn-sm b-green",disabled:busy,onClick:gravaJson},"Gravar parâmetros"),React.createElement("button",{className:"btn-sm",type:"button",onClick:()=>setJson(JSON.stringify(d.padrao,null,2))},"Voltar ao padrão do arquivo"))
),
(d.historico||[]).length>0&&React.createElement("details",null,React.createElement("summary",{style:{cursor:'pointer'}},"Histórico da chave"),React.createElement("div",{className:"ev-sub",style:{display:'grid',gap:2}},d.historico.map((h,i)=>React.createElement("div",{key:i},new Date(h.em).toLocaleString('pt-BR')," · ",h.acao," · ",h.por||'?',h.desligou?` · desligou ${h.desligou.length} regra(s)`:'',h.religou?` · religou ${h.religou.length}`:'',h.versao?` · ${h.versao}`:''))))
);
}



function FontesJustaCard(){
const[d,setD]=useState(null),[cfg,setCfg]=useState(null),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
useEffect(()=>{fetch('/api/master/fontes-justa',{credentials:'include'}).then(async(r)=>{const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'HTTP '+r.status);setD(x);setCfg(x.cfg);}).catch((e)=>setMsg('❌ '+e.message));},[]);
if(!d||!cfg)return React.createElement("div",{className:"ev-sub"},msg||'carregando quem participa da justa…');

const LISTAS=[['jogo','Mercados de jogo e Super Odds: base da justa (P6j)','A Pinnacle sem margem é a âncora e não sai. Cada bolsa marcada puxa a justa para o meio do livro dela, com o peso da P6j (bolsa, esporte, minutos até o jogo, spread e idade do livro). Desmarcar tira a bolsa da justa.'],
['esports','E-sports: bolsas da justa','Com a P6j: só a Polymarket entra na conta dos e-sports (SPEC 6.1; a Kalshi pesou ~0). Com a P6j desligada: a regra A, a MAIOR justa entre a Pinnacle e cada bolsa marcada.'],
['propsEua','Props americanas: fontes calculadas como justa','O par Mais/Menos sem margem de cada fonte marcada vira opção em "Quem vota" dos segmentos de props (quem vota de fato é o segmento).'],
['consenso','Consenso das bolsas (só auditoria)','O "w" do consenso no EV+: não muda a justa nem regra nenhuma.']];
const alterna=(k,f)=>{if(k==='jogo'&&f==='pinnacle')return;const v=cfg[k]||[];setCfg({...cfg,[k]:v.includes(f)?v.filter((x)=>x!==f):[...v,f]});};
const salvar=async()=>{setBusy(true);setMsg('');try{const r=await fetch('/api/master/fontes-justa',{method:'PUT',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(cfg)});const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'HTTP '+r.status);setCfg(x.cfg);setMsg('✅ Salvo. Vale na próxima volta do EV+ (até 30 s) e do coletor.');}catch(e){setMsg('❌ '+e.message);}setBusy(false);};
return React.createElement("div",{className:"card",style:{padding:16,border:'1px solid var(--line-2)',borderRadius:12,display:'grid',gap:12}},
React.createElement("b",{style:{fontSize:15}},"Quem participa da odd justa"),
React.createElement("div",{className:"ev-sub",style:{fontSize:13,maxWidth:860}},"Casa nova entra ",React.createElement("b",null,"desmarcada"),". Marcar uma fonte aqui muda a justa do EV+ (e o que o robô vê) a partir da próxima volta."),
LISTAS.map(([k,rot,ajuda])=>React.createElement("div",{key:k,style:{display:'grid',gap:6}},React.createElement("b",{style:{fontSize:13}},rot),React.createElement("div",{className:"ev-sub"},ajuda),
React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},(d.candidatas[k]||[]).map((f)=>{const on=(cfg[k]||[]).includes(f);const trava=k==='jogo'&&f==='pinnacle';return React.createElement("button",{key:f,id:'fj-'+k+'-'+f,type:"button",disabled:trava,className:'pill'+(on?' on':''),style:{cursor:trava?'default':'pointer',border:'1px solid var(--line-2)',background:on?'color-mix(in srgb,var(--teal) 18%,transparent)':'transparent'},onClick:()=>alterna(k,f)},d.nomes[f]||f);})))),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}},React.createElement("button",{id:"fj-salvar",className:"btn-sm b-green",disabled:busy,onClick:salvar},"Salvar"),React.createElement("button",{className:"btn-sm",type:"button",onClick:()=>setCfg({...d.padrao})},"Voltar ao padrão"),msg&&React.createElement("span",null,msg),cfg.por&&React.createElement("span",{className:"ev-sub"},"última mudança: ",cfg.por,cfg.em?' · '+new Date(cfg.em).toLocaleString('pt-BR'):''))
);
}




function JustaSegmentoTab(){
const[d,setD]=useState(null),[erro,setErro]=useState(null),[msg,setMsg]=useState(''),[ed,setEd]=useState(null),[busy,setBusy]=useState(false),[aberto,setAberto]=useState(null);
const load=()=>fetch('/api/master/justa-segmentos',{credentials:'include'}).then(async(r)=>{const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'HTTP '+r.status);setD(x);setErro(null);}).catch((e)=>setErro(e.message));
useEffect(()=>{load();const i=setInterval(load,20000);return()=>clearInterval(i);},[]);
if(erro)return React.createElement("div",{className:"empty",style:{padding:32}},"Não carregou: ",erro);
if(!d)return React.createElement("div",{style:{padding:32,color:'var(--on-surface-variant)'}},"Carregando…");
const TIPO={jogo:'Mercados de jogo e Super Odds',jogador:'Props de jogador'};
const nomeMerc=(c)=>d.nomesMercado&&d.nomesMercado[c]||c;
const resumoParams=(metodo,p)=>{const m=d.metodos[metodo];if(!m||!p)return'';return Object.entries(m.params).map(([k,def])=>{const v=p[k];if(v==null)return null;
if(def.tipo==='opcao')return def.rot+': '+(def.opcoes[v]||v);if(def.tipo==='lista')return def.rot+': '+v.map((x)=>def.opcoes[x]||x).join(', ');
if(def.tipo==='pesos')return p.combina==='media_peso'?def.rot+': '+Object.entries(v).map(([a,b])=>(def.opcoes[a]||a)+' '+b).join(' · '):null;return def.rot+': '+v;}).filter(Boolean).join(' · ');};
const recorte=(s)=>[TIPO[s.tipo]||s.tipo,s.esporte?evEsporte(s.esporte)[0]:'todos os esportes',s.mercado?nomeMerc(s.mercado):'todos os mercados',s.liga?'liga '+s.liga:null].filter(Boolean).join(' · ');
const novo=()=>setEd({nome:'',tipo:'jogo',esporte:'',mercado:'',liga:'',metodo:'pinnacle_sem_margem',params:{},modo:'sombra',ativo:true});
const salvar=async(seg)=>{const s=seg||ed;setBusy(true);setMsg('');try{const r=await fetch('/api/master/justa-segmentos'+(s.id?'/'+s.id:''),{method:s.id?'PUT':'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(s)});const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'HTTP '+r.status);setMsg('✅ '+(x.msg||'Salvo'));setEd(null);load();}catch(e){setMsg('❌ '+e.message);}finally{setBusy(false);}};
const exclui=async(s)=>{if(!(await confirma(`Excluir o segmento "${s.nome}"?`)))return;await fetch('/api/master/justa-segmentos/'+s.id,{method:'DELETE',credentials:'include'});setMsg('Segmento excluído');load();};
const metodosDoTipo=(t)=>Object.entries(d.metodos).filter(([,m])=>m.tipo===t);
const met=ed&&d.metodos[ed.metodo];
const pv=(k,def)=>ed.params&&ed.params[k]!=null?ed.params[k]:def.padrao;
const setP=(k,v)=>setEd({...ed,params:{...ed.params,[k]:v}});
const campoParam=(k,def)=>{const v=pv(k,def);
if(def.tipo==='opcao')return React.createElement("label",{key:k,style:{display:'grid',gap:4}},def.rot,React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:'js-p-'+k,className:"sel",value:v,onChange:(e)=>setP(k,e.target.value)},Object.entries(def.opcoes).map(([o,r])=>React.createElement("option",{key:o,value:o},r))),React.createElement(Ic,{n:"arrow_drop_down"})));
if(def.tipo==='lista')return React.createElement("div",{key:k,style:{display:'grid',gap:6}},React.createElement("b",{style:{fontSize:13}},def.rot),React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},Object.entries(def.opcoes).map(([o,r])=>{const on=v.includes(o);return React.createElement("button",{key:o,type:"button",className:'pill'+(on?' on':''),style:{cursor:'pointer',border:'1px solid var(--line-2)',background:on?'color-mix(in srgb,var(--teal) 18%,transparent)':'transparent'},onClick:()=>setP(k,on?v.filter((x)=>x!==o):[...v,o])},r);})));
if(def.tipo==='numero')return React.createElement("label",{key:k,style:{display:'grid',gap:4}},def.rot,React.createElement("input",{id:'js-p-'+k,type:"number",min:def.min,max:def.max,value:v,onChange:(e)=>setP(k,e.target.value),style:{width:110}}));
if(def.tipo==='pesos'){if(pv('combina',met.params.combina||{})!=='media_peso')return null;return React.createElement("div",{key:k,style:{display:'grid',gap:6}},React.createElement("b",{style:{fontSize:13}},def.rot),React.createElement("div",{style:{display:'flex',gap:10,flexWrap:'wrap'}},Object.entries(def.opcoes).map(([o,r])=>React.createElement("label",{key:o,style:{display:'flex',gap:6,alignItems:'center'}},r,React.createElement("input",{id:'js-peso-'+o,type:"number",min:"0",max:"100",value:(v||{})[o]??1,onChange:(e)=>setP(k,{...(v||{}),[o]:e.target.value}),style:{width:70}})))));}
return null;};
const mercadosDoTipo=ed?(ed.tipo==='jogo'?d.mercadosJogo:d.mercadosProps)||[]:[];
const sombraTxt=(s)=>{const m=s.sombra;if(!m)return React.createElement("span",{className:"ev-sub"},"medindo na próxima volta…");
return React.createElement(React.Fragment,null,React.createElement("b",{style:{color:'var(--up)'}},"+",m.aMais)," / ",React.createElement("b",{style:{color:'#B3423A'}},"−",m.aMenos)," EVs",React.createElement("div",{className:"ev-sub"},m.linhas.toLocaleString('pt-BR')," linhas · EV+ agora ",m.evAgora," → com ele ",m.evSombra,m.semJusta?` · ${m.semJusta} sem justa`:''));};
return React.createElement("div",{style:{display:'grid',gap:16}},
msg&&React.createElement("div",{className:"toast"},msg),
d.erro&&React.createElement("div",{className:"toast"},"❌ ",d.erro),
React.createElement("div",{className:"ev-sub",style:{fontSize:13,maxWidth:860}},"Cada ",React.createElement("b",null,"segmento")," diz como a odd justa do EV+ é calculada num recorte: tipo, esporte e, se quiser, mercado e liga. Vale o mais específico (mercado > liga > esporte); sem segmento, o ",React.createElement("b",null,"padrão do sistema"),". Segmento novo nasce em ",React.createElement("b",null,"sombra"),": não muda a tela EV+, só mostra aqui o que mudaria. Ative quando a diferença fizer sentido. Método novo: descreva para o desenvolvedor — ele entra na biblioteca com teste e aparece na lista."),
React.createElement(P6jCard,null),
React.createElement(FontesJustaCard,null),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}},React.createElement("button",{className:"btn-sm b-green",onClick:novo},"Novo segmento"),React.createElement("span",{className:"ev-sub"},"sombra medida ",d.sombraEm?new Date(d.sombraEm).toLocaleTimeString('pt-BR'):'—')),
ed&&React.createElement("div",{className:"card",style:{padding:16,border:'1px solid var(--line-2)',borderRadius:12,display:'grid',gap:12}},
React.createElement("label",{style:{display:'grid',gap:4}},"Nome",React.createElement("input",{id:"js-nome",value:ed.nome,onChange:(e)=>setEd({...ed,nome:e.target.value}),placeholder:"Ex.: NBA — margem multiplicativa"})),
React.createElement("div",{style:{display:'flex',gap:10,flexWrap:'wrap'}},
React.createElement("label",{style:{display:'grid',gap:4}},"Tipo",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"js-tipo",className:"sel",value:ed.tipo,onChange:(e)=>{const t=e.target.value;const m=metodosDoTipo(t)[0];setEd({...ed,tipo:t,mercado:'',metodo:m?m[0]:'',params:{}});}},Object.entries(TIPO).map(([k,v])=>React.createElement("option",{key:k,value:k},v))),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("label",{style:{display:'grid',gap:4}},"Esporte",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"js-esporte",className:"sel",value:ed.esporte,onChange:(e)=>setEd({...ed,esporte:e.target.value})},React.createElement("option",{value:""},"Todos"),(d.esportes||[]).map((e)=>React.createElement("option",{key:e,value:e},evEsporte(e)[0]))),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("label",{style:{display:'grid',gap:4}},"Mercado",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"js-mercado",className:"sel",value:ed.mercado,onChange:(e)=>setEd({...ed,mercado:e.target.value})},React.createElement("option",{value:""},"Todos"),mercadosDoTipo.map((m)=>React.createElement("option",{key:m,value:m},nomeMerc(m)))),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("label",{style:{display:'grid',gap:4}},"Liga (opcional, nome exato)",React.createElement("input",{id:"js-liga",value:ed.liga,onChange:(e)=>setEd({...ed,liga:e.target.value}),placeholder:"Ex.: NBA"}))
),
React.createElement("label",{style:{display:'grid',gap:4}},"Método",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"js-metodo",className:"sel",value:ed.metodo,onChange:(e)=>setEd({...ed,metodo:e.target.value,params:{}})},metodosDoTipo(ed.tipo).map(([k,m])=>React.createElement("option",{key:k,value:k},m.nome))),React.createElement(Ic,{n:"arrow_drop_down"})),met&&React.createElement("span",{className:"ev-sub"},met.descricao)),
met&&Object.entries(met.params).map(([k,def])=>campoParam(k,def)),
React.createElement("label",{style:{display:'grid',gap:4}},"Modo",React.createElement("div",{className:"sel-wrap"},React.createElement("select",{id:"js-modo",className:"sel",value:ed.modo,onChange:(e)=>setEd({...ed,modo:e.target.value})},React.createElement("option",{value:"sombra"},"Sombra — só mede, não muda a tela"),React.createElement("option",{value:"ativo"},"Ativo — vale no EV+")),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("div",{style:{display:'flex',gap:8}},React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:()=>salvar()},busy?'Salvando…':'Salvar segmento'),React.createElement("button",{className:"btn-sm",onClick:()=>setEd(null)},"Cancelar"))
),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Segmento"),React.createElement("th",null,"Recorte"),React.createElement("th",null,"Método"),React.createElement("th",null,"Modo"),React.createElement("th",null,"Efeito"),React.createElement("th",null))),React.createElement("tbody",null,
(d.segmentos||[]).map((s)=>React.createElement(React.Fragment,{key:s.id},React.createElement("tr",{style:s.ativo?undefined:{opacity:.55}},
React.createElement("td",{style:{fontWeight:600}},s.nome,React.createElement("div",{className:"ev-sub"},s.por?'por '+s.por:'')),
React.createElement("td",null,recorte(s)),
React.createElement("td",null,(d.metodos[s.metodo]||{}).nome||s.metodo,React.createElement("div",{className:"ev-sub"},resumoParams(s.metodo,s.params))),
React.createElement("td",null,React.createElement("span",{className:"pill",style:{color:s.modo==='ativo'?'var(--up)':'var(--on-surface-variant)'}},!s.ativo?'desligado':s.modo==='ativo'?'Ativo':'Sombra')),
React.createElement("td",{className:"ev-num"},!s.ativo?'—':s.modo==='ativo'?React.createElement(React.Fragment,null,s.evNoArAgora," EVs no ar"):sombraTxt(s)),
React.createElement("td",null,React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},
s.ativo&&s.modo==='sombra'&&React.createElement("button",{className:"btn-sm b-green",disabled:busy,onClick:async()=>{if(await confirma(`Ativar "${s.nome}"? A justa do EV+ nesse recorte passa a vir deste método.`))salvar({...s,modo:'ativo'});}},"Ativar"),
s.ativo&&s.modo==='ativo'&&React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>salvar({...s,modo:'sombra'})},"Voltar para sombra"),
s.modo==='sombra'&&s.sombra&&s.sombra.exemplos&&s.sombra.exemplos.length>0&&React.createElement("button",{className:"btn-sm",onClick:()=>setAberto(aberto===s.id?null:s.id)},aberto===s.id?'Fechar exemplos':'Exemplos'),
React.createElement("button",{className:"btn-sm",onClick:()=>setEd({...s})},"Editar"),
React.createElement("button",{className:"btn-sm",onClick:()=>salvar({...s,ativo:!s.ativo})},s.ativo?'Desligar':'Ligar'),
React.createElement("button",{className:"btn-sm b-red",onClick:()=>exclui(s)},"Excluir")))
),
aberto===s.id&&s.sombra&&React.createElement("tr",null,React.createElement("td",{colSpan:6},React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Odd"),React.createElement("th",null,"Justa agora"),React.createElement("th",null,"EV agora"),React.createElement("th",null,"Justa com ele"),React.createElement("th",null,"EV com ele"))),React.createElement("tbody",null,
s.sombra.exemplos.map((x,i)=>React.createElement("tr",{key:i},React.createElement("td",null,x.jogo),React.createElement("td",null,x.selecao,React.createElement("div",{className:"ev-sub"},x.mercado)),React.createElement("td",null,x.casa),React.createElement("td",{className:"ev-num"},Number(x.odd).toFixed(2)),React.createElement("td",{className:"ev-num"},Number(x.justaAgora).toFixed(3)),React.createElement("td",{className:"ev-num"},x.evAgora>0?'+':'',Number(x.evAgora).toFixed(1),"%"),React.createElement("td",{className:"ev-num"},Number(x.justaSombra).toFixed(3)),React.createElement("td",{className:"ev-num",style:{fontWeight:700,color:x.evSombra>0?'var(--up)':'#B3423A'}},x.evSombra>0?'+':'',Number(x.evSombra).toFixed(1),"%")))
)))))
)),
!(d.segmentos||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:6,className:"ev-sub"},"Nenhum segmento — vale o padrão do sistema em tudo."))
))),
React.createElement("div",null,React.createElement("b",null,"Padrão do sistema")," ",React.createElement("span",{className:"ev-sub"},"— vale onde nenhum segmento pega")),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Padrão"),React.createElement("th",null,"Método"),React.createElement("th",null,"EVs no ar agora"))),React.createElement("tbody",null,
(d.sistema||[]).map((s)=>React.createElement("tr",{key:s.id},React.createElement("td",{style:{fontWeight:600}},s.nome),React.createElement("td",null,(d.metodos[s.metodo]||{}).nome,React.createElement("div",{className:"ev-sub"},resumoParams(s.metodo,s.params))),React.createElement("td",{className:"ev-num"},s.evNoArAgora)))
))),
React.createElement("div",null,React.createElement("b",null,"Regras fixas do cálculo")," ",React.createElement("span",{className:"ev-sub"},"— valem para todo segmento (estão no código)")),
React.createElement("ul",{style:{margin:0,paddingLeft:20,display:'grid',gap:4,fontSize:13,maxWidth:860}},(d.regrasFixas||[]).map((r,i)=>React.createElement("li",{key:i},r)))
);
}



function ChavesLeituraTab(){
const[d,setD]=useState(null),[msg,setMsg]=useState(''),[nova,setNova]=useState(null),[nome,setNome]=useState('rotina de bugs (nuvem)');
const load=()=>fetch('/api/master/chaves-leitura',{credentials:'include'}).then((r)=>r.json()).then(setD).catch((e)=>setMsg('❌ '+e.message));
useEffect(()=>{load();},[]);
const gerar=async()=>{setMsg('');const r=await fetch('/api/master/chaves-leitura',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({nome})});const x=await r.json().catch(()=>({}));if(!r.ok){setMsg('❌ '+(x.error||'Erro'));return;}setNova(x.chave);load();};
const revogar=async(c)=>{if(!(await confirma(`Revogar a chave "${c.nome}"? Quem usa para de ler na hora.`)))return;await fetch('/api/master/chaves-leitura/'+c.id+'/revogar',{method:'POST',credentials:'include'});setMsg('Chave revogada');load();};
const fmt=(t)=>t?new Date(String(t).replace(' ','T')+(String(t).includes('Z')?'':'Z')).toLocaleString('pt-BR'):'—';
return React.createElement("div",{style:{display:'grid',gap:14,maxWidth:900}},
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement("div",{className:"ev-sub",style:{fontSize:13}},"A rotina que roda na nuvem não tem o seu login. Ela lê a produção com uma chave daqui, que só consulta (GET) as rotas de diagnóstico — nunca grava, nunca muda configuração. A chave aparece ",React.createElement("b",null,"uma vez"),": copie e cole no ambiente da rotina. Revogue quando não precisar mais."),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'end',flexWrap:'wrap'}},React.createElement("label",{style:{display:'grid',gap:4}},"Nome",React.createElement("input",{id:"cl-nome",value:nome,onChange:(e)=>setNome(e.target.value),style:{width:260}})),React.createElement("button",{className:"btn-sm b-green",onClick:gerar},"Gerar chave")),
nova&&React.createElement("div",{style:{padding:12,border:'1px solid var(--line-2)',borderRadius:10,display:'grid',gap:6}},React.createElement("b",null,"Chave nova (não aparece de novo):"),React.createElement("code",{style:{wordBreak:'break-all',userSelect:'all'}},nova),React.createElement("div",{style:{display:'flex',gap:8}},React.createElement("button",{className:"btn-sm",onClick:()=>{try{navigator.clipboard.writeText(nova);setMsg('✅ Copiada');}catch(e){}}},"Copiar"),React.createElement("button",{className:"btn-sm",onClick:()=>setNova(null)},"Já copiei"))),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Nome"),React.createElement("th",null,"Criada por"),React.createElement("th",null,"Criada em"),React.createElement("th",null,"Último uso"),React.createElement("th",null,"Situação"),React.createElement("th",null))),React.createElement("tbody",null,
(d&&d.chaves||[]).map((c)=>React.createElement("tr",{key:c.id,style:Number(c.ativo)?undefined:{opacity:.5}},React.createElement("td",{style:{fontWeight:600}},c.nome),React.createElement("td",null,c.criado_por||'—'),React.createElement("td",null,fmt(c.criado_em)),React.createElement("td",null,fmt(c.usado_em)),React.createElement("td",null,Number(c.ativo)?'ativa':'revogada'),React.createElement("td",null,Number(c.ativo)?React.createElement("button",{className:"btn-sm b-red",onClick:()=>revogar(c)},"Revogar"):null))),
d&&!(d.chaves||[]).length&&React.createElement("tr",null,React.createElement("td",{colSpan:6,className:"ev-sub"},"Nenhuma chave."))
)))
);
}









const fbNum=(n)=>n==null||n===''?'—':String(n).replace('.',',');
const fbHora=(ms)=>{if(!ms)return'—';try{return fusoSP.fmtSP(new Date(Number(ms)));}catch(e){return String(ms);}};
const fbHa=(ms)=>{if(!ms)return'nunca';const s=Math.max(0,Math.round((Date.now()-Number(ms))/1000));return s<90?`há ${s} s`:s<5400?`há ${Math.round(s/60)} min`:s<172800?`há ${Math.round(s/3600)} h`:`há ${Math.round(s/86400)} dias`;};
const fbLe=(p,ch)=>{const[a,b]=ch.split('.');return b===undefined?(p||{})[a]:((p||{})[a]||{})[b];};
const fbPoe=(p,ch,v)=>{const[a,b]=ch.split('.');return b===undefined?{...p,[a]:v}:{...p,[a]:{...((p||{})[a]||{}),[b]:v}};};
const fbOrd=(v)=>Array.isArray(v)?[...v].sort():v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map((k)=>[k,v[k]])):v;
const fbIgual=(a,b)=>JSON.stringify(fbOrd(a))===JSON.stringify(fbOrd(b));
const fbFaixa=(c)=>[c.min!=null?'de '+fbNum(c.min):'',c.max!=null?'até '+fbNum(c.max):'',c.unidade||''].filter(Boolean).join(' ');

const fbNomeDe=(lista,ch,soNome)=>{const o=(lista||[]).find((x)=>x.chave===ch);return o&&o.nome&&o.nome!==ch?soNome?o.nome:`${o.nome} (${ch})`:ch;};

const fbValor=(c,v,op)=>{

if(c&&c.tipo==='vigiaPortal')return v&&typeof v==='object'?'ligada ('+(c.campos||[]).map((f)=>`${f.rotulo}: ${v[f.chave]==null||v[f.chave]===''?'(vazio)':String(v[f.chave])}`).join(' · ')+')':'desligada';
if(v==null)return'(vazio)';
if(!c)return typeof v==='object'?JSON.stringify(v):String(v);
if(c.tipo==='booleano')return v?'ligado':'desligado';

if(c.tipo==='opcao')return c.rotulos&&Object.prototype.hasOwnProperty.call(c.rotulos,v)?c.rotulos[v]:fbNomeDe(c.chave==='estado'?op&&op.estados:null,v,true);
if(c.tipo==='lista')return v.length?v.map((x)=>fbNomeDe(op&&(c.de?op[c.de]:c.chave==='tipos'?op.tipos:c.chave==='classes'?op.classes:null),x,!c.de)).join(', '):'(vazio)';

if(c.tipo==='excecoes'){const l=Array.isArray(v)?v:[],on=l.filter((r)=>r&&r.ativa).length;return l.length?`${l.length} ${l.length===1?'regra':'regras'} (${on} ${on===1?'ligada':'ligadas'})`:'nenhuma';}
if(c.tipo==='mapa'){const ks=Object.keys(v);return ks.length?ks.sort().map((k)=>`${fbNomeDe(op&&op.casas,k)}: ${fbNum(v[k])}`).join(', '):'(vazio)';}
if(c.tipo==='inteiro'||c.tipo==='numero')return fbNum(v)+(c.unidade?' '+c.unidade:'');
return v===''?'(vazio)':String(v);};

const fbLinha=(lado,linha)=>{const l=String(lado||'').toLowerCase(),n=fbNum(linha);return /^(over|mais|acima)$/.test(l)?'Mais de '+n:/^(under|menos|abaixo)$/.test(l)?'Menos de '+n:null;};
const fbAposta=(t)=>{const lin=t.linha!=null&&t.linha!==''?fbLinha(t.lado,t.linha):null;return lin?[t.jogador,t.mercadoNome||t.mercado,lin].filter(Boolean).join(' · '):t.descricao||t.selecao||'—';};
const fbPct=(n)=>n==null?'—':fbNum(Math.round(Number(n)*100)/100)+'%';
const fbOdd=(n)=>n==null?'—':Number(n).toFixed(2).replace('.',',');

const fbLista=(d,k)=>Array.isArray(d)?d:d&&Array.isArray(d[k])?d[k]:null;

const fbSemSessao=(e)=>{if(e&&e.status===401){location.href='/login';return true;}return false;};
const FB_MOTIVO={sem_fonte:'Nenhuma fonte grátis lê este mercado',divergencia:'As fontes discordam do resultado',regra_da_casa:'Depende da regra escrita da casa (não cadastrada)',regra_nao_executavel:'A regra da casa não dá para aplicar sozinha',jogo_nao_identificado:'O jogo não foi achado na fonte',jogador_nao_identificado:'O jogador não foi achado na fonte',sem_identificador:'A tip não tem o identificador do jogo',sem_dado:'A fonte não trouxe o dado',multipla:'Múltipla ou bet builder: só à mão',mercado_sem_regra:'Mercado sem regra de resultado',selecao_invalida:'Seleção que o FishBot não soube ler',jogo_nao_acabou:'O jogo ainda não acabou',jogo_adiado:'Jogo adiado',estado_desconhecido:'A fonte não diz se o jogo acabou',bolsa_nao_resolvida:'A bolsa ainda não resolveu o mercado',bolsa_em_disputa:'A resolução da bolsa está em disputa',bolsa_em_correcao:'A bolsa está corrigindo a resolução',teto_de_trafego:'Teto de tráfego do SofaScore atingido',erro_de_fonte:'A fonte deu erro',tip_sem_dados:'A tip não guardou o que o resultado precisa',carimbo_recusado:'O resultado foi lido, mas o bot não conseguiu carimbar a mensagem',bolsa_sem_resultado:'A bolsa liquidou sem um resultado que dê para ler',erro_interno:'Erro interno do FishBot',cadencia:'A fila do bot está cheia: tente de novo em instantes',sem_liquidacao_automatica:'Sem leitura automática do resultado para este mercado',falha_bot:'O bot recusou ou falhou ao postar',envio_incerto:'Envio incerto: não dá para saber se a mensagem saiu',nao_apostavel:'Linha marcada como não apostável',aguardando:'Aguardando confirmação da casa',tipo:'Tipo de linha fora do perfil',casa:'Casa fora do perfil',esporte:'Esporte fora do perfil',prop_esporte:'Prop de jogador em esporte fora do perfil',liga:'Liga fora do perfil',mercado:'Mercado fora do perfil',ev_baixo:'EV abaixo do mínimo',ev_alto:'EV acima do máximo',odd:'Odd fora da faixa',idade:'Odd da casa velha demais',idade_pinnacle:'Pinnacle velha demais',antecedencia:'Fora do tempo até o jogo',linha_antiga:'Linha antiga (só linha nova ligado)',sobrecarga_selecao:'Seleção já com a stake inteira',sobrecarga_grupo:'Teto do jogo ou do jogador atingido',bloqueio_mesma_casa:'Mesma casa e seleção há pouco tempo',kelly_zero:'Conta de Kelly deu zero',liquidez_baixa:'Liquidez abaixo do mínimo',liquidez_alta:'Liquidez acima do máximo',liquidez_sem_leitura:'Casa deveria informar liquidez e veio sem leitura',retorno_baixo:'Retorno potencial abaixo do mínimo',volume_grupo:'Cota de tips por hora do grupo',horario_zero:'Fora do horário principal com valor zero (a caixa do Volume proíbe também Super Odd e bolsa)',volume_casa:'Cota de tips por hora da casa'};

const fbMotivo=(m)=>m==null||m===''?'':FB_MOTIVO[m]||String(m);
const fbAte=(ms)=>ms?`até ${fbHora(ms)}`:'';

Object.assign(FB_MOTIVO,{ritmo:'Aguardando a vez: o grupo solta as tips aos poucos',volume_esporte:'Cota de tips do esporte em 60 minutos',superodd_limite:'A Super Odd já teve indicado o limite dela'});


const fbCambio=(x)=>{if(!x||typeof x!=='object'||!x.regras||typeof x.regras!=='object')return null;const c=x.cambio&&typeof x.cambio==='object'?x.cambio:null,a=x.auto,m=x.manual,linhas=[],rs=(v)=>'R$ '+fbNum(Number(v).toFixed(4));
const valendo=c?`${rs(c.brlPorUsd)} por dólar — ${c.origem==='manual'?'fixado à mão':'automático'} (${fbHora(c.lidoEm)})`:null;
if(a)linhas.push(`Automático (${x.fonte||'fonte pública'}): ${rs(a.brlPorUsd)}, lido ${fbHora(a.lidoEm)}${a.cotadoEm?' — cotação de '+String(a.cotadoEm):''}${a.vencido?` — VENCIDO (mais de ${x.regras.validadeDias} dias)`:''}`);else
linhas.push(`Automático (${x.fonte||'fonte pública'}): ainda não foi lido`);
if(m)linhas.push(`Fixado à mão: ${rs(m.brlPorUsd)}${m.por?' por '+String(m.por):''} (${fbHora(m.em)}) — vale no lugar do automático`);
if(x.proximaLeituraEm)linhas.push(`Próxima leitura automática: ${fbHora(x.proximaLeituraEm)} (1 por dia)`);
return{valendo,alerta:c?null:`Sem câmbio válido: a leitura automática ${a?`tem mais de ${x.regras.validadeDias} dias`:'ainda não aconteceu'} e nada foi fixado à mão. Grupo em US$ fica sem o valor em dólar até haver câmbio.`,
erro:x.erro&&x.erro.erro?`A última leitura automática falhou (${fbHora(x.erro.em)}): ${String(x.erro.erro)}`:null,linhas};};

const fbCambioDigitado=(txt,regras)=>{const t=String(txt??'').trim().replace(',','.');if(t==='')return{manual:null};const n=Number(t);
return Number.isFinite(n)&&n>=regras.manualMin&&n<=regras.manualMax?{manual:n}:{erro:`O câmbio precisa ser um número de ${fbNum(regras.manualMin)} a ${fbNum(regras.manualMax)} reais por dólar (ou vazio, para usar o automático).`};};


const fbRitmo=(x,agora)=>{const r=x&&typeof x==='object'&&x.ritmo&&typeof x.ritmo==='object'?x.ritmo:{},n=(v)=>v==null||v===''||typeof v==='boolean'||!Number.isFinite(Number(v))?null:Number(v),out=[];
const e=n(r.enviadas60min),t=n(r.teto),f=n(r.fichas),p=n(r.proximaFichaMs),i=n(r.intervaloMs),j=n(r.janelaCheiaAteMs),em=(ms)=>{const s=Math.round((ms-Number(agora))/1000);return s<=0?'agora':s<90?`em ${s} s`:`em ${Math.round(s/60)} min`;};
if(e!=null)out.push(`Enviadas nos últimos 60 min: ${e}${t!=null?' de '+t:''}`);
if(f!=null)out.push(`Fichas disponíveis: ${fbNum(Math.round(f*10)/10)}`);
if(p!=null&&p>0)out.push(`Próxima ficha ${em(p)} (${fbHora(p)})`);
if(i!=null&&i>0)out.push(`Uma ficha a cada ${fbNum(Math.round(i/6000)/10)} min`);
if(j!=null&&j>Number(agora))out.push(`Janela de 60 min cheia até ${fbHora(j)}`);
return out;};

const fbLiqDoGrupo=(saude,g)=>{const x=saude&&saude.grupos&&saude.grupos[g];if(x&&x.liquidacao&&typeof x.liquidacao==='object')return x.liquidacao;const l=saude&&saude.liquidacao;if(!l||typeof l!=='object')return null;const d=l.grupos&&typeof l.grupos==='object'?l.grupos[g]:l[g];return d&&typeof d==='object'&&!Array.isArray(d)?d:null;};


const fbPortalDaSaude=(v)=>{if(!v||typeof v!=='object'||Array.isArray(v))return null;const n=(x)=>x==null||x===''||typeof x==='boolean'||!Number.isFinite(Number(x))?null:Number(x),s=n(v.batimentoHaS),t=(x)=>String(x).slice(0,200),e=v.estado,up=v.ultimaParada&&typeof v.ultimaParada==='object'?v.ultimaParada:null,out=[{texto:'Portal de resultados: '+(e==='ok'?'gravando'+(s!=null?` (último batimento há ${Math.round(s)} s)`:''):e==='parado'?'leitor PARADO'+(s!=null?` há ${Math.round(s/60)} min`:''):e==='sem_registro'?'sem batimento do leitor':e==='sem_leitura'?'não consegui ler o portal'+(v.erro?` (${t(v.erro)})`:''):e==='tip_fora'?'tip saiu e o portal não gravou':e==null||e===''?'estado não informado pelo serviço':String(e).slice(0,60)),alerta:e!=='ok'}];if(up)out.push({texto:`última parada ${up.quandoMs?fbHora(up.quandoMs).slice(-5):'—'}: ${String(up.motivo==null?'':up.motivo).slice(0,120)}`,alerta:false});if(v.erroDoAviso)out.push({texto:'aviso ao ADM falhou: '+t(v.erroDoAviso),alerta:true});return out;};


const fbFontesDeResultado=(saude)=>{const l=saude&&saude.liquidacao;const e=l&&typeof l==='object'?l.fontes||l.errosPorFonte||null:null;if(!e||typeof e!=='object'||Array.isArray(e))return[];return Object.keys(e).sort().map((f)=>{const v=e[f],o=v&&typeof v==='object'?v:{erros:Number(v)||0},ue=o.ultimoErro;return{fonte:f,leituras:o.leituras??null,erros:Number(o.erros??o.n??0)||0,sucessoMs:o.ultimoSucessoMs??null,erro:ue?typeof ue==='object'?String(ue.erro??''):String(ue):null,erroMs:ue&&typeof ue==='object'?ue.em??null:null};});};

const fbLido=(v)=>v==null?'—':typeof v==='object'?JSON.stringify(v).slice(0,120):fbNum(v);



const fbPctDaFracao=(f)=>{const n=Number(f);return f==null||f===''||!Number.isFinite(n)||n<=0||n>=1?null:fbNum(Math.round(n*1000000)/10000)+'%';};
const fbFracaoDoPct=(txt)=>{const t=String(txt==null?'':txt).trim().replace(/\s*%$/,'').replace(',','.');if(!/^\d{1,3}(\.\d{1,2})?$/.test(t))return{erro:'Digite quanto a casa pagou em %, só o número, com até duas casas depois da vírgula (ex.: 50 ou 62,5).'};const p=Number(t);if(!(p>0&&p<100))return{erro:'O quanto a casa pagou tem de ser maior que 0 e menor que 100 (0% é Perdida e 100% é Ganha).'};return{fracao:Math.round(p*100)/10000};};

const fbResultado=(estado,fracao)=>estado==='Parcial'?`Parcial (${fbPctDaFracao(fracao)||'fração não informada'})`:estado==null||estado===''?'—':String(estado);
const fbEstado=(t)=>t&&t.estado?fbResultado(t.estado,t.fracao):'pendente';





const FB_SHARK={parceiro_desligado:'o bot está sem a configuração do Shark Track (nenhuma tip automática vai para lá)',sem_tip_no_parceiro:'esta mensagem não tem tip no Shark Track (foi postada com ele desligado)',pendente:'o bot ainda está tentando',parceiro_fora_do_ar:'o Shark Track estava fora do ar',parceiro_sem_resposta:'o Shark Track não respondeu a tempo',parceiro_recusou:'o Shark Track recusou o pedido',parceiro_resposta_invalida:'o Shark Track respondeu algo que o bot não entendeu',parceiro_nao_achou:'o Shark Track não achou a tip desta mensagem',parcial_sem_equivalente:'o Shark Track não tem pagamento parcial — os bilhetes de quem planilhou ficam para acerto à mão',erro_interno:'erro inesperado do bot',dropada:'a tip foi derrubada antes de existir no Shark Track: não há o que planilhar',cadencia:'a fila do bot estava cheia na hora de pôr o link de planilhar',telegram_falhou:'o Telegram recusou a edição que põe o link de planilhar',resultado_mudando:'o resultado mudou várias vezes enquanto o bot avisava'};
const fbSharkMotivo=(m)=>m==null||m===''?'sem motivo informado':Object.prototype.hasOwnProperty.call(FB_SHARK,m)?FB_SHARK[m]:String(m);

const FB_SHARK_RESULT={green:'ganha',half_green:'meio-ganha',red:'perdida',half_red:'meio-perdida',void:'anulada'};

const fbSharkFim=(x)=>(typeof x.detalhe==='string'&&x.detalhe?` (${x.detalhe})`:'')+(x.novaTentativa===true?' — o bot vai tentar de novo':'')+(x.desmarcado===true?' — desmarcado no Shark Track (lá a tip voltou a ficar sem resultado)':'');
const fbShark=(t)=>{const s=t&&t.shark&&typeof t.shark==='object'&&!Array.isArray(t.shark)?t.shark:null,b=(x)=>x&&typeof x==='object'&&typeof x.ok==='boolean'?x:null,tp=s&&b(s.tip),rs=s&&b(s.resultado),num=(x)=>x.id!=null&&x.id!==''?` (nº ${x.id})`:'',out=[];
if(tp)out.push(tp.ok?{texto:'Criada no Shark Track'+num(tp),alerta:false}:{texto:'NÃO criada no Shark Track'+num(tp)+': '+fbSharkMotivo(tp.motivo)+fbSharkFim(tp),alerta:tp.motivo!=='dropada'});
if(rs)out.push(rs.ok?{texto:'Resultado avisado ao Shark Track'+(rs.result!=null&&rs.result!==''?` (${Object.prototype.hasOwnProperty.call(FB_SHARK_RESULT,rs.result)?FB_SHARK_RESULT[rs.result]:String(rs.result)})`:''),alerta:false}:{texto:'Resultado NÃO avisado ao Shark Track: '+fbSharkMotivo(rs.motivo)+fbSharkFim(rs),alerta:rs.motivo!=='dropada'});
return out;};

const fbSharkDoResultado=(x)=>{const l=fbShark({shark:{tip:null,resultado:x&&x.shark}}).find((y)=>y.alerta);return l?' Atenção: '+l.texto+'.':'';};


const fbSharkDaSaude=(saude)=>{const s=saude&&saude.shark,n=s&&typeof s==='object'?Number(s.avisos):NaN;if(!(n>0))return null;const pm=s.porMotivo&&typeof s.porMotivo==='object'?s.porMotivo:{},q=(v)=>Number(v)>0?Number(v):0;
const partes=[q(s.daTip)?`${q(s.daTip)} de tip que não foi criada`:'',q(s.doResultado)?`${q(s.doResultado)} de resultado que não foi avisado`:'',q(s.emNovaTentativa)?`${q(s.emNovaTentativa)} o bot ainda tenta acertar sozinho`:'',q(s.janelaH)?`nas tips dos últimos ${Math.round(q(s.janelaH)/24)} dias`:''].filter(Boolean);
return{texto:typeof s.aviso==='string'&&s.aviso?s.aviso:`Shark Track: ${n} aviso(s) pendente(s)`,partes,motivos:Object.keys(pm).sort().filter((k)=>Number(pm[k])>0).map((k)=>`${fbSharkMotivo(k)} (${pm[k]})`)};};

const fbFamilia=(t)=>{const k=t&&typeof t.casaChave==='string'?t.casaChave:'';return k.indexOf('clone:')===0&&k.length>6?k.slice(6):null;};

const fbUltimaCorrecao=(t)=>{const c=Array.isArray(t&&t.correcoes)&&t.correcoes.length?t.correcoes[t.correcoes.length-1]:null;return c&&typeof c==='object'?c:null;};
const fbCaixa={padding:'14px 16px',border:'1px solid var(--line-2)',borderRadius:12,background:'var(--card)'};
const fbErroCx={padding:'10px 12px',border:'1px solid #F0C4C4',borderRadius:10,background:'#FFF5F5',color:'var(--down)',fontSize:13,fontWeight:600};
const fbChip={display:'inline-flex',alignItems:'center',gap:6,padding:'3px 8px',margin:'2px 4px 2px 0',borderRadius:8,border:'1px solid var(--line-2)',background:'var(--paper-2)',fontSize:12.5};


const fbSemAcento=(t)=>String(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();





function FbListaLivre({valor,opcoes,onChange,exemplo,semOutro,vazio,soNome}){
const[outro,setOutro]=useState(''),[busca,setBusca]=useState('');
const v=Array.isArray(valor)?valor:[],ops=opcoes||[];
const todas=[...ops,...v.filter((x)=>!ops.some((o)=>o.chave===x)).map((x)=>({chave:x,nome:x}))];
const q=fbSemAcento(busca.trim());
const vistas=q?todas.filter((o)=>fbSemAcento(o.nome+' '+o.chave+' '+(o.classe||'')).includes(q)):todas;
const mostra=vistas.slice(0,150);
const troca=(k)=>onChange(v.includes(k)?v.filter((y)=>y!==k):[...v,k]);
const poe=(x)=>{const t=String(x||'').trim();if(t&&!v.includes(t))onChange([...v,t]);};
return React.createElement("div",{style:{display:'grid',gap:5,minWidth:0}},
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},React.createElement("b",null,v.length," de ",todas.length," marcadas"),!v.length&&vazio?' — '+vazio:'',vistas.some((o)=>!v.includes(o.chave))&&React.createElement("button",{type:"button",onClick:()=>onChange([...v,...vistas.map((o)=>o.chave).filter((k)=>!v.includes(k))]),style:{marginLeft:8,border:'none',background:'none',cursor:'pointer',color:'var(--teal-deep)',fontSize:12,padding:0}},q?`marcar as ${vistas.length} da busca`:'marcar todas'),v.length>0&&React.createElement("button",{type:"button",onClick:()=>onChange([]),style:{marginLeft:8,border:'none',background:'none',cursor:'pointer',color:'var(--teal-deep)',fontSize:12,padding:0}},"desmarcar todas")),
v.length>0&&React.createElement("div",null,v.slice(0,40).map((x)=>React.createElement("span",{key:x,style:fbChip},fbNomeDe(ops,x,soNome),React.createElement("button",{type:"button","aria-label":'Tirar '+x,onClick:()=>onChange(v.filter((y)=>y!==x)),style:{border:'none',background:'none',cursor:'pointer',fontWeight:700,color:'var(--down)'}},"×"))),v.length>40&&React.createElement("span",{className:"ev-sub",style:{fontSize:12}}," +",v.length-40," marcadas")),
todas.length>8&&React.createElement("input",{type:"search","aria-label":"Buscar na lista",value:busca,onChange:(e)=>setBusca(e.target.value),placeholder:"Buscar na lista…",style:{maxWidth:260,width:'100%'}}),
todas.length>0&&React.createElement("div",{style:{maxHeight:190,overflowY:'auto',border:'1px solid var(--line-2)',borderRadius:8,padding:'6px 8px',display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(170px,1fr))',gap:'3px 12px'}},
mostra.map((o)=>React.createElement("label",{key:o.chave,style:{display:'flex',gap:6,alignItems:'flex-start',fontSize:12.5,cursor:'pointer',minWidth:0,overflowWrap:'anywhere'}},React.createElement("input",{type:"checkbox",checked:v.includes(o.chave),onChange:()=>troca(o.chave)}),React.createElement("span",null,o.nome&&o.nome!==o.chave?soNome?o.nome:`${o.nome} (${o.chave})`:o.chave,o.classe?' · '+o.classe:''))),
!mostra.length&&React.createElement("span",{className:"ev-sub"},"Nada na lista com esse texto.")
),
vistas.length>mostra.length&&React.createElement("div",{className:"ev-sub"},"Mostrando ",mostra.length," de ",vistas.length,": escreva na busca para achar as outras."),
!semOutro&&React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap'}},
React.createElement("input",{value:outro,onChange:(e)=>setOutro(e.target.value),onKeyDown:(e)=>{if(e.key==='Enter'){e.preventDefault();poe(outro);setOutro('');}},placeholder:'Outro (ex.: '+(exemplo||'')+')',style:{width:190,maxWidth:'100%'}}),
React.createElement("button",{type:"button",className:"btn-sm",disabled:!outro.trim(),onClick:()=>{poe(outro);setOutro('');}},"Adicionar")
)
);
}


const FB_PARTES_EXC=[{campo:'casas',rotulo:'Casas',todos:'todas as casas',exemplo:'cloudbet'},{campo:'esportes',rotulo:'Esportes',todos:'todos os esportes',exemplo:'basketball'},
{campo:'tipos',rotulo:'Tipo de linha',todos:'todos os tipos',fixa:true},{campo:'mercados',rotulo:'Mercados',todos:'todos os mercados',exemplo:'prop:first_scorer'},
{campo:'periodos',rotulo:'Períodos',todos:'todos os períodos',fixa:true}];
const fbExcVazia=(r)=>!r||FB_PARTES_EXC.every((p)=>!(Array.isArray(r[p.campo])&&r[p.campo].length));
const fbJunta=(l,ultimo)=>l.length<2?l.join(''):l.slice(0,-1).join(', ')+' '+ultimo+' '+l[l.length-1];

const fbFraseExcecao=(r,op)=>{
if(fbExcVazia(r))return'Regra vazia: preencha pelo menos uma parte (casa, esporte, tipo de linha, mercado ou período). Do jeito que está, ela bloquearia tudo e não pode ser salva.';
const nomes=(campo)=>(r[campo]||[]).map((x)=>fbNomeDe(op&&op[campo],x,true));
const casas=nomes('casas'),esportes=nomes('esportes'),tipos=nomes('tipos').map((t)=>t.charAt(0).toLowerCase()+t.slice(1)),mercados=nomes('mercados'),periodos=nomes('periodos');
const f='Não enviar '+(tipos.length?fbJunta(tipos,'nem')+(casas.length?' de ':''):'')+(casas.length?fbJunta(casas,'nem'):tipos.length?' de nenhuma casa':'nenhuma casa')+(
esportes.length?(esportes.length===1?' no esporte ':' nos esportes ')+fbJunta(esportes,'e'):' em qualquer esporte')+(
mercados.length?(mercados.length===1?', no mercado ':', nos mercados ')+fbJunta(mercados,'e'):', em qualquer mercado')+(
periodos.length?(periodos.length===1?', só no período ':', só nos períodos ')+fbJunta(periodos,'e')+' (linha de jogo; prop de jogador não tem período)':'')+'.';
return(r.ativa?'':'DESLIGADA (não bloqueia nada agora) — ')+f;};
function FbExcecoes({c,valor,op,onChange,extra}){
const l=Array.isArray(valor)?valor:[];


const gravadas=extra&&Array.isArray(extra.gravadas)?extra.gravadas:[],doServico=extra&&Array.isArray(extra.doServico)&&extra.doServico.length===gravadas.length?extra.doServico:null;
const barrou=(r,i)=>{const x=doServico&&gravadas[i]&&fbIgual(gravadas[i],r)?doServico[i]:null,n=x&&typeof x==='object'?Number(x.recusas):NaN;return Number.isFinite(n)&&n>=0?n:null;};
const muda=(i,campo,v)=>onChange(l.map((r,j)=>j===i?{...r,[campo]:v}:r));
const cheia=c.max!=null&&l.length>=c.max;
return React.createElement("div",{style:{display:'grid',gap:10,minWidth:0}},
!l.length&&React.createElement("div",{className:"ev-sub"},"Nenhuma exceção: vale só o que está nas outras abas."),
l.map((r,i)=>{const vazia=fbExcVazia(r);return(
React.createElement("div",{key:i,style:{border:'1px solid '+(vazia?'var(--down)':'var(--line-2)'),borderRadius:10,padding:'10px 12px',display:'grid',gap:8,background:r.ativa?undefined:'var(--paper-2)',minWidth:0}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8,flexWrap:'wrap'}},
React.createElement("b",{style:{fontSize:13.5}},"Exceção ",i+1),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}},
React.createElement("label",{style:{display:'inline-flex',gap:6,alignItems:'center',cursor:'pointer',fontSize:13}},React.createElement("input",{type:"checkbox",checked:!!r.ativa,onChange:(e)=>muda(i,'ativa',e.target.checked)}),r.ativa?'Ligada':'Desligada'),
React.createElement("button",{type:"button",className:"btn-sm",disabled:cheia,onClick:()=>onChange([...l.slice(0,i+1),JSON.parse(JSON.stringify(r)),...l.slice(i+1)])},"Duplicar"),
React.createElement("button",{type:"button",className:"btn-sm b-red",onClick:()=>onChange(l.filter((_,j)=>j!==i))},"Apagar")
)
),
React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(230px,1fr))',gap:8,minWidth:0}},
FB_PARTES_EXC.map((p)=>{const v=Array.isArray(r[p.campo])?r[p.campo]:[];return(
React.createElement("details",{key:p.campo,style:{border:'1px solid var(--line)',borderRadius:8,padding:'6px 8px',minWidth:0}},
React.createElement("summary",{style:{cursor:'pointer',fontSize:13,overflowWrap:'anywhere'}},React.createElement("b",null,p.rotulo,":")," ",v.length?v.map((x)=>fbNomeDe(op[p.campo],x,true)).join(', '):React.createElement("span",{className:"ev-sub"},p.todos)),
React.createElement("div",{style:{marginTop:6}},React.createElement(FbListaLivre,{valor:v,opcoes:op[p.campo],onChange:(x)=>muda(i,p.campo,x),exemplo:p.exemplo,semOutro:!!p.fixa||(p.campo==='esportes'||p.campo==='mercados')&&(op[p.campo]||[]).length>0,soNome:p.campo==='esportes'||p.campo==='mercados',vazio:'vale para '+p.todos}))
));})
),
React.createElement("label",{style:{display:'grid',gap:3,fontSize:12.5}},React.createElement("span",{className:"ev-sub"},"Nota (para quem ler depois: por que esta regra existe)"),
React.createElement("input",{value:r.nota??'',maxLength:c.maxNota||undefined,onChange:(e)=>muda(i,'nota',e.target.value),style:{width:'100%',maxWidth:520}})),
React.createElement("div",{style:{fontSize:13,fontWeight:600,color:vazia?'var(--down)':r.ativa?'var(--navy-700)':'var(--on-surface-variant)'}},fbFraseExcecao(r,op)),
barrou(r,i)!=null&&React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Barrou ",barrou(r,i)," ",barrou(r,i)===1?'linha':'linhas'," desde que o serviço subiu.")
));}),
React.createElement("div",null,React.createElement("button",{type:"button",className:"btn-sm b-green",disabled:cheia,onClick:()=>onChange([...l,{casas:[],esportes:[],tipos:[],mercados:[],periodos:[],nota:'',ativa:true}])},"Nova exceção"),
cheia&&React.createElement("span",{className:"ev-sub",style:{marginLeft:8}},"O grupo já tem o máximo de exceções (",fbNum(c.max),")."))
);
}


function FbMapa({c,valor,opcoes,onChange}){
const[casa,setCasa]=useState(''),[n,setN]=useState('');
const v=valor&&typeof valor==='object'?valor:{};
const faltam=(opcoes||[]).filter((o)=>!(o.chave in v));
return React.createElement("div",null,
Object.keys(v).sort().map((k)=>React.createElement("div",{key:k,style:{display:'flex',gap:6,alignItems:'center',margin:'3px 0'}},React.createElement("span",{style:{minWidth:170,fontSize:13}},fbNomeDe(opcoes,k)),
React.createElement("input",{type:"number","aria-label":c.rotulo+': '+k,step:"any",min:c.min,max:c.max,value:v[k]??'',onChange:(e)=>onChange({...v,[k]:e.target.value===''?null:Number(e.target.value)}),style:{width:90}}),React.createElement("span",{className:"ev-sub"},c.unidade||''),
React.createElement("button",{type:"button",className:"btn-sm b-red",onClick:()=>{const x={...v};delete x[k];onChange(x);}},"Tirar"))),
!Object.keys(v).length&&React.createElement("span",{className:"ev-sub"},"(nenhuma casa com número próprio)"),
React.createElement("div",{style:{display:'flex',gap:6,flexWrap:'wrap',marginTop:4}},
React.createElement("select",{"aria-label":c.rotulo+': casa a acrescentar',value:casa,onChange:(e)=>setCasa(e.target.value),style:{maxWidth:240}},React.createElement("option",{value:""},"Casa…"),faltam.map((o)=>React.createElement("option",{key:o.chave,value:o.chave},o.nome&&o.nome!==o.chave?`${o.nome} (${o.chave})`:o.chave))),
React.createElement("input",{type:"number","aria-label":c.rotulo+': valor da casa a acrescentar',step:"any",min:c.min,max:c.max,value:n,onChange:(e)=>setN(e.target.value),placeholder:c.unidade||'valor',style:{width:90}}),
React.createElement("button",{type:"button",className:"btn-sm",disabled:!casa||n==='',onClick:()=>{onChange({...v,[casa]:Number(n)});setCasa('');setN('');}},"Adicionar")
)
);
}


const fbErroCampo=(c,valor)=>{
if(c.tipo==='vigiaPortal'){const e=fbErrosDaVigia(c,valor);return e.length?e.map((x)=>`${x.f.rotulo}: ${x.erro}`).join('; '):null;}
if(c.tipo==='inteiro'||c.tipo==='numero')return!(c.vazio&&valor==null)&&(valor==null||Number.isNaN(valor)||c.min!=null&&valor<c.min||c.max!=null&&valor>c.max||c.tipo==='inteiro'&&!Number.isInteger(valor))?'valor fora da faixa':null;
if(c.tipo==='excecoes'){const i=(Array.isArray(valor)?valor:[]).findIndex(fbExcVazia);return i<0?null:`a exceção ${i+1} está vazia: preencha pelo menos uma parte (casa, esporte, tipo de linha, mercado ou período) ou apague a regra`;}
return null;};



const fbVigiaC=(op)=>op&&op.vigiaPortal&&typeof op.vigiaPortal==='object'&&Array.isArray(op.vigiaPortal.campos)?{...op.vigiaPortal,tipo:'vigiaPortal'}:null;
const fbErroDaVigia=(f,x)=>{if(f.tipo==='inteiro')return x==null||x===''||Number.isNaN(x)?'preencha este campo':!Number.isInteger(x)||f.min!=null&&x<f.min||f.max!=null&&x>f.max?'valor fora da faixa ('+fbFaixa(f)+', número inteiro)':null;const t=typeof x==='string'?x:'';if(!t)return'preencha este campo';if(/\s/.test(t))return'não pode ter espaço';if(f.prefixo&&t.indexOf(f.prefixo)!==0)return'precisa começar com '+f.prefixo;if(f.formato&&!new RegExp(f.formato).test(t))return`aceita de ${f.min} a ${f.max} caracteres, só letras minúsculas, números, hífen e sublinhado`;if(f.max!=null&&t.length>f.max)return`aceita no máximo ${f.max} caracteres`;return null;};
const fbErrosDaVigia=(c,v)=>v==null?[]:(c.campos||[]).map((f)=>({f,erro:fbErroDaVigia(f,(typeof v==='object'?v:{})[f.chave])})).filter((x)=>x.erro);


function FbVigiaPortal({c,valor,onChange,mudou}){
const ultima=useRef(null);
const ligada=!!valor&&typeof valor==='object',id='fb-'+c.chave,erros=fbErrosDaVigia(c,valor);
if(ligada)ultima.current=valor;
const vazia=()=>Object.fromEntries((c.campos||[]).map((f)=>[f.chave,f.tipo==='inteiro'?null:'']));
return React.createElement("div",{style:{padding:'10px 0',borderTop:'1px solid var(--line)',display:'grid',gap:4,alignContent:'start',minWidth:0,gridColumn:'1 / -1'}},
React.createElement("label",{htmlFor:id,style:{fontWeight:600,fontSize:13.5}},c.rotulo,mudou&&React.createElement("span",{className:"pill",style:{marginLeft:8}},"mudou")),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},c.ajuda),
React.createElement("label",{style:{display:'inline-flex',gap:8,alignItems:'center',cursor:'pointer'}},React.createElement("input",{id:id,type:"checkbox",checked:ligada,onChange:(e)=>onChange(e.target.checked?ultima.current||vazia():null)}),ligada?'Ligado':'Desligado'),
ligada&&React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:'0 22px',minWidth:0}},
(c.campos||[]).map((f)=>{const fid=id+'-'+f.chave,num=f.tipo==='inteiro',x=valor[f.chave],er=(erros.find((e)=>e.f===f)||{}).erro,muda=(v)=>onChange({...valor,[f.chave]:v});return(
React.createElement("div",{key:f.chave,style:{padding:'8px 0',display:'grid',gap:4,alignContent:'start',minWidth:0}},
React.createElement("label",{htmlFor:fid,style:{fontWeight:600,fontSize:13.5}},f.rotulo),
f.ajuda&&React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},f.ajuda),
num?React.createElement("input",{id:fid,type:"number",step:1,min:f.min??undefined,max:f.max??undefined,value:x??'',onChange:(e)=>muda(e.target.value===''?null:Number(e.target.value)),style:{width:120,borderColor:er?'var(--down)':undefined}}):
React.createElement("input",{id:fid,value:x??'',maxLength:f.max||undefined,spellCheck:false,onChange:(e)=>muda(e.target.value),style:{width:f.tipo==='endereco'?420:260,maxWidth:'100%',borderColor:er?'var(--down)':undefined}}),
React.createElement("div",{className:"ev-sub"},num&&fbFaixa(f)?React.createElement(React.Fragment,null,"Aceita ",fbFaixa(f),". "):null,er&&React.createElement("b",{style:{color:'var(--down)'}},er))
));})
),
React.createElement("div",{className:"ev-sub"},"Desligado: o grupo é gravado sem a vigia. Ligado: os quatro campos são obrigatórios.")
);
}

const fbCampoLargo=(c)=>c.tipo==='lista'||c.tipo==='mapa'||c.tipo==='excecoes';

function FbCampo({c,valor,onChange,op,mudou,travadas,nota,extra}){
if(c.tipo==='vigiaPortal')return React.createElement(FbVigiaPortal,{c:c,valor:valor,onChange:onChange,mudou:mudou});
const id='fb-'+c.chave.replace('.','-');
const num=c.tipo==='inteiro'||c.tipo==='numero';
const erro=fbErroCampo(c,valor),fora=num&&!!erro;
const fixas=c.opcoes?c.chave==='tipos'?op.tipos:c.chave==='classes'?op.classes:c.chave==='estado'?op.estados:c.opcoes.map((x)=>({chave:x,nome:c.rotulos&&c.rotulos[x]||x})):null;
let ed;
if(c.tipo==='opcao')ed=React.createElement("select",{id:id,value:valor??'',onChange:(e)=>onChange(e.target.value)},fixas.map((o)=>React.createElement("option",{key:o.chave,value:o.chave,disabled:(travadas||[]).includes(o.chave)},o.nome,(travadas||[]).includes(o.chave)?' — só o admin master':'')));else
if(c.tipo==='booleano')ed=React.createElement("label",{style:{display:'inline-flex',gap:8,alignItems:'center',cursor:'pointer'}},React.createElement("input",{id:id,type:"checkbox",checked:!!valor,onChange:(e)=>onChange(e.target.checked)}),valor?'Ligado':'Desligado');else
if(num)ed=React.createElement("span",{style:{display:'inline-flex',gap:6,alignItems:'center'}},React.createElement("input",{id:id,type:"number",step:c.tipo==='inteiro'?1:'any',min:c.min??undefined,max:c.max??undefined,value:valor??'',placeholder:c.vazio?'vazio':undefined,onChange:(e)=>onChange(e.target.value===''?null:Number(e.target.value)),style:{width:120,borderColor:fora?'var(--down)':undefined}}),React.createElement("span",{className:"ev-sub"},c.unidade||''));else
if(c.tipo==='cor')ed=React.createElement("span",{style:{display:'inline-flex',gap:8,alignItems:'center'}},React.createElement("input",{type:"color","aria-label":c.rotulo,value:/^#[0-9a-fA-F]{6}$/.test(valor||'')?valor:'#000000',onChange:(e)=>onChange(e.target.value.toUpperCase())}),React.createElement("input",{id:id,value:valor??'',onChange:(e)=>onChange(e.target.value),style:{width:110}}));else
if(c.tipo==='lista'&&fixas)ed=React.createElement("div",null,fixas.map((o)=>{const on=(valor||[]).includes(o.chave);return React.createElement("label",{key:o.chave,style:{...fbChip,cursor:'pointer',background:on?'var(--teal-deep)':'var(--paper-2)',color:on?'#fff':'inherit'}},React.createElement("input",{type:"checkbox",checked:on,onChange:()=>onChange(on?(valor||[]).filter((x)=>x!==o.chave):[...(valor||[]),o.chave]),style:{display:'none'}}),o.nome);}));else
if(c.tipo==='lista')ed=React.createElement(FbListaLivre,{valor:valor,opcoes:op[c.de],onChange:onChange,exemplo:c.de==='casas'?'cloudbet':c.de==='mercados'?'prop:first_scorer':c.de==='esportes'?'basketball':'NBA',soNome:c.de==='esportes'||c.de==='ligas'||c.de==='mercados',semOutro:(c.de==='esportes'||c.de==='ligas'||c.de==='mercados')&&(op[c.de]||[]).length>0});else
if(c.tipo==='mapa')ed=React.createElement(FbMapa,{c:c,valor:valor,opcoes:op.casas,onChange:onChange});else
if(c.tipo==='excecoes')ed=React.createElement(FbExcecoes,{c:c,valor:valor,op:op,onChange:onChange,extra:extra});else
ed=React.createElement("input",{id:id,value:valor??'',maxLength:c.max||undefined,onChange:(e)=>onChange(e.target.value),style:{width:260,maxWidth:'100%'}});
return React.createElement("div",{style:{padding:'10px 0',borderTop:'1px solid var(--line)',display:'grid',gap:4,alignContent:'start',minWidth:0,gridColumn:fbCampoLargo(c)?'1 / -1':undefined}},
React.createElement("label",{htmlFor:id,style:{fontWeight:600,fontSize:13.5}},c.rotulo,mudou&&React.createElement("span",{className:"pill",style:{marginLeft:8}},"mudou")),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},c.ajuda),
ed,
nota&&React.createElement("div",{style:{fontSize:12.5,color:'#9a6700',fontWeight:600}},nota),
React.createElement("div",{className:"ev-sub"},fbFaixa(c)&&(num||c.tipo==='mapa')?React.createElement(React.Fragment,null,"Aceita ",fbFaixa(c),". "):null,"Padrão: ",fbValor(c,c.padrao,op),erro&&React.createElement("b",{style:{color:'var(--down)'}}," · ",erro))
);
}



function FbRobo({op}){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[banca,setBanca]=useState(null),[casas,setCasas]=useState(null),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
const vivo=useRef(true);
useEffect(()=>{vivo.current=true;return()=>{vivo.current=false;};},[]);
const carrega=()=>leJson('/api/fishbot/robo').then((x)=>{if(vivo.current){setD(x);setErro('');}}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current)setErro('A configuração do robô não carregou: '+e.message);});
useEffect(()=>{carrega();},[]);
const r=d&&d.robo&&typeof d.robo==='object'&&Array.isArray(d.robo.casas)?d.robo:null,lim=d&&d.limites||{};
const bancaEd=banca??(r?r.bancaUsd:null),casasEd=casas??(r?r.casas:[]);
const fora=bancaEd==null||Number.isNaN(bancaEd)||lim.bancaMin!=null&&bancaEd<lim.bancaMin||lim.bancaMax!=null&&bancaEd>lim.bancaMax;
const mudou=!r||!fbIgual(bancaEd,r.bancaUsd)||!fbIgual(casasEd,r.casas);
const nomes=(l)=>l.length?l.map((x)=>fbNomeDe(op&&op.casas,x)).join(', '):'(nenhuma)';
const salvar=async()=>{
if(!(await confirma(`Salvar a configuração do robô?\n\n• Banca do robô: US$ ${fbNum(bancaEd)}\n• Casas em que o robô aposta: ${nomes(casasEd)}\n\nVale para todos os grupos com a espera da tip apertada ligada. O FishBot passa a usar em até 30 segundos.`)))return;
setBusy(true);setMsg('');
try{const x=await leJson('/api/fishbot/robo',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({bancaUsd:bancaEd,casas:casasEd}),prazoMs:0});
if(vivo.current){setMsg('✅ '+x.mensagem);setD(x);setBanca(null);setCasas(null);}}
catch(e){if(fbSemSessao(e))return;if(vivo.current)setMsg('❌ O robô não foi gravado: '+e.message);}
if(vivo.current)setBusy(false);};
return React.createElement("div",{style:{...fbCaixa,display:'grid',gap:8}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,flexWrap:'wrap'}},
React.createElement("b",{style:{fontSize:15}},"Robô (reserva de liquidez)"),
d&&!erro&&React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center'}},
r&&mudou&&React.createElement("span",{className:"ev-sub"},"mudança ainda não salva"),
React.createElement("button",{className:"btn-sm",disabled:busy||!r||!mudou,onClick:()=>{setBanca(null);setCasas(null);setMsg('');}},"Desfazer"),
React.createElement("button",{className:"btn-sm b-green",disabled:busy||!mudou||fora,onClick:salvar},busy?'Salvando…':'Salvar')
)
),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"O que o robô tentaria apostar em cada linha — a stake da regra × esta banca — fica reservado para ele nas casas marcadas. Vale para todos os grupos que têm a espera da tip apertada ligada. Casa não marcada nunca espera."),
msg&&React.createElement("div",{className:"toast",style:{whiteSpace:'pre-wrap'}},msg),
erro?React.createElement("div",{style:fbErroCx},erro," ",React.createElement("button",{className:"btn-sm",onClick:carrega},"Tentar de novo")):!d?React.createElement("div",{className:"ev-sub"},"Carregando…"):React.createElement(React.Fragment,null,
!r&&React.createElement("div",{style:fbErroCx},"A configuração do robô gravada não pôde ser lida: o FishBot está sem reserva para o robô (nenhuma tip espera). Preencha e salve para corrigir."),
React.createElement("div",{style:{display:'grid',gap:4}},
React.createElement("label",{htmlFor:"fb-robo-banca",style:{fontWeight:600,fontSize:13.5}},"Banca do robô (US$)"),
React.createElement("span",{style:{display:'inline-flex',gap:6,alignItems:'center'}},React.createElement("input",{id:"fb-robo-banca",type:"number",step:"any",min:lim.bancaMin??undefined,max:lim.bancaMax??undefined,value:bancaEd??'',onChange:(e)=>setBanca(e.target.value===''?NaN:Number(e.target.value)),style:{width:140,borderColor:fora?'var(--down)':undefined}}),React.createElement("span",{className:"ev-sub"},"US$")),
React.createElement("div",{className:"ev-sub"},"Quanto o robô tem para apostar. Aceita de ",fbNum(lim.bancaMin)," até ",fbNum(lim.bancaMax)," US$. Com 0, nenhuma tip espera.",fora&&React.createElement("b",{style:{color:'var(--down)'}}," · valor fora da faixa"))
),
React.createElement("div",{style:{display:'grid',gap:4,borderTop:'1px solid var(--line)',paddingTop:10}},
React.createElement("div",{style:{fontWeight:600,fontSize:13.5}},"Casas em que o robô aposta"),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Marque toda casa que estiver ligada no robô (até ",fbNum(lim.maxCasas),"). Sem nenhuma marcada, nenhuma tip espera."),
React.createElement(FbListaLivre,{valor:casasEd,opcoes:op?op.casas:[],onChange:setCasas,exemplo:"cloudbet"})
),
d.atualizadoEm?React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Gravado ",fbHa(d.atualizadoEm)," (",fbHora(d.atualizadoEm),")",d.por?' por '+d.por:'',"."):null
)
);
}


function FbArredondamento(){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[pct,setPct]=useState(null),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
const vivo=useRef(true);
useEffect(()=>{vivo.current=true;return()=>{vivo.current=false;};},[]);
const carrega=()=>leJson('/api/fishbot/arredondamento').then((x)=>{if(vivo.current){setD(x);setErro('');}}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current)setErro('O percentual da aposta mínima não carregou: '+e.message);});
useEffect(()=>{carrega();},[]);
const a=d&&d.arredondamento&&typeof d.arredondamento==='object'&&typeof d.arredondamento.pctDaMinima==='number'?d.arredondamento:null,lim=d&&d.limites||{};
const pctEd=pct??(a?a.pctDaMinima:null);
const fora=pctEd==null||Number.isNaN(pctEd)||lim.pctMin!=null&&pctEd<lim.pctMin||lim.pctMax!=null&&pctEd>lim.pctMax;
const mudou=!a||!fbIgual(pctEd,a.pctDaMinima);
const salvar=async()=>{
if(!(await confirma(`Salvar o percentual da aposta mínima?\n\n• Arredondar quando o valor for pelo menos ${fbNum(pctEd)}% da aposta mínima da casa${pctEd===0?' (0 = função desligada)':''}\n\nVale para todos os grupos. O FishBot passa a usar em até 30 segundos.`)))return;
setBusy(true);setMsg('');
try{const x=await leJson('/api/fishbot/arredondamento',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pctDaMinima:pctEd}),prazoMs:0});
if(vivo.current){setMsg('✅ '+x.mensagem);setD(x);setPct(null);}}
catch(e){if(fbSemSessao(e))return;if(vivo.current)setMsg('❌ O percentual não foi gravado: '+e.message);}
if(vivo.current)setBusy(false);};
return React.createElement("div",{style:{...fbCaixa,display:'grid',gap:8}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,flexWrap:'wrap'}},
React.createElement("b",{style:{fontSize:15}},"Aposta mínima da casa"),
d&&!erro&&React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center'}},
a&&mudou&&React.createElement("span",{className:"ev-sub"},"mudança ainda não salva"),
React.createElement("button",{className:"btn-sm",disabled:busy||!a||!mudou,onClick:()=>{setPct(null);setMsg('');}},"Desfazer"),
React.createElement("button",{className:"btn-sm b-green",disabled:busy||!mudou||fora,onClick:salvar},busy?'Salvando…':'Salvar')
)
),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"A aposta mínima de cada casa vem do grupo de clones do Peixe Admin. Se o valor da tip ficar abaixo da mínima da casa, mas for pelo menos este percentual dela, o valor sobe para a mínima e a tip sai com a observação do arredondamento (o percentual da stake não muda). Abaixo deste percentual, a tip não sai. Casa sem mínima cadastrada: nada muda. Com 0, a função fica desligada."),
msg&&React.createElement("div",{className:"toast",style:{whiteSpace:'pre-wrap'}},msg),
erro?React.createElement("div",{style:fbErroCx},erro," ",React.createElement("button",{className:"btn-sm",onClick:carrega},"Tentar de novo")):!d?React.createElement("div",{className:"ev-sub"},"Carregando…"):React.createElement(React.Fragment,null,
!a&&React.createElement("div",{style:fbErroCx},"O percentual gravado não pôde ser lido: o FishBot está com o arredondamento desligado. Preencha e salve para corrigir."),
React.createElement("div",{style:{display:'grid',gap:4}},
React.createElement("label",{htmlFor:"fb-arredondamento-pct",style:{fontWeight:600,fontSize:13.5}},"Arredondar quando o valor for pelo menos X% da aposta mínima"),
React.createElement("span",{style:{display:'inline-flex',gap:6,alignItems:'center'}},React.createElement("input",{id:"fb-arredondamento-pct",type:"number",step:"any",min:lim.pctMin??undefined,max:lim.pctMax??undefined,value:pctEd??'',onChange:(e)=>setPct(e.target.value===''?NaN:Number(e.target.value)),style:{width:120,borderColor:fora?'var(--down)':undefined}}),React.createElement("span",{className:"ev-sub"},"% da aposta mínima")),
React.createElement("div",{className:"ev-sub"},"Aceita de ",fbNum(lim.pctMin)," até ",fbNum(lim.pctMax)," (pode ter casa decimal).",fora&&React.createElement("b",{style:{color:'var(--down)'}}," · valor fora da faixa"))
),
d.atualizadoEm?React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Gravado ",fbHa(d.atualizadoEm)," (",fbHora(d.atualizadoEm),")",d.por?' por '+d.por:'',"."):null
)
);
}



function FbBots(){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
const[ed,setEd]=useState(null);
const vivo=useRef(true);
useEffect(()=>{vivo.current=true;return()=>{vivo.current=false;};},[]);
const[grupos,setGrupos]=useState({});
const carrega=()=>{leJson('/api/fishbot/bots').then((x)=>{if(vivo.current){setD(x);setErro('');}}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current)setErro('O cadastro de bots não carregou: '+e.message);});
leJson('/api/fishbot/config').then((x)=>{if(vivo.current)setGrupos(x&&x.grupos||{});}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current)setErro('Os grupos não carregaram (para mostrar quem usa cada bot): '+e.message);});};
useEffect(()=>{carrega();},[]);
const bots=d&&d.bots||{},nomes=Object.keys(bots).sort(),lim=d&&d.limites||{};

const usoDe={};for(const[id,g]of Object.entries(grupos)){const b=String(g&&g.bot||'').trim();if(b)(usoDe[b]=usoDe[b]||[]).push(id);}
const semCadastro=Object.keys(usoDe).filter((b)=>!bots[b]).sort();
const manda=async(caminho,corpo,falha)=>{setBusy(true);setMsg('');
try{const x=await leJson(caminho,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(corpo),prazoMs:0});
if(vivo.current){setD(x);setEd(null);setMsg('✅ '+x.mensagem);}}
catch(e){if(fbSemSessao(e))return;if(vivo.current)setMsg('❌ '+falha+': '+e.message);}
if(vivo.current)setBusy(false);};
const nomeOk=ed&&/^[a-z0-9][a-z0-9_-]{0,59}$/.test(ed.nome.trim()),urlOk=ed&&/^https?:\/\/\S+$/.test(ed.url.trim());
const tokenOk=ed&&(ed.token.trim()?ed.token.trim().length>=(lim.tokenMin||16):!ed.novo);
const salvar=()=>manda('/api/fishbot/bots',{nome:ed.nome.trim(),url:ed.url.trim(),...(ed.token.trim()?{token:ed.token.trim()}:{})},'O bot não foi gravado');
const remover=async(nome)=>{if(!(await window.confirma(`Remover o bot "${nome}" do cadastro?\n\nO grupo que aponta para ele fica sem este postador. Grupo ligado usando o bot impede a remoção.`)))return;manda('/api/fishbot/bots/remover',{nome},'O bot não foi removido');};
return React.createElement("div",{style:{...fbCaixa,display:'grid',gap:8}},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,flexWrap:'wrap'}},
React.createElement("b",{style:{fontSize:15}},"Bots postadores"),
d&&!erro&&!ed&&React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>{setEd({nome:'',url:'',token:'',novo:true});setMsg('');}},"+ Cadastrar bot")
),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Cada grupo sai pelo postador dele (o Caçador pelo postador do Caçador: envelope, cofre e stake em unidades). O campo ",React.createElement("b",null,"Bot")," do grupo diz o nome; aqui ficam o endereço da porta interna e o token de cada bot. ",React.createElement("b",null,"Todo bot tem de estar cadastrado aqui"),": grupo apontado para um nome que não existe fica sem postador. O token fica guardado cifrado e nunca volta para esta tela."),
msg&&React.createElement("div",{className:"toast",style:{whiteSpace:'pre-wrap'}},msg),
erro?React.createElement("div",{style:fbErroCx},erro," ",React.createElement("button",{className:"btn-sm",onClick:carrega},"Tentar de novo")):!d?React.createElement("div",{className:"ev-sub"},"Carregando…"):React.createElement(React.Fragment,null,
!nomes.length&&!semCadastro.length&&!ed&&React.createElement("div",{className:"ev-sub"},"Nenhum bot cadastrado."),
semCadastro.map((n)=>React.createElement("div",{key:'sem-'+n,style:{...fbErroCx,display:'flex',gap:10,alignItems:'center',justifyContent:'space-between',flexWrap:'wrap'}},
React.createElement("span",null,React.createElement("b",null,n)," é o bot do grupo ",usoDe[n].join(', ')," e ",React.createElement("b",null,"não está cadastrado"),". ",n==='peixe-bot'?'Ele ainda funciona pelo endereço antigo, gravado no servidor do FishBot antes deste cadastro existir. Cadastre-o aqui para ficar igual aos outros.':'O grupo está sem postador até ele ser cadastrado.'),
React.createElement("button",{className:"btn-sm",disabled:busy||!!ed,onClick:()=>{setEd({nome:n,url:'',token:'',novo:true});setMsg('');}},"Cadastrar")
)),
nomes.map((n)=>{const b=bots[n];return React.createElement("div",{key:n,style:{padding:'8px 10px',border:'1px solid var(--line-2)',borderRadius:10,display:'flex',gap:10,alignItems:'center',justifyContent:'space-between',flexWrap:'wrap'}},
React.createElement("div",{style:{fontSize:13,minWidth:0}},
React.createElement("b",null,n)," · ",React.createElement("span",{style:{wordBreak:'break-all'}},b.url),usoDe[n]?React.createElement("span",{className:"ev-sub"}," · usado por: ",usoDe[n].join(', ')):React.createElement("span",{className:"ev-sub"}," · nenhum grupo usa"),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Token termina em ••••",b.tokenFinal||'????',b.por?', gravado por '+b.por:'',b.em?' em '+fbHora(b.em):'',"."),
b.ilegivel&&React.createElement("div",{style:{...fbErroCx,marginTop:4}},"O token gravado não pôde ser lido (a chave mestra do painel mudou): o FishBot está sem este bot. Cole o token de novo.")
),
React.createElement("div",{style:{display:'flex',gap:8}},
React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>{setEd({nome:n,url:b.url,token:'',novo:false});setMsg('');}},"Editar"),
React.createElement("button",{className:"btn-sm b-red",disabled:busy,onClick:()=>remover(n)},"Remover")
)
);}),
ed&&React.createElement("div",{style:{padding:'10px 12px',border:'1px solid var(--line-2)',borderRadius:10,display:'grid',gap:8}},
React.createElement("b",{style:{fontSize:14}},ed.novo?'Bot novo':'Editar o bot '+ed.nome),
React.createElement("div",{style:{display:'grid',gap:4}},
React.createElement("label",{htmlFor:"fb-bot-nome",style:{fontWeight:600,fontSize:13}},"Nome (o mesmo do campo Bot do grupo)"),
React.createElement("input",{id:"fb-bot-nome",type:"text",spellCheck:false,disabled:!ed.novo,value:ed.nome,onChange:(e)=>setEd({...ed,nome:e.target.value}),placeholder:"ex.: cacador",style:{width:260,borderColor:ed.nome&&!nomeOk?'var(--down)':undefined}}),
React.createElement("div",{className:"ev-sub"},"Letras minúsculas, números, hífen ou sublinhado.")
),
React.createElement("div",{style:{display:'grid',gap:4}},
React.createElement("label",{htmlFor:"fb-bot-url",style:{fontWeight:600,fontSize:13}},"Endereço da porta interna do bot"),
React.createElement("input",{id:"fb-bot-url",type:"text",spellCheck:false,value:ed.url,onChange:(e)=>setEd({...ed,url:e.target.value}),placeholder:"http://nome-do-serviço:8080",style:{width:520,maxWidth:'-webkit-fill-available',borderColor:ed.url&&!urlOk?'var(--down)':undefined}}),
React.createElement("div",{className:"ev-sub"},"Começa com http:// ou https://, sem espaços.")
),
React.createElement("div",{style:{display:'grid',gap:4}},
React.createElement("label",{htmlFor:"fb-bot-token",style:{fontWeight:600,fontSize:13}},ed.novo?'Token da porta interna':'Token novo (vazio = fica o que está)'),
React.createElement("input",{id:"fb-bot-token",type:"password",autoComplete:"new-password",spellCheck:false,value:ed.token,onChange:(e)=>setEd({...ed,token:e.target.value}),placeholder:"cole o token aqui",style:{width:420,maxWidth:'-webkit-fill-available',borderColor:ed.token&&!tokenOk?'var(--down)':undefined}}),
React.createElement("div",{className:"ev-sub"},"De ",lim.tokenMin||16," a ",lim.tokenMax||512," caracteres, sem espaços. É o mesmo valor da variável do token interno do bot.")
),
React.createElement("div",{style:{display:'flex',gap:8}},
React.createElement("button",{className:"btn-sm b-green",disabled:busy||!nomeOk||!urlOk||!tokenOk,onClick:salvar},busy?'Salvando…':'Salvar bot'),
React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>{setEd(null);setMsg('');}},"Cancelar")
)
)
)
);
}



const fbSemChave=(p)=>{const{sharkChaveDefinida,sharkChaveFinal,sharkChavePor,sharkChaveEm,sharkChaveIlegivel,...r}=p||{};return r;};
function FbSharkChave({id,perfil,aoSalvar}){
const[digitada,setDigitada]=useState(''),[trocando,setTrocando]=useState(false),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
const vivo=useRef(true);
useEffect(()=>{vivo.current=true;return()=>{vivo.current=false;};},[]);
const definida=!!(perfil&&perfil.sharkChaveDefinida),campo='fb-shark-'+id;

const ilegivel=definida&&!!perfil.sharkChaveIlegivel;
const manda=async(caminho,corpo,falha)=>{setBusy(true);setMsg('');
try{const x=await leJson('/api/fishbot/grupos/'+encodeURIComponent(id)+caminho,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(corpo),prazoMs:0});
if(vivo.current){setDigitada('');setTrocando(false);setMsg('✅ '+x.mensagem);}aoSalvar();}
catch(e){if(fbSemSessao(e))return;if(vivo.current)setMsg('❌ '+falha+': '+e.message);}
if(vivo.current)setBusy(false);};
const salvar=()=>manda('/shark-chave',{chave:digitada.trim()},'A chave não foi gravada');
const remover=async()=>{if(!(await confirma(`Remover a chave do Shark Track do grupo "${id}"?\n\nAs tips deste grupo passam a aparecer no Shark Track com o parceiro padrão do bot, até outra chave ser gravada.`)))return;manda('/shark-chave/remover',{},'A chave não foi removida');};
return React.createElement("div",{style:{marginTop:10,padding:'10px 12px',border:'1px solid var(--line-2)',borderRadius:10,display:'grid',gap:6}},
React.createElement("b",{style:{fontSize:14}},"Shark Track deste grupo"),
React.createElement("div",{style:{fontSize:13}},definida?React.createElement(React.Fragment,null,"Chave do parceiro ",React.createElement("b",null,"definida"),", termina em ••••",perfil.sharkChaveFinal||'????',", gravada por ",perfil.sharkChavePor||'—'," em ",fbHora(perfil.sharkChaveEm),"."):React.createElement(React.Fragment,null,React.createElement("b",null,"Não definida"),": as tips deste grupo aparecem no Shark Track com o parceiro padrão do bot.")),
ilegivel&&React.createElement("div",{style:fbErroCx},"A chave gravada não pôde ser lida (a chave mestra do painel mudou). Cole a chave de novo."),
msg&&React.createElement("div",{className:"toast",style:{whiteSpace:'pre-wrap'}},msg),
!definida||trocando||ilegivel?React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}},
React.createElement("label",{htmlFor:campo,style:{fontWeight:600,fontSize:13}},definida?'Chave nova do parceiro':'Chave do parceiro no Shark Track'),
React.createElement("input",{id:campo,type:"password",autoComplete:"new-password",spellCheck:false,value:digitada,onChange:(e)=>setDigitada(e.target.value),placeholder:"cole a chave aqui",style:{width:300}}),
React.createElement("button",{type:"button",className:"btn-sm b-green",disabled:busy||!digitada.trim(),onClick:salvar},busy?'Salvando…':'Salvar chave'),
trocando&&React.createElement("button",{type:"button",className:"btn-sm",disabled:busy,onClick:()=>{setTrocando(false);setDigitada('');setMsg('');}},"Cancelar")
):React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap'}},
React.createElement("button",{type:"button",className:"btn-sm",disabled:busy,onClick:()=>{setTrocando(true);setMsg('');}},"Trocar"),
React.createElement("button",{type:"button",className:"btn-sm b-red",disabled:busy,onClick:remover},"Remover")
),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"A chave fica guardada cifrada e nunca volta para esta tela: depois de salva, só aparecem os 4 últimos caracteres.")
);
}



const fbAbaGuardada=(id)=>{try{return localStorage.getItem('fb-aba-'+id)||'';}catch(e){return'';}};
const fbGuardaAba=(id,aba)=>{try{localStorage.setItem('fb-aba-'+id,aba);}catch(e){console.warn('[tips dos grupos] a aba aberta não foi lembrada:',e.message);}};
function FbGrupo({id,perfil,versao,catalogo,op,aoSalvar,master,doServico}){
const[ed,setEd]=useState(perfil),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false),[aba,setAba]=useState(()=>fbAbaGuardada(id));
const sujo=useRef(false);


useEffect(()=>{if(sujo.current)setMsg('⚠️ Este grupo foi salvo por outra pessoa enquanto você editava: os campos voltaram ao que está gravado. Refaça a sua mudança.');setEd(perfil);},[JSON.stringify(fbSemChave(perfil))]);
const mudados=catalogo.filter((c)=>!fbIgual(fbLe(ed,c.chave),fbLe(perfil,c.chave)));


const vigiaC=fbVigiaC(op);
if(vigiaC&&!fbIgual(fbLe(ed,vigiaC.chave)??null,fbLe(perfil,vigiaC.chave)??null))mudados.push(vigiaC);
sujo.current=mudados.length>0;
const comErro=catalogo.map((c)=>({c,erro:fbErroCampo(c,fbLe(ed,c.chave))})).filter((x)=>x.erro);
if(vigiaC){const e=fbErroCampo(vigiaC,fbLe(ed,vigiaC.chave));if(e)comErro.push({c:vigiaC,erro:e});}

const porChave=Object.fromEntries(catalogo.map((c)=>[c.chave,c]));
const abas=(op.abas||[]).map((a)=>({...a,itens:(a.campos||[]).map((k)=>porChave[k]).filter(Boolean)}));
const soltos=catalogo.filter((c)=>!abas.some((a)=>a.itens.includes(c)));
if(soltos.length){if(abas.length)abas[abas.length-1].itens.push(...soltos);else abas.push({id:'campos',titulo:'Campos',ajuda:'',itens:soltos});}

if(vigiaC&&abas.length)(abas.find((a)=>a.comVigiaDoPortal)||abas[abas.length-1]).itens.push(vigiaC);
const visiveis=abas.filter((a)=>a.itens.length),atual=visiveis.find((a)=>a.id===aba)||visiveis[0];
const abasMudadas=visiveis.filter((a)=>a.itens.some((c)=>mudados.includes(c)));
const abre=(a)=>{setAba(a);fbGuardaAba(id,a);};

const semAoVivo=!master&&fbLe(perfil,'estado')!=='ao_vivo';
const estadoC=porChave.estado;
const salvar=async()=>{
if(comErro.length){setMsg('❌ Não dá para salvar ainda. '+comErro.map((x)=>`${x.c.rotulo}: ${x.erro}`).join('; ')+'.');return;}
let mud={};for(const c of mudados)mud=fbPoe(mud,c.chave,fbLe(ed,c.chave));
const resumo=mudados.map((c)=>`• ${c.rotulo}: de ${fbValor(c,fbLe(perfil,c.chave),op)} para ${fbValor(c,fbLe(ed,c.chave),op)}`).join('\n');
if(!(await confirma(`Salvar o perfil do grupo "${id}"?\n\n${resumo}\n\nO FishBot passa a usar a versão nova em até 30 segundos.`)))return;
setBusy(true);setMsg('');
try{const x=await leJson('/api/fishbot/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({versaoBase:versao,grupo:id,perfil:mud}),prazoMs:0});setMsg('✅ '+x.mensagem);aoSalvar();}
catch(e){if(fbSemSessao(e))return;setMsg('❌ '+e.message);}
setBusy(false);};
const est=fbLe(perfil,'estado'),res=op.resumo||{};
return React.createElement("div",{style:{...fbCaixa,minWidth:0}},

React.createElement("div",{style:{display:'flex',alignItems:'center',gap:'6px 14px',flexWrap:'wrap'}},
React.createElement("b",{style:{fontSize:16}},id),
React.createElement("span",{className:"pill",style:est==='ao_vivo'?{background:'var(--teal-deep)',color:'#fff'}:est==='teste'?{background:'#9a6700',color:'#fff'}:undefined},fbValor(estadoC,est,op)),
(res.linha||[]).map((k)=>porChave[k]&&React.createElement("span",{key:k,className:"ev-sub",style:{fontSize:12.5,overflowWrap:'anywhere'}},porChave[k].rotulo,": ",React.createElement("b",{style:{color:'var(--navy-700)'}},fbValor(porChave[k],fbLe(perfil,k),op)||'(vazio)',porChave[k].unidade&&fbLe(perfil,k)!=null?' '+porChave[k].unidade:'')))
),
React.createElement("div",{style:{marginTop:6}},
(res.selos||[]).map((x)=>porChave[x.chave]&&React.createElement("span",{key:x.chave,style:fbChip},x.rotulo,": ",React.createElement("b",null,fbValor(porChave[x.chave],fbLe(perfil,x.chave),op)))),
React.createElement("span",{style:{...fbChip,...(perfil.sharkChaveIlegivel?{borderColor:'var(--down)',color:'var(--down)'}:{})}},"Shark Track: ",React.createElement("b",null,perfil.sharkChaveIlegivel?'chave ilegível':perfil.sharkChaveDefinida?'chave definida':'sem chave própria'))
),
msg&&React.createElement("div",{className:"toast",style:{whiteSpace:'pre-wrap'}},msg),

React.createElement("div",{role:"tablist","aria-label":'Seções do perfil do grupo '+id,className:"seg",style:{marginTop:10,flexWrap:'nowrap',overflowX:'auto',maxWidth:'100%'}},
visiveis.map((a)=>{const n=a.itens.filter((c)=>mudados.includes(c)).length,ruim=a.itens.some((c)=>comErro.some((x)=>x.c===c));return(
React.createElement("button",{key:a.id,type:"button",role:"tab","aria-selected":a===atual,className:'segb'+(a===atual?' on':''),onClick:()=>abre(a.id),style:{whiteSpace:'nowrap',flex:'0 0 auto'}},
a.titulo,n>0&&React.createElement("span",{className:"pill",style:{marginLeft:6},title:"campos alterados e ainda não salvos"},n),ruim&&React.createElement("span",{"aria-label":"tem erro",style:{marginLeft:6,color:'var(--down)',fontWeight:700}},"● erro")
));})
),
atual&&React.createElement("div",{role:"tabpanel",style:{marginTop:8,minWidth:0}},
atual.ajuda&&React.createElement("div",{className:"ev-sub",style:{fontSize:12.5,marginBottom:4}},atual.ajuda),
atual.comChaveDoGrupo&&React.createElement(FbSharkChave,{id:id,perfil:perfil,aoSalvar:aoSalvar}),

React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:'0 22px',marginTop:atual.comChaveDoGrupo?10:0,minWidth:0}},
atual.itens.map((c)=>React.createElement(FbCampo,{key:c.chave,c:c,valor:fbLe(ed,c.chave),onChange:(v)=>setEd((p)=>fbPoe(p,c.chave,v)),op:op,mudou:mudados.includes(c),
extra:c.tipo==='excecoes'?{gravadas:fbLe(perfil,c.chave),doServico:doServico&&doServico[c.chave]}:null,
travadas:c.chave==='estado'&&semAoVivo?['ao_vivo']:null,nota:c.chave==='estado'&&semAoVivo?'Só o admin master põe o grupo Ao vivo. Você pode editar os filtros e usar Teste; quando o teste estiver ok, peça ao master a passagem para Ao vivo.':null}))
)
),

mudados.length>0&&React.createElement("div",{style:{position:'sticky',bottom:0,zIndex:2,marginTop:12,padding:'10px 12px',background:'var(--card)',border:'1px solid var(--line-2)',borderRadius:10,boxShadow:'0 -2px 10px rgba(0,40,75,.08)',display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,flexWrap:'wrap'}},
React.createElement("div",{style:{fontSize:13,minWidth:0}},React.createElement("b",null,mudados.length," ",mudados.length===1?'alteração':'alterações'," em ",abasMudadas.length," ",abasMudadas.length===1?'aba':'abas')," ",React.createElement("span",{className:"ev-sub"},"(",abasMudadas.map((a)=>a.titulo).join(', '),") — ainda não salvo"),
comErro.length>0&&React.createElement("div",{style:{color:'var(--down)',fontWeight:600,fontSize:12.5}},"Corrija antes de salvar: ",comErro.map((x)=>`${x.c.rotulo}: ${x.erro}`).join('; '),".")),
React.createElement("div",{style:{display:'flex',gap:8}},
React.createElement("button",{className:"btn-sm",disabled:busy,onClick:()=>{setEd(perfil);setMsg('');}},"Desfazer"),
React.createElement("button",{className:"btn-sm b-green",disabled:busy||comErro.length>0,onClick:salvar},busy?'Salvando…':'Salvar')
)
)
);
}
function TipsGruposTab({usuario}){
const[cfg,setCfg]=useState(null),[cat,setCat]=useState(null),[op,setOp]=useState(null),[erro,setErro]=useState('');
const[chave,setChave]=useState(null),[erroChave,setErroChave]=useState(''),[nova,setNova]=useState(null),[msg,setMsg]=useState('');
const[saude,setSaude]=useState(null),[erroSaude,setErroSaude]=useState('');
const[tips,setTips]=useState(null),[erroTips,setErroTips]=useState(''),[grupoTips,setGrupoTips]=useState('');
const[rec,setRec]=useState(null),[erroRec,setErroRec]=useState(''),[horas,setHoras]=useState('24');
const[pend,setPend]=useState(null),[erroPend,setErroPend]=useState('');
const[dolar,setDolar]=useState(null),[erroDolar,setErroDolar]=useState(''),[dolarEd,setDolarEd]=useState(null);
const[hist,setHist]=useState(null),[erroHist,setErroHist]=useState(''),[verHist,setVerHist]=useState(false);
const[novoId,setNovoId]=useState(''),[agora,setAgora]=useState(Date.now());
const vivo=useRef(true);
useEffect(()=>{vivo.current=true;return()=>{vivo.current=false;};},[]);
const post=(url,corpo)=>leJson(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(corpo||{}),prazoMs:0});

const carregaPerfil=()=>Promise.all([leJson('/api/fishbot/config'),leJson('/api/fishbot/catalogo'),leJson('/api/fishbot/opcoes')]).
then(([c,k,o])=>{if(!vivo.current)return;setCfg(c);setCat(k);setOp(o);setErro('');}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current)setErro('O perfil dos grupos não carregou: '+e.message);});
const carregaChave=()=>leJson('/api/fishbot/chave-servico').then((x)=>{if(vivo.current){setChave(x);setErroChave('');}}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current)setErroChave('O estado da chave de serviço não carregou: '+e.message);});
const carregaHist=()=>leJson('/api/fishbot/config/historico?limite=50').then((x)=>{if(vivo.current){setHist(x.versoes||[]);setErroHist('');}}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current)setErroHist('O histórico não carregou: '+e.message);});

const le=(url,set,setE)=>leJson(url,{prazoMs:0}).then((x)=>{if(vivo.current){set(x);setE('');}}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current){set(null);setE(e.message);}});
const carregaServico=()=>{setAgora(Date.now());return Promise.all([
le('/api/fishbot/saude',setSaude,setErroSaude),
le('/api/fishbot/tips?limite=100'+(grupoTips?'&grupo='+encodeURIComponent(grupoTips):''),setTips,setErroTips),
le('/api/fishbot/recusas?horas='+horas+(grupoTips?'&grupo='+encodeURIComponent(grupoTips):''),setRec,setErroRec),
le('/api/fishbot/pendentes',setPend,setErroPend)]);};

useEffect(()=>{carregaPerfil();carregaChave();const t=setInterval(carregaPerfil,60000);return()=>clearInterval(t);},[]);
useEffect(()=>{const v=saude&&saude.perfil&&saude.perfil.versao;if(cfg&&v!=null&&Number(v)>Number(cfg.versao))carregaPerfil();},[saude&&saude.perfil&&saude.perfil.versao]);

useEffect(()=>{if(!nova)return;const t=setTimeout(()=>{setNova(null);setMsg('A chave nova saiu da tela (5 minutos). Se não copiou, gere outra.');},300000);return()=>clearTimeout(t);},[nova]);
useEffect(()=>{carregaServico();const t=setInterval(()=>{carregaServico();carregaChave();},30000);return()=>clearInterval(t);},[grupoTips,horas]);
useEffect(()=>{if(verHist)carregaHist();},[verHist,cfg&&cfg.versao]);

const carregaDolar=()=>leJson('/api/fishbot/cambio').then((x)=>{if(vivo.current){setDolar(x);setErroDolar('');}}).catch((e)=>{if(fbSemSessao(e))return;if(vivo.current)setErroDolar('O câmbio do dólar não carregou: '+e.message);});
const fixaDolar=async()=>{const d=fbCambioDigitado(dolarEd,dolar.regras);if(d.erro){setMsg('❌ '+d.erro);return;}
if(!(await confirma(d.manual==null?'Apagar o câmbio fixado à mão e voltar ao automático?':`Fixar o câmbio do dólar em R$ ${fbNum(d.manual)}? Ele vale no lugar do automático para todos os grupos em US$, até alguém apagar.`)))return;
setMsg('');try{const x=await post('/api/fishbot/cambio',{manual:d.manual});setMsg('✅ '+x.mensagem);setDolarEd(null);carregaDolar();}catch(e){if(fbSemSessao(e))return;setMsg('❌ O câmbio não foi gravado: '+e.message);}};
useEffect(()=>{carregaDolar();const t=setInterval(carregaDolar,60000);return()=>clearInterval(t);},[]);
const gerar=async()=>{
if(!(await confirma((chave&&chave.chave&&chave.chave.existe?'Já existe uma chave de serviço. Ao gerar outra, a atual para de valer na hora e o FishBot fica sem ler até receber a nova.\n\n':'')+'Gerar a chave do serviço FishBot? Ela aparece uma única vez.')))return;
setMsg('');try{const x=await post('/api/fishbot/chave-servico');setNova(x.chave);carregaChave();}catch(e){if(fbSemSessao(e))return;setMsg('❌ A chave não foi gerada: '+e.message);}};
const criar=async()=>{const id=novoId.trim().toLowerCase();
if(!(await confirma(`Criar o grupo "${id}"? Ele nasce desligado, com os valores do robô, e você ajusta antes de ligar.`)))return;
setMsg('');try{const x=await post('/api/fishbot/config',{versaoBase:cfg.versao,grupo:id});setMsg('✅ '+x.mensagem);setNovoId('');carregaPerfil();}catch(e){if(fbSemSessao(e))return;setMsg('❌ O grupo não foi criado: '+e.message);}};
const marcar=async(t,estado)=>{
const qual=`a tip de ${t.jogo||'jogo não informado'} (${fbAposta(t)})`;
let corpo={estado},nome=estado;


if(estado==='Parcial'){
const n=await pergunta(`Parcial: quanto a casa pagou (%)?\n\nVocê está marcando ${qual}.\n\nDigite quanto a casa pagou do retorno cheio, em %: maior que 0 e menor que 100. Ex.: 50 quando a bolsa resolveu o mercado meio a meio (50-50). A vírgula decimal vale (ex.: 62,5).\n\nO bot edita a mensagem do grupo com esse resultado.`,'',{sim:'Marcar Parcial'});
if(n==null)return;
const f=fbFracaoDoPct(n);if(f.erro){setMsg('❌ '+f.erro+' Nada foi enviado ao FishBot.');return;}
corpo={estado,fracao:f.fracao};nome=fbResultado(estado,f.fracao);
}else if(!(await confirma(`Marcar como "${estado}" ${qual}?\n\nO bot edita a mensagem do grupo com esse resultado.`)))return;
setMsg('');try{const x=await post('/api/fishbot/tips/'+encodeURIComponent(t.id)+'/resultado',corpo);setMsg(`✅ Resultado "${nome}" enviado ao FishBot.`+fbSharkDoResultado(x));carregaServico();}catch(e){if(fbSemSessao(e))return;setMsg('❌ O resultado NÃO foi marcado: '+e.message);}};

const conferir=async(a,postada)=>{
const qual=`${a.jogo||'jogo não informado'} — ${a.descricao||'aposta não informada'} (${a.casa||'casa não informada'}, grupo ${a.grupo||'?'})`;
let corpo={postada:false};
if(postada){
const n=await pergunta(`A tip FOI postada no canal?\n\n${qual}\n\nSe souber, digite o número da mensagem no Telegram (fica no fim do link da mensagem). Pode deixar em branco: a tip conta como enviada, mas o FishBot não vai conseguir carimbar o resultado nela.`,'');
if(n==null)return;
const txt=String(n).trim();
if(txt&&!/^[1-9][0-9]{0,14}$/.test(txt)){setMsg('❌ O número da mensagem tem só dígitos (ex.: 4812). Nada foi enviado ao FishBot.');return;}
corpo=txt?{postada:true,messageId:Number(txt)}:{postada:true};
}else if(!(await confirma(`A tip NÃO foi postada no canal?\n\n${qual}\n\nO FishBot libera esta aposta: ela pode sair de novo se ainda tiver valor.`)))return;
setMsg('');try{await post('/api/fishbot/tips/'+encodeURIComponent(a.tipId)+'/conferida',corpo);setMsg(postada?'✅ Anotado: a tip foi postada'+(corpo.messageId?` (mensagem ${corpo.messageId})`:' (sem o número da mensagem)')+'.':'✅ Anotado: a tip não foi postada. A aposta está liberada.');carregaServico();}
catch(e){if(fbSemSessao(e))return;setMsg('❌ A conferência NÃO foi gravada: '+e.message);}};
const ch=chave&&chave.chave,rp=chave&&chave.repasse;
const listaTips=fbLista(tips,'tips'),listaPend=fbLista(pend,'pendentes');
const motivos=rec?Array.isArray(rec)?rec.map((x)=>[x.motivo,Number(x.n)]):rec.motivos&&typeof rec.motivos==='object'?Object.entries(rec.motivos).map(([k,n])=>[k,Number(n)]):null:null;
const gruposIds=cfg?Object.keys(cfg.grupos).sort():[];
const porChave=cat?Object.fromEntries(cat.map((c)=>[c.chave,c])):{};
{const vigiaC=fbVigiaC(op);if(vigiaC)porChave[vigiaC.chave]=vigiaC;}
const st=saude&&saude.stream,pf=saude&&saude.perfil;
const semFormato=React.createElement("div",{style:fbErroCx},"O FishBot respondeu num formato que esta tela não reconhece. Nada é mostrado para não parecer lista vazia.");
return React.createElement("div",{style:{display:'grid',gap:16,maxWidth:1180}},
msg&&React.createElement("div",{className:"toast"},msg),


React.createElement("div",{style:fbCaixa},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8,flexWrap:'wrap'}},React.createElement("b",{style:{fontSize:15}},"Saúde do FishBot"),React.createElement("button",{className:"btn-sm",onClick:()=>{carregaServico();carregaChave();}},"Atualizar agora")),
erroSaude?React.createElement("div",{style:{...fbErroCx,marginTop:8}},erroSaude):!saude?React.createElement("div",{className:"ev-sub",style:{marginTop:8}},"Perguntando ao FishBot…"):
React.createElement("div",{style:{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:10,marginTop:8}},
React.createElement("div",null,React.createElement("div",{className:"ev-sub"},"Ligado ao stream do EV+"),React.createElement("b",{style:{color:st&&st.ligado?'var(--teal-deep)':'var(--down)'}},st?st.ligado?'Sim':'NÃO — o FishBot está cego':'não informado pelo serviço')),
React.createElement("div",null,React.createElement("div",{className:"ev-sub"},"Última leitura do stream"),React.createElement("b",null,st&&st.ultimaLeituraMs?`${fbHa(st.ultimaLeituraMs)} (${fbHora(st.ultimaLeituraMs)})`:'não informado pelo serviço')),
React.createElement("div",null,React.createElement("div",{className:"ev-sub"},"Versão do perfil em uso"),React.createElement("b",{style:{color:pf&&cfg&&pf.versao!=null&&Number(pf.versao)!==Number(cfg.versao)?'var(--down)':undefined}},pf&&pf.versao!=null?`versão ${pf.versao}`:'não informado pelo serviço',pf&&cfg&&pf.versao!=null&&Number(pf.versao)!==Number(cfg.versao)?` — o painel está na versão ${cfg.versao}`:''),pf&&pf.erro&&React.createElement("div",{style:{color:'var(--down)',fontSize:12.5}},"Perfil recusado pelo serviço: ",String(pf.erro)))
),
saude&&st&&st.erro&&React.createElement("div",{style:{...fbErroCx,marginTop:8}},"Erro na leitura do stream: ",String(st.erro)),
saude&&saude.laco&&saude.laco.casas&&saude.laco.casas.erro&&React.createElement("div",{style:{...fbErroCx,marginTop:8}},"O FishBot não leu as casas do bot (clones contam como uma casa): ",String(saude.laco.casas.erro)),
saude&&saude.grupos&&typeof saude.grupos==='object'&&React.createElement("div",{className:"tbl-wrap",style:{marginTop:10}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Grupo"),React.createElement("th",null,"Estado no serviço"),React.createElement("th",null,"Enviadas na última hora"),React.createElement("th",null,"Disjuntor"),React.createElement("th",null,"Pausa"),React.createElement("th",null,"Último erro"),React.createElement("th",null,"Resultados (24 h)"))),React.createElement("tbody",null,
Object.keys(saude.grupos).sort().map((g)=>{const x=saude.grupos[g]||{},dj=x.disjuntor,aberto=dj&&(dj===true||dj.aberto),pa=x.pausa&&typeof x.pausa==='object'?x.pausa:null,ue=x.ultimoErro,lq=fbLiqDoGrupo(saude,g),av=x.avisos&&typeof x.avisos==='object'?Object.entries(x.avisos).filter(([,n])=>Number(n)>0):[];
const pend=lq&&lq.pendentesPorMotivo&&typeof lq.pendentesPorMotivo==='object'?Object.entries(lq.pendentesPorMotivo).filter(([,n])=>Number(n)>0):[];
return React.createElement("tr",{key:g},React.createElement("td",{style:{fontWeight:600}},g),
React.createElement("td",null,x.estado==null?'—':fbValor(porChave.estado,x.estado,op),x.linhasQuePassaramNoFiltro!=null&&React.createElement("div",{className:"ev-sub"},x.linhasQuePassaramNoFiltro," linha(s) passaram no filtro agora"),Array.isArray(x.passaramSemSair)&&x.passaramSemSair.length>0&&React.createElement("details",{style:{marginTop:4}},React.createElement("summary",{className:"ev-sub",style:{cursor:'pointer'}},"Por que não saíram (",x.passaramSemSair.length," seleção(ões))"),React.createElement("div",{style:{fontSize:11.5,lineHeight:1.5}},x.passaramSemSair.map((l,i)=>React.createElement("div",{key:i},"EV ",fbPct(l.evPct)," — ",React.createElement("b",null,l.motivo?fbMotivo(l.motivo):'sem recusa neste ciclo (saiu ou está no envio)')," · odd ",l.odd!=null?fbOdd(l.odd):'—'," · ",l.casa||'—'," · ",l.jogo||'—'," · ",l.linha!=null&&l.linha!==''&&fbLinha(l.lado,l.linha)?fbAposta(l):[l.mercado,l.jogador,l.selecao||[l.lado,l.linha!=null?fbNum(l.linha):null].filter(Boolean).join(' ')].filter(Boolean).join(' · '),l.tamanhoUsd!=null?` · liquidez US$ ${fbNum(Math.round(Number(l.tamanhoUsd)*100)/100)}`:'')))),
x.perfilRecusado&&React.createElement("div",{style:{color:'var(--down)',fontSize:12.5,fontWeight:600}},"Perfil recusado pelo serviço: ",Array.isArray(x.perfilRecusado)?x.perfilRecusado.join('; '):String(x.perfilRecusado)),
av.length>0&&React.createElement("div",{className:"ev-sub"},"Avisos: ",av.map(([k,n])=>`${fbMotivo(k)} (${n})`).join(' · ')),
(fbPortalDaSaude(x.vigiaPortal)||[]).map((l,i)=>React.createElement("div",{key:'portal'+i,className:l.alerta?undefined:'ev-sub',style:l.alerta?{color:'var(--down)',fontSize:12.5,fontWeight:600}:undefined},l.texto))),
React.createElement("td",null,x.enviadasNaHora??'—',fbRitmo(x,agora).map((l)=>React.createElement("div",{key:l,className:"ev-sub"},l))),
React.createElement("td",{style:aberto?{color:'var(--down)',fontWeight:700}:undefined},dj==null?'—':aberto?React.createElement(React.Fragment,null,"ABERTO — grupo pausado",dj.motivo?': '+fbMotivo(dj.motivo):'',dj.ateMs?React.createElement("div",null,fbAte(dj.ateMs)):null,dj.medianaPct!=null||dj.altasNaJanela!=null?React.createElement("div",{className:"ev-sub"},dj.medianaPct!=null?`EV do meio da lista ${fbPct(dj.medianaPct)}`:'',dj.medianaPct!=null&&dj.altasNaJanela!=null?' · ':'',dj.altasNaJanela!=null?`${dj.altasNaJanela} jogo(s) de EV alto na janela`:''):null):'fechado (normal)',(()=>{const ab=dj&&(dj.naAbertura||dj.ultimo&&dj.ultimo.naAbertura);const bloco=(titulo,ls)=>Array.isArray(ls)&&ls.length?React.createElement("details",{style:{marginTop:4,fontWeight:400,color:'var(--on-surface)'}},React.createElement("summary",{className:"ev-sub",style:{cursor:'pointer'}},titulo),React.createElement("div",{style:{fontSize:11.5,lineHeight:1.5}},ls.map((l,i)=>React.createElement("div",{key:i},"EV ",fbNum(l.evPct),"% · odd ",l.odd!=null?fbNum(l.odd):'—'," · ",l.casa||'—'," · ",l.jogo||'—'," · ",[l.mercado,l.jogador,l.selecao||l.lado,l.linha!=null?String(l.linha).replace('.',','):null].filter(Boolean).join(' '),l.linhasDoJogo>1?` (a maior de ${l.linhasDoJogo} linhas do jogo)`:'')))):null;return dj?React.createElement(React.Fragment,null,bloco(`Jogos na lista agora (${dj.jogosNoTotal!=null?dj.jogosNoTotal:(dj.linhasAgora||[]).length}; uma aposta por jogo)`,dj.linhasAgora),ab?bloco(`Lista ${dj.aberto?'quando abriu':'da última vez que abriu'} (${fbHora(ab.emMs)}; EV do meio ${fbPct(ab.medianaPct)}, limite ${fbNum(ab.limiteMedianaPct)}%)`,ab.linhas):null):null;})()),
React.createElement("td",{style:pa||x.botPausadoAteMs?{color:'var(--down)',fontWeight:600}:undefined},pa?React.createElement(React.Fragment,null,"Pausado",pa.motivo?': '+fbMotivo(pa.motivo):'',React.createElement("div",null,fbAte(pa.ateMs))):x.botPausadoAteMs?React.createElement(React.Fragment,null,"Bot pausado",React.createElement("div",null,fbAte(x.botPausadoAteMs))):'—'),
React.createElement("td",{style:{fontSize:12.5}},ue?typeof ue==='object'?React.createElement(React.Fragment,null,ue.onde?React.createElement("b",null,String(ue.onde),": "):null,String(ue.erro??''),ue.em?React.createElement("div",{className:"ev-sub"},fbHa(ue.em)," (",fbHora(ue.em),")"):null):String(ue):'—'),
React.createElement("td",{style:{fontSize:12.5}},lq?React.createElement(React.Fragment,null,lq.resolvidasSozinhas24h!=null&&React.createElement("div",null,"Resolvidas sozinhas: ",React.createElement("b",null,lq.resolvidasSozinhas24h)),lq.marcadasAMao24h!=null&&React.createElement("div",null,"Marcadas à mão: ",React.createElement("b",null,lq.marcadasAMao24h)),lq.correcoes24h!=null&&React.createElement("div",null,"Correções: ",React.createElement("b",null,lq.correcoes24h)),pend.length>0&&React.createElement("div",null,"Pendentes agora: ",pend.map(([k,n])=>`${fbMotivo(k)} (${n})`).join(' · ')),lq.soAMao>0&&React.createElement("div",{style:{color:'var(--down)'}},lq.soAMao," só saem à mão"),lq.portalComResultadoAnterior>0&&React.createElement("div",{style:{color:'#9a6700'}},lq.portalComResultadoAnterior," corrigida(s) que o portal ainda mostra com o resultado anterior")):'—',x.sharkAvisos>0&&React.createElement("div",{style:{color:'#9a6700'}},x.sharkAvisos," aviso(s) do Shark Track"),x.esperandoCadencia>0&&React.createElement("div",{className:"ev-sub"},x.esperandoCadencia," pedido(s) esperando a fila do bot")));})
))),
(()=>{const ev=saude&&saude.laco&&saude.laco.envios;if(!ev||typeof ev!=='object')return null;const inc=Array.isArray(ev.incertasVencidas)?ev.incertasVencidas:[],conf=Array.isArray(ev.conferirNoCanal)?ev.conferirNoCanal:[],ue=ev.ultimoErro;
return React.createElement("div",{style:{marginTop:10,display:'grid',gap:6}},
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Envios",ev.emEnvio!=null?` · no meio do envio agora: ${ev.emEnvio}`:'',ev.recuperadas!=null?` · recuperados: ${ev.recuperadas}`:'',ev.liberadas!=null?` · liberados: ${ev.liberadas}`:'',ev.dropadas!=null?` · tiradas pelo 👎: ${ev.dropadas}`:'',ev.pausadaAteMs?` · conferência pausada ${fbAte(ev.pausadaAteMs)}`:''),
ue&&React.createElement("div",{style:fbErroCx},"Último erro na conferência dos envios",typeof ue==='object'&&ue.onde?' ('+String(ue.onde)+')':'',": ",typeof ue==='object'?String(ue.erro??''):String(ue),typeof ue==='object'&&ue.em?' — '+fbHa(ue.em):''),
inc.length>0&&React.createElement("div",null,React.createElement("div",{style:{...fbErroCx,marginBottom:6}},"Envios incertos vencidos: ",inc.length,". O FishBot não conseguiu saber se estas tips saíram — confira no canal."),
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Quando"),React.createElement("th",null,"Grupo"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Tip"))),React.createElement("tbody",null,
inc.map((a,i)=>React.createElement("tr",{key:a.tipId||i},React.createElement("td",{style:{whiteSpace:'nowrap'}},fbHora(a.em)),React.createElement("td",null,a.grupo||'—'),React.createElement("td",null,a.casa||'—'),React.createElement("td",null,a.jogo||'—'),React.createElement("td",{className:"ev-sub"},a.tipId||'—')))
)))),

conf.length>0&&React.createElement("div",null,React.createElement("div",{style:{...fbErroCx,marginBottom:6}},"Conferir no canal: ",conf.length," ",conf.length===1?'tip que o FishBot não sabe se saiu':'tips que o FishBot não sabe se saíram',". Olhe o canal do grupo e diga o que aconteceu — enquanto ninguém responde, a mesma aposta não sai de novo."),
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Pedida em"),React.createElement("th",null,"Grupo"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"O que aconteceu no canal?"))),React.createElement("tbody",null,
conf.map((a,i)=>React.createElement("tr",{key:a.tipId||i},React.createElement("td",{style:{whiteSpace:'nowrap'}},fbHora(a.reservadaMs),a.desdeMs?React.createElement("div",{className:"ev-sub"},"incerta ",fbHa(a.desdeMs)):null),React.createElement("td",null,a.grupo||'—',a.modo==='teste'&&React.createElement("span",{className:"pill",style:{marginLeft:4}},"teste")),React.createElement("td",null,a.casa||'—'),React.createElement("td",null,a.jogo||'—'),React.createElement("td",null,a.descricao||'—'),
React.createElement("td",{style:{whiteSpace:'nowrap'}},a.tipId!=null?React.createElement(React.Fragment,null,React.createElement("button",{className:"btn-sm b-green",style:{marginRight:4},onClick:()=>conferir(a,true)},"Foi postada"),React.createElement("button",{className:"btn-sm b-red",onClick:()=>conferir(a,false)},"Não foi postada")):React.createElement("span",{className:"ev-sub"},"sem identificador: não dá para responder daqui"))))
))))
);})(),

(()=>{const sk=fbSharkDaSaude(saude);return sk?React.createElement("div",{style:{...fbErroCx,marginTop:10,color:'#9a6700',borderColor:'#E8D5A8',background:'#FFFAEB'}},sk.texto,sk.partes.length?' ('+sk.partes.join('; ')+')':'',sk.motivos.length?': '+sk.motivos.join(' · '):'',". Veja as linhas do Shark Track em \"Tips enviadas\"."):null;})(),

(()=>{const lq=saude&&saude.liquidacao;if(!lq||typeof lq!=='object')return null;const ur=lq.ultimaRodada&&typeof lq.ultimaRodada==='object'?lq.ultimaRodada:null,fontes=fbFontesDeResultado(saude),pm=ur&&ur.porMotivo&&typeof ur.porMotivo==='object'?Object.entries(ur.porMotivo).filter(([,n])=>Number(n)>0):[];
const erroDe=(x)=>x?typeof x==='object'?`${String(x.erro??'')}${x.em?' — '+fbHa(x.em):''}`:String(x):null;
return React.createElement("div",{style:{marginTop:10,display:'grid',gap:6}},
React.createElement("div",{style:{fontSize:13}},React.createElement("b",null,"Resultado automático:")," ",lq.ligada===false?React.createElement("b",{style:{color:'var(--down)'}},"desligado no FishBot — todo resultado é à mão"):lq.ligada===true?'ligado':'—',lq.intervaloMs?` · uma rodada a cada ${Math.round(Number(lq.intervaloMs)/60000)} min`:'',lq.rodadas!=null?` · ${lq.rodadas} rodada(s) desde que o serviço subiu`:'',lq.botEmEspera?' · esperando a fila do bot':''),
ur?React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Última rodada: ",ur.ms?`${fbHa(ur.ms)} (${fbHora(ur.ms)})`:'sem hora',ur.duracaoMs!=null?`, ${fbNum(Math.round(Number(ur.duracaoMs)/100)/10)} s`:'',ur.naFila!=null?` · na fila: ${ur.naFila}`:'',ur.lidas!=null?` · lidas: ${ur.lidas}`:'',ur.liquidadas!=null?` · resolvidas: ${ur.liquidadas}`:'',ur.pendentes!=null?` · seguem pendentes: ${ur.pendentes}`:'',ur.corrigidas?` · corrigidas: ${ur.corrigidas}`:'',ur.erros?` · erros: ${ur.erros}`:'',pm.length?` · por motivo: ${pm.map(([k,n])=>`${fbMotivo(k)} (${n})`).join(', ')}`:''):
lq.ligada!==false&&React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Nenhuma rodada de resultado ainda."),
erroDe(lq.ultimoErro)&&React.createElement("div",{style:fbErroCx},"Último erro do ciclo de resultado: ",erroDe(lq.ultimoErro)),
erroDe(lq.ultimoErroDoBot)&&React.createElement("div",{style:fbErroCx},"Último erro do bot ao carimbar resultado: ",erroDe(lq.ultimoErroDoBot)),
fontes.length>0&&React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0,maxWidth:860}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Fonte de resultado"),React.createElement("th",{style:{textAlign:'right'}},"Leituras"),React.createElement("th",{style:{textAlign:'right'}},"Erros"),React.createElement("th",null,"Último sucesso"),React.createElement("th",null,"Último erro"))),React.createElement("tbody",null,
fontes.map((f)=>React.createElement("tr",{key:f.fonte},React.createElement("td",{style:{fontWeight:600}},f.fonte),React.createElement("td",{style:{textAlign:'right'}},f.leituras??'—'),React.createElement("td",{style:{textAlign:'right',color:f.erros>0?'var(--down)':undefined,fontWeight:f.erros>0?700:undefined}},f.erros),
React.createElement("td",{style:{whiteSpace:'nowrap'}},f.sucessoMs?`${fbHa(f.sucessoMs)} (${fbHora(f.sucessoMs)})`:React.createElement("span",{style:{color:f.leituras>0||f.erros>0?'var(--down)':undefined}},"nenhum até agora")),
React.createElement("td",{style:{fontSize:12.5}},f.erro?React.createElement(React.Fragment,null,f.erro,f.erroMs?React.createElement("span",{className:"ev-sub"}," — ",fbHa(f.erroMs)):null):'—')))
)))
);})(),
React.createElement("div",{style:{borderTop:'1px solid var(--line)',marginTop:12,paddingTop:12,display:'grid',gap:8}},
React.createElement("b",{style:{fontSize:14}},"Chave de serviço"),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"O FishBot roda em outro servidor e não tem login. Ele lê o EV+ e o perfil dos grupos com esta chave, que só consulta — nunca grava. A chave aparece ",React.createElement("b",null,"uma vez"),": copie e cole na configuração do FishBot. Gerar outra desliga a anterior."),
erroChave?React.createElement("div",{style:fbErroCx},erroChave):!ch?React.createElement("div",{className:"ev-sub"},"Carregando…"):React.createElement(React.Fragment,null,
React.createElement("div",{style:{fontSize:13}},ch.existe?React.createElement(React.Fragment,null,"Chave em vigor: gerada por ",React.createElement("b",null,ch.criadaPor||'—')," em ",fbHora(ch.criadaEm)," · último uso: ",React.createElement("b",null,ch.usadaEm?fbHa(ch.usadaEm):'nunca usada')):React.createElement("b",{style:{color:'var(--down)'}},"Nenhuma chave gerada: o FishBot não consegue ler o painel.")),
React.createElement("div",{style:{fontSize:13,color:ch.recusas.total?'var(--down)':undefined}},"Tentativas recusadas desde que o painel subiu (",fbHora(ch.desde),"): ",React.createElement("b",null,ch.recusas.total),ch.recusas.total?` — chave errada: ${ch.recusas.chaveErrada+ch.recusas.semChave}, rota não permitida: ${ch.recusas.rota}; a última ${fbHa(ch.recusas.ultimaEm)}`:''),

ch.stream&&React.createElement("div",{style:{fontSize:13}},"Streams do FishBot abertos agora: ",React.createElement("b",null,ch.stream.abertos)," (máximo ",ch.stream.limites&&ch.stream.limites.maxConexoes,")",ch.stream.ultimaFotoEm?` · última conexão ${fbHa(ch.stream.ultimaFotoEm)}`:'',
(()=>{const d=ch.stream.derrubados||{},r=ch.stream.recusadosPorLimite||{};const t=[d.chave_trocada?`${d.chave_trocada} derrubado(s) pela troca da chave`:'',d.fila_cheia?`${d.fila_cheia} derrubado(s) por parar de ler`:'',r.conexoes?`${r.conexoes} pedido(s) recusado(s) por excesso de conexões`:'',r.intervalo?`${r.intervalo} recusado(s) por reconectar rápido demais`:''].filter(Boolean);return t.length?React.createElement("span",{style:{color:'var(--down)'}}," · ",t.join(' · ')):null;})()),
ch.banco&&ch.banco.erros>0&&React.createElement("div",{style:fbErroCx},"O painel não conseguiu conferir a chave no banco ",ch.banco.erros," vez(es): ",ch.banco.ultimoErro),
ch.uso&&ch.uso.falhasAoMarcar>0&&React.createElement("div",{style:fbErroCx},"O último uso da chave não foi gravado ",ch.uso.falhasAoMarcar," vez(es): ",ch.uso.ultimoErro),
rp&&!rp.configurado&&React.createElement("div",{style:fbErroCx},"O painel ainda não sabe onde o FishBot está: ",rp.faltando,". As variáveis são ",(chave.variaveis||[]).join(' e '),"."),
React.createElement("div",null,usuario&&usuario.master?React.createElement("button",{className:"btn-sm b-green",onClick:gerar},"Gerar chave do serviço"):React.createElement("span",{className:"ev-sub"},"Só o admin master gera a chave do serviço."))
),
nova&&React.createElement("div",{style:{padding:12,border:'1px solid var(--line-2)',borderRadius:10,display:'grid',gap:6}},React.createElement("b",null,"Chave nova (não aparece de novo):"),React.createElement("code",{style:{wordBreak:'break-all',userSelect:'all'}},nova),React.createElement("div",{style:{display:'flex',gap:8}},React.createElement("button",{className:"btn-sm",onClick:()=>{navigator.clipboard.writeText(nova).then(()=>setMsg('✅ Chave copiada')).catch((e)=>setMsg('❌ Não consegui copiar sozinho ('+e.message+'): selecione a chave e copie à mão'));}},"Copiar"),React.createElement("button",{className:"btn-sm",onClick:()=>setNova(null)},"Já copiei")))
)
),


React.createElement("div",{style:{...fbCaixa,display:'grid',gap:8}},
React.createElement("b",{style:{fontSize:15}},"Câmbio do dólar"),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Vale para todos os grupos com a moeda de envio em US$: o valor em dólar da mensagem sai da banca em reais do grupo dividida por este câmbio. O painel lê o câmbio sozinho uma vez por dia; um valor fixado à mão vale no lugar dele até ser apagado."),
erroDolar?React.createElement("div",{style:fbErroCx},erroDolar):!dolar?React.createElement("div",{className:"ev-sub"},"Carregando…"):(()=>{const c=fbCambio(dolar);
return!c?React.createElement("div",{style:fbErroCx},"O câmbio veio num formato que esta tela não reconhece. Nada é mostrado para não parecer um valor."):React.createElement(React.Fragment,null,
c.valendo?React.createElement("div",{style:{fontSize:14}},"Valendo agora: ",React.createElement("b",null,c.valendo)):React.createElement("div",{style:fbErroCx},c.alerta),
c.erro&&React.createElement("div",{style:fbErroCx},c.erro),
c.linhas.map((l)=>React.createElement("div",{key:l,className:"ev-sub",style:{fontSize:12.5}},l)),
React.createElement("div",{style:{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap',fontSize:13}},React.createElement("label",{htmlFor:"fb-cambio-manual",style:{fontWeight:600}},"Fixar à mão (R$ por dólar)"),
React.createElement("input",{id:"fb-cambio-manual",type:"text",inputMode:"decimal",placeholder:"vazio = usa o automático",value:dolarEd??(dolar.manual?fbNum(dolar.manual.brlPorUsd):''),onChange:(e)=>setDolarEd(e.target.value),style:{width:190}}),
React.createElement("button",{className:"btn-sm",disabled:dolarEd==null,onClick:fixaDolar},"Gravar"))
);})()
),


React.createElement(FbRobo,{op:op}),

React.createElement(FbArredondamento,null),

React.createElement(FbBots,null),


React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8,flexWrap:'wrap'}},
React.createElement("b",{style:{fontSize:15}},"Perfil de cada grupo",cfg?React.createElement("span",{className:"ev-sub",style:{fontWeight:400}}," — versão ",cfg.versao,", salva ",fbHa(cfg.atualizadoEm)," (",fbHora(cfg.atualizadoEm),")",cfg.por?' por '+cfg.por:''):null),
React.createElement("button",{className:"btn-sm",onClick:()=>setVerHist((v)=>!v)},verHist?'Esconder o histórico':'Histórico de versões')
),
erro&&React.createElement("div",{style:fbErroCx},erro),
!erro&&(!cfg||!cat||!op)&&React.createElement("div",{className:"ev-sub"},"Carregando o perfil dos grupos…"),

op&&(op.semCodigo||[]).length>0&&React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Casas com linha no EV+ agora e ",React.createElement("b",null,"sem código de fonte")," (não entram em nenhum grupo pela lista de casas): ",op.semCodigo.map((x)=>`${x.casa} (${x.tipo==='superodd'?'Super Odd':x.tipo==='prop'?'prop de jogador':'jogo'}, ${x.linhas} ${x.linhas===1?'linha':'linhas'})`).join(' · ')),
verHist&&React.createElement("div",{style:fbCaixa},
erroHist?React.createElement("div",{style:fbErroCx},erroHist):!hist?React.createElement("div",{className:"ev-sub"},"Carregando o histórico…"):
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Versão"),React.createElement("th",null,"Quando"),React.createElement("th",null,"Quem"),React.createElement("th",null,"O que mudou"))),React.createElement("tbody",null,
hist.map((v)=>React.createElement("tr",{key:v.versao},React.createElement("td",{style:{fontWeight:600}},v.versao),React.createElement("td",{style:{whiteSpace:'nowrap'}},fbHora(v.em)),React.createElement("td",null,v.por||'—'),
React.createElement("td",{style:{fontSize:12.5}},(v.mudancas||[]).map((m,i)=>{const c=porChave[m.campo];return React.createElement("div",{key:i},React.createElement("b",null,m.grupo)," · ",m.campo==='(grupo novo)'?'grupo '+String(m.para):React.createElement(React.Fragment,null,c?c.rotulo:m.campo,": de ",fbValor(c,m.de,op)," para ",fbValor(c,m.para,op)));}),!(v.mudancas||[]).length&&'—')))
)))
),
cfg&&cat&&op&&gruposIds.map((g)=>React.createElement(FbGrupo,{key:g,id:g,perfil:cfg.grupos[g],versao:cfg.versao,catalogo:cat,op:op,aoSalvar:carregaPerfil,master:!!(usuario&&usuario.master),doServico:saude&&saude.grupos&&typeof saude.grupos==='object'?saude.grupos[g]:null})),
cfg&&cat&&op&&React.createElement("div",{style:{...fbCaixa,display:'flex',gap:8,alignItems:'end',flexWrap:'wrap'}},
React.createElement("label",{style:{display:'grid',gap:4,fontSize:13}},"Novo grupo (nome interno: letras minúsculas, números e hífen)",React.createElement("input",{value:novoId,onChange:(e)=>setNovoId(e.target.value),placeholder:"ex.: nomade",style:{width:240}})),
React.createElement("button",{className:"btn-sm",disabled:!novoId.trim()||gruposIds.includes(novoId.trim().toLowerCase()),onClick:criar},"Criar grupo desligado"),
React.createElement("span",{className:"ev-sub"},"Nasce desligado, com os valores do robô de apostas.")
),


React.createElement("div",{style:fbCaixa},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8,flexWrap:'wrap'}},React.createElement("b",{style:{fontSize:15}},"Tips enviadas"),
React.createElement("label",{style:{fontSize:13}},"Grupo ",React.createElement("select",{value:grupoTips,onChange:(e)=>setGrupoTips(e.target.value)},React.createElement("option",{value:""},"todos"),gruposIds.map((g)=>React.createElement("option",{key:g,value:g},g))))),
erroTips?React.createElement("div",{style:{...fbErroCx,marginTop:8}},erroTips):!tips?React.createElement("div",{className:"ev-sub",style:{marginTop:8}},"Perguntando ao FishBot…"):!listaTips?semFormato:
React.createElement("div",{className:"tbl-wrap",style:{marginTop:8,marginBottom:0}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Quando"),React.createElement("th",null,"Grupo"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"Odd"),React.createElement("th",null,"Justa"),React.createElement("th",null,"Stake"),React.createElement("th",null,"Estado"),React.createElement("th",null,"ALT"))),React.createElement("tbody",null,
listaTips.map((t,i)=>React.createElement("tr",{key:t.id||i},React.createElement("td",{style:{whiteSpace:'nowrap'}},fbHora(t.enviadaEm)),React.createElement("td",null,t.grupo||'—',t.modo==='teste'&&React.createElement("span",{className:"pill",style:{marginLeft:4}},"teste")),React.createElement("td",null,t.casa||'—',fbFamilia(t)?React.createElement("div",{className:"ev-sub",title:"A tip saiu por uma casa com clones: o bloqueio da mesma aposta e o teto por hora valem para a família inteira"},"família de clones: ",fbFamilia(t)):null),React.createElement("td",null,t.jogo||'—'),React.createElement("td",null,fbAposta(t)),React.createElement("td",null,fbOdd(t.odd)),React.createElement("td",null,fbOdd(t.justa)),React.createElement("td",null,fbPct(t.stakePct)),React.createElement("td",null,fbEstado(t),(t.correcoes||[]).length?` (corrigida ${(t.correcoes||[]).length}×)`:'',t.motivoFalha?React.createElement("div",{style:{color:'var(--down)',fontSize:12.5}},fbMotivo(t.motivoFalha)):null,
fbShark(t).map((l,j)=>React.createElement("div",{key:'sk'+j,className:l.alerta?undefined:'ev-sub',style:l.alerta?{color:'#9a6700',fontSize:12.5,fontWeight:600}:{fontSize:12.5}},l.texto)),
t.casaNoCadastro===false&&React.createElement("div",{style:{color:'var(--down)',fontSize:12.5,fontWeight:600},title:"O bot não achou esta casa no cadastro dele: a tip saiu, mas confira o nome e o link da casa"},"casa fora do cadastro do bot")),
React.createElement("td",{style:{fontSize:12.5}},(t.alts||[]).map((a,j)=>React.createElement("div",{key:j},a.casa," ",fbOdd(a.odd)," · ",fbPct(a.stakePct))),!(t.alts||[]).length&&'—',Number(t.altsCortadas)>0&&React.createElement("div",{style:{color:'#9a6700'}},t.altsCortadas," ALT cortada(s) pelo bot para a mensagem caber")))),
!listaTips.length&&React.createElement("tr",null,React.createElement("td",{colSpan:10,className:"ev-sub"},"O FishBot respondeu: nenhuma tip enviada",grupoTips?' neste grupo':'',"."))
)))
),


React.createElement("div",{style:fbCaixa},
React.createElement("div",{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8,flexWrap:'wrap'}},React.createElement("b",{style:{fontSize:15}},"Por que as linhas foram recusadas"),
React.createElement("label",{style:{fontSize:13}},"Período ",React.createElement("select",{value:horas,onChange:(e)=>setHoras(e.target.value)},React.createElement("option",{value:"1"},"última hora"),React.createElement("option",{value:"6"},"últimas 6 horas"),React.createElement("option",{value:"24"},"últimas 24 horas"),React.createElement("option",{value:"168"},"últimos 7 dias")))),
erroRec?React.createElement("div",{style:{...fbErroCx,marginTop:8}},erroRec):!rec?React.createElement("div",{className:"ev-sub",style:{marginTop:8}},"Perguntando ao FishBot…"):!motivos?semFormato:
React.createElement("div",{className:"tbl-wrap",style:{marginTop:8,marginBottom:0,maxWidth:620}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Motivo"),React.createElement("th",{style:{textAlign:'right'}},"Linhas recusadas"))),React.createElement("tbody",null,
motivos.sort((a,b)=>b[1]-a[1]).map(([m,n])=>React.createElement("tr",{key:m},React.createElement("td",null,FB_MOTIVO[m]||m,FB_MOTIVO[m]&&React.createElement("span",{className:"ev-sub"}," (",m,")")),React.createElement("td",{style:{textAlign:'right',fontWeight:600}},n))),
!motivos.length&&React.createElement("tr",null,React.createElement("td",{colSpan:2,className:"ev-sub"},"O FishBot respondeu: nenhuma recusa no período",grupoTips?' neste grupo':'',"."))
)))
),


React.createElement("div",{style:fbCaixa},
React.createElement("b",{style:{fontSize:15}},"Resultado pendente em tip dos grupos"),
React.createElement("div",{className:"ev-sub",style:{fontSize:12.5}},"Tips cujo resultado não saiu sozinho no prazo. Marque à mão: o bot edita a mensagem do grupo. Marcar de novo com outro resultado corrige."),
erroPend?React.createElement("div",{style:{...fbErroCx,marginTop:8}},erroPend):!pend?React.createElement("div",{className:"ev-sub",style:{marginTop:8}},"Perguntando ao FishBot…"):!listaPend?semFormato:
React.createElement("div",{className:"tbl-wrap",style:{marginTop:8,marginBottom:0}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Enviada"),React.createElement("th",null,"Grupo"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"Odd"),React.createElement("th",null,"Stake"),React.createElement("th",null,"Por que está pendente"),React.createElement("th",null,"Marcar resultado"))),React.createElement("tbody",null,
listaPend.map((t,i)=>React.createElement("tr",{key:t.id||i},React.createElement("td",{style:{whiteSpace:'nowrap'}},fbHora(t.enviadaEm)),React.createElement("td",null,t.grupo||'—'),React.createElement("td",null,t.casa||'—'),React.createElement("td",null,t.jogo||'—',t.inicioMs?React.createElement("div",{className:"ev-sub"},"jogo: ",fbHora(t.inicioMs)):null),React.createElement("td",null,fbAposta(t)),React.createElement("td",null,fbOdd(t.odd)),React.createElement("td",null,fbPct(t.stakePct)),React.createElement("td",{style:{fontSize:12.5}},t.motivo?React.createElement(React.Fragment,null,React.createElement("b",null,fbMotivo(t.motivo)),FB_MOTIVO[t.motivo]?React.createElement("span",{className:"ev-sub"}," (",t.motivo,")"):null):'—',
t.detalhe?React.createElement("div",null,typeof t.detalhe==='object'?JSON.stringify(t.detalhe).slice(0,200):String(t.detalhe)):null,
Array.isArray(t.valores)&&t.valores.length>0&&React.createElement("div",null,"O que cada fonte leu: ",t.valores.map((v,j)=>React.createElement("div",{key:j,className:"ev-sub",style:{fontSize:12.5}},String(v&&v.fonte||'fonte ?'),": ",React.createElement("b",null,fbResultado(v&&v.estado,v&&v.fracao)),v&&v.valorLido!=null?` (leu ${fbLido(v.valorLido)})`:''))),
fbShark(t).map((l,j)=>React.createElement("div",{key:'sk'+j,className:l.alerta?undefined:'ev-sub',style:l.alerta?{color:'#9a6700',fontWeight:600}:undefined},l.texto)),
(t.tentativas!=null||t.proximaTentativaMs||t.ultimaTentativaMs)&&React.createElement("div",{className:"ev-sub"},t.tentativas!=null?`${t.tentativas} tentativa(s)`:'',t.ultimaTentativaMs?` · última ${fbHa(t.ultimaTentativaMs)}`:'',t.proximaTentativaMs?` · próxima: ${fbHora(t.proximaTentativaMs)}`:t.tentativas>0||t.pendencia&&t.pendencia.soAMao?' · o FishBot não tenta mais: só à mão':''),
t.fimPrevistoMs?React.createElement("div",{className:"ev-sub"},"fim previsto do jogo: ",fbHora(t.fimPrevistoMs)):null),
React.createElement("td",{style:{whiteSpace:'nowrap'}},t.id?(op&&op.resultados||[]).map((r)=>React.createElement("button",{key:r,className:'btn-sm'+(/^(Perdida|Meio-perdida)$/.test(r)?' b-red':/^(Ganha|Meio-ganha)$/.test(r)?' b-green':''),style:{marginRight:4},onClick:()=>marcar(t,r)},r)):React.createElement("span",{className:"ev-sub"},"tip sem identificador: não dá para marcar daqui")))),
!listaPend.length&&React.createElement("tr",null,React.createElement("td",{colSpan:9,className:"ev-sub"},"O FishBot respondeu: nenhuma tip com resultado pendente."))
))),

pend&&Array.isArray(pend.correcoesNoPortal)&&pend.correcoesNoPortal.length>0&&React.createElement("div",{style:{marginTop:12}},
React.createElement("div",{style:{...fbErroCx,marginBottom:6,color:'#9a6700',borderColor:'#E8D5A8',background:'#FFFAEB'}},"Resultado corrigido; o portal ainda mostra o anterior: ",pend.correcoesNoPortal.length,". No canal a mensagem já está com o resultado novo — confira o portal de resultados."),
React.createElement("div",{className:"tbl-wrap",style:{marginBottom:0}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Grupo"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Jogo"),React.createElement("th",null,"Aposta"),React.createElement("th",null,"Correção"),React.createElement("th",null,"Quando"))),React.createElement("tbody",null,
pend.correcoesNoPortal.map((t,i)=>{const c=fbUltimaCorrecao(t);return React.createElement("tr",{key:t.id||i},React.createElement("td",null,t.grupo||'—'),React.createElement("td",null,t.casa||'—'),React.createElement("td",null,t.jogo||'—'),React.createElement("td",null,fbAposta(t)),
React.createElement("td",null,c?React.createElement(React.Fragment,null,"de ",React.createElement("b",null,fbResultado(c.anterior,c.fracaoAnterior))," para ",React.createElement("b",null,fbResultado(c.resultado??t.estado,c.fracao??t.fracao)),c.fonte?React.createElement("span",{className:"ev-sub"}," (",String(c.fonte),c.por?', '+String(c.por):'',")"):null):React.createElement(React.Fragment,null,"resultado atual: ",React.createElement("b",null,fbResultado(t.estado,t.fracao)))),
React.createElement("td",{style:{whiteSpace:'nowrap'}},fbHora(c&&c.emMs||t.resultadoMs)));})
)))
)
)
);
}




const EQ_EST={ligada:['ligada','#1a7f37'],sombra:['sombra','#9a6700'],desligada:['desligada','#6e7781']};
const eqPc=(x)=>x==null?'—':String(x).replace('.',',');
const eqDif=(d)=>!d||!d.n?'—':`${eqPc(d.p50)} / ${eqPc(d.p90)} pt${d.acima?` · ${d.acima} acima de 2`:''}`;
const eqSel=(x)=>`${x.mercado}${x.periodo&&x.periodo!=='jogo'?' · '+x.periodo:''}${x.participante?' · '+x.participante:''}${x.linha?' '+eqPc(x.linha):''} · ${x.lado}`;
const eqHora=(t)=>{if(!t)return'—';try{return fusoSP.fmtSP(new Date(t));}catch(e){return String(t);}};
function EquivalenciasTab(){
const[d,setD]=useState(null),[erro,setErro]=useState(''),[msg,setMsg]=useState(''),[aberta,setAberta]=useState(null);
const load=()=>leJson('/api/equivalencias').then((x)=>{setD(x);setErro('');}).catch((e)=>setErro('A tela não carregou: '+e.message));
useEffect(()=>{load();const t=setInterval(load,60_000);return()=>clearInterval(t);},[]);
const muda=async(r,estado)=>{setMsg('');try{const x=await leJson('/api/equivalencias/estado',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({regra:r.id,estado})});setMsg('✅ '+x.msg);load();}catch(e){setMsg('❌ '+e.message);}};
if(erro)return React.createElement("div",{className:"toast"},"❌ ",erro);
if(!d)return React.createElement("div",{className:"ev-sub"},"Carregando…");
const sj=d.sombra&&d.sombra.jogo,sp=d.sombra&&d.sombra.props;
const medJ=new Map((sj&&sj.regras||[]).map((r)=>[r.id,r])),medP=new Map((sp&&sp.regras||[]).map((r)=>[r.id,r]));
const idadeMin=sj&&sj.em?Math.round((Date.now()-Date.parse(sj.em))/60000):null;
const horasDe=(id)=>(d.horas||[]).filter((h)=>h.regra===id);
const Estado=({r})=>{const[t,c]=EQ_EST[r.estado]||[r.estado,'#6e7781'];return React.createElement("span",{className:"ev-tag",style:{background:c,color:'#fff'}},t);};
const Botoes=({r})=>r.jaCalculadaEm?React.createElement("span",{className:"ev-sub"},"já existia (no código dela)"):
React.createElement("span",{style:{display:'flex',gap:4,flexWrap:'wrap'}},r.estado!=='ligada'&&r.estadoInicial==='ligada'&&React.createElement("button",{className:"btn-sm",onClick:()=>muda(r,'ligada')},"Ligar"),
r.estado!=='sombra'&&React.createElement("button",{className:"btn-sm",onClick:()=>muda(r,'sombra')},"Sombra"),r.estado!=='desligada'&&React.createElement("button",{className:"btn-sm",onClick:()=>muda(r,'desligada')},"Desligar"));
const Condicoes=({r})=>React.createElement("div",{className:"ev-sub",style:{marginTop:4}},"Liquidação que precisa bater: ",r.liquidacao.map((c)=>c.texto).join(' '),r.jaCalculadaEm?React.createElement(React.Fragment,null,React.createElement("br",null),"Calculada hoje em: ",r.jaCalculadaEm):null);
const jogo=d.regras.filter((r)=>r.familia==='jogo'),props=d.regras.filter((r)=>r.familia==='props');
return React.createElement("div",{style:{display:'grid',gap:14}},
msg&&React.createElement("div",{className:"toast"},msg),
React.createElement("div",{className:"ev-sub",style:{fontSize:13,maxWidth:980}},"Cada regra diz que uma aposta é ",
React.createElement("b",null,"matematicamente a mesma")," que outra: o placar 2-1 no tênis é o vencedor menos o handicap −1,5 sets; o handicap −0,5 é a vitória do 1x2. Só entra o que é ",
React.createElement("b",null,"exato"),", nada estimado. Decisão do Matheus de 03/11 (A, B e C): as regras estão ",React.createElement("b",null,"ligadas")," no EV+, na Odds Screen, nas Super Odds, no detalhe e no robô, com a origem na tela (“calculada por …”, “travada por …”). A conta pelo equivalente entra ",
React.createElement("b",null,"só quando a Pinnacle não tem a aposta direta"),"; com dois caminhos vale o",
React.createElement("b",null,"mais conservador")," (a maior odd justa); conta por diferença só com a ",React.createElement("b",null,"conferência entre caminhos")," (até 2 pontos). “Desligar” ou “Sombra” é o interruptor de emergência (volta a justa de antes em até 1 min, sem deploy). Os números abaixo são medidos a cada 5 min (a justa das fontes aqui é a Pinnacle sem margem, power)."

),
React.createElement("div",{className:"ev-sub"},"Última medição dos jogos: ",React.createElement("b",null,sj&&sj.em?eqHora(sj.em):'nenhuma ainda'),idadeMin!=null?` (há ${idadeMin} min, ${sj.linhasLidas} linhas das casas, ${sj.ms} ms)`:'',
sj&&sj.discordamComLigada?React.createElement(React.Fragment,null," · ",React.createElement("b",{style:{color:'#cf222e'}},sj.discordamComLigada)," seleção(ões) em que a justa de hoje fica a mais de 2 pontos de outro caminho exato"):null,
sj&&(sj.erro||sj.erroEstados||sj.erroGravacao)?React.createElement("div",{style:{color:'#cf222e'}},"Erro: ",sj.erro||sj.erroEstados||sj.erroGravacao):null,
React.createElement("br",null),"Props: ",sp?`${sp.vivas} avaliações vivas (últimos 30 min)`:'sem medição ainda',sp&&sp.erro?React.createElement("span",{style:{color:'#cf222e'}}," · Erro: ",sp.erro):null," · registro ",d.versao.split(',').length," regras"),

React.createElement("h3",{style:{margin:'6px 0 0'}},"Mercados de jogo"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Regra"),React.createElement("th",null,"Estado"),React.createElement("th",{className:"ev-num"},"Linhas do alvo"),React.createElement("th",{className:"ev-num"},"Sem fonte"),React.createElement("th",{className:"ev-num"},"Já tinham justa"),
React.createElement("th",{className:"ev-num"},"Ganham justa"),React.createElement("th",{className:"ev-num"},"No ar"),React.createElement("th",{className:"ev-num"},"EV > 0"),React.createElement("th",{className:"ev-num"},"EV > 3%"),React.createElement("th",null,"Diferença da direta (mediana / 90%)"),React.createElement("th",null,"Entre caminhos"),React.createElement("th",{className:"ev-num"},"Mudam / recusadas"),React.createElement("th",null))),React.createElement("tbody",null,
jogo.map((r)=>{const m=medJ.get(r.id)||{};const ab=aberta===r.id;return React.createElement(React.Fragment,{key:r.id},
React.createElement("tr",{style:{cursor:'pointer'},onClick:()=>setAberta(ab?null:r.id)},
React.createElement("td",null,React.createElement("b",null,r.nome),React.createElement("div",{className:"ev-sub"},r.texto)),React.createElement("td",null,React.createElement(Estado,{r:r})),
React.createElement("td",{className:"ev-num"},m.alvo??'—'),React.createElement("td",{className:"ev-num"},m.semFonte??'—'),React.createElement("td",{className:"ev-num"},m.jaTinhaDireta!=null?`${m.jaTinhaDireta}${m.jaTinhaLigada?` + ${m.jaTinhaLigada}`:''}`:'—'),
React.createElement("td",{className:"ev-num"},r.estado==='ligada'?React.createElement("span",{title:"Regra ligada: estas linhas já têm justa por ela hoje"},m.comCaminho??'—',React.createElement("div",{className:"ev-sub"},"com justa por ela")):React.createElement(React.Fragment,null,React.createElement("b",null,m.ganham??'—'),m.selecoes?React.createElement("div",{className:"ev-sub"},m.selecoes," seleções"):null)),React.createElement("td",{className:"ev-num"},m.frescas??'—'),
React.createElement("td",{className:"ev-num"},m.ev0??'—'),React.createElement("td",{className:"ev-num"},m.ev3??'—'),React.createElement("td",null,eqDif(m.difDireta)),React.createElement("td",null,eqDif(m.difCaminhos)),
React.createElement("td",{className:"ev-num",title:"Mudam: a linha já tinha justa pela linha calculada e esta regra deu uma maior (a mais conservadora vale). Recusadas: conta por diferença sem a conferência entre caminhos."},m.mudam??'—'," / ",m.recusadas??'—'),
React.createElement("td",{onClick:(e)=>e.stopPropagation()},React.createElement(Botoes,{r:r}))),
ab&&React.createElement("tr",null,React.createElement("td",{colSpan:13,style:{background:'var(--bg-2, rgba(127,127,127,.06))'}},
React.createElement(Condicoes,{r:r}),
(m.exemplos||[]).length?React.createElement("div",{className:"tbl-wrap",style:{marginTop:8}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Jogo"),React.createElement("th",null,"Casa"),React.createElement("th",null,"Seleção"),React.createElement("th",{className:"ev-num"},"Odd"),React.createElement("th",{className:"ev-num"},"Justa"),React.createElement("th",{className:"ev-num"},"EV"),React.createElement("th",null,"Caminhos"),React.createElement("th",null,"Fontes da Pinnacle (justa sem margem)"))),React.createElement("tbody",null,
m.exemplos.map((x,i)=>React.createElement("tr",{key:i},React.createElement("td",null,x.jogo,React.createElement("div",{className:"ev-sub"},x.liga||''," · ev. ",x.evento)),React.createElement("td",null,x.fonte),React.createElement("td",null,eqSel(x)),React.createElement("td",{className:"ev-num"},x.odd),React.createElement("td",{className:"ev-num"},x.justa),
React.createElement("td",{className:"ev-num"},"+",eqPc(x.ev),"%"),React.createElement("td",{className:"ev-sub"},x.caminhos.map((c)=>`${c.regra} ${c.justa}`).join(' · ')),React.createElement("td",{className:"ev-sub"},x.fontes.map((f)=>`${eqSel(f)} = ${f.justa}`).join('; '))))
))):React.createElement("div",{className:"ev-sub",style:{marginTop:6}},"Sem exemplo com EV positivo na última medição."),
horasDe(r.id).length?React.createElement("div",{className:"ev-sub",style:{marginTop:8}},"Por hora (média das medições): ",horasDe(r.id).slice(0,12).map((h)=>`${eqHora(h.hora).slice(4)}: ${h.dados.ganhamMedia??0} linhas, ${h.dados.ev3Media??0} com EV>3%, direta ${eqPc(h.dados.difDireta&&h.dados.difDireta.p50)} pt`).join(' · ')):null
))
);})
))),
React.createElement("div",{className:"ev-sub"},"“Já tinham justa”: a linha direta da Pinnacle (mais as que uma regra ligada já cobre). “Diferença da direta”: onde a Pinnacle tem a linha direta, quanto a conta da regra fica longe dela, em pontos percentuais de probabilidade — mostra o ruído de cada caminho. “EV”: odd da casa × probabilidade da regra − 1, só linhas no ar, sem taxa das bolsas."),

React.createElement("h3",{style:{margin:'6px 0 0'}},"Player props"),
React.createElement("div",{className:"tbl-wrap"},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Regra"),React.createElement("th",null,"Estado"),React.createElement("th",{className:"ev-num"},"Seleções avaliadas"),React.createElement("th",{className:"ev-num"},"Travadas (antes fora)"),React.createElement("th",{className:"ev-num"},"Ainda fora"),React.createElement("th",null,"Quanto a justa subiu (mediana / 90% / máx.)"),React.createElement("th",null))),React.createElement("tbody",null,
props.map((r)=>{const m=medP.get(r.id)||{};const ab=aberta===r.id;const pc=(x)=>x==null?'—':'+'+((x-1)*100).toFixed(1).replace('.',',')+'%';return React.createElement(React.Fragment,{key:r.id},
React.createElement("tr",{style:{cursor:'pointer'},onClick:()=>setAberta(ab?null:r.id)},
React.createElement("td",null,React.createElement("b",null,r.nome),React.createElement("div",{className:"ev-sub"},r.texto)),React.createElement("td",null,React.createElement(Estado,{r:r})),
React.createElement("td",{className:"ev-num"},r.tipo==='exata'?m.comAsTres!=null?`${m.comAsTres} com as 3 justas`:'—':m.avaliadas??'—'),
React.createElement("td",{className:"ev-num"},React.createElement("b",null,r.tipo==='exata'?m.negativas!=null?`${m.negativas} dariam negativa`:'—':m.fora??'—')),React.createElement("td",{className:"ev-num",style:m.aindaFora?{color:'#cf222e',fontWeight:700}:undefined},r.tipo==='exata'?'—':m.aindaFora??'—'),
React.createElement("td",null,r.tipo==='exata'?'—':m.subida?`${pc(m.subida.p50)} / ${pc(m.subida.p90)} / ${pc(m.subida.max)}`:'—'),
React.createElement("td",{onClick:(e)=>e.stopPropagation()},React.createElement(Botoes,{r:r}))),
ab&&React.createElement("tr",null,React.createElement("td",{colSpan:7,style:{background:'var(--bg-2, rgba(127,127,127,.06))'}},
React.createElement(Condicoes,{r:r}),
(m.exemplos||[]).length?React.createElement("div",{className:"tbl-wrap",style:{marginTop:8}},React.createElement("table",null,React.createElement("thead",null,React.createElement("tr",null,React.createElement("th",null,"Partida"),React.createElement("th",null,"Jogador"),React.createElement("th",null,"Mercado"),React.createElement("th",{className:"ev-num"},"Justa do segmento"),React.createElement("th",{className:"ev-num"},"Piso"),React.createElement("th",{className:"ev-num"},"Teto"),React.createElement("th",{className:"ev-num"},"Justa travada"))),React.createElement("tbody",null,
m.exemplos.map((x,i)=>React.createElement("tr",{key:i},React.createElement("td",null,x.matchId),React.createElement("td",null,x.jogador||'—'),React.createElement("td",null,x.mercado," ",x.lado),React.createElement("td",{className:"ev-num"},eqPc(x.justa&&Math.round(x.justa*100)/100)),React.createElement("td",{className:"ev-num"},eqPc(x.piso)),React.createElement("td",{className:"ev-num"},eqPc(x.teto)),React.createElement("td",{className:"ev-num"},React.createElement("b",null,eqPc(x.justaAjustada)))))
))):React.createElement("div",{className:"ev-sub",style:{marginTop:6}},"Nenhuma seleção fora do intervalo agora.")
))
);})
))),
React.createElement("div",{className:"ev-sub"},"Piso e teto em odd: a justa de “marca ou assiste” não pode ficar abaixo de 1 ÷ (P marca + P assiste) nem acima da menor das duas justas. “Travadas”: a justa do segmento estava fora e foi presa no intervalo (decisão A). “Ainda fora”: justa gravada fora do intervalo — meta zero."),

(d.log||[]).length?React.createElement("div",{className:"ev-sub"},"Mudanças de estado: ",d.log.map((l)=>`${eqHora(l.em)} ${l.regra}: ${l.de||'—'} → ${l.para} (${l.por||'?'})`).join(' · ')):null
);
}





const VOTO_VELHO_S=1200;
function VotoVelho({em,agora,longo}){
if(!(em>0))return null;
const s=Math.round(((agora||Date.now())-em)/1000);if(s<VOTO_VELHO_S)return null;
const tit='A justa usou um preço de casa sem confirmação há '+fmtIdade(s)+' (o voto mais velho). Não foi cortado: confira antes de apostar.';
return longo?React.createElement("div",{className:"ev-sub",style:{color:'#a35a00',marginTop:4}},React.createElement("b",null,"⏱ Justa com preço velho:")," o voto mais velho está sem confirmação há ",fmtIdade(s),"."):
React.createElement("div",{className:"ev-sub",style:{color:'#a35a00'},title:tit},"⏱ voto há ",fmtIdade(s));
}
function EqOrigem({o,cls,longo}){
if(!o)return null;
const j=(x)=>x==null?'—':String(x).replace('.',',');

const cam=(o.caminhos||[]).map((c)=>(c.conta||c.regra)+' → '+j(c.justa)+(c.conferenciaPp!=null?' (conferência '+j(c.conferenciaPp)+' pt)':'')).join(' · ');
const tit=(o.tipo==='limite'?'A justa do segmento ('+j(o.de)+') estava fora do intervalo exato: piso '+j(o.piso)+', teto '+j(o.teto)+'. ':'A Pinnacle não tem esta aposta direta: a justa sai da conta exata de outro mercado que é a mesma aposta. ')+(o.texto||'')+(cam?' Caminhos: '+cam+(o.caminhos.length>1?' — vale o mais conservador (a maior justa).':''):'');
const txt=o.tipo==='limite'?'travada por '+(o.nome||o.regra):o.conta?'calculada: '+o.conta:'calculada por '+(o.nome||o.regra);
return longo?React.createElement("div",{className:"ev-sub",style:{marginBottom:6}},React.createElement("b",null,txt)," — ",tit):React.createElement("div",{className:cls||'ev-sub',title:tit},txt);
}
function AdminPanel({usuario,onClose,tab,onNav}){


const isSuper=usuario&&usuario.papel==='admin';

const pode=(id)=>isSuper||(usuario&&usuario.abas||ABAS_PADRAO).includes(id);

return React.createElement("div",null,
tab==='props'&&pode('props')&&React.createElement(PlayerPropsTab,{onClose:onClose,onNav:onNav,admin:!!isSuper}),
tab==='ev'&&pode('ev')&&React.createElement(EvTab,{onNav:onNav,pode:pode}),
tab==='odds'&&pode('odds')&&React.createElement(OddsScreenTab,null),
tab==='propscasas'&&isSuper&&React.createElement(PropsCasasTab,{onClose:onClose}),
tab==='propsligas'&&isSuper&&React.createElement(PropsLigasTab,{onClose:onClose}),
tab==='propsparams'&&isSuper&&React.createElement(PropsParamsTab,{onClose:onClose}),
tab==='status'&&React.createElement(StatusTab,{onClose:onClose}),
tab==='fontes'&&isSuper&&React.createElement(FontesTab,{onClose:onClose}),
tab==='logs'&&React.createElement(LogsTab,{onClose:onClose}),
tab==='solic'&&isSuper&&React.createElement(SolicitacoesTab,{onClose:onClose}),
tab==='usuarios'&&isSuper&&React.createElement(UsuariosTab,{onClose:onClose,usuario:usuario}),
tab==='botusers'&&isSuper&&React.createElement(BotUsersTab,{onClose:onClose}),
tab==='perfis'&&isSuper&&React.createElement(PerfisTab,{onClose:onClose}),
tab==='grupo'&&isSuper&&React.createElement(GrupoFiltrosTab,{onClose:onClose}),
tab==='tipsgrupos'&&isSuper&&React.createElement(TipsGruposTab,{usuario:usuario}),
tab==='pareamentos'&&isSuper&&React.createElement(PareamentosTab,{onClose:onClose}),
tab==='obsliq'&&isSuper&&React.createElement(ObsLiquidacaoTab,null),
tab==='evfiltro'&&isSuper&&usuario&&usuario.master&&React.createElement(EvFiltroTab,null),
tab==='evhist'&&isSuper&&usuario&&usuario.master&&React.createElement(EvHistoricoTab,null),
tab==='evjusta'&&isSuper&&usuario&&usuario.master&&React.createElement(JustaSegmentoTab,null),
tab==='chavesleitura'&&isSuper&&usuario&&usuario.master&&React.createElement(ChavesLeituraTab,null),
tab==='equivalencias'&&isSuper&&usuario&&usuario.master&&React.createElement(EquivalenciasTab,null),
tab==='meusfiltros'&&React.createElement(MeusFiltrosTab,{onClose:onClose}),
tab==='conta'&&React.createElement(MinhaContaTab,{usuario:usuario,onClose:onClose})
);
}


function GrupoFiltrosTab({onClose}){




const[grupos,setGrupos]=useState([]);
const[casas,setCasas]=useState([]);
const[labelsPorCasa,setLabelsPorCasa]=useState({});
const[casasComLive,setCasasComLive]=useState([]);
const[sel,setSel]=useState(0);
const[carregando,setCarregando]=useState(true),[msg,setMsg]=useState('');
const[q,setQ]=useState(''),[flt,setFlt]=useState('all');
const[labelModal,setLabelModal]=useState(null);
const[novoModal,setNovoModal]=useState(false);
const[editModal,setEditModal]=useState(null);
const headers={'Content-Type':'application/json'};

const TIPOS=[['new','Nova Odd',false],['increased','Aumento',true],['decreased','Diminuição',true],['readded','Reabertura',false],['removed','Odd Removida',false]];

const carregar=async()=>{
try{
const r=await fetch('/api/admin/grupos-config',{credentials:'include'});
if(r.status===401){onClose('relogin');return;}
const d=await r.json();
setGrupos(d.grupos||[]);
setCasas((d.casas||[]).slice().sort((a,b)=>a.localeCompare(b,'pt-BR',{sensitivity:'base'})));
setLabelsPorCasa(d.labelsPorCasa||{});
setCasasComLive(d.casasComLive||[]);
}catch(e){setMsg('❌ '+e.message);}finally{setCarregando(false);}
};
useEffect(()=>{carregar();},[]);

const salvar=async(novaLista)=>{
const lista=novaLista||grupos;
try{
const r=await fetch('/api/admin/grupos-config',{method:'POST',credentials:'include',headers,body:JSON.stringify({grupos:lista})});
if(!r.ok)throw new Error((await r.json().catch(()=>({}))).error||'Erro ao salvar');
const d=await r.json();
setGrupos(d.grupos||lista);
setMsg('✅ Salvo');setTimeout(()=>setMsg(''),2000);
}catch(e){setMsg('❌ '+e.message);}
};



const selSafe=grupos.length?Math.min(Math.max(sel,0),grupos.length-1):0;


const patchGrupo=(patch)=>{
const lista=grupos.map((g,i)=>i===selSafe?{...g,...patch}:g);
setGrupos(lista);salvar(lista);
};

if(carregando)return React.createElement("div",{style:{textAlign:'center',padding:48,color:'var(--on-surface-variant)'}},"Carregando…");

const g=grupos[selSafe];


const criarGrupo=(nome,chatId)=>{
const id=nome.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'grupo-'+Date.now();
const novo={id,nome,chatId,casasBloqueadas:[],labelsBloqueadosPorCasa:{},casasSemLive:[],
tipos:{new:{on:true},increased:{on:true,minPct:10},decreased:{on:false,minPct:10},readded:{on:true},removed:{on:false}}};
const lista=[...grupos,novo];setSel(lista.length-1);setNovoModal(false);salvar(lista);
};
const editarGrupo=(nome,chatId)=>{const lista=grupos.map((x,i)=>i===selSafe?{...x,nome,chatId}:x);setEditModal(null);salvar(lista);};
const removerGrupo=async()=>{
if(!(await confirma(`Remover o grupo "${g.nome}"? Ele deixa de receber alertas.`)))return;
const lista=grupos.filter((_,i)=>i!==selSafe);setSel(Math.max(0,selSafe-1));salvar(lista);
};


const bloquearCasa=(casa)=>patchGrupo({casasBloqueadas:g.casasBloqueadas.includes(casa)?g.casasBloqueadas:[...g.casasBloqueadas,casa]});
const desbloquearCasa=(casa)=>patchGrupo({casasBloqueadas:g.casasBloqueadas.filter((c)=>c!==casa)});
const liberarTudo=(casa)=>{const lb={...g.labelsBloqueadosPorCasa};delete lb[casa];patchGrupo({labelsBloqueadosPorCasa:lb,casasBloqueadas:g.casasBloqueadas.filter((c)=>c!==casa)});};
const toggleLive=(casa)=>patchGrupo({casasSemLive:g.casasSemLive.includes(casa)?g.casasSemLive.filter((c)=>c!==casa):[...g.casasSemLive,casa]});
const salvarFiltroLabels=(casa,marcados)=>{
const todos=labelsPorCasa[casa]||[];
const bloqueados=todos.filter((l)=>!marcados.includes(l));
const lb={...g.labelsBloqueadosPorCasa};
if(bloqueados.length)lb[casa]=bloqueados;else delete lb[casa];
patchGrupo({labelsBloqueadosPorCasa:lb});
};

const toggleTipo=(k)=>patchGrupo({tipos:{...g.tipos,[k]:{...g.tipos[k],on:!g.tipos[k].on}}});
const setMinPct=(k,v)=>patchGrupo({tipos:{...g.tipos,[k]:{...g.tipos[k],minPct:Number(v)||0}}});


const linhas=casas.filter((c)=>{
if(q&&!c.toLowerCase().includes(q.toLowerCase()))return false;
const temBloq=(g.labelsBloqueadosPorCasa[c]||[]).length>0;
if(flt==='blocked')return g.casasBloqueadas.includes(c);
if(flt==='filtered')return temBloq&&!g.casasBloqueadas.includes(c);
if(flt==='live')return casasComLive.includes(c);
return true;
});

return React.createElement(React.Fragment,null,
msg&&React.createElement("div",{className:"toast"},msg),


React.createElement("div",{style:{display:'flex',gap:8,flexWrap:'wrap',marginBottom:16,alignItems:'center'}},
grupos.map((gr,i)=>
React.createElement("button",{key:gr.id,onClick:()=>setSel(i),className:"segb"+(i===selSafe?' on':''),
style:{padding:'8px 16px',borderRadius:9,border:'1px solid '+(i===selSafe?'var(--teal-deep)':'var(--line-2)'),background:i===selSafe?'var(--teal-deep)':'var(--paper-2)',color:i===selSafe?'#fff':'var(--navy-700)',fontWeight:600,fontSize:13,cursor:'pointer'}},
gr.nome.replace(/^Odds Radar - /,'')
)),
React.createElement("button",{onClick:()=>setNovoModal(true),style:{padding:'8px 14px',borderRadius:9,border:'1px dashed var(--line-2)',background:'transparent',color:'var(--teal-deep)',fontWeight:600,fontSize:13,cursor:'pointer'}},"+ Novo grupo")
),

!g?React.createElement("div",{style:{textAlign:'center',padding:40,color:'var(--on-surface-variant)'}},"Nenhum grupo. Clique em \"+ Novo grupo\" pra criar."):React.createElement(React.Fragment,null,


React.createElement("div",{className:"glass panel",style:{marginBottom:14,padding:'16px 18px',display:'flex',alignItems:'center',justifyContent:'space-between',gap:12,flexWrap:'wrap'}},
React.createElement("div",{style:{display:'flex',flexDirection:'column',gap:6}},
React.createElement("div",{style:{fontWeight:700,fontSize:16,color:'var(--navy-900)',lineHeight:1.2}},g.nome),
React.createElement("div",{style:{display:'flex',alignItems:'center',gap:6}},
React.createElement("span",{style:{fontSize:11,color:'var(--on-surface-variant)',textTransform:'uppercase',letterSpacing:.3}},"chat id"),
React.createElement("code",{style:{fontSize:12,background:'var(--paper-2)',border:'1px solid var(--line-2)',borderRadius:6,padding:'2px 8px',color:'var(--navy-700)'}},g.chatId)
)
),
React.createElement("div",{style:{display:'flex',gap:8,flexShrink:0}},
React.createElement("button",{className:"btn-sm b-amber",onClick:()=>setEditModal({nome:g.nome,chatId:g.chatId})},"Editar"),
React.createElement("button",{className:"btn-sm b-red",onClick:removerGrupo},"Remover grupo")
)
),


React.createElement("div",{className:"glass panel",style:{marginBottom:14}},
React.createElement("div",{className:"panel-head",style:{cursor:'default'}},React.createElement("div",{className:"t"},React.createElement("h2",null,"Tipos de evento"))),
React.createElement("div",{style:{display:'flex',flexWrap:'wrap',gap:10,padding:'6px 2px'}},
TIPOS.map(([k,label,temPct])=>{const t=g.tipos[k]||{on:false};return(
React.createElement("div",{key:k,style:{display:'flex',alignItems:'center',gap:8,border:'1px solid var(--line-2)',borderRadius:10,padding:'8px 12px',background:t.on?'var(--paper-2)':'transparent'}},
React.createElement("button",{onClick:()=>toggleTipo(k),title:t.on?'ligado':'desligado',
style:{width:38,height:22,borderRadius:12,border:'none',cursor:'pointer',background:t.on?'var(--teal-deep)':'var(--line-2)',position:'relative',flexShrink:0}},
React.createElement("span",{style:{position:'absolute',top:2,left:t.on?18:2,width:18,height:18,borderRadius:'50%',background:'#fff',transition:'left .15s'}})
),
React.createElement("span",{style:{fontSize:13,fontWeight:600,color:t.on?'var(--navy-900)':'var(--on-surface-variant)'}},label),
temPct&&t.on&&React.createElement("span",{style:{display:'flex',alignItems:'center',gap:4}},
React.createElement("span",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},"mín"),
React.createElement("input",{type:"number",min:"0",step:"0.5",value:t.minPct??10,onChange:(e)=>setMinPct(k,e.target.value),
style:{width:56,height:30,padding:'0 6px',border:'1px solid var(--line-2)',borderRadius:7,fontSize:12.5,background:'#fff'}}),
React.createElement("span",{style:{fontSize:11.5,color:'var(--on-surface-variant)'}},"%")
)
));})
),
React.createElement("div",{style:{fontSize:11.5,color:'var(--on-surface-variant)',padding:'2px 4px 4px'}},"Aumento/Diminuição: só envia se a variação for maior ou igual ao mínimo.")
),


React.createElement("div",{className:"adm-filters"},
React.createElement("input",{className:"adm-inp",placeholder:"Buscar casa…",value:q,onChange:(e)=>setQ(e.target.value)}),
React.createElement("div",{className:"seg"},[['all','Todas'],['filtered','Filtradas'],['blocked','Bloqueadas'],['live','Com live']].map(([v,l])=>React.createElement("button",{key:v,className:"segb"+(flt===v?' on':''),onClick:()=>setFlt(v)},l)))
),


React.createElement("h3",{className:"sec-t",style:{color:'var(--primary)'}},"Casas (",linhas.length,")"),
React.createElement("div",{className:"tbl-wrap"},
React.createElement("table",null,
React.createElement("thead",null,React.createElement("tr",{style:{cursor:'default'}},React.createElement("th",{style:{cursor:'default'}},"Casa"),React.createElement("th",{style:{cursor:'default'}},"Status no Grupo"),React.createElement("th",{style:{cursor:'default'}},"Labels Ativos"),React.createElement("th",{style:{cursor:'default'}},"Ao Vivo"),React.createElement("th",{style:{cursor:'default'}},"Ações"))),
React.createElement("tbody",null,
linhas.map((casa)=>{
const todos=(labelsPorCasa[casa]||[]).slice().sort((a,b)=>(a||'').localeCompare(b||'','pt-BR'));
const bloqueados=g.labelsBloqueadosPorCasa[casa]||[];
const casaBloqueada=g.casasBloqueadas.includes(casa);
const temFiltro=bloqueados.length>0;
const temLive=casasComLive.includes(casa);
const liveOff=g.casasSemLive.includes(casa);
const permitidos=todos.filter((l)=>!bloqueados.includes(l));
return React.createElement("tr",{key:casa},
React.createElement("td",{style:{fontWeight:600,whiteSpace:'nowrap'}},React.createElement("span",{className:"sdot",style:{background:casaBloqueada?'var(--down)':'var(--primary)'}}),casa),
React.createElement("td",{style:{whiteSpace:'nowrap'}},
casaBloqueada?React.createElement("span",{style:{color:'var(--error,#E24B4A)',fontWeight:600}},"🔒 Bloqueada"):
temFiltro?React.createElement("span",{style:{color:'#B8860B',fontWeight:600}},"⚠️ Filtrada"):
React.createElement("span",{style:{color:'var(--primary)',fontWeight:600}},"✅ Liberada")
),
React.createElement("td",null,todos.length>0?todos.map((l)=>React.createElement("span",{key:l,className:"pill",style:bloqueados.includes(l)?{textDecoration:'line-through',opacity:.55}:null},l)):React.createElement("span",{style:{color:'var(--on-surface-variant)',opacity:.5}},"—")),
React.createElement("td",{style:{whiteSpace:'nowrap'}},
!temLive?React.createElement("span",{style:{color:'var(--on-surface-variant)',opacity:.5,fontSize:12}},"—"):
React.createElement("button",{onClick:()=>toggleLive(casa),disabled:casaBloqueada,title:liveOff?'live desligado':'live ligado',
style:{width:38,height:22,borderRadius:12,border:'none',cursor:casaBloqueada?'default':'pointer',background:!liveOff&&!casaBloqueada?'var(--teal-deep)':'var(--line-2)',position:'relative',opacity:casaBloqueada?.4:1}},
React.createElement("span",{style:{position:'absolute',top:2,left:!liveOff&&!casaBloqueada?18:2,width:18,height:18,borderRadius:'50%',background:'#fff'}})
)
),
React.createElement("td",{style:{whiteSpace:'nowrap'}},React.createElement("div",{style:{display:'flex',gap:6}},
casaBloqueada?
React.createElement("button",{className:"btn-sm b-green",onClick:()=>desbloquearCasa(casa)},"Liberar"):
temFiltro?
React.createElement(React.Fragment,null,React.createElement("button",{className:"btn-sm b-green",onClick:()=>liberarTudo(casa)},"Liberar tudo"),React.createElement("button",{className:"btn-sm b-red",onClick:()=>bloquearCasa(casa)},"Bloquear")):
React.createElement("button",{className:"btn-sm b-red",onClick:()=>bloquearCasa(casa)},"Bloquear"),
React.createElement("button",{className:"btn-sm b-amber",onClick:()=>setLabelModal({casa,allLabels:todos,current:permitidos}),disabled:casaBloqueada,style:casaBloqueada?{opacity:.45,cursor:'default'}:null},"Filtrar")
))
);
})
)
)
),
linhas.length===0&&React.createElement("div",{style:{textAlign:'center',padding:30,color:'var(--on-surface-variant)'}},"Nenhuma casa pra esse filtro.")
),

labelModal&&React.createElement(LabelModal,{casa:labelModal.casa,allLabels:labelModal.allLabels,current:labelModal.current,
onSave:(marcados)=>salvarFiltroLabels(labelModal.casa,marcados),onClose:()=>setLabelModal(null)}),
novoModal&&React.createElement(GrupoModal,{titulo:"Novo grupo",onSave:criarGrupo,onClose:()=>setNovoModal(false)}),
editModal&&React.createElement(GrupoModal,{titulo:"Editar grupo",nomeInit:editModal.nome,chatIdInit:editModal.chatId,onSave:editarGrupo,onClose:()=>setEditModal(null)})
);
}


function GrupoModal({titulo,nomeInit,chatIdInit,onSave,onClose}){
const[nome,setNome]=useState(nomeInit||'');
const[chatId,setChatId]=useState(chatIdInit||'');
const ok=nome.trim()&&chatId.trim();
return React.createElement("div",{className:"overlay",onClick:(e)=>e.target===e.currentTarget&&onClose()},
React.createElement("div",{className:"modal",style:{maxWidth:440}},
React.createElement("h3",{style:{fontFamily:'var(--f-display)',fontSize:17,fontWeight:700,color:'var(--navy-900)',marginBottom:14}},titulo),
React.createElement("div",{className:"fg",style:{marginBottom:12}},
React.createElement("label",null,"Nome do grupo"),
React.createElement("input",{className:"adm-inp",style:{width:'100%',flex:'none'},value:nome,onChange:(e)=>setNome(e.target.value),placeholder:"Ex: Odds Radar - Águas Profundas"})
),
React.createElement("div",{className:"fg",style:{marginBottom:8}},
React.createElement("label",null,"Chat ID do Telegram"),
React.createElement("input",{className:"adm-inp",style:{width:'100%',flex:'none'},value:chatId,onChange:(e)=>setChatId(e.target.value),placeholder:"Ex: -1004318027455"}),
React.createElement("div",{style:{fontSize:11,color:'var(--on-surface-variant)',marginTop:5}},"O ID do supergrupo (começa com -100). O bot precisa ser admin lá.")
),
React.createElement("div",{style:{display:'flex',gap:9,marginTop:18}},
React.createElement("button",{className:"btn-sm b-green",style:{flex:1,padding:10,opacity:ok?1:.5,cursor:ok?'pointer':'default'},disabled:!ok,onClick:()=>ok&&onSave(nome.trim(),chatId.trim())},"Salvar"),
React.createElement("button",{className:"btn-sm b-red",style:{flex:1,padding:10},onClick:onClose},"Cancelar")
)
)
);
}


function OddsTable({odds,sort,onSort}){
const pct=(o)=>o.original_odds>0?Math.round((o.odds-o.original_odds)/o.original_odds*100):null;



const[larg,salvaLarg]=usePrefServidor('soColW',{});
const[arrasto,setArrasto]=useState(null);
const Wd=arrasto||larg||{};
const soltouEm=useRef(0);
const cw=(k,conteudo)=>Wd[k]?React.createElement("div",{className:"so-cw",style:{width:Wd[k]}},conteudo):conteudo;
const fix=(k)=>Wd[k]?' so-fix':'';
const inicia=(e,k)=>{
e.preventDefault();e.stopPropagation();
const th=e.currentTarget.parentElement,cs=getComputedStyle(th),el=e.currentTarget;
const w0=th.getBoundingClientRect().width-parseFloat(cs.paddingLeft||0)-parseFloat(cs.paddingRight||0);
const x0=e.clientX;let atual={...Wd};el.classList.add('on');
const mv=(ev)=>{atual={...atual,[k]:Math.max(30,Math.round(w0+ev.clientX-x0))};setArrasto(atual);};
const up=()=>{window.removeEventListener('mousemove',mv);window.removeEventListener('mouseup',up);el.classList.remove('on');
soltouEm.current=Date.now();setArrasto(null);salvaLarg(atual);};
window.addEventListener('mousemove',mv);window.addEventListener('mouseup',up);
};
const reseta=(e,k)=>{e.preventDefault();e.stopPropagation();soltouEm.current=Date.now();const n={...(larg||{})};delete n[k];salvaLarg(n);};
const Rz=({k})=>React.createElement("span",{className:"so-rz",title:"arraste para mudar a largura (fica salva) · dois cliques: automático",onMouseDown:(e)=>inicia(e,k),onClick:(e)=>e.stopPropagation(),onDoubleClick:(e)=>reseta(e,k)});


const th=(col,label,alignR)=>{
const pos=sort.findIndex((x)=>x.col===col);
const on=pos>=0;
const dir=on?sort[pos].dir:null;

return React.createElement("th",{className:(on?'sorted':'')+fix(col),onClick:()=>{if(Date.now()-soltouEm.current<400)return;onSort(col);},style:alignR?{textAlign:'right'}:null},
cw(col,React.createElement(React.Fragment,null,label,React.createElement(Ic,{n:on?dir==='asc'?'arrow_upward':'arrow_downward':'unfold_more'}),
on&&sort.length>1?React.createElement("sup",{style:{fontSize:'9px',marginLeft:'1px',color:'var(--teal-deep)',fontWeight:700}},pos+1):null)),
React.createElement(Rz,{k:col})
);
};
const go=(o)=>{const u=o.url||o.casa_url;if(u)window.open(u,'_blank','noopener');};
const bet=(o)=>{const rn=o.runner_name||'';return rn.includes('\n')?rn.split('\n').map((p)=>p.replace(/^\s*•\s*/,'')).join(' + '):rn;};
return React.createElement("div",{className:"tbl-view"},React.createElement("table",{className:"odds-tbl"},
React.createElement("thead",null,React.createElement("tr",null,
th('casa','Casa'),
th('event','Evento'),
th('comp','Torneio'),
th('bet','Aposta'),
th('label','Boost'),
th('sport','Esporte'),
th('odds','Odd',true),
th('pct','Aumento',true),
th('ev','Justa/EV',true),
th('recent','Quando',true),
React.createElement("th",{className:fix('go')},cw('go',''),React.createElement(Rz,{k:"go"}))
)),
React.createElement("tbody",null,odds.map((o)=>{const p=pct(o);return(
React.createElement("tr",{key:o.uuid,onClick:()=>go(o)},
React.createElement("td",{className:"td-casa"+fix('casa'),title:o.casa},cw('casa',React.createElement(React.Fragment,null,React.createElement("span",{className:"cdot",style:{background:casaColor(o.casa)}}),o.casa,React.createElement(ObsAlerta,{casa:o.casa,mercado:o.mercado_cat,esporte:o.sport})))),
React.createElement("td",{className:"td-ev"+fix('event'),title:o.event_name_casa?'Na casa: '+o.event_name_casa:o.event_name||''},cw('event',o.event_name||'—')),
React.createElement("td",{className:"td-comp"+fix('comp'),title:o.competition||''},cw('comp',o.competition||'—')),
React.createElement("td",{className:"td-bet"+fix('bet'),title:bet(o)||''},cw('bet',bet(o)||'—')),
React.createElement("td",{className:fix('label')},cw('label',o.boost_label?React.createElement("span",{className:"t-label"},o.boost_label):'—')),
React.createElement("td",{className:fix('sport')},cw('sport',React.createElement(React.Fragment,null,o.sport||'—',o.live?React.createElement("span",{className:"t-live"},"LIVE"):null))),
React.createElement("td",{className:"t-odds"+fix('odds'),style:{textAlign:'right'}},cw('odds',React.createElement(React.Fragment,null,o.original_odds>0&&React.createElement("span",{className:"orig"},Number(o.original_odds).toFixed(2)),Number(o.odds).toFixed(2),o.limite_aposta>0&&React.createElement("span",{className:"o-lim",style:{fontSize:'11px',opacity:.8,marginLeft:'6px',whiteSpace:'nowrap'},title:'Aposta máxima que a casa aceita neste boost'+(o.limite_pagamento>0?' · prêmio máximo '+Number(o.limite_pagamento).toLocaleString('pt-BR'):'')+(o.limite_moeda?' ('+String(o.limite_moeda).toUpperCase()+')':'')},"máx. ",String(o.limite_moeda||'').toLowerCase()==='usd'?'US$ ':String(o.limite_moeda||'').toLowerCase()==='brl'?'R$ ':'',Number(o.limite_aposta).toLocaleString('pt-BR'))))),
React.createElement("td",{className:"t-pct"+(p==null||p<=0?' neg':'')+fix('pct'),style:{textAlign:'right'}},cw('pct',p!=null?p>0?'+'+p+'%':p+'%':'—')),
React.createElement("td",{className:fix('ev'),style:{textAlign:'right',fontFamily:'var(--f-data)',fontSize:'12.5px'}},cw('ev',React.createElement(React.Fragment,null,o.fair_odds>0?React.createElement(React.Fragment,null,Number(o.fair_odds).toFixed(2),o.ev_pct!=null&&React.createElement("span",{style:{marginLeft:6,fontWeight:700,color:Number(o.ev_pct)>=0?'var(--up)':'#B3423A'}},Number(o.ev_pct)>=0?'+':'',Number(o.ev_pct).toFixed(1),"%"),(()=>{const k=kellyQuarto(o);return k>0?React.createElement("span",{style:{marginLeft:6,fontSize:'11px',color:'var(--on-surface-variant)'}},"K¼ ",(k*100).toFixed(2),"%"):null;})(),o.motor&&o.motor.regra&&React.createElement("span",{title:o.motor.regra,style:{marginLeft:6,fontSize:'10.5px',fontWeight:700,color:'#B3423A'}},"⛔ regra"),o.motor&&o.motor.liq&&o.motor.liq!=='sem_efeito'&&React.createElement("span",{title:'Liquidação (mesmo efeito da EV+): '+o.motor.liq,style:{marginLeft:6,fontSize:'10.5px',fontWeight:700,color:o.motor.liq==='a_favor'?'var(--up)':'#8a6110'}},"liq: ",o.motor.liq.replace('_',' ')),o.fair_min!=null&&React.createElement("span",{title:"Idade da justa (defasagem do ciclo, não erro)",style:{marginLeft:6,fontSize:'10.5px',color:Number(o.fair_min)>3?'#8a6110':'var(--on-surface-variant)',fontWeight:Number(o.fair_min)>3?700:400}},Number(o.fair_min)>3?'⚠ ':'',"há ",o.fair_min,"min")):o.live?'—':React.createElement("span",{title:o.justa_motivo?'Sem justa: '+o.justa_motivo:'Ainda não avaliada pelo motor',style:{fontSize:'11px',color:'var(--on-surface-variant)',fontFamily:'var(--f-body)'}},"— ",o.justa_motivo?o.justa_motivo:'aguardando cálculo')))),
React.createElement("td",{className:"t-ago"+fix('recent'),style:{textAlign:'right'}},cw('recent',timeAgo(o.createdAt))),
React.createElement("td",{className:fix('go'),style:{textAlign:'right'}},cw('go',(o.url||o.casa_url)&&React.createElement("a",{className:"t-go",href:o.url||o.casa_url,target:"_blank",rel:"noopener noreferrer",onClick:(e)=>e.stopPropagation()},"Ir →")))
));}))
));
}

function App(){
const[pagina,setPagina]=useRota('p','dashboard',true);

const irMenu=(id)=>{if(window.Rota)window.Rota.set({p:id==='dashboard'?null:id},{push:true,manter:['p','v']});setPagina(id);};
const[usuario,setUsuario]=useState(null);



const[semUsuario,setSemUsuario]=useState({espera:true,tentativas:0,erro:''});
useEffect(()=>{let vivo=true;
leJson('/api/auth/me',{aoFalhar:(e,n)=>{if(vivo)setSemUsuario({espera:true,tentativas:n,erro:''});}}).
then((d)=>{if(!d||!d.usuario)throw new Error('o painel respondeu sem o usuário');if(vivo)setUsuario(d.usuario);}).
catch((e)=>{if(!vivo)return;if(e.status===401){location.href='/login';return;}setSemUsuario({espera:false,tentativas:0,erro:e.message});});
return()=>{vivo=false;};},[]);


const[versaoNova,setVersaoNova]=useState(false);
useEffect(()=>{let base=null;const ver=()=>fetch('/api/versao').then((r)=>r.ok?r.json():null).then((d)=>{if(!d)return;if(base===null)base=d.versao;else if(d.versao!==base)setVersaoNova(true);}).catch(()=>{});ver();const t=setInterval(ver,60000);return()=>clearInterval(t);},[]);
const[odds,setOdds]=useState([]),[stats,setStats]=useState(null),[loading,setLoading]=useState(true);
const[filterCasas,setFilterCasas]=useState([]),[filterLabels,setFilterLabels]=useState([]);
const[filterSport,setFilterSport]=useState([]),[searchEvent,setSearchEvent]=useState('');
const[searchAposta,setSearchAposta]=useState(''),[oddMin,setOddMin]=useState('');
const[oddMax,setOddMax]=useState(''),[sortBy,setSortBy]=useState('recent');
const[autoRefresh,setAutoRefresh]=useState(true),[filtersOpen,setFiltersOpen]=useState(true);
const[showAllCasas,setShowAllCasas]=useState(false);


const[menuAberto,setMenuAberto]=useState(()=>{try{return localStorage.getItem('menuAberto')!=='0';}catch(e){return true;}});
useEffect(()=>{try{localStorage.setItem('menuAberto',menuAberto?'1':'0');}catch(e){}},[menuAberto]);
const[visibleCount,setVisibleCount]=useState(100);
const[filterLive,setFilterLive]=useState('');
const[filterTipo,setFilterTipo]=useState('');
const[filterActive,setFilterActive]=useState(true);
const[view,setView]=useRota('v','cards');



const[tblSort,setTblSort]=useState([{col:'recent',dir:'desc'}]);
const[filterComp,setFilterComp]=useState([]);
const[pctMin,setPctMin]=useState('');
const[evMin,setEvMin]=useState('');
const[truncado,setTruncado]=useState(false);
const[apiErro,setApiErro]=useState('');
const[facetaTorneios,setFacetaTorneios]=useState([]);
const[limiteOdds,setLimiteOdds]=useState(0);





const fetchSeq=useRef(0);
const paginaRef=useRef(pagina);
paginaRef.current=pagina;
const compNamesRef=useRef([]);

const hasFilters=filterCasas.length>0||filterLabels.length>0||filterSport.length>0||searchEvent||searchAposta||oddMin||oddMax||filterLive||!filterActive||filterComp.length>0||pctMin||evMin||filterTipo;
const clearFilters=()=>{setFilterCasas([]);setFilterLabels([]);setFilterSport([]);setSearchEvent('');setSearchAposta('');setOddMin('');setOddMax('');setFilterLive('');setFilterActive(true);setFilterComp([]);setPctMin('');setEvMin('');setFilterTipo('');};












const[searchEventDeb,setSearchEventDeb]=useState('');
const[searchApostaDeb,setSearchApostaDeb]=useState('');
const[oddMinDeb,setOddMinDeb]=useState('');
const[oddMaxDeb,setOddMaxDeb]=useState('');
const[pctMinDeb,setPctMinDeb]=useState('');
const[evMinDeb,setEvMinDeb]=useState('');
useEffect(()=>{const t=setTimeout(()=>setSearchEventDeb(searchEvent),400);return()=>clearTimeout(t);},[searchEvent]);
useEffect(()=>{const t=setTimeout(()=>setSearchApostaDeb(searchAposta),400);return()=>clearTimeout(t);},[searchAposta]);
useEffect(()=>{const t=setTimeout(()=>setOddMinDeb(oddMin),400);return()=>clearTimeout(t);},[oddMin]);
useEffect(()=>{const t=setTimeout(()=>setOddMaxDeb(oddMax),400);return()=>clearTimeout(t);},[oddMax]);
useEffect(()=>{const t=setTimeout(()=>setPctMinDeb(pctMin),400);return()=>clearTimeout(t);},[pctMin]);
useEffect(()=>{const t=setTimeout(()=>setEvMinDeb(evMin),400);return()=>clearTimeout(t);},[evMin]);

const fetchData=useCallback(async()=>{
const meuSeq=++fetchSeq.current;
try{
const p=new URLSearchParams();





const lista=(a)=>'\x1f'+a.join('\x1f');
if(filterCasas.length)p.set('casas',lista(filterCasas));
if(filterLabels.length)p.set('boost_labels',lista(filterLabels));
if(filterSport.length)p.set('sports',lista(filterSport));
if(filterLive)p.set('live',filterLive);
if(filterTipo)p.set('tipo',filterTipo);
if(sortBy==='ev'||view==='table'&&tblSort[0]&&tblSort[0].col==='ev')p.set('ordenar','ev');
p.set('active',filterActive?'1':'0');
if(searchEventDeb)p.set('search_event',searchEventDeb);
if(searchApostaDeb)p.set('search_aposta',searchApostaDeb);






const compsTotal=compNamesRef.current.length;
if(filterComp.length&&!(compsTotal&&filterComp.length>=compsTotal)){
const v=lista(filterComp);
if(encodeURIComponent(v).length<=6000)p.set('competitions',v);
}
if(oddMinDeb!==''&&!isNaN(parseFloat(oddMinDeb)))p.set('odd_min',oddMinDeb);
if(oddMaxDeb!==''&&!isNaN(parseFloat(oddMaxDeb)))p.set('odd_max',oddMaxDeb);
if(pctMinDeb!==''&&!isNaN(parseFloat(pctMinDeb)))p.set('pct_min',pctMinDeb);
if(evMinDeb!==''&&!isNaN(parseFloat(evMinDeb)))p.set('ev_min',evMinDeb);




const[ro,rs,rt]=await Promise.all([
fetch(`/api/odds?${p}`,{credentials:'include'}),
fetch(`/api/stats?active=${filterActive?'1':'0'}`,{credentials:'include'}),
fetch(`/api/torneios?${p}`,{credentials:'include'})]
);


if(meuSeq!==fetchSeq.current||paginaRef.current!=='dashboard')return;
if(ro.status===401||rs.status===401){location.href='/login';return;}
const[o,s]=await Promise.all([ro.json().catch(()=>null),rs.json().catch(()=>null)]);
const t=rt.ok?await rt.json().catch(()=>[]):[];


if(meuSeq!==fetchSeq.current||paginaRef.current!=='dashboard')return;





if(Array.isArray(o)){setOdds(o);setApiErro('');}else
setApiErro(String(o&&o.error||'HTTP '+ro.status));
if(s&&typeof s==='object'&&!s.error)setStats(s);
setTruncado(ro.headers.get('X-Odds-Truncado')==='1');
setLimiteOdds(Number(ro.headers.get('X-Odds-Limite'))||0);


if(rt.ok)setFacetaTorneios(Array.isArray(t)?t:[]);
}catch(e){console.error(e);}finally{if(meuSeq===fetchSeq.current&&paginaRef.current==='dashboard')setLoading(false);}},[filterCasas,filterLabels,filterSport,filterLive,filterActive,searchEventDeb,searchApostaDeb,filterComp,oddMinDeb,oddMaxDeb,pctMinDeb,evMinDeb,filterTipo,sortBy,tblSort,view]);



useEffect(()=>{if(pagina==='dashboard')fetchData();else fetchSeq.current++;},[pagina,fetchData]);
useEffect(()=>{if(pagina!=='dashboard'||!autoRefresh)return;const i=setInterval(fetchData,30000);return()=>clearInterval(i);},[pagina,autoRefresh,fetchData]);



const pct=(o)=>o.original_odds>0?(o.odds-o.original_odds)/o.original_odds*100:0;
const clientFiltered=useMemo(()=>{
const nMin=parseFloat(oddMin),nMax=parseFloat(oddMax),nPct=parseFloat(pctMin),nEv=parseFloat(evMin);

const qEv=normBusca(searchEvent);
const qAp=normBusca(searchAposta);
return odds.filter((o)=>{
if(!isNaN(nMin)&&o.odds<nMin)return false;
if(!isNaN(nMax)&&o.odds>nMax)return false;
if(!isNaN(nPct)&&pct(o)<nPct)return false;
if(!isNaN(nEv)&&(o.ev_pct==null||Number(o.ev_pct)<nEv))return false;
if(filterComp.length&&!filterComp.includes(o.competition))return false;
if(qEv&&!normBusca((o.event_name||'')+' '+(o.event_name_casa||'')).includes(qEv))return false;
if(qAp&&!(normBusca(o.runner_name).includes(qAp)||normBusca(o.market_name).includes(qAp)))return false;
return true;
});
},[odds,oddMin,oddMax,pctMin,evMin,filterComp,searchEvent,searchAposta]);


const cmp={
casa:(a,b)=>(a.casa||'').localeCompare(b.casa||'','pt-BR'),
event:(a,b)=>(a.event_name||'').localeCompare(b.event_name||'','pt-BR'),
comp:(a,b)=>(a.competition||'').localeCompare(b.competition||'','pt-BR'),
bet:(a,b)=>(a.runner_name||'').localeCompare(b.runner_name||'','pt-BR'),
label:(a,b)=>(a.boost_label||'').localeCompare(b.boost_label||'','pt-BR'),
sport:(a,b)=>(a.sport||'').localeCompare(b.sport||'','pt-BR'),
odds:(a,b)=>a.odds-b.odds,
pct:(a,b)=>pct(a)-pct(b),
ev:(a,b)=>(a.ev_pct==null?-1e9:Number(a.ev_pct))-(b.ev_pct==null?-1e9:Number(b.ev_pct)),
recent:(a,b)=>new Date(a.createdAt)-new Date(b.createdAt)
};
const sortedOdds=useMemo(()=>{
const s=[...clientFiltered];
if(view==='table'){


const cols=tblSort&&tblSort.length?tblSort:[{col:'recent',dir:'desc'}];
s.sort((a,b)=>{
for(const{col,dir}of cols){
const f=cmp[col]||cmp.recent;
const r=f(a,b);
if(r!==0)return dir==='desc'?-r:r;
}
return 0;
});
}else{
switch(sortBy){
case'oldest':s.sort((a,b)=>new Date(a.createdAt)-new Date(b.createdAt));break;
case'odds_high':s.sort((a,b)=>b.odds-a.odds);break;
case'odds_low':s.sort((a,b)=>a.odds-b.odds);break;
case'boost':s.sort((a,b)=>pct(b)-pct(a));break;
case'ev':s.sort((a,b)=>(b.ev_pct==null?-1e9:Number(b.ev_pct))-(a.ev_pct==null?-1e9:Number(a.ev_pct)));break;
default:s.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
}
}
return s;
},[clientFiltered,sortBy,view,tblSort]);
useEffect(()=>{setVisibleCount(100);},[sortBy,tblSort,view,filterCasas,filterLabels,filterSport,oddMin,oddMax,pctMin,filterComp,searchEvent,searchAposta,filterLive,filterActive,filterTipo]);
const casaCounts=useMemo(()=>stats?.byCasa?Object.fromEntries(stats.byCasa.map((c)=>[c.casa,c.total])):{},[stats]);
const casaNames=useMemo(()=>stats?.byCasa?.map((c)=>c.casa)||[],[stats]);
const casaNamesAlpha=useMemo(()=>[...casaNames].sort((a,b)=>a.localeCompare(b,'pt-BR',{sensitivity:'base'})),[casaNames]);


const sportNames=useMemo(()=>{
const nomes=(stats?.bySport||[]).map((x)=>x.sport==null||x.sport===''?VAZIO:x.sport);
return[...new Set(nomes)].sort(ordenaOpcoes);
},[stats]);




const compNames=useMemo(()=>{
const base=facetaTorneios.length?
facetaTorneios.map((t)=>t.competition):
[...new Set(odds.map((o)=>o.competition).filter(Boolean))];

const set=new Set(base);filterComp.forEach((c)=>set.add(c));
return[...set].sort(ordenaOpcoes);
},[facetaTorneios,odds,filterComp]);

compNamesRef.current=compNames;
const compCounts=useMemo(()=>Object.fromEntries(facetaTorneios.map((t)=>[t.competition,t.total])),[facetaTorneios]);

const availableLabels=useMemo(()=>{





const porCasa=stats?.labelsByCasaAtivas||stats?.labelsByCasa;
let base;
if(!porCasa)base=stats?.byLabel?.map((l)=>l.boost_label)||[];else
if(!filterCasas.length)base=stats.byLabel?.map((l)=>l.boost_label)||[];else
{const set=new Set();porCasa.forEach((r)=>{if(filterCasas.includes(r.casa))set.add(r.boost_label);});base=[...set];}


return[...new Set(base.map((l)=>l==null||l===''?VAZIO:l))].sort(ordenaOpcoes);
},[stats,filterCasas]);
const labelCounts=useMemo(()=>stats?.byLabel?Object.fromEntries(stats.byLabel.map((l)=>[l.boost_label==null||l.boost_label===''?VAZIO:l.boost_label,l.total])):{},[stats]);


const dirPadrao=(col)=>col==='recent'||col==='odds'||col==='pct'?'desc':'asc';
const toggleTblSort=(col)=>setTblSort((s)=>{
if(s[0]&&s[0].col===col)return[{col,dir:s[0].dir==='asc'?'desc':'asc'},...s.slice(1)];

const resto=s.filter((x)=>x.col!==col);
return[{col,dir:dirPadrao(col)},...resto];
});

const isSuper=usuario&&usuario.papel==='admin';
const doLogout=async()=>{try{await fetch('/api/auth/logout',{method:'POST',credentials:'include'});}catch(e){}location.href='/login';};
const toggleCasa=(casa)=>setFilterCasas((prev)=>prev.includes(casa)?prev.filter((c)=>c!==casa):[...prev,casa]);


const menuNav=isSuper?
[['dashboard','Super Odds','analytics'],['props','Player Props','sports_soccer'],['ev','EV+','trending_up'],['odds','Odds Screen','table_chart'],['meusfiltros','Meus filtros','filter_list'],['conta','Minha conta','account_circle'],
{sep:'Admin Menu'},
{grp:'g-usuarios',lbl:'Usuários',ic:'group',items:[['perfis','Perfis','filter_alt'],['solic','Solicitações de Cadastro','how_to_reg'],['usuarios','Usuários cadastrados','manage_accounts'],['botusers','Usuários do bot','smart_toy']]},

{grp:'g-gestao',lbl:'Gestão Peixe Esperto',ic:'storefront',items:[['propscasas','Casas dos Player Props','storefront'],['propsligas','Ligas dos Player Props','emoji_events'],['propsparams','Parâmetros dos Player Props','tune'],['obsliq','Observações de liquidação','report'],['grupo','Filtros dos Grupos','diversity_3'],['tipsgrupos','Tips dos grupos','campaign'],
...(usuario&&usuario.master?[['evfiltro','Filtro de EV','filter_alt_off'],['evhist','Histórico de EV','history'],['evjusta','Odd justa por segmento','functions'],['chavesleitura','Chaves de leitura','key'],['equivalencias','Correspondências entre mercados','compare_arrows']]:[])].sort((a,b)=>a[1].localeCompare(b[1],'pt-BR'))},
{grp:'g-dev',lbl:'Dev.',ic:'code',items:[['logs','Logs','terminal'],['pareamentos','Pareamentos','join_inner'],['status','Status','monitor_heart'],['fontes','Fontes','power_settings_new']]}]:
[...ABAS_PERFIL.filter(([id])=>(usuario&&usuario.abas||ABAS_PADRAO).includes(id)),['meusfiltros','Meus filtros','filter_list'],['conta','Minha conta','account_circle']];
const abasNav=menuNav.flatMap((m)=>Array.isArray(m)?[m]:m.items||[]);

const[gruposAbertos,setGruposAbertos]=useState(()=>{try{return JSON.parse(localStorage.getItem('or_menu_grupos')||'{}');}catch(e){return{};}});
const grupoDe=(id)=>{const g=menuNav.find((m)=>m&&m.grp&&m.items.some((i)=>i[0]===id));return g?g.grp:null;};
useEffect(()=>{const g=grupoDe(pagina);if(g&&!gruposAbertos[g])setGruposAbertos((v)=>({...v,[g]:true}));},[pagina]);
const toggleGrupo=(g)=>setGruposAbertos((v)=>{const n={...v,[g]:!v[g]};try{localStorage.setItem('or_menu_grupos',JSON.stringify(n));}catch(e){}return n;});

const idsPermitidos=abasNav.map((a)=>a[0]);
useEffect(()=>{if(usuario&&!idsPermitidos.includes(pagina))setPagina(idsPermitidos[0]);},[usuario,pagina]);
const tituloPagina={equivalencias:['Correspondências entre mercados','A justa de um mercado avaliando outro que é a mesma aposta — regras novas em sombra até a decisão do Matheus; só o admin master vê'],evfiltro:['Filtro de EV','Regras que tiram EVs da tela EV+ por recorte — só o admin master vê'],chavesleitura:['Chaves de leitura','Para a rotina de bugs na nuvem ler a produção (só consulta) — só o admin master vê'],evjusta:['Odd justa por segmento','Como a odd justa do EV+ é calculada em cada recorte — com modo sombra antes de ativar; só o admin master vê'],evhist:['Histórico de EV','Cada EV que esteve na tela EV+ e a banca no ar pelo ¼ Kelly — só o admin master vê'],obsliq:['Observações de liquidação','Regras de liquidação por casa e mercado — viram alerta em todas as telas'],ev:['EV+','Apostas com valor esperado positivo, ao vivo — a lista se atualiza sozinha'],odds:['Odds Screen','Todas as casas lado a lado, por jogo e mercado — com a justa da Pinnacle e as props do jogo'],dashboard:['Super Odds','Odds aumentadas em tempo real'],props:['Player Props','Odds de player props unificadas'],propscasas:['Casas dos Player Props','Vincule as casas trazidas pelas fontes ao cadastro do Peixe Admin (uma coluna por casa, nome do cadastro)'],propsligas:['Ligas dos Player Props','Ative, inative e inclua ligas — liga inativa não é mais descoberta nem varrida'],propsparams:['Parâmetros dos Player Props','Configurações do coletor de player props — valem pra todas as fontes'],status:['Status','Monitoramento por casa'],fontes:['Fontes','Ligue e desligue cada fonte — casa fora do ar ou economia de proxy, sem mexer em código'],logs:['Logs','Registros do sistema'],grupo:['Filtros dos Grupos','O que cada grupo do Telegram recebe'],tipsgrupos:['Tips dos grupos','FishBot: tips automáticas do EV+ nos grupos — perfil de cada grupo, tips enviadas, recusas e resultados pendentes; só admin'],pareamentos:['Pareamentos','Quem é quem no sistema — times, jogadores, eventos e mercados, valendo para Super Odds e Player Props'],perfis:['Perfis','Conjuntos de filtros pros tipsters'],usuarios:['Usuários cadastrados','Contas do dashboard'],botusers:['Usuários do bot','Quem recebe no Telegram'],solic:['Solicitações de Cadastro','Cadastros aguardando aprovação'],meusfiltros:['Meus filtros','Escolha o que você quer receber'],conta:['Minha conta','Suas configurações']}[pagina]||['',''];


if(usuario&&usuario.trocar_senha)return React.createElement(TrocaSenhaObrigatoria,{usuario:usuario});

return React.createElement("div",{className:"shell"},
versaoNova&&React.createElement("div",{role:"status",style:{position:'fixed',top:12,left:'50%',transform:'translateX(-50%)',zIndex:9999,background:'#1c6b52',color:'#fff',padding:'10px 16px',borderRadius:10,boxShadow:'0 6px 20px rgba(0,0,0,.25)',display:'flex',gap:12,alignItems:'center',fontSize:14}},"Uma versão nova do painel foi publicada.",React.createElement("button",{className:"btn-sm",onClick:()=>location.reload()},"Recarregar")),
React.createElement("aside",{className:"sidebar"+(menuAberto?'':' recolhida')},
React.createElement("div",{className:"sb-brand"},
React.createElement("img",{src:"/logo-mark.png",alt:"Odds Radar"}),
React.createElement("h1",null,"Odds",React.createElement("span",{className:"sub"},"Radar")),
React.createElement("button",{className:"sb-toggle",onClick:()=>setMenuAberto((v)=>!v),
title:menuAberto?'Recolher menu':'Expandir menu',
"aria-label":menuAberto?'Recolher menu':'Expandir menu'},
React.createElement(Ic,{n:menuAberto?'chevron_left':'chevron_right'})
)
),
usuario&&React.createElement("div",{className:"sb-user"},
React.createElement("div",{className:"ava"},React.createElement(Ic,{n:"account_circle"})),
React.createElement("div",{className:"who"},React.createElement("div",{className:"nm"},usuario.nome||'Usuário'),React.createElement("div",{className:"rl"},isSuper?'Admin':'Tipster'))
),
React.createElement("nav",{className:"sb-nav"},
usuario&&menuNav.map((m,ix)=>{
if(Array.isArray(m)){const[id,lbl,ic]=m;return React.createElement("button",{key:id,className:"sb-item"+(pagina===id?' on':''),onClick:()=>irMenu(id),title:menuAberto?null:lbl},React.createElement(Ic,{n:ic}),React.createElement("span",{className:"rot"},lbl));}
if(m.sep)return React.createElement("div",{key:'sep'+ix,className:"sb-sep",title:menuAberto?null:m.sep},React.createElement("span",null,m.sep));
const aberto=!!gruposAbertos[m.grp],ativo=m.items.some((i)=>i[0]===pagina);
return React.createElement("div",{key:m.grp,className:"sb-group"},
React.createElement("button",{className:"sb-item grp"+(aberto?' aberto':'')+(ativo?' ativo':''),onClick:()=>{if(!menuAberto)setMenuAberto(true);toggleGrupo(m.grp);},title:menuAberto?null:m.lbl,"aria-expanded":aberto},
React.createElement(Ic,{n:m.ic}),React.createElement("span",{className:"rot"},m.lbl),React.createElement("span",{className:"ms-icon chev"},"expand_more")
),
React.createElement("div",{className:"sb-sub"+(aberto||!menuAberto&&ativo?'':' fechado')},
m.items.map(([id,lbl,ic])=>React.createElement("button",{key:id,className:"sb-item"+(pagina===id?' on':''),onClick:()=>irMenu(id),title:menuAberto?null:lbl},React.createElement(Ic,{n:ic}),React.createElement("span",{className:"rot"},lbl)))
)
);
})
),
React.createElement("div",{className:"sb-foot"},
React.createElement("button",{className:"sb-item sair",onClick:doLogout,title:menuAberto?null:'Sair'},React.createElement(Ic,{n:"logout"}),React.createElement("span",{className:"rot"},"Sair"))
)
),

React.createElement("main",{className:"content"},
React.createElement(AvisoPinnacle,{rota:"/api/sistema/saude"}),
React.createElement(AvisoPinnacle,{rota:"/api/tempo-real/saude"}),
React.createElement(AvisoPinnacle,null),
React.createElement(AvisoPainelEsperando,null),
React.createElement("div",{className:"content-head"},
React.createElement("div",null,
React.createElement("div",{className:"pg-title"},tituloPagina[0]),
React.createElement("div",{className:"pg-sub"},tituloPagina[1])
),
pagina==='dashboard'&&React.createElement("div",{className:"dash-actions"},
React.createElement("div",{className:"act"+(filterActive?' auto':''),onClick:()=>setFilterActive((v)=>!v),title:filterActive?'Mostrando só apostas ativas (vistas agora). Clique pra incluir o histórico (que já saíram).':'Mostrando tudo, incluindo apostas que já saíram. Clique pra ver só as ativas.'},React.createElement(Ic,{n:filterActive?'bolt':'history'}),React.createElement("span",{className:"lbl"},filterActive?'Só ativas':'Com histórico')),
React.createElement("div",{className:"act auto"+(autoRefresh?'':' off'),onClick:()=>setAutoRefresh(!autoRefresh)},React.createElement("span",{className:"ring pulse-dot"}),React.createElement("span",{className:"lbl"},autoRefresh?'Auto 30s':'Pausado')),
React.createElement("div",{className:"act",onClick:()=>{setLoading(true);fetchData();}},React.createElement(Ic,{n:"refresh"}),"Atualizar")
)
),

!usuario?
React.createElement("div",{className:"content-body dash"},React.createElement("div",{className:"sem-acesso",role:"status"},
React.createElement("div",{className:"sa-ic"},React.createElement(Ic,{n:semUsuario.espera?'sync':'error'})),
React.createElement("div",{className:"sa-t"},semUsuario.espera?'Conectando ao painel…':'Não foi possível abrir o painel'),
semUsuario.espera&&semUsuario.tentativas>0&&React.createElement("div",{className:"sa-sub"},"O painel está reiniciando (publicação nova). Tentando de novo sozinho — tentativa ",semUsuario.tentativas,"."),
!semUsuario.espera&&React.createElement("div",{className:"sa-sub"},semUsuario.erro),
!semUsuario.espera&&React.createElement("button",{className:"btn-sm b-green",onClick:()=>location.reload()},"Recarregar")
)):
pagina!=='dashboard'?
React.createElement("div",{className:"content-body"},React.createElement(AdminPanel,{usuario:usuario,tab:pagina,onNav:setPagina,onClose:(reason)=>{if(reason==='relogin'){location.href='/login';}}})):
!isSuper&&usuario&&usuario.qtd_perfis===0?
React.createElement("div",{className:"content-body dash"},React.createElement("div",{className:"sem-acesso"},
React.createElement("div",{className:"sa-ic"},React.createElement(Ic,{n:"lock"})),
React.createElement("div",{className:"sa-t"},"Acesso ainda não liberado"),
React.createElement("div",{className:"sa-sub"},"Seu acesso às odds ainda não foi configurado. Assim que um administrador definir seus filtros, elas aparecem aqui automaticamente."),
usuario.id_telegram?null:React.createElement("div",{className:"sa-tip"},React.createElement(Ic,{n:"lightbulb"}),"Dica: vincule seu Telegram em ",React.createElement("b",null,"Minha conta")," pra receber os alertas no app também.")
)):
React.createElement("div",{className:"content-body dash"},
stats&&React.createElement("section",{className:"metrics"},
React.createElement(Metric,{k:"Total de Odds",v:fmtNum(stats.total),c:"var(--primary)",icon:"stacked_line_chart",s:`Atualizado ${timeAgo(stats.lastUpdate)}`}),
React.createElement(Metric,{k:"Casas Ativas",v:stats.casasAtivas,c:"var(--secondary)",icon:"storefront"}),
React.createElement(Metric,{k:"Tipos de Boost",v:stats.byLabel?.length||0,c:"var(--tertiary)",icon:"bolt"}),
React.createElement(Metric,{k:"Exibindo",v:fmtNum(Math.min(visibleCount,sortedOdds.length)),c:"var(--primary-dim)",icon:"filter_list",s:sortedOdds.length>visibleCount?`de ${fmtNum(sortedOdds.length)} ${hasFilters?'filtradas':'odds'}`:hasFilters?'resultado filtrado':'todas as odds'})
),

React.createElement("section",{className:"casas-sec"},
React.createElement("div",{className:"casas-head"},
React.createElement("div",{className:"ch-title"},React.createElement(Ic,{n:"analytics",className:"ms-icon ch-ic"}),React.createElement("h2",null,"Monitoramento por Casa")),
casaNames.length>6&&React.createElement("button",{className:"ch-vertodas",onClick:()=>setShowAllCasas((s)=>!s)},showAllCasas?'Ver menos':'Ver todas',React.createElement(Ic,{n:showAllCasas?'expand_less':'expand_more',className:"ms-icon"}))
),
React.createElement("div",{className:"chips"+(showAllCasas?' wrap':' scroll')},
React.createElement("div",{className:"chip"+(filterCasas.length===0?' active':''),onClick:()=>setFilterCasas([])},React.createElement("span",{className:"cnm"},"Todas")," ",React.createElement("span",{className:"cnt"},fmtNum(stats?.total||0))),
(showAllCasas?casaNames:casaNames.slice(0,6)).map((casa)=>{const on=filterCasas.includes(casa);return(
React.createElement("div",{key:casa,className:"chip"+(on?' active':''),onClick:()=>toggleCasa(casa)},React.createElement("span",{className:"cnm"},casa)," ",React.createElement("span",{className:"cnt"},fmtNum(casaCounts[casa]||0))));})
)
),

React.createElement("section",{className:"glass panel"},
React.createElement("div",{className:"panel-head",onClick:()=>setFiltersOpen(!filtersOpen)},
React.createElement("div",{className:"t"},React.createElement(Ic,{n:"filter_alt"}),React.createElement("h2",null,"Filtros avançados"),hasFilters&&React.createElement("span",{className:"on-pill"},"Ativos")),
React.createElement(Ic,{n:"expand_less",className:"ms-icon chev",style:{transform:filtersOpen?'none':'rotate(180deg)'}})
),
filtersOpen&&React.createElement(React.Fragment,null,
React.createElement("div",{className:"fgrid"},
React.createElement("div",{className:"fg"},React.createElement("label",null,"Casa"),React.createElement(MultiSelect,{items:casaNamesAlpha,selected:filterCasas,onChange:setFilterCasas,counts:casaCounts})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Tipo de Boost"),React.createElement(MultiSelect,{items:availableLabels,selected:filterLabels,onChange:setFilterLabels,counts:labelCounts})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Esporte"),React.createElement(MultiSelect,{items:sportNames,selected:filterSport,onChange:setFilterSport})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Torneio"),React.createElement(MultiSelect,{items:compNames,selected:filterComp,onChange:setFilterComp,counts:compCounts})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Ao vivo"),React.createElement("div",{className:"sel-wrap"},React.createElement("select",{className:"sel",value:filterLive,onChange:(e)=>setFilterLive(e.target.value)},React.createElement("option",{value:""},"Todas"),React.createElement("option",{value:"1"},"Só ao vivo"),React.createElement("option",{value:"0"},"Só pré-jogo")),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Tipo de aposta"),React.createElement("div",{className:"sel-wrap"},React.createElement("select",{className:"sel",value:filterTipo,onChange:(e)=>setFilterTipo(e.target.value)},React.createElement("option",{value:""},"Todas"),React.createElement("option",{value:"simples"},"Simples (1 perna)"),React.createElement("option",{value:"bet_builder"},"Bet Builder (mesmo jogo)"),React.createElement("option",{value:"multipla"},"Múltipla (jogos diferentes)")),React.createElement(Ic,{n:"arrow_drop_down"}))),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Odd Mín"),React.createElement("input",{className:"inp data",type:"number",step:"0.01",inputMode:"decimal",placeholder:"1.50",value:oddMin,onChange:(e)=>setOddMin(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Odd Máx"),React.createElement("input",{className:"inp data",type:"number",step:"0.01",inputMode:"decimal",placeholder:"5.00",value:oddMax,onChange:(e)=>setOddMax(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Aumento mín (%)"),React.createElement("input",{className:"inp data",type:"number",step:"1",inputMode:"numeric",placeholder:"10",value:pctMin,onChange:(e)=>setPctMin(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"EV mín (%)"),React.createElement("input",{className:"inp data",type:"number",step:"0.5",inputMode:"decimal",placeholder:"0",value:evMin,onChange:(e)=>setEvMin(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Evento"),React.createElement("input",{className:"inp",placeholder:"Ex: Atlético x São Paulo",value:searchEvent,onChange:(e)=>setSearchEvent(e.target.value)})),
React.createElement("div",{className:"fg"},React.createElement("label",null,"Aposta"),React.createElement("input",{className:"inp",placeholder:"Ex: Over 2.5",value:searchAposta,onChange:(e)=>setSearchAposta(e.target.value)})),
view==='cards'&&React.createElement("div",{className:"fg"},React.createElement("label",null,"Ordenar"),React.createElement("div",{className:"sel-wrap"},React.createElement("select",{className:"sel",value:sortBy,onChange:(e)=>setSortBy(e.target.value)},React.createElement("option",{value:"recent"},"Mais recentes"),React.createElement("option",{value:"oldest"},"Mais antigas"),React.createElement("option",{value:"odds_high"},"Maior odd"),React.createElement("option",{value:"odds_low"},"Menor odd"),React.createElement("option",{value:"boost"},"Maior boost %"),React.createElement("option",{value:"ev"},"Maior EV")),React.createElement(Ic,{n:"arrow_drop_down"})))
),
hasFilters&&React.createElement("div",{style:{marginTop:16}},React.createElement("button",{className:"btn-clear",onClick:clearFilters},React.createElement(Ic,{n:"close"}),"Limpar"))
)
),

apiErro&&React.createElement("div",{style:{display:'flex',alignItems:'center',gap:8,margin:'16px 0 0',padding:'10px 14px',borderRadius:10,background:'color-mix(in srgb, var(--red, #c43) 12%, transparent)',border:'1px solid color-mix(in srgb, var(--red, #c43) 40%, transparent)',color:'var(--on-surface-variant)',fontSize:12.5}},
React.createElement(Ic,{n:"error",style:{color:'var(--red, #c43)'}}),
React.createElement("span",null,"API de odds com erro: ",React.createElement("b",null,apiErro)," — mostrando os últimos dados carregados. Avisa o suporte se não voltar sozinho em alguns minutos.")
),
truncado&&React.createElement("div",{style:{display:'flex',alignItems:'center',gap:8,margin:'16px 0 0',padding:'10px 14px',borderRadius:10,background:'color-mix(in srgb, var(--amber) 12%, transparent)',border:'1px solid color-mix(in srgb, var(--amber) 40%, transparent)',color:'var(--on-surface-variant)',fontSize:12.5}},
React.createElement(Ic,{n:"warning",style:{color:'var(--amber-deep)'}}),
React.createElement("span",null,"Mostrando as ",React.createElement("b",null,limiteOdds?fmtNum(limiteOdds):'primeiras'," odds mais recentes")," que batem nos filtros — existem mais no banco. Refine os filtros (casa, torneio, evento) pra ver o resto.")
),
React.createElement("div",{className:"toolbar"},
React.createElement("div",{className:"count"},React.createElement("b",null,fmtNum(Math.min(visibleCount,sortedOdds.length)))," ",sortedOdds.length===1?'odd':'odds'," ",sortedOdds.length>visibleCount?`de ${fmtNum(sortedOdds.length)}`:'exibidas'),
React.createElement("div",{className:"viewtoggle"},
React.createElement("button",{className:view==='cards'?'on':'',onClick:()=>setView('cards')},React.createElement(Ic,{n:"grid_view"}),"Cards"),
React.createElement("button",{className:view==='table'?'on':'',onClick:()=>setView('table')},React.createElement(Ic,{n:"table_rows"}),"Tabela")
)
),

React.createElement("section",null,
loading?view==='cards'?React.createElement("div",{className:"grid"},[...Array(9)].map((_,i)=>React.createElement("div",{key:i,className:"skel"}))):React.createElement("div",{className:"skel",style:{height:340}}):
sortedOdds.length===0?React.createElement("div",{className:"empty"},React.createElement("div",{className:"em-ic"},React.createElement(Ic,{n:"search_off"})),React.createElement("div",{className:"em-t"},"Nenhuma odd encontrada"),React.createElement("div",null,"Tente ajustar os filtros")):
view==='table'?
React.createElement(React.Fragment,null,React.createElement(OddsTable,{odds:sortedOdds.slice(0,visibleCount),sort:tblSort,onSort:toggleTblSort}),
sortedOdds.length>visibleCount&&React.createElement("div",{className:"load-more"},React.createElement("button",{onClick:()=>setVisibleCount((c)=>c+100)},React.createElement(Ic,{n:"expand_more"}),"Carregar mais (",fmtNum(sortedOdds.length-visibleCount)," restantes)"))):
React.createElement(React.Fragment,null,React.createElement("div",{className:"grid"},sortedOdds.slice(0,visibleCount).map((odd,i)=>React.createElement(OddCard,{key:odd.uuid,odd:odd,index:i}))),
sortedOdds.length>visibleCount&&React.createElement("div",{className:"load-more"},React.createElement("button",{onClick:()=>setVisibleCount((c)=>c+100)},React.createElement(Ic,{n:"expand_more"}),"Carregar mais (",fmtNum(sortedOdds.length-visibleCount)," restantes)")))
)
)
)
);
}

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App,null));