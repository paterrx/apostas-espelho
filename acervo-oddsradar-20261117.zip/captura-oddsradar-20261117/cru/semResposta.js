/**
 * [05/10] AÇÃO SEM RESPOSTA DO PAINEL (issue #35). Durante um deploy o painel fica até ~1 min sem responder: o fetch
 * falha ("Failed to fetch") ou o proxy devolve 502/503/504 em HTML, e cada tela mostrava um erro diferente ("Unexpected
 * token <", nada, ou ficava girando). O operador não sabia se a mescla tinha sido gravada. Aqui, para TODA chamada do
 * painel, a falha vira uma mensagem só: o painel está reiniciando e a ação não foi confirmada. A resposta 503 do próprio
 * painel desligando (desligamento.js) já vem em JSON com o motivo e passa direto.
 */
(function (raiz) {
  var MSG_ACAO = "O painel está reiniciando (publicação nova) e não respondeu. Esta ação NÃO foi confirmada: espere o painel voltar (cerca de 1 min), recarregue e confira antes de repetir.";
  var MSG_LEITURA = "O painel está reiniciando (publicação nova) e não respondeu. Tente de novo em cerca de 1 min.";
  function doPainel(url, origem) {
    var u = String(url && url.url ? url.url : url || "");
    return u.charAt(0) === "/" || (origem && u.indexOf(origem) === 0);
  }
  function embrulha(fetchOriginal, origem) {
    return function (entrada, opcoes) {
      var metodo = String((opcoes && opcoes.method) || (entrada && entrada.method) || "GET").toUpperCase();
      var msg = metodo === "GET" || metodo === "HEAD" ? MSG_LEITURA : MSG_ACAO;
      if (!doPainel(entrada, origem)) return fetchOriginal(entrada, opcoes);
      return fetchOriginal(entrada, opcoes).then(function (r) {
        var tipo = (r.headers && r.headers.get && r.headers.get("content-type")) || "";
        if ((r.status === 502 || r.status === 503 || r.status === 504) && tipo.indexOf("json") < 0) {
          var e = new Error(msg); e.painelReiniciando = true; throw e;
        }
        return r;
      }, function (err) {
        if (err && err.name === "AbortError") throw err;
        var e = new Error(msg); e.painelReiniciando = true; e.causa = err; throw e;
      });
    };
  }
  /**
   * [12/10] LEITURA QUE ESPERA O PAINEL VOLTAR. A leitura feita uma vez só, ao abrir a tela, que caía na janela do
   * deploy ficava errada até alguém recarregar a página: em 12/10 (~23 h) o /api/auth/me sem resposta deixou o admin
   * com o menu de tipster (sem EV+, Odds Screen e Admin Menu), e as listas de casas, etiquetas e opções dos
   * formulários ficavam em branco sem aviso. leJson repete a leitura enquanto o painel está reiniciando (rede caída,
   * 502/503/504 do proxy ou o 503 em JSON do desligamento.js), com espera de 2 s, 4 s, ... até 15 s, por até 3 min.
   * Qualquer outra resposta não-ok vira erro com o status e a mensagem do servidor, para a tela mostrar.
   */
  function criaLeitor(fetchFn, cfg) {
    cfg = cfg || {};
    var dorme = cfg.dorme || function (ms) { return new Promise(function (ok) { setTimeout(ok, ms); }); };
    var relogio = cfg.relogio || Date.now;
    // [30/10] issue #167: a leitura que espera o painel voltar não fica calada. Com o painel reiniciando, a busca de
    // Identidades esperava até 3 min com a lista vazia, sem mensagem nem erro (08:41 e 12:33 BRT de 30/10, nas quedas e
    // publicações do painel). Agora `cfg.aviso(n)` recebe quantas leituras estão esperando (sobe na 1ª repetição de cada
    // uma e desce quando ela termina, com resposta ou erro); no navegador vira o evento "painel-esperando" e a faixa do App.
    var aviso = cfg.aviso || function () {}, esperando = 0;
    return function leJson(url, opcoes) {
      opcoes = opcoes || {};
      var prazo = opcoes.prazoMs != null ? opcoes.prazoMs : 180000, inicio = relogio(), n = 0, init = {};
      for (var k in opcoes) if (k !== "prazoMs" && k !== "aoFalhar") init[k] = opcoes[k];
      if (!init.credentials) init.credentials = "include";
      function fim() { if (n > 0) { esperando--; aviso(esperando); } }
      function tenta() {
        return fetchFn(url, init).then(function (r) {
          return r.json().catch(function () { return null; }).then(function (d) {
            if (r.ok) return d;
            var e = new Error((d && d.error) || ("HTTP " + r.status)); e.status = r.status;
            if (r.status === 503 && d && d.reiniciando) e.painelReiniciando = true;
            throw e;
          });
        }).catch(function (e) {
          if (!e || !e.painelReiniciando || relogio() - inicio >= prazo) throw e;
          n++;
          if (n === 1) { esperando++; aviso(esperando); }
          if (opcoes.aoFalhar) opcoes.aoFalhar(e, n);
          return dorme(Math.min(15000, 2000 * n)).then(tenta);
        });
      }
      return tenta().then(function (d) { fim(); return d; }, function (e) { fim(); throw e; });
    };
  }
  if (typeof module !== "undefined" && module.exports) module.exports = { embrulha: embrulha, criaLeitor: criaLeitor, MSG_ACAO: MSG_ACAO, MSG_LEITURA: MSG_LEITURA };
  else if (raiz && raiz.fetch && !raiz.fetch.__semResposta) {
    var f = embrulha(raiz.fetch.bind(raiz), raiz.location ? raiz.location.origin : "");
    f.__semResposta = true;
    raiz.fetch = f;
    raiz.leJson = criaLeitor(function (u, i) { return raiz.fetch(u, i); }, {
      aviso: function (n) { try { raiz.dispatchEvent(new CustomEvent("painel-esperando", { detail: { n: n } })); } catch (e) { console.warn("[leJson] aviso:", e); } },
    });
  }
})(typeof window !== "undefined" ? window : null);
