// =====================================================================
// [07/10] FUSO DE SÃO PAULO EM TODA DATA MOSTRADA OU DIGITADA (decisão do Matheus, issue #64: "tudo sempre respeite o fuso
// de São Paulo").
//
// O banco guarda instantes (UTC nas tabelas er_*/props_*); quem lê e quem digita é gente em São Paulo. A tela formatava
// com o fuso do NAVEGADOR (toLocaleString sem timeZone, getHours, getDate) e o servidor com o do CONTÊINER (UTC): o mesmo
// jogo aparecia em horas diferentes conforme quem abria. Aqui fica o padrão do sistema, nas duas pontas:
//   - toLocaleString/DateString/TimeString e Intl.DateTimeFormat sem timeZone passam a usar America/Sao_Paulo;
//   - partesSP(d) dá dia/mês/ano/hora/minuto/dia da semana em São Paulo (no lugar de getHours/getDate);
//   - lerHoraSP("08/10 20:05") lê a hora DIGITADA como hora de São Paulo e devolve o instante;
//   - fmtSP(d) escreve "qua 08/10 20:05".
// Carregado no topo do index.html (antes de qualquer tela) e por require no servidor.
// =====================================================================
(function (raiz) {
  const TZ = "America/Sao_Paulo";
  const temTz = (o) => o && typeof o === "object" && o.timeZone;
  const comTz = (o) => (temTz(o) ? o : Object.assign({}, o || {}, { timeZone: TZ }));

  function instala() {
    const D = Date.prototype;
    if (D.__fusoSP) return;
    for (const nome of ["toLocaleString", "toLocaleDateString", "toLocaleTimeString"]) {
      const orig = D[nome];
      D[nome] = function (loc, opts) { return orig.call(this, loc, comTz(opts)); };
    }
    const DTF = Intl.DateTimeFormat;
    const Novo = function (loc, opts) { return new DTF(loc, comTz(opts)); };
    Novo.prototype = DTF.prototype;
    Novo.supportedLocalesOf = DTF.supportedLocalesOf.bind(DTF);
    Intl.DateTimeFormat = Novo;
    Object.defineProperty(D, "__fusoSP", { value: true });
  }

  const SEMANA = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];
  const fmtPartes = new Intl.DateTimeFormat("en-US", { timeZone: TZ, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", weekday: "short" });
  const DIAS_EN = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  /** Dia, mês, ano, hora, minuto e dia da semana do instante em São Paulo (null se a data não vale). */
  function partesSP(d) {
    const t = d instanceof Date ? d : new Date(d);
    if (isNaN(t.getTime())) return null;
    const p = {};
    for (const x of fmtPartes.formatToParts(t)) p[x.type] = x.value;
    return { ano: Number(p.year), mes: Number(p.month), dia: Number(p.day), hora: Number(p.hour) % 24, minuto: Number(p.minute), semana: DIAS_EN[p.weekday] };
  }
  const dd = (n) => String(n).padStart(2, "0");
  /** "qua 08/10 20:05" em São Paulo. */
  function fmtSP(d) {
    const p = partesSP(d);
    return p ? `${SEMANA[p.semana]} ${dd(p.dia)}/${dd(p.mes)} ${dd(p.hora)}:${dd(p.minuto)}` : "—";
  }
  /** "AAAA-MM-DD" do dia em São Paulo (filtro "hoje", agrupamento por dia). */
  function diaSP(d) { const p = partesSP(d); return p ? `${p.ano}-${dd(p.mes)}-${dd(p.dia)}` : null; }
  /** Diferença (min) entre a hora de parede de São Paulo e o UTC no instante (−180 hoje; vale também se voltar o horário de verão). */
  function deslocamentoSP(t) {
    const p = partesSP(t);
    return Math.round((Date.UTC(p.ano, p.mes - 1, p.dia, p.hora, p.minuto) - Math.floor(t.getTime() / 60000) * 60000) / 60000);
  }
  /** Hora de parede de São Paulo → instante. */
  function instanteSP(ano, mes, dia, hora, minuto) {
    const parede = Date.UTC(ano, mes - 1, dia, hora, minuto);
    let t = new Date(parede + 180 * 60000);
    for (let i = 0; i < 2; i++) t = new Date(parede - deslocamentoSP(t) * 60000);
    const p = partesSP(t);
    return p && p.dia === dia && p.mes === mes && p.hora === hora && p.minuto === minuto ? t : null;
  }
  /**
   * Hora DIGITADA por gente, lida como hora de São Paulo: "08/10 20:05", "08/10/2026 20:05", "8/10 20h05" ou só
   * "20:05" (no dia de `ref` em São Paulo). Ano ausente = o ano de `ref`. Devolve { ok, data } ou { erro }.
   */
  function lerHoraSP(texto, ref) {
    const s = String(texto || "").trim().toLowerCase().replace(/\s+/g, " ");
    if (!s) return { erro: "hora vazia" };
    const base = partesSP(ref instanceof Date || ref ? new Date(ref) : new Date()) || partesSP(new Date());
    let m = /^(\d{1,2})\/(\d{1,2})(?:\/(\d{2}|\d{4}))?\s*(?:às|as|,)?\s*(\d{1,2})\s*(?::|h)\s*(\d{2})?$/.exec(s);
    let dia, mes, ano, hora, minuto;
    if (m) {
      dia = Number(m[1]); mes = Number(m[2]); ano = m[3] ? Number(m[3].length === 2 ? "20" + m[3] : m[3]) : base.ano;
      hora = Number(m[4]); minuto = Number(m[5] || 0);
    } else if ((m = /^(\d{1,2})\s*(?::|h)\s*(\d{2})?$/.exec(s))) {
      dia = base.dia; mes = base.mes; ano = base.ano; hora = Number(m[1]); minuto = Number(m[2] || 0);
    } else return { erro: `não entendi "${texto}": escreva dia/mês e hora de São Paulo, ex.: 08/10 20:05` };
    if (!(mes >= 1 && mes <= 12 && dia >= 1 && dia <= 31 && hora >= 0 && hora <= 23 && minuto >= 0 && minuto <= 59)) return { erro: `data ou hora inválida: "${texto}"` };
    const t = instanteSP(ano, mes, dia, hora, minuto);
    return t ? { ok: true, data: t } : { erro: `data inválida: "${texto}"` };
  }

  const api = { TZ, instala, partesSP, fmtSP, diaSP, lerHoraSP, instanteSP };
  if (typeof module === "object" && module.exports) module.exports = api;
  else { raiz.fusoSP = api; instala(); }
})(typeof window !== "undefined" ? window : globalThis);
