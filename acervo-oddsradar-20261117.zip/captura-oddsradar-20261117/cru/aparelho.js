// =====================================================================
// [31/10] APARELHO DA SESSÃO, EM PORTUGUÊS. A lista de sessões da tela de usuários mostrava o "user agent" cru
// ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/…"), que ninguém lê. Aqui ele vira
// "Safari no iPhone", "Chrome no Windows". Carregado no index.html e por require nos testes.
// =====================================================================
(function (raiz) {
  function aparelho(ua) {
    const s = String(ua || "");
    if (!s.trim()) return "Aparelho desconhecido";
    const nav = /Edg(e|A|iOS)?\//.test(s) ? "Edge"
      : /OPR\/|Opera/.test(s) ? "Opera"
      : /SamsungBrowser/.test(s) ? "Samsung Internet"
      : /Firefox\/|FxiOS/.test(s) ? "Firefox"
      : /Chrome\/|CriOS/.test(s) ? "Chrome"
      : /Safari\//.test(s) ? "Safari"
      : "Navegador";
    const so = /iPhone/.test(s) ? "iPhone"
      : /iPad/.test(s) ? "iPad"
      : /Android/.test(s) ? "Android"
      : /Windows/.test(s) ? "Windows"
      : /Mac OS X|Macintosh/.test(s) ? "Mac"
      : /CrOS/.test(s) ? "Chromebook"
      : /Linux/.test(s) ? "Linux"
      : "";
    return so ? `${nav} no ${so}` : nav;
  }
  const api = { aparelho };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else raiz.aparelho = aparelho;
})(typeof window !== "undefined" ? window : globalThis);
