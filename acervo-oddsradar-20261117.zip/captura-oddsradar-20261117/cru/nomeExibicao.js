// =====================================================================
// [14/10] issue #90: NOME DE EXIBIÇÃO DO CADASTRO.
//
// Não havia como trocar o nome que a tela mostra. O #12060 nasceu "Jose Flaco Lopez" (apelido do López do Palmeiras,
// #29342) e é o José Ángel López do Espanyol: API-Football 585288 "J. A. Lopez", Sportradar 2906547 "Jose Angel Lopez".
// O Resolver ofereceu o cadastro com o nome errado e o operador criou uma duplicata (#3846807, já juntada). Outros:
// #176228 "Pedro" (Fluminense) é o Jhonny (Sportradar 2200520 "Jhonny"; 19 das 21 grafias dizem "jhonny").
//
// Decisão do Matheus (opção a, 14/10):
//   - ação "Trocar nome" na ficha de Identidades: o nome de cada número de provedor, cada grafia ou texto livre. Grava
//     er_entity.nome_por = 'human', com antes e depois no er_report e Desfazer. Nome de gente nunca é trocado por regra;
//   - regra automática (faxina 63): jogador com número Sportradar e sem nome de gente fica com o nome do provedor quando
//     o atual difere — nunca por um nome abreviado ("J. A. Lopez") ou mais curto que o atual. Checagem nome_contra_provedor.
//
// Carregado no index.html (opções da ação) e por require no servidor (rota, faxina, Saúde) e nos testes.
// =====================================================================
(function (raiz) {
  // letras que o NFD não decompõe (mesma tabela de letraSemNfd.js / núcleo texto.ts)
  const TRANSLIT = { "ø": "o", "œ": "oe", "æ": "ae", "å": "a", "ł": "l", "đ": "d", "ð": "d", "þ": "th", "ß": "ss", "ı": "i", "ħ": "h", "ŋ": "n", "ŧ": "t", "ə": "e" };
  const LETRA_SEM_NFD = /[øœæåłđðþßıħŋŧə]/gi;
  const PARTICULAS = new Set(["da", "de", "do", "das", "dos", "del", "della", "di", "du", "van", "von", "der", "den", "la", "le", "e", "y", "al", "el", "bin", "ben"]);

  /** Chave de comparação: sem acento, sem pontuação, minúscula. "José Ángel López" = "jose angel lopez". */
  function chaveNome(x) {
    return String(x == null ? "" : x).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(LETRA_SEM_NFD, c => TRANSLIT[c.toLowerCase()] || c)
      .toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  }
  const tokens = x => chaveNome(x).split(" ").filter(Boolean);

  /** Nome com inicial ("J. A. Lopez", "V. Hoff", "Lopez J.") ou só uma letra numa palavra. */
  function ehAbreviado(nome) {
    const t = String(nome == null ? "" : nome).trim();
    if (!t) return false;
    if (/(^|[\s.])\p{L}\.(?=\s|$|\p{L})/u.test(t)) return true;
    return tokens(t).some(w => w.length === 1 && !/^\d$/.test(w));
  }

  /** Texto limpo: sem caractere de controle nem invisível, espaços simples. */
  function limpa(x) {
    return String(x == null ? "" : x).replace(/[\u0000-\u001f\u007f­​-‍⁠﻿]+/g, " ").replace(/\s+/g, " ").trim();
  }

  /** Nome do provedor em formato de exibição: "Lopez, Jose Angel" (sobrenome, prenome) vira "Jose Angel Lopez". */
  function nomeLegivel(x) {
    const t = limpa(x);
    const m = /^([^,]+),\s*([^,]+)$/.exec(t);
    return m ? (m[2].trim() + " " + m[1].trim()) : t;
  }

  /** Grafia das casas (normalizada, minúscula: "jose angel lopez") com maiúsculas para exibir: "Jose Angel Lopez". */
  function capitalizaGrafia(g) {
    return limpa(g).split(" ").filter(Boolean)
      .map((w, i) => (i > 0 && PARTICULAS.has(w.toLowerCase())) ? w.toLowerCase() : w.charAt(0).toLocaleUpperCase("pt-BR") + w.slice(1)).join(" ");
  }

  /** Caixa sem informação: tudo maiúsculo ("VITOR MACHADO FERREIRA") ou tudo minúsculo. */
  function caixaSemInformacao(x) {
    const t = String(x || "");
    if (!/\p{L}/u.test(t)) return false;
    return t === t.toLocaleUpperCase("pt-BR") || t === t.toLocaleLowerCase("pt-BR");
  }

  /** Texto livre digitado na ação: { nome } ou { erro }. */
  function nomeDigitado(texto) {
    const nome = limpa(texto);
    if (nome.length < 2) return { erro: "o nome precisa de pelo menos 2 letras" };
    if (nome.length > 120) return { erro: "o nome passa de 120 caracteres" };
    if (!/\p{L}/u.test(nome)) return { erro: "o nome precisa ter letras" };
    return { nome };
  }

  /**
   * Regra automática (faxina 63 e checagem nome_contra_provedor). Entrada: nome atual, nome do provedor (Sportradar),
   * quem decidiu o nome atual (nome_por), as grafias do cadastro, o estado do número e se outro jogador do mesmo time já
   * usa o nome. Saída: { trocar, nome, motivo }. Só troca para um nome que acrescenta — nunca abreviado, nunca mais curto.
   */
  function decideNomePeloProvedor({ atual, provedor, nomePor, grafias, estado, ocupado } = {}) {
    if (String(nomePor || "") === "human") return { trocar: false, motivo: "nome escolhido por gente" };
    const nome = nomeLegivel(provedor);
    if (!nome) return { trocar: false, motivo: "o provedor não deu nome" };
    const ka = chaveNome(atual), kp = chaveNome(nome);
    if (!kp) return { trocar: false, motivo: "o provedor não deu nome" };
    if (ka === kp) return { trocar: false, motivo: "igual" };
    if (ehAbreviado(nome)) return { trocar: false, motivo: "o nome do provedor é abreviado" };
    if (caixaSemInformacao(nome)) return { trocar: false, motivo: "o nome do provedor está todo em maiúsculas ou minúsculas" };
    const ta = tokens(atual), tp = tokens(nome);
    // o atual já contém o do provedor ("Jhonny Cardinoti Pedro" x "Jhonny") ou tem mais palavras: o do provedor é mais curto
    if (tp.length < ta.length || (tp.every(w => ta.includes(w)) && ta.length >= tp.length)) return { trocar: false, motivo: "o nome do provedor é mais curto que o atual" };
    // [14/10] issue #90, 2ª rodada: o provedor que só ACRESCENTA nomes ao atual ("Luis Suarez" → "Luis Javier Suarez", "Andre
    // Vasquez" → "Lisandro Andre Vasquez Pizarro") não corrige nada — é o nome de registro, pior para ler e para buscar. A
    // primeira versão ia trocar 1.449 nomes assim (Saúde 14/10 04:16 UTC). Só troca o nome que CONTRADIZ o provedor: alguma
    // palavra do atual que o provedor não tem ("Flaco" em "Jose Flaco Lopez" × "Jose Angel Lopez"; "Pedro" × "Jhonny").
    if (ta.every(w => tp.includes(w))) return { trocar: false, motivo: "o provedor só acrescenta nomes ao atual (nada errado)" };
    // prova de que é a mesma pessoa: alguma casa escreve o nome do provedor, ou gente pôs o número no cadastro. "confirmado"
    // não basta: 7.650 dos números Sportradar de jogador vieram confirmados da migração (14/10), sem casa nenhuma conferir
    if (estado !== "humano" && !(grafias || []).some(g => chaveNome(g) === kp)) return { trocar: false, motivo: "nenhuma grafia confirma o nome do provedor" };
    if (ocupado) return { trocar: false, motivo: "outro jogador do mesmo time já tem este nome" };
    return { trocar: true, nome: nome.slice(0, 120), motivo: "nome do provedor" };
  }

  /**
   * Opções da ação "Trocar nome": o nome de cada número de provedor (tabela por provedor e ids das casas) e cada grafia,
   * sem repetir (pela chave) e sem o nome atual. Cada uma diz a origem.
   */
  function opcoesDeNome({ atual, provedores, ids, apelidos } = {}) {
    const vistas = new Set([chaveNome(atual)]), out = [];
    const poe = (nome, origem) => {
      const n = limpa(nome).slice(0, 120), k = chaveNome(n);
      if (!k || vistas.has(k)) return;
      vistas.add(k); out.push({ nome: n, origem });
    };
    for (const p of provedores || []) if (p && p.nome_fonte) poe(nomeLegivel(p.nome_fonte), `${p.provedor} ${p.id_externo}`);
    for (const x of ids || []) if (x && x.raw_name) poe(nomeLegivel(x.raw_name), `${x.source} ${x.external_id}`);
    // grafias: a mais frequente primeiro (19 das 21 do #176228 dizem "jhonny")
    const cont = new Map();
    for (const a of apelidos || []) { const g = limpa(a && a.alias_norm); if (g) cont.set(g, (cont.get(g) || 0) + 1); }
    for (const [g, n] of [...cont.entries()].sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)) poe(capitalizaGrafia(g), `grafia (${n}x)`);
    return out;
  }

  /**
   * Nome escolhido por gente que um automático trocou depois (checagem nome_humano_trocado, faxina 63 repõe). A escolha é a
   * última 'nome_por_gente' do cadastro com depois.por = 'human'. registros: [{ rid, payload }]; cadastros: os com nome_por = 'human'.
   */
  function nomesDeGenteTrocados(registros, cadastros) {
    const ultima = new Map();
    for (const r of registros || []) {
      const p = typeof r.payload === "string" ? JSON.parse(r.payload) : r.payload;
      if (p && p.id) ultima.set(Number(p.id), { rid: r.rid, p });
    }
    const out = [];
    for (const e of cadastros || []) {
      const u = ultima.get(Number(e.id));
      if (!u || !u.p.depois || u.p.depois.por !== "human" || !u.p.depois.nome) continue;
      if (String(e.display_name) !== String(u.p.depois.nome)) out.push({ id: Number(e.id), atual: String(e.display_name), escolhido: String(u.p.depois.nome), rid: u.rid });
    }
    return out;
  }

  const api = { chaveNome, ehAbreviado, nomeLegivel, capitalizaGrafia, caixaSemInformacao, nomeDigitado, decideNomePeloProvedor, opcoesDeNome, nomesDeGenteTrocados, TRANSLIT };
  if (typeof module === "object" && module.exports) module.exports = api;
  else raiz.nomeExibicao = api;
})(typeof window !== "undefined" ? window : globalThis);
