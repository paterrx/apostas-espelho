// =====================================================================
// [18/10] issue #126: O CARIMBO DO "VERIFICAR AGORA" É O DA VERIFICAÇÃO, NÃO O DA FAXINA.
//
// Na Saúde, o único carimbo perto do botão era "Última faxina: … · rodando agora". A faxina é outra coisa (limpeza a cada
// 10 min, ~220 s em 18/10) e o botão não a roda: o auditor clicava, via a hora da faxina parada (16:36:52 depois de dois
// cliques às 16:43) e "rodando agora" por minutos (a faxina seguinte), enquanto as checagens andavam (29/18 → 27/17). O
// carimbo da verificação ("Verificado …") ficava no pé de uma tabela de 125 linhas. A verificação leva ~180 s (soma das
// checagens em 18/10 04:29); pedida no meio de uma, espera ela acabar e roda outra, até ~6 min.
// Aqui fica a linha que vai ao lado do botão: quando foi a última verificação, quanto levou, se há uma rodando (desde quando)
// e se o pedido do operador está na fila. Idade acima de 2 voltas automáticas (15 min cada) sai como atrasada.
// Carregado no index.html e por require nos testes.
// =====================================================================
(function (raiz) {
  const VOLTA_MS = 15 * 60_000;

  const seg = (ms) => Math.max(0, Math.round(Number(ms || 0) / 1000));
  const duracao = (ms) => { const s = seg(ms); return s < 120 ? `${s} s` : `${Math.round(s / 60)} min`; };
  const ms = (x) => (x == null ? null : typeof x === "number" ? x : Date.parse(x));

  /** d = resposta de /api/admin/er/consistencia; fmt(ms) = hora para a tela (fuso de São Paulo). */
  function carimboVerificacao(d, agora, fmt) {
    if (!d) return { texto: "", atrasada: false };
    const partes = [];
    const feito = ms(d.geradoEm);
    let atrasada = false;
    if (feito) {
      partes.push(`Verificado às ${fmt(feito)}` + (d.duracaoMs ? ` (levou ${duracao(d.duracaoMs)})` : ""));
      if (agora - feito > 2 * VOLTA_MS) { atrasada = true; partes.push(`há ${duracao(agora - feito)}: a verificação automática (a cada 15 min) está atrasada`); }
    } else partes.push("Ainda sem verificação desde que o painel subiu");
    if (d.falhaVerificacao && (!feito || ms(d.falhaVerificacao.em) > feito)) { atrasada = true; partes.push(`a última verificação falhou às ${fmt(ms(d.falhaVerificacao.em))}: ${d.falhaVerificacao.erro}`); }
    if (d.calculando) {
      const desde = ms(d.calculandoDesde);
      partes.push("verificando agora" + (desde ? ` desde ${fmt(desde)}` : "") + (d.duracaoMs ? `, leva ~${duracao(d.duracaoMs)}` : ""));
      // [31/10] issue #166: em 30/10 19:19 BRT a tela ficou >15 min só em "Verificando…": agora diz em qual checagem está e há quanto tempo
      const a = d.andamento;
      if (a) {
        partes.push(`${a.feitas || 0}${a.total ? ` de ~${a.total}` : ""} checagens feitas` +
          (a.atual && a.atual.id ? `, agora em ${a.atual.id} há ${duracao(agora - ms(a.atual.desde))}` : ""));
      }
      if (desde && agora - desde > VOLTA_MS) { atrasada = true; partes.push(`passou de ${duracao(VOLTA_MS)}: o banco está lento (a linha saude_calculo_lento mostra as checagens que pesaram quando este terminar)`); }
      if (d.pedidoNaFila) partes.push(`o pedido${ms(d.pedidoEm) ? ` das ${fmt(ms(d.pedidoEm))}` : ""} roda logo depois desta, que começou antes dele`);
    }
    return { texto: partes.join(" · "), atrasada };
  }

  // [20/10] issue #135: o selo do título contava TODA checagem com número (126 = 101 invariantes + 25 de fila e
  // monitoramento: ev_preco_velho, id_provedor_conflito, pinnacle_bic_atrasada…) e o quadro só as invariantes: ⚠️ 21 × "15
  // de 101 invariantes violadas" (medido 20/10 00:58: 21 = 14 invariantes + 7 outras). O selo diz as duas partes.
  /** d = resposta de /api/admin/er/consistencia → { texto, invariantes, outras, erros } para o título da Saúde. */
  function seloSaude(d) {
    if (!d || !d.checks) return { texto: "", invariantes: 0, outras: 0, erros: 0 };
    const inv = new Set([...((d.invariantes && d.invariantes.violadas) || []), ...((d.invariantes && d.invariantes.erros) || [])].map(v => v.id));
    let invariantes = 0, outras = 0, erros = 0;
    for (const c of d.checks) {
      if (!(c.erro || Number(c.n || 0) > 0)) continue;
      if (c.erro) erros++;
      if (inv.has(c.id)) invariantes++; else outras++;
    }
    if (!invariantes && !outras) return { texto: "✓", invariantes, outras, erros };
    const partes = [];
    if (invariantes) partes.push(`${invariantes} ${invariantes === 1 ? "invariante" : "invariantes"}`);
    else partes.push("invariantes em zero");
    if (outras) partes.push(`${outras} ${outras === 1 ? "outra checagem" : "outras checagens"} (fila/monitoramento)`);
    return { texto: (invariantes ? "⚠️ " : "") + partes.join(" + "), invariantes, outras, erros };
  }

  const api = { carimboVerificacao, seloSaude, VOLTA_MS };
  if (typeof module === "object" && module.exports) module.exports = api;
  else raiz.carimboSaude = api;
})(typeof window !== "undefined" ? window : globalThis);
