// =====================================================================
// [13/11] O RÓTULO DA JUSTA P6j — uma regra só para a lista do EV+ (public/index.html) e o quadro "De onde vem a justa" (ev.js, /api/ev/detalhe).
//
// Pedido do Matheus (via principal): em e-sports a coluna da justa dizia "P6j e-sports · 1 bolsa" com Kalshi, predict.fun e Polymarket na lista,
// e ele leu como erro de contagem — o número era de livros DENTRO da conta. Agora o rótulo NOMEIA as bolsas da conta ("P6j e-sports · justa com
// Polymarket"; sem nenhuma, "P6j e-sports · só Pinnacle") e o title explica cada bolsa da aposta que ficou fora, com o motivo vindo da REGRA
// (o registro da conta, justaP6j.registro): `sem` = a bolsa admitida que não deu livro (sem leitura no frescor, um lado só...); `fr` = as bolsas
// da P6j que a regra deixa fora desta seleção (nos e-sports, esports.bolsas; no resto, as fontes da justa); `cand` = as que a regra admite.
// Bolsa fora de cand e de fr não é livro da P6j. Nenhum texto fixo por casa.
// =====================================================================
(function (raiz, fabrica) {
  const m = fabrica();
  if (typeof module === "object" && module.exports) module.exports = m;
  else raiz.P6jRotulo = m;
})(typeof self !== "undefined" ? self : this, function () {
  const MOTIVO_SEM = {
    sem_leitura: frS => `livro sem leitura nos últimos ${frS ? Math.round(frS / 60) + " min" : "minutos do frescor"} (só entra livro no ar)`,
    um_lado_so: () => "o livro tem um lado só",
    sem_os_lados: () => "faltam lados do livro",
    preco_ilegivel: () => "preço do livro ilegível",
  };
  const lista = xs => xs.join(", ").replace(/, ([^,]*)$/, " e $1");
  const nomeP6j = metodo => metodo === "p6j_esports" ? "P6j e-sports" : "P6j";

  /** Os nomes das bolsas que entraram na conta (na ordem do registro). */
  function naConta(reg, nomeDe) {
    const ls = reg && Array.isArray(reg.livros) ? reg.livros : [];
    return [...new Set(ls.map(x => x.b))].map(b => nomeDe(b));
  }
  /** "P6j e-sports · justa com Polymarket" / "P6j · só Pinnacle". */
  function rotulo(metodo, reg, nomeDe) {
    const n = naConta(reg, nomeDe);
    return `${nomeP6j(metodo)} · ${n.length ? "justa com " + lista(n) : "só Pinnacle"}`;
  }
  /**
   * As bolsas que ficaram fora da conta, com o motivo da regra. `fontes` = as fontes da aposta (a casa da linha e as outras com a mesma
   * seleção); sem elas, as que o registro conhece (admitidas que não deram livro e as que a regra deixa fora). [{ b, nome, motivo }]
   * [13/11] `classeDe(fonte)` = a classe da casa no cadastro (Peixe Admin): a fonte que o registro não conhece só entra como "não é livro da
   * P6j" quando é BOLSA (predict.fun, Betfair Exchange...) — a casa comum da aposta (3ET, Stake, Heritage) não é bolsa e não aparece.
   */
  function fora(metodo, reg, fontes, nomeDe, classeDe) {
    if (!reg) return [];
    const usadas = new Set((reg.livros || []).map(x => x.b));
    const cand = Array.isArray(reg.cand) ? reg.cand : null, fr = Array.isArray(reg.fr) ? reg.fr : [];
    const sem = reg.sem && typeof reg.sem === "object" ? reg.sem : {};
    const todas = cand ? [...cand, ...fr] : null;
    const alvo = fontes ? [...new Set(fontes.map(String))] : [...new Set([...(cand || []), ...fr, ...Object.keys(sem)])];
    const out = [];
    for (const b of alvo) {
      if (!b || b === "pinnacle" || b.startsWith("so:") || usadas.has(b)) continue;
      let motivo = null;
      if (sem[b]) motivo = (MOTIVO_SEM[sem[b]] || (() => sem[b]))(reg.frS);
      else if (fr.includes(b)) motivo = metodo === "p6j_esports" ? "fora das bolsas da P6j e-sports (parâmetro esports.bolsas)" : "fora das bolsas da justa deste segmento (fontes da justa)";
      else if (cand && cand.includes(b)) motivo = "o livro não entrou (travas de spread, meio ou distância, ou sem este mercado)";
      else if (todas && typeof classeDe === "function" && classeDe(b) === "BOLSA") motivo = `não é livro da P6j (as bolsas da P6j: ${lista(todas.map(nomeDe))})`;
      if (motivo) out.push({ b, nome: nomeDe(b), motivo });
    }
    return out;
  }
  /** O title da célula: a conta e as que ficaram fora. `pin` = a Pinnacle sem margem já formatada (ou null). */
  function titulo(metodo, reg, fontes, nomeDe, pin, classeDe) {
    const n = naConta(reg, nomeDe), f = fora(metodo, reg, fontes, nomeDe, classeDe);
    const conta = `${nomeP6j(metodo)}: Pinnacle sem margem${pin ? " " + pin : ""}${n.length ? " + " + lista(n) : " (nenhuma bolsa na conta)"}`;
    return f.length ? `${conta}. Fora da conta: ${f.map(x => `${x.nome} — ${x.motivo}`).join("; ")}.` : `${conta}.`;
  }
  return { rotulo, fora, titulo, naConta, MOTIVO_SEM };
});
