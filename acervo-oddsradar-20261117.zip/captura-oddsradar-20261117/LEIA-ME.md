# Acervo Odds Radar — 17/11/2026

Cópia de tudo que o nosso acesso (papel `tipster`) alcança de estruturante no painel,
mais o código e o estado do nosso pipeline que consome esse painel.

Feito para estudo offline. Nada aqui depende do painel estar de pé.

## O que tem

| pasta/arquivo | conteúdo |
|---|---|
| `cru/` | respostas cruas, uma por chamada, com o caminho da API no nome |
| `cru/api_odds-screen_jogo_*` | jogo a jogo: colunas por casa (chave, nome, site, sharp), mercados canônicos (grupo, parte, período, linha, lado) e odds por casa com `ef` (id externo da fonte), `via` e hora da gravação |
| `cru/grade_*` | as grades por esporte, tipo e janela: jogos, linhas, justa, liquidez e URL de aposta |
| `cru/api_props_*` | partidas e busca de jogador do módulo de props |
| `cru/api_casas`, `api_fontes_atraso`, `api_pinnacle_saude` | desenho do sistema: casas com layout e integração, fontes com atraso medido, saúde do canal Pinnacle |
| `cru/compilado_*.js`, `index.html` | o front inteiro, para reextrair vocabulário e regras |
| `textos-do-metodo.md` | textos da interface que descrevem o método (justa P6j, bolsas, taxa, ER, liquidez) |
| `catalogo/` | consolidado legível: `casas.json`, `mercados.json`, `estatisticos.json`, `fontes.json`, `eventos.csv`, `resumo.json` |
| `partidas.json` | catálogo de eventos/ligas do módulo de props (`all=1`) |
| `local/` | cópia do nosso código e estado: `codigo/`, `docs/`, `estado/` |
| `manifesto*.json` | prova: url, hora, bytes e sha256 de cada chamada |
| `cru/stream_45s.txt` | 45 segundos do SSE, se a captura chegou lá |

## O que o acervo prova sobre o método deles

- A justa é a Pinnacle **sem margem**, e depois **puxada pelas bolsas** (Kalshi, Polymarket,
  SX, predict.fun), com ajuste 50/50 que só vale quando deixa a justa mais conservadora;
  bolsa com mínimo de 100 amostras por mercado e fallback para o esporte.
- A taxa de cada casa é lida pelo coletor no ato e descontada da odd; não é cadastrada.
- O casamento tem catálogo próprio: apelido escopado por liga, interseção de elencos para
  achar o time do jogador, nome ambíguo abre revisão em vez de fundir, e uma taxa mede
  quantas vezes o automático errou.
- Liquidez por mercado é registrada por casa que informa (bolsas: valor disponível agora).
- O filtro de EV só libera linha com cobertura de regra classificada e aprovada.
- Stake por ¼ de Kelly, com mínima por casa vinda de grupo de clones e arredondamento.

## Ressalvas

- `estado/painel-cookies.json` contém a sessão viva do painel — trate como segredo.
- A grade entrega o que o painel manda agora; evento encerrado não volta pelo `/jogo/<id>`.
- `cru/api_odds-screen_jogo_*` com `{"error":"jogo não encontrado"}` é id de partida de
  props que não é o mesmo id da odds screen. Guardados como estão, sem limpeza.

## Achados desta rodada que mudam o mapa

- `catalogo/grupos_de_casas.json`: 56 grupos de clones do Peixe Admin, cada um com a casa e
  as fontes que o alimentam, com contagem. É a topologia do casamento deles.
- `catalogo/rotulos_de_estatistica.json`: 315 rótulos de prop (mercado canônico traduzido).
- `catalogo/modelo_de_justa.json`: os três modelos (`legacy`, `comparative`, `semiSharp`),
  com parâmetros de cobertura (`kNominal`, `kEffective`, `kMinimo`, `kFlutuante`) e o motivo
  de recusa (`few_groups`); `exponent` é o devig da linha.
- `catalogo/fontes_por_grupo.json`: Betmonitor sozinho respondeu 130 mil linhas; depois Stake,
  Heritage, 3et, Magic, Cloudbet, Overtime, ProphetX, Novig, og, Kalshi, Polymarket.
- `cru/stream_50s.txt`: formato interno da chave canônica
  (`j|<fonte>|<evento>|<mercado>|<periodo>|<linha>|<lado>`) e o vínculo `pinChave`/`pinIdade_s`
  com a Pinnacle — é o índice que amarra casa, mercado e sharp no mesmo identificador.
