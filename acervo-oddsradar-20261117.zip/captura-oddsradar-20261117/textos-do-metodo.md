# Textos de regra e metodo no front do Odds Radar (17/11/2026)

- Contra: a regra da casa pode piorar este lado — confira antes de apostar
- A favor: a regra da casa só melhora este lado (o EV mostrado é o mínimo)
- Contagem completa das seleções ativas lidas nos últimos 60 minutos, por casa, esporte, mercado e período. Meta: nenhuma combinação sem regra classificada e aprovada.
- Dado inicial: resposta provada na regra escrita da casa (levantamento do FishBot)
- A casa tem uma regra diferente que não cabe nas opções (ex.: 'pode anular', regra por mercado). A pergunta fica pendente para marcação à mão e NÃO liquida como a Pinnacle.
- trecho da regra, entre aspas (o que prova a resposta)
- . Nada foi mudado: confira a regra da casa e corrija a resposta ou a observação.
- A casa não diz: vale a regra escrita da Pinnacle. Para mudar, responda a pergunta nesta casa (ou marque 'regra própria').
- A regra vale quando a odd veio deste mercado da casa
- A justa do motor do EV+ (P6j: Pinnacle sem margem + bolsas, decisão de 30/10) — a MESMA justa da odd comum daquele mercado; a idade é a da leitura que fez a justa
- Idade da justa: quando o motor calculou com os preços da Pinnacle daquele momento. O site ao vivo pode ter se movido desde então — defasagem, não erro de conta.
- Só vale enquanto as regras da conta não forem lidas
- . Clique no certo para vincular. Se dois ou mais cadastros forem a mesma pessoa, marque-os e use
- da liga. Os apelidos de time valem dentro da liga cadastrada: apelido de liga solto ou liga duplicada é o que faz um clube virar dois. O sistema aprende sozinho quando um jogo fecha; aqui você liga o que ficou solto, tira apelido errado e junta liga duplicada.
- ); a grafia é apelido do esporte. Grafia que o cadastro não conhece fica aqui até você ligar ao esporte, marcar como categoria de aposta ou criar o esporte.
- time(s). O crawler preenche a cada 5 minutos pelo rótulo da liga e pelas ligas em que o time joga, e reconfere a área automática das ligas com a regra de hoje.
- jogo(s). Confira os apelidos: os que forem dele, mova aqui embaixo.
- ,String(h.por||'').startsWith('auto')?'regra':h.por||h.kind,
- " (código de 3 letras, ex.: THA, ou o nome). Vazio devolve o país para a regra (ligas e ficha).
- . O nome escolhido aparece em todas as telas (inclusive como candidato no Resolver) e fica como decisão sua: nenhuma regra automática troca. As grafias e os números não mudam.
- ),
modo==='apelido:'+a.alias_norm+'|'+(a.scope_key||'')&&React.createElement(
- )
))
)
)),
raio&&!(raio.apelidos||[]).length&&React.createElement(
- ,React.createElement("br",null)),"Último cálculo de odd justa em lote: ",
fmt(ev.em)," · ",ev.comEv??
- : toda vez que você move um apelido, funde, separa ou desamarra, o automático tinha errado. Se essa taxa sobe, a qualidade caiu; se cai, melhorou.
- ))
))),
!!(lg.semVinculo||[]).length&&React.createElement(React.Fragment,null,
React.createElement(
- . O jogador agora é entidade do registro, com apelido escopado nos dois elencos da partida: nome ambíguo abre revisão em vez de fundir. O time do jogador não vem de nenhuma fonte — sai da interseção das partidas em que ele aparece.
- O mesmo id de time aparece em competições de países diferentes. Como o apelido é único por grafia, o segundo clube nunca ganhou id próprio — foi absorvido pelo primeiro.
- = decisão tomada aqui ou no Resolver, que manda sobre a regra. Trocar ou desfazer vale no próximo ciclo. O nome aparece sem os times: [mandante] e [visitante].
- Tira a sua decisão: volta a valer a regra do código (sem regra, a grafia volta ao Resolver)
- A comparação é pela chave do catálogo: mesmo jogo do registro, mesmo mercado, período, linha e lado. A odd justa tira a margem da Pinnacle pelo mesmo método do Super Odds.
- Odd justa do Super Odds lida pelo catálogo (sombra, desde
- a um mercado nosso, então é jogada fora. Ligar é decisão sua, na guia Resolver: escolha o nosso mercado e vale no próximo ciclo, sem mexer no código. Marque “não interessa” no que for ruído.
- ):null,
podeMexer&&inativo?React.createElement(
- ),
u.papel!=='admin'&&podeMexer?React.createElement(
- ):null,
u.totp_ativo&&podeMexer?React.createElement(
- Não consegui copiar sozinho: selecione a senha com o mouse e copie (Ctrl+C).
- ,null,EV_NOME_BOLSA[x.b]||x.b,x.m2!=null?' (meio corrigido pelo 50/50)':' (meio do livro)',x.calc?' · calculada de '+x.calc:''),React.createElement(
- ,linha.casa,pagL?', com o 50/50':semL?', P6j — 50/50 não aplicado: deixaria a justa menor':'',
- . É a mesma justa da lista e da tabela das casas.
- ) usam a maior entre a P6j e a justa com o 50/50 (o 50/50 só vale quando deixa a justa mais conservadora)
- A justa que entra no EV desta casa: EV = odd ÷ justa − 1
- ¼ Kelly: fração da banca pelo critério de Kelly dividido por 4, contra a justa desta casa
- A Pinnacle sem a margem. Com a P6j, a justa que vale é a de baixo (Pinnacle puxada pelas bolsas)
- bolsa(s) utilizada(s). Bolsa de um lado só: Polymarket pelo spread típico do mercado (semente + vivo, 14 dias); Kalshi pela média de 15 min; mínimo de 100 jogadores; mercado sem 100 usa o esporte inteiro, e sem 100 no esporte a bolsa fica de fora.
- Valor disponível na melhor oferta (bolsas: Kalshi, Polymarket, SX, predict.fun). Casa que não informa o valor continua aparecendo.
- Odd de quem oferece (ordem parada na Limitless, sem taxa): a casa só paga se alguém tomar a ordem. Postar a
- % é BRUTO (sem a taxa) — fora do robô e dos tips até a casa ganhar a fórmula (aí o selo some sozinho)
- : desconto dela ainda não lido — vale a odd da casa com a taxa da casa (
- ). A taxa da casa não entra: o desconto da corretora já é o custo
- Bolsa: valor disponível a esta odd agora (taxa já descontada da odd)
- ,fmtOddF(l.justa,formato)),l.sem5050&&React.createElement(
- Lado em que a regra de liquidação da casa piora a aposta de um jeito que não dá para medir (ex.: reserva que entra vale, vermelho conta 1 cartão no Mais)
- , a mesma conta do EV+. O EV de cada uma é odd ÷ esta justa − 1.
- Taxa da documentação, ainda não lida nem medida — decisão do Matheus, 04/11
- A Pinnacle não tem esta linha: a justa sai exata das duas linhas vizinhas dela (meias), como no EV+.
- A maior odd entre as casas (verde quando passa da justa)
- ),c.nome,c.taxaNaoConferida&&React.createElement(
- )))
)),
!(d.regras||[]).length&&React.createElement(
- ) — o que as regras tiraram nesta volta, com o motivo
- ,null,b.regraNome||nomeRegra(b.regra),React.createElement(
- As regras se somam (SEG-5): todas estas tirariam
- ,pt(a.dBolsa),a.clBolsa?' '+SETA[a.clBolsa]:'',a.metodo&&a.metodo!=='meio'?' ('+a.metodo+')':'',React.createElement(
- — do produto no Peixe Admin; sem produto, OUTRO (não há reserva no código desde 12/11: a casa é achada pelo nome, pela chave ou pelo nome do produto; com o Admin fora na subida vale o último cadastro guardado). Avisos SEG por enquanto só avisam (o robô continua podendo apostar).
- A taxa que o coletor aplicou na odd, lida no ato (o custo não é mais cadastrado no Peixe Admin)
- ,null,c.origem==='admin'?'Peixe Admin':c.origem==='reserva'?'classe de reserva':'sem cadastro'),React.createElement(
- ,null,DE_TAXA[t.de]||t.de),React.createElement(
- ,Number(l.justa_max).toFixed(2))),
React.createElement(
- ))," com pelo menos um livro de bolsa, ",(v.movidas||0).toLocaleString(
- )," com a justa diferente da Pinnacle (maior diferença ",String(v.maiorMudancaPt||0).replace(
- Mercados de jogo e Super Odds: base da justa (P6j)
- A Pinnacle sem margem é a âncora e não sai. Cada bolsa marcada puxa a justa para o meio do livro dela, com o peso da P6j (bolsa, esporte, minutos até o jogo, spread e idade do livro). Desmarcar tira a bolsa da justa.
- Com a P6j: só a Polymarket entra na conta dos e-sports (SPEC 6.1; a Kalshi pesou ~0). Com a P6j desligada: a regra A, a MAIOR justa entre a Pinnacle e cada bolsa marcada.
- Props americanas: fontes calculadas como justa
- O "w" do consenso no EV+: não muda a justa nem regra nenhuma.
- . Marcar uma fonte aqui muda a justa do EV+ (e o que o robô vê) a partir da próxima volta.
- Depende da regra escrita da casa (não cadastrada)
- A bolsa liquidou sem um resultado que dê para ler
- Casa deveria informar liquidez e veio sem leitura
- Fora do horário principal com valor zero (a caixa do Volume proíbe também Super Odd e bolsa)
- A configuração do robô gravada não pôde ser lida: o FishBot está sem reserva para o robô (nenhuma tip espera). Preencha e salve para corrigir.
- A aposta mínima de cada casa vem do grupo de clones do Peixe Admin. Se o valor da tip ficar abaixo da mínima da casa, mas for pelo menos este percentual dela, o valor sobe para a mínima e a tip sai com a observação do arredondamento (o percentual da stake não muda). Abaixo deste percentual, a tip não sai. Casa sem mínima cadastrada: nada muda. Com 0, a função fica desligada.
- O percentual gravado não pôde ser lido: o FishBot está com o arredondamento desligado. Preencha e salve para corrigir.
- Arredondar quando o valor for pelo menos X% da aposta mínima
- O FishBot não leu as casas do bot (clones contam como uma casa):
- A tip saiu por uma casa com clones: o bloqueio da mesma aposta e o teto por hora valem para a família inteira
- , nada estimado. Decisão do Matheus de 03/11 (A, B e C): as regras estão
- (a maior odd justa); conta por diferença só com a
- (até 2 pontos). “Desligar” ou “Sombra” é o interruptor de emergência (volta a justa de antes em até 1 min, sem deploy). Os números abaixo são medidos a cada 5 min (a justa das fontes aqui é a Pinnacle sem margem, power).
- “Já tinham justa”: a linha direta da Pinnacle (mais as que uma regra ligada já cobre). “Diferença da direta”: onde a Pinnacle tem a linha direta, quanto a conta da regra fica longe dela, em pontos percentuais de probabilidade — mostra o ruído de cada caminho. “EV”: odd da casa × probabilidade da regra − 1, só linhas no ar, sem taxa das bolsas.
- ,null,eqPc(x.justaAjustada)))))
))):React.createElement(
- Piso e teto em odd: a justa de “marca ou assiste” não pode ficar abaixo de 1 ÷ (P marca + P assiste) nem acima da menor das duas justas. “Travadas”: a justa do segmento estava fora e foi presa no intervalo (decisão A). “Ainda fora”: justa gravada fora do intervalo — meta zero.
- A Pinnacle não tem esta aposta direta: a justa sai da conta exata de outro mercado que é a mesma aposta.
- &&isSuper&&usuario&&usuario.master&&React.createElement(JustaSegmentoTab,null),
tab===
- Idade da justa (defasagem do ciclo, não erro)
- ,o.justa_motivo?o.justa_motivo:'aguardando cálculo')))),
React.createElement(
- A justa de um mercado avaliando outro que é a mesma aposta — regras novas em sombra até a decisão do Matheus; só o admin master vê
- Regras que tiram EVs da tela EV+ por recorte — só o admin master vê
- Como a odd justa do EV+ é calculada em cada recorte — com modo sombra antes de ativar; só o admin master vê
- Regras de liquidação por casa e mercado — viram alerta em todas as telas
- Todas as casas lado a lado, por jogo e mercado — com a justa da Pinnacle e as props do jogo
- Vincule as casas trazidas pelas fontes ao cadastro do Peixe Admin (uma coluna por casa, nome do cadastro)
- Ligue e desligue cada fonte — casa fora do ar ou economia de proxy, sem mexer em código
- ainda não tem cadastro nesta partida (o coletor não o ligou a ninguém). Escolha quem ele é: as odds dele passam para essa pessoa e o nome vira apelido dela.
- , e o nome fica gravado como apelido dele nesta partida e no clube: as próximas varreduras já chegam ligadas.
- Todos os grupos de clones disponíveis. Mediana superior do método legado aplicado a todas as combinações de K grupos, com o expoente do mercado. K flutua por linha: é a quantidade de grupos com casa do OddsChecker UK que têm cotação nesta seleção, nunca menos de 4.
- Média das duas maiores odds semi-sharp, após descartar no máximo uma maior isolada que supere a segunda já sem juice. Com apenas dois grupos, ambos são sempre mantidos. Depois aplica o expoente do mercado.
- Pinnacle sem margem: as duas pernas (Mais e Menos) da MESMA linha do jogador, com a margem tirada pelo power — a mesma conta dos mercados de jogo. Casa em outra linha fica sem justa.
- Novig sem margem: as duas pernas (Mais e Menos) da MESMA linha do jogador na bolsa, com a margem tirada pelo power. Sem as duas pernas, não vota.
- ProphetX sem margem: as duas pernas (Mais e Menos) da MESMA linha, no preço da bolsa antes da comissão de 2% do lucro, com a margem tirada pelo power. Sem as duas pernas, não vota.
- ;
        const dica = (acima ? kellyTxt(r.best.odds, maiorJusta) :
- Ligado: a coluna Melhor mostra a melhor odd só entre casas de regulamentação federal (apostáveis no Brasil), e o destaque verde vale só para elas — inclusive o de acima da odd justa. Fica salvo para você em qualquer navegador.
- vincular as casas cruas das fontes ao cadastro do Peixe Admin
- Na odd justa comparativa, K é medido em cada linha: quantos grupos com casa do OddsChecker UK têm cotação naquela seleção (mínimo 4). Passe o mouse na célula da comparativa para ver o K da linha.
- Casas sem grupo vinculado ficam fora dos cálculos. Cada grupo conta uma única vez, mesmo no modo de colunas por fonte.
- Na aba Player Props, casas vinculadas à mesma casa do cadastro viram
- ; se a fonte mais recente não tem aquele mercado, entra a seguinte. Fonte que a casa não vinculou aparece com o nome cru, agrupada pela fonte.
- odd justa = odd de referência elevada ao expoente
- ; no
  // vencedor do basquete nenhum efeito a cobria e a tela mostrava "Sem classificação". Regra única, para todas as telas:
  //   - observação COM efeitos vale só no mercado que algum efeito cobre (
- (apelido do López do Palmeiras,
// #29342) e é o José Ángel López do Espanyol: API-Football 585288
- na ficha de Identidades: o nome de cada número de provedor, cada grafia ou texto livre. Grava
//     er_entity.nome_por = 'human', com antes e depois no er_report e Desfazer. Nome de gente nunca é trocado por regra;
//   - regra automática (faxina 63): jogador com número Sportradar e sem nome de gente fica com o nome do provedor quando
//     o atual difere — nunca por um nome abreviado (
- (ev.js, /api/ev/detalhe).
//
// Pedido do Matheus (via principal): em e-sports a coluna da justa dizia
- com Kalshi, predict.fun e Polymarket na lista,
// e ele leu como erro de contagem — o número era de livros DENTRO da conta. Agora o rótulo NOMEIA as bolsas da conta (
- fora das bolsas da P6j e-sports (parâmetro esports.bolsas)
- fora das bolsas da justa deste segmento (fontes da justa)
