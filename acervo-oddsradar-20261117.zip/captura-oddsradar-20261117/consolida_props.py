import glob, json, os
from collections import defaultdict

AQUI = os.path.dirname(os.path.abspath(__file__))
CRU = os.path.join(AQUI, "cru")
SAIDA = os.path.join(AQUI, "catalogo")
os.makedirs(SAIDA, exist_ok=True)

labels, jogadores, grupos = {}, {}, {}
modelos = {"tipos": None, "exemplo": None}
contagem_fonte = defaultdict(int)

for arq in sorted(os.listdir(CRU)):
    if not arq.startswith("api_odds-screen_jogo_"):
        continue
    try:
        d = json.load(open(os.path.join(CRU, arq), encoding="utf8"))
    except Exception:
        continue
    p = d.get("props") if isinstance(d, dict) else None
    if not p:
        continue
    labels.update(p.get("marketLabels") or {})
    jogadores[str(p.get("match_id"))] = sorted({
        (r.get("player"), r.get("playerKey"))
        for m in p.get("markets") or [] for r in m.get("rows") or [] if r.get("player")})
    for b in p.get("books") or []:
        grupos[b.get("key")] = {"grupo": b.get("group"), "casa": b.get("casa"), "book": b.get("book"),
                                "br": b.get("br"),
                                "fontes": {s.get("source"): s.get("n") for s in (b.get("sources") or [])}}
        for s in b.get("sources") or []:
            contagem_fonte[s.get("source")] += s.get("n") or 0
    if not modelos["tipos"] and p.get("fairOdds"):
        modelos["tipos"] = p["fairOdds"]
        for m in p.get("markets") or []:
            for r in m.get("rows") or []:
                if r.get("fair"):
                    modelos["exemplo"] = {"mercado": m.get("market"), "linha": r.get("line"),
                                           "lado": r.get("side"), "fair": r["fair"]}
                    break
            if modelos["exemplo"]:
                break


def grava(nome, obj):
    with open(os.path.join(SAIDA, nome), "w", encoding="utf8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


grava("rotulos_de_estatistica.json", labels)
grava("jogadores_por_partida.json", jogadores)
grava("grupos_de_casas.json", grupos)
grava("modelo_de_justa.json", modelos)
grava("fontes_por_grupo.json", dict(contagem_fonte))
print(json.dumps({"rotulos": len(labels), "partidas_com_jogadores": len(jogadores),
                  "grupos": len(grupos), "fontes": dict(contagem_fonte),
                  "tipos_de_justa": (modelos["tipos"] or {}).get("tipos")}, ensure_ascii=False, indent=1))
