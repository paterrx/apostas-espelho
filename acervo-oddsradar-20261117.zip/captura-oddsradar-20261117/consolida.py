"""Consolida o acervo cru em tabelas de casamento legíveis.

Saída: casas, mercados, estatísticos, eventos, fontes, pares de apelido
observáveis, contagens. Nada de rede: só lê o cru.
"""
import glob, json, os, re
from collections import Counter, defaultdict

AQUI = os.path.dirname(os.path.abspath(__file__))
CRU = os.path.join(AQUI, "cru")
SAIDA = os.path.join(AQUI, "catalogo")
os.makedirs(SAIDA, exist_ok=True)

casas = {}
mercados = {}
estatisticos = {}
jogadores = {}
ids_fonte = {}
fontes = Counter()
vias = Counter()
eventos = {}
apelidos = defaultdict(set)
erros = Counter()
linhas = 0

for arq in sorted(os.listdir(CRU)):
    p = os.path.join(CRU, arq)
    if arq.startswith("api_casas"):
        try:
            for c in json.load(open(p, encoding="utf8")):
                casas[c["key"]] = {k: c.get(k) for k in ("key", "nome", "url", "layout", "br", "sharp")}
        except Exception:
            pass
    if not arq.startswith("api_odds-screen_jogo_"):
        continue
    try:
        d = json.load(open(p, encoding="utf8"))
    except Exception:
        continue
    if d.get("error"):
        erros[d["error"]] += 1
        continue
    j = d.get("jogo") or {}
    ev = j.get("evento")
    if ev:
        eventos[str(ev)] = j
    for c in d.get("colunas") or []:
        if c.get("key"):
            casas.setdefault(c["key"], {"key": c["key"], "nome": c.get("nome"), "url": c.get("site"),
                                         "layout": None, "br": None, "sharp": c.get("sharp")})
    if j.get("jogador"):
        jogadores.setdefault(str(ev), set()).add(j["jogador"])
    for m in d.get("mercados") or []:
        linhas += 1
        chave = m.get("mercado") or ""
        mercados.setdefault(chave, {"mercado": chave, "grupo": m.get("grupo"), "parte": m.get("parte"),
                                    "periodo": m.get("periodo"), "n": 0})
        mercados[chave]["n"] += 1
        if m.get("participante"):
            estatisticos.setdefault(m["participante"], set()).add(m.get("titulo"))
        if j.get("jogador"):
            estatisticos.setdefault(j["jogador"], set()).add(m.get("grupo") or "")
        for lado in m.get("lados") or []:
            for casa, o in (lado.get("odds") or {}).items():
                fontes[casa] += 1
                if isinstance(o, dict):
                    if o.get("ef"):
                        ids_fonte.setdefault(casa, set()).add(str(o["ef"]))
                    if o.get("via"):
                        vias[o["via"]] += 1
                    if o.get("rotulo"):
                        apelidos[casa].add(str(o["rotulo"]))


def escreve(nome, obj, campo=None):
    p = os.path.join(SAIDA, nome)
    if campo:
        with open(p, "w", encoding="utf8", newline="") as f:
            f.write(campo + "\n")
            for k, v in obj:
                f.write(("%s" % k).replace("\t", " ") + "\n")
        return
    with open(p, "w", encoding="utf8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


escreve("casas.json", casas)
escreve("mercados.json", mercados)
escreve("jogadores.json", {k: sorted(v) for k, v in jogadores.items()})
escreve("ids_externos_por_casa.json", {k: sorted(v)[:500] for k, v in ids_fonte.items()})
escreve("estatisticos.json", {k: sorted(v) for k, v in estatisticos.items()})
escreve("fontes.json", {"contagem_por_casa": dict(fontes), "via": dict(vias), "apelido_por_casa": {k: sorted(v) for k, v in apelidos.items()}})
with open(os.path.join(SAIDA, "eventos.csv"), "w", encoding="utf8", newline="") as f:
    f.write("evento\tcasa\tfora\tliga\tesporte\tkickoff\n")
    for ev, j in eventos.items():
        f.write("\t".join(str(x or "").replace("\t", " ") for x in
                          (ev, j.get("casa"), j.get("fora"), j.get("liga"), j.get("esporte"), j.get("kickoff"))) + "\n")

resumo = {"eventos": len(eventos), "casas": len(casas), "mercados": len(mercados),
          "estatisticos": len(estatisticos), "jogadores": sum(len(v) for v in jogadores.values()), "linhas_de_mercado": linhas,
          "chamadas_com_erro": dict(erros), "fontes_vistas": dict(fontes), "via": dict(vias)}
escreve("resumo.json", resumo)
print(json.dumps(resumo, ensure_ascii=False, indent=1)[:2000])
